﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net
{
    [Flags]
    public enum ReaderStatus
    {
        /// <summary>
        /// 状态正常
        /// </summary>
        None = 0,
        /// <summary>
        /// 低电量报警
        /// </summary>
        LowPoer = 1,
        /// <summary>
        /// 上一次执行命令时，由于驱动访问异常导致命令执行失败
        /// </summary>
        DriverError = 4,
        /// <summary>
        /// 上一次执行命令时，由于射频异常导致命令执行失败
        /// </summary>
        RfError = 8,
        /// <summary>
        /// 当前PSAM处于异常状态
        /// </summary>
        PsamError = 16,
        /// <summary>
        /// 上一次执行命令时，写FLASH失败
        /// </summary>
        FlashError = 32,
        /// <summary>
        /// 当前阅读器有异常
        /// </summary>
        HasError = 128
    }
}
