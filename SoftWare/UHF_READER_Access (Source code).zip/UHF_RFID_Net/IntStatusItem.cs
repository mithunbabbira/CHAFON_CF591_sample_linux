﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net
{
    [StructLayout(LayoutKind.Sequential)]
    public struct IntStatusItem
    {
        public static readonly IntStatusItem[] EmptyArray = new IntStatusItem[0];

        byte m_status;
        uint m_time;

        public byte Status
        {
            get { return m_status; }
            set { m_status = value; }
        }

        public uint Time
        {
            get { return m_time; }
            set { m_time = value; }
        }
    }
}
