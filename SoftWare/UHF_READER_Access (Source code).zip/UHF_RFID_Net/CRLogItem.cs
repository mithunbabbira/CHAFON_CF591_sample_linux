﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net
{
    [StructLayout(LayoutKind.Sequential)]
    public struct CRLogItem
    {
        public static readonly CRLogItem[] EmptyArray = new CRLogItem[0];

        ushort m_addr;
        byte m_value;
        uint m_time;

        public ushort RegAddr
        {
            get { return m_addr; }
            set { m_addr = value; }
        }

        public byte RegValue
        {
            get { return m_value; }
            set { m_value = value; }
        }

        public uint Time
        {
            get { return m_time; }
            set { m_time = value; }
        }
    }
}
