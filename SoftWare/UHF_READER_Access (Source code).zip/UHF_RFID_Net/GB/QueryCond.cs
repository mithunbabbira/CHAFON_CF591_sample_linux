﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.GB
{
    public enum QueryCond
    {
        All,
        SL1,
        SL0,
        RFU
    }

    public class QueryCondItem
    {
        public static readonly QueryCondItem[] Options = new QueryCondItem[] {
            new QueryCondItem(QueryCond.All),
            new QueryCondItem(QueryCond.SL1),
            new QueryCondItem(QueryCond.SL0),
            new QueryCondItem(QueryCond.RFU) };

        QueryCond m_value;

        public QueryCond Value
        {
            get { return m_value; }
        }

        public QueryCondItem(QueryCond value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return QueryCondToString(m_value);
        }

        public static string QueryCondToString(QueryCond value)
        {
            switch (value)
            {
                case QueryCond.All:
                    return "所有标签";
                case QueryCond.SL1:
                    return "匹配标志为1";
                case QueryCond.SL0:
                    return "匹配标志为0";
                case QueryCond.RFU:
                    return "11:系统保留";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
