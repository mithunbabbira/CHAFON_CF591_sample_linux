﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.GB
{
    public enum LinkBLF
    {
        F_64KHz,
        F_137_14KHz,
        F_174_55KHz,
        F_320KHz,
        F_128KHz,
        F_274_29KHz,
        F_349_09KHz,
        F_640KHz
    }

    public class LinkBLFItem
    {
        public static readonly LinkBLFItem[] Options = new LinkBLFItem[] {
            new LinkBLFItem(LinkBLF.F_64KHz),
            new LinkBLFItem(LinkBLF.F_137_14KHz),
            new LinkBLFItem(LinkBLF.F_174_55KHz),
            new LinkBLFItem(LinkBLF.F_320KHz),
            new LinkBLFItem(LinkBLF.F_128KHz),
            new LinkBLFItem(LinkBLF.F_274_29KHz),
            new LinkBLFItem(LinkBLF.F_349_09KHz),
            new LinkBLFItem(LinkBLF.F_640KHz) };

        LinkBLF m_value;

        public LinkBLF Value
        {
            get { return m_value; }
        }

        public LinkBLFItem(LinkBLF value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return LinkBLFToString(m_value);
        }

        public static string LinkBLFToString(LinkBLF value)
        {
            switch (value)
            {
                case LinkBLF.F_64KHz:
                    return "64 Khz";
                case LinkBLF.F_137_14KHz:
                    return "137.14 Khz";
                case LinkBLF.F_174_55KHz:
                    return "174.55 Khz";
                case LinkBLF.F_320KHz:
                    return "320 Khz";
                case LinkBLF.F_128KHz:
                    return "128 Khz";
                case LinkBLF.F_274_29KHz:
                    return "274 Khz";
                case LinkBLF.F_349_09KHz:
                    return "349 Khz";
                case LinkBLF.F_640KHz:
                    return "640 Khz";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }

        public static LinkBLFItem OptionFromValue(LinkBLF blf)
        {
            foreach (LinkBLFItem item in Options)
            {
                if (item.Value == blf)
                    return item;
            }
            return null;
        }
    }
}
