﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.GB
{
    public enum LinkTRext
    {
        NoTRext,
        HasTRext
    }

    public class LinkTRextItem
    {
        public static readonly LinkTRextItem[] Options = new LinkTRextItem[] {
            new LinkTRextItem(LinkTRext.NoTRext),
            new LinkTRextItem(LinkTRext.HasTRext) };

        LinkTRext m_value;

        public LinkTRext Value
        {
            get { return m_value; }
        }

        public LinkTRextItem(LinkTRext value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return LinkTRextToString(m_value);
        }

        public static string LinkTRextToString(LinkTRext value)
        {
            switch (value)
            {
                case LinkTRext.NoTRext:
                    return "无前导信号";
                case LinkTRext.HasTRext:
                    return "有前导信号";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }

        public static LinkTRextItem OptionFromValue(LinkTRext trext)
        {
            foreach (LinkTRextItem item in Options)
            {
                if (item.Value == trext)
                    return item;
            }
            return null;
        }
    }
}
