﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.GB
{
    public enum SortAction
    {
        Math1_NoMath0,
        MathNothing_NoMath0,
        Math1_NoNothing,
        Math0_NoMath1
    }

    public class SortRuleItem
    {
        public static readonly SortRuleItem[] Options = new SortRuleItem[] {
            new SortRuleItem(SortAction.Math1_NoMath0),
            new SortRuleItem(SortAction.MathNothing_NoMath0),
            new SortRuleItem(SortAction.Math1_NoNothing),
            new SortRuleItem(SortAction.Math0_NoMath1) };

        SortAction m_value;

        public SortAction Value
        {
            get { return m_value; }
        }

        public SortRuleItem(SortAction value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return SortRuleToString(m_value);
        }

        public static string SortRuleToString(SortAction value)
        {
            switch (value)
            {
                case SortAction.Math1_NoMath0:
                    return "匹配置1, 不匹配置0";
                case SortAction.MathNothing_NoMath0:
                    return "不匹配置0";
                case SortAction.Math1_NoNothing:
                    return "匹配置1";
                case SortAction.Math0_NoMath1:
                    return "匹配置0, 不匹配置1";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
