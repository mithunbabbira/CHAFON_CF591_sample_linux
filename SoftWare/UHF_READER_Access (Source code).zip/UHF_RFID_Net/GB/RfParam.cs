﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net.GB
{
    /// <summary>
    /// 国标GB/T 29768射频参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct RfParam
    {
        /// <summary>
        /// 前向链路的基准时间
        /// </summary>
        private byte m_tc;

        /// <summary>
        ///反向链路频率：
        ///0000b：K=1/5
        ///0001b：K=3/7
        ///0010b：K=6/11
        ///0011b：K=1
        ///0100b：K=2/5
        ///0101b：K=6/7
        ///0110b ：K=12/11
        ///0111b：K=2
        ///1000b~1111b：保留
        /// </summary>
        private byte m_blf;

        /// <summary>
        /// 反向链路编码方式：
        /// 1:miller2
        /// 2:miller4
        /// 3:miller8
        /// </summary>
        private byte m_miller;

        /// <summary>
        /// 反向链路前导码是否使用长前导信号：
        /// 0：TRext=0b
        /// 1：TRext=1b
        /// </summary>
        private byte m_trext;

        private byte m_modu;


        /// <summary>
        /// 前向链路的基准时间
        /// </summary>
        public LinkTc TC
        {
            get { return (LinkTc)m_tc; }
            set { m_tc = (byte)value; }
        }

        /// <summary>
        ///反向链路频率：
        ///0000b：K=1/5
        ///0001b：K=3/7
        ///0010b：K=6/11
        ///0011b：K=1
        ///0100b：K=2/5
        ///0101b：K=6/7
        ///0110b ：K=12/11
        ///0111b：K=2
        ///1000b~1111b：保留
        /// </summary>
        public LinkBLF BLF
        {
            get { return (LinkBLF)m_blf; }
            set { m_blf = (byte)value; }
        }

        /// <summary>
        /// 反向链路编码方式：
        /// 1:miller2
        /// 2:miller4
        /// 3:miller8
        /// </summary>
        public LinkM Miller
        {
            get { return (LinkM)m_miller; }
            set { m_miller = (byte)value; }
        }

        /// <summary>
        /// 反向链路前导码是否使用长前导信号：
        /// 0：TRext=0b
        /// 1：TRext=1b
        /// </summary>
        public LinkTRext Trext
        {
            get { return (LinkTRext)m_trext; }
            set { m_trext = (byte)value; }
        }

        /// <summary>
        /// 前向链路调制方式
        /// </summary>
        public LinkModu Modu
        {
            get { return (LinkModu)m_modu; }
            set { m_modu = (byte)value; }
        }
    }
}
