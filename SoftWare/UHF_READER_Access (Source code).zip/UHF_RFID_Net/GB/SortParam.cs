﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net.GB
{
    /// <summary>
    /// Sort参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct SortParam
    {
        /// <summary>
        /// 0:S0
        /// 1:S1
        /// 2:S2
        /// 3:S3
        /// 4:匹配标志
        /// </summary>
        private byte m_target;
        /// <summary>
        /// 0:匹配的标签将标志设置为1b，不匹配的标签将标志设置为0b
        /// 1:匹配的标签其标志保持不变，不匹配的标签将标志设置为0b；
        /// 2:匹配的标签将标志设置为1b，不匹配的标签其标志保持不变；
        /// 3:匹配的标签将标志设置为0b，不匹配的标签将标志设置为1b；
        /// </summary>
        private byte m_action;
        /// <summary>
        /// 0x00:标签信息区
        /// 0x10:编码区；
        /// 0x30:用户区0；
        /// 0x31:用户区1
        /// 0x32:用户区2
        /// 0x33:用户区3
        /// </summary>
        private byte m_memBank;
        private ushort m_maskPtr;
        private byte m_maskLen;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 255)]
        private byte[] m_maskData;


        /// <summary>
        /// 0:S0
        /// 1:S1
        /// 2:S2
        /// 3:S3
        /// 4:匹配标志
        /// </summary>
        public SortTarget Target
        {
            get { return (SortTarget)m_target; }
            set { m_target = (byte)value; }
        }

        /// <summary>
        /// 0:匹配的标签将标志设置为1b，不匹配的标签将标志设置为0b
        /// 1:匹配的标签其标志保持不变，不匹配的标签将标志设置为0b；
        /// 2:匹配的标签将标志设置为1b，不匹配的标签其标志保持不变；
        /// 3:匹配的标签将标志设置为0b，不匹配的标签将标志设置为1b；
        /// </summary>
        public SortAction Action
        {
            get { return (SortAction)m_action; }
            set { m_target = (byte)value; }
        }

        /// <summary>
        /// 0x00:标签信息区
        /// 0x10:编码区；
        /// 0x30:用户区0；
        /// 0x31:用户区1
        /// 0x32:用户区2
        /// 0x33:用户区3
        /// </summary>
        public MemBank MemBank
        {
            get { return (MemBank)m_memBank; }
            set { m_memBank = (byte)value; }
        }

        public ushort MaskPtr
        {
            get { return m_maskPtr; }
            set { m_maskPtr = value; }
        }

        public byte MaskLen
        {
            get { return m_maskLen; }
            set { m_maskLen = value; }
        }

        public byte[] MaskData
        {
            get { return m_maskData; }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");
                m_maskData = value;
            }
        }
    }
}
