﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.GB
{
    public enum LinkTc
    {
        T_6_25,
        T_12_5
    }

    public class LinkTcItem
    {
        public static readonly LinkTcItem[] Options = new LinkTcItem[] {
            new LinkTcItem(LinkTc.T_6_25),
            new LinkTcItem(LinkTc.T_12_5) };

        LinkTc m_value;

        public LinkTc Value
        {
            get { return m_value; }
        }

        public LinkTcItem(LinkTc value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return LinkTcToString(m_value);
        }

        public static string LinkTcToString(LinkTc value)
        {
            switch (value)
            {
                case LinkTc.T_6_25:
                    return "6.25 us";
                case LinkTc.T_12_5:
                    return "12.5 us";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }

        public static LinkTcItem OptionFromValue(LinkTc tc)
        {
            foreach (LinkTcItem item in Options)
            {
                if (item.Value == tc)
                    return item;
            }
            return null;
        }
    }
}
