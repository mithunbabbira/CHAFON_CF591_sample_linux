﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.GB
{
    public enum SortTarget
    {
        S0,
        S1,
        S2,
        S3,
        SL,
        RFU1,
        RFU2,
        RFU3
    }

    public class SortTargetItem
    {
        public static readonly SortTargetItem[] Options = new SortTargetItem[] {
            new SortTargetItem(SortTarget.S0),
            new SortTargetItem(SortTarget.S1),
            new SortTargetItem(SortTarget.S2),
            new SortTargetItem(SortTarget.S3),
            new SortTargetItem(SortTarget.SL) };

        SortTarget m_value;

        public SortTarget Value
        {
            get { return m_value; }
        }

        public SortTargetItem(SortTarget value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return SortTargetToString(m_value);
        }

        public static string SortTargetToString(SortTarget value)
        {
            switch (value)
            {
                case SortTarget.S0:
                    return "S0";
                case SortTarget.S1:
                    return "S1";
                case SortTarget.S2:
                    return "S2";
                case SortTarget.S3:
                    return "S3";
                case SortTarget.SL:
                    return "Sl";
                case SortTarget.RFU1:
                    return "101:RFU";
                case SortTarget.RFU2:
                    return "110:RFU";
                case SortTarget.RFU3:
                    return "111:RFU";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
