﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.GB
{
    public enum LockCfg
    {
        Membank,
        SecurityMode
    }
}
