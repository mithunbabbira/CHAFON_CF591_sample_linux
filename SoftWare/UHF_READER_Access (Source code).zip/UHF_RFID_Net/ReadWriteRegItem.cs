﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net
{
    [StructLayout(LayoutKind.Sequential)]
    public struct ReadWriteRegItem
    {
        byte m_option;
        ushort m_addr;
        ushort m_value;
        ushort m_interval;

        public bool IsWriteReg
        {
            get { return (m_option & 1) != 0; }
            set { m_option |= (byte)(value ? 1 : 0); }
        }

        public ushort Addr
        {
            get { return m_addr; }
            set { m_addr = value; }
        }

        public ushort Value
        {
            get { return m_value; }
            set { m_value = value; }
        }

        public ushort Interval
        {
            get { return m_interval; }
            set { m_interval = value; }
        }

        public ReadWriteRegItem(byte option, ushort addr, ushort value, ushort interval)
        {
            m_option = option;
            m_addr = addr;
            m_value = value;
            m_interval = option;
        }
    }
}
