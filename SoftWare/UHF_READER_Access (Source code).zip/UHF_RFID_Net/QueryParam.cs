﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net
{
    /// <summary>
    /// Query参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct QueryParam
    {
        /// <summary>
        /// ISO参数如下：
        ///00b：ALL
        ///01b：ALL
        ///10b：~SL
        ///11b：SL
        ///
        /// GB/GJB参数如下：
        ///00b：所有标签参与此次盘点
        ///01b：匹配标志是1b的标签参与此次盘点
        ///10b：匹配标志是0b的标签参与此次盘点
        ///11b：保留
        /// </summary>
        private byte m_sel;

        /// <summary>
        /// 0:S0
        /// 1:S1
        /// 2:S2
        /// 3:S3
        /// </summary>
        private byte m_session;

        /// <summary>
        /// ISO参数如下：
        /// 0:A
        /// 1:B
        /// 
        /// GB/GJB参数如下：
        /// 0:目标0b
        /// 1:目标1b
        /// </summary>
        private byte m_target;

        /// <summary>
        /// ISO参数如下：
        ///00b：ALL
        ///01b：ALL
        ///10b：~SL
        ///11b：SL
        ///
        /// GB/GJB参数如下：
        ///00b：所有标签参与此次盘点
        ///01b：匹配标志是1b的标签参与此次盘点
        ///10b：匹配标志是0b的标签参与此次盘点
        ///11b：保留
        /// </summary>
        public byte Sel
        {
            get { return m_sel; }
            set { m_sel = value; }
        }

        /// <summary>
        /// 会话，盘点循环所在的会话号
        /// 0:S0
        /// 1:S1
        /// 2:S2
        /// 3:S3
        /// </summary>
        public byte Session
        {
            get { return m_session; }
            set { m_session = value; }
        }

        /// <summary>
        /// ISO参数如下：
        /// 0:A
        /// 1:B
        /// 
        /// GB/GJB参数如下：
        /// 0:目标0b
        /// 1:目标1b
        /// </summary>
        public byte Target
        {
            get { return m_target; }
            set { m_target = value; }
        }
    }
}
