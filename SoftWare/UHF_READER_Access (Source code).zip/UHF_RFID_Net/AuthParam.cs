﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace HD17R01URNet
{
    /// <summary>
    /// 认证参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct AuthParam
    {
        /// <summary>
        /// 安全PSAM模块密钥文件索引
        /// </summary>
        private byte m_kid;
        /// <summary>
        /// 0:不分散
        /// 1:分散因子为TID；
        /// 2:分散因子为FAC部分数据；
        /// </summary>
        private byte m_tkf;

        /// <summary>
        /// 分散因子，只有当TKF=0x02时，该参数数据有效
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        private byte[] m_fac;

        /// <summary>
        /// 安全PSAM模块密钥文件索引
        /// </summary>
        public byte KID
        {
            get { return m_kid; }
            set { m_kid = value; }
        }

        /// <summary>
        /// 0:不分散
        /// 1:分散因子为TID；
        /// 2:分散因子为FAC部分数据；
        /// </summary>
        public AuthKeyHash TKF
        {
            get { return (AuthKeyHash)m_tkf; }
            set { m_tkf = (byte)value; }
        }

        /// <summary>
        /// 分散因子，只有当TKF=0x02时，该参数数据有效
        /// </summary>
        public byte[] FAC
        {
            get { return m_fac; }
            set { m_fac = value; }
        }
    }
}
