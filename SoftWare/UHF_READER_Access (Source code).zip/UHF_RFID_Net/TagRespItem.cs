﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net
{
    public class TagRespItem
    {
        private static readonly byte[] s_arrEmpty = new byte[0];

        /// <summary>
        /// 标签状态
        /// </summary>
        private byte m_tagStatus;
        /// <summary>
        /// 标签的PC或编码长度+编码头数据
        /// </summary>
        private byte[] m_pc;
        /// <summary>
        /// 标签的UII或编码数据
        /// </summary>
        private byte[] m_code;
        /// <summary>
        /// 天线索引
        /// </summary>
        private byte m_ant;
        /// <summary>
        /// CRC
        /// </summary>
        private byte[] m_crc;

        /// <summary>
        /// 标签状态
        /// </summary>
        public byte TagStatus
        {
            get { return m_tagStatus; }
        }

        /// <summary>
        /// 标签的PC或编码长度+编码头数据
        /// </summary>
        public byte[] PC
        {
            get { return m_pc; }
        }

        /// <summary>
        /// 标签的UII或编码数据
        /// </summary>
        public byte[] Code
        {
            get { return m_code; }
        }

        /// <summary>
        /// 天线接口序号
        /// </summary>
        public byte Antenna
        {
            get { return m_ant; }
        }

        /// <summary>
        /// CRC
        /// </summary>
        public byte[] CRC
        {
            get { return m_crc; }
        }

        public TagRespItem(byte tagStatus, byte[] pc, byte codeLen, byte[] code, byte ant, byte[] crc)
        {
            if (pc == null)
                throw new ArgumentNullException("pc");
            if (pc.Length != 2)
                throw new ArgumentException("pc长度必须是两字节");
            if (codeLen > 0 && code == null)
                throw new ArgumentNullException("code");
            if (codeLen > code.Length)
                throw new ArgumentOutOfRangeException("codeLen", "编码长度值超出实际编码长度");

            m_tagStatus = tagStatus;
            m_pc = pc;
            m_ant = ant;
            m_crc = crc;
            if (codeLen > 0)
            {
                m_code = new byte[codeLen];
                Array.Copy(code, m_code, codeLen);
            }
            else
                m_code = s_arrEmpty;
        }

        internal TagRespItem(UHF_RFID_API.TagResp info)
        {
            if (info.PC == null)
                throw new ArgumentNullException("pc");
            if (info.PC.Length != 2)
                throw new ArgumentException("pc长度必须是两字节");
            byte codeLen = info.CodeLength;
            if (codeLen > 0 && info.Code == null)
                throw new ArgumentNullException("code");
            if (codeLen > info.Code.Length)
                throw new ArgumentOutOfRangeException("codeLen", "编码长度值超出实际编码长度");

            m_tagStatus = info.TagStatus;
            m_pc = info.PC;
            m_ant = info.Antenna;
            m_crc = info.CRC;
            if (codeLen > 0)
            {
                m_code = new byte[codeLen];
                Array.Copy(info.Code, m_code, codeLen);
            }
            else
                m_code = s_arrEmpty;
        }
    }
}
