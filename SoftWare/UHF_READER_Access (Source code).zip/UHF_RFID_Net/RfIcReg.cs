﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net
{
    /// <summary>
    /// 射频寄存器项
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct RfIcReg
    {
        public static readonly RfIcReg[] EmptyArray = new RfIcReg[0];

        /// <summary>
        /// 寄存器地址
        /// </summary>
        ushort m_addr;

        /// <summary>
        /// 寄存器值
        /// </summary>
        byte m_val;

        /// <summary>
        /// 寄存器地址
        /// </summary>
        public ushort Addr
        {
            get { return m_addr; }
            set { m_addr = value; }
        }

        /// <summary>
        /// 寄存器值
        /// </summary>
        public byte Value
        {
            get { return m_val; }
            set { m_val = value; }
        }

        public RfIcReg(ushort addr, byte value)
        {
            this.m_addr = addr;
            this.m_val = value;
        }
    }
}
