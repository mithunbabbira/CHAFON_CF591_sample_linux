﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net
{
    /// <summary>
    /// Sort参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct SelectSortParam
    {
        /// <summary>
        /// 只针对ISO协议有效
        ///000b：S0
        ///001b：S1
        ///010b：S2
        ///011b：S3
        ///100b：SL
        /// </summary>
        private byte m_target;
        /// <summary>
        /// 只针对ISO协议有效
        ///00b：不截断
        ///01b：截断
        /// </summary>
        private byte m_trucate;

        private byte m_action;

        private byte m_membank;

        private ushort m_ptr;

        private byte m_len;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 31)]
        private byte[] m_mask;

        /// <summary>
        ///000b：S0
        ///001b：S1
        ///010b：S2
        ///011b：S3
        ///100b：SL
        /// </summary>
        public byte Target
        {
            get { return m_target; }
            set { m_target = value; }
        }

        /// <summary>
        /// false：不截断
        /// true：截断
        /// </summary>
        public bool Trucate
        {
            get { return m_trucate != 0; }
            set { m_trucate = (byte)(value ? 1 : 0); }
        }

        public byte Action
        {
            get { return m_action; }
            set { m_action = value; }
        }

        public byte MemBank
        {
            get { return m_membank; }
            set { m_membank = value; }
        }

        public ushort MaskPtr
        {
            get { return m_ptr; }
            set { m_ptr = value; }
        }

        public byte MaskLen
        {
            get { return m_len; }
            set { m_len = value; }
        }

        public byte[] MaskData
        {
            get { return m_mask; }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");
                if (m_mask == null)
                    m_mask = new byte[31];
                Array.Copy(value, m_mask, value.Length < 31 ? value.Length : 31);
            }
        }
    }
}
