﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net
{
    public enum LinkModu
    {
        DSB_ASK,
        SSB_ASK,
        PR_ASK
    }

    public class LinkModuItem
    {
        public static readonly LinkModuItem[] Options = new LinkModuItem[] {
            new LinkModuItem(LinkModu.DSB_ASK),
            new LinkModuItem(LinkModu.SSB_ASK),
            new LinkModuItem(LinkModu.PR_ASK) };

        public static readonly LinkModuItem[] GbOptions = new LinkModuItem[] {
            Options[0],
            Options[1] };

        LinkModu m_value;

        public LinkModu Value
        {
            get { return m_value; }
        }

        public LinkModuItem(LinkModu value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return LinkModuToString(m_value);
        }

        public static string LinkModuToString(LinkModu value)
        {
            switch (value)
            {
                case LinkModu.DSB_ASK:
                    return "DSB-ASK";
                case LinkModu.SSB_ASK:
                    return "SSB-ASK";
                case LinkModu.PR_ASK:
                    return "PR-ASK";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }

        public static LinkModuItem OptionFromValue(LinkModu modu)
        {
            foreach (LinkModuItem item in Options)
            {
                if (item.Value == modu)
                    return item;
            }
            return null;
        }
    }
}
