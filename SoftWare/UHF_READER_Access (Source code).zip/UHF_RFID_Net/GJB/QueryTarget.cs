﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.GJB
{
    public enum QueryTarget
    {
        Q0,
        Q1
    }

    public class QueryTargetItem
    {
        public static readonly QueryTargetItem[] Options = new QueryTargetItem[] {
            new QueryTargetItem(QueryTarget.Q0),
            new QueryTargetItem(QueryTarget.Q1) };

        QueryTarget m_value;

        public QueryTargetItem(QueryTarget value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return QueryTargetToString(m_value);
        }

        public static string QueryTargetToString(QueryTarget value)
        {
            switch (value)
            {
                case QueryTarget.Q0:
                    return "0";
                case QueryTarget.Q1:
                    return "1";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
