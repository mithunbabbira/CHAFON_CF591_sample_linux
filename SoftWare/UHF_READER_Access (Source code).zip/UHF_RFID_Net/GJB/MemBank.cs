﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.GJB
{
    public enum MemBank : byte
    {
        Info = 0x00,
        Code = 0x10,
        Security = 0x20,
        User0 = 0x30,
        User1 = 0x31,
        User2 = 0x32,
        User3 = 0x33,
        User4 = 0x34,
        User5 = 0x35,
        User6 = 0x36,
        User7 = 0x37,
        User8 = 0x38,
        User9 = 0x39,
        User10 = 0x3A,
        User11 = 0x3B
    }

    public class MemBankItem
    {
        public static readonly MemBankItem[] Options = new MemBankItem[] {
            new MemBankItem(MemBank.Info),
            new MemBankItem(MemBank.Code),
            new MemBankItem(MemBank.Security),
            new MemBankItem(MemBank.User0),
            new MemBankItem(MemBank.User1),
            new MemBankItem(MemBank.User2),
            new MemBankItem(MemBank.User3),
            new MemBankItem(MemBank.User4),
            new MemBankItem(MemBank.User5),
            new MemBankItem(MemBank.User6),
            new MemBankItem(MemBank.User7),
            new MemBankItem(MemBank.User8),
            new MemBankItem(MemBank.User9),
            new MemBankItem(MemBank.User10),
            new MemBankItem(MemBank.User11) };

        MemBank m_value;

        public MemBank Value
        {
            get { return m_value; }
        }

        public MemBankItem(MemBank value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return MemBankToString(m_value);
        }

        public static string MemBankToString(MemBank value)
        {
            switch (value)
            {
                case MemBank.Info:
                    return "信息区";
                case MemBank.Code:
                    return "编码区";
                case MemBank.Security:
                    return "安全区";
                case MemBank.User0:
                    return "用户区0";
                case MemBank.User1:
                    return "用户区1";
                case MemBank.User2:
                    return "用户区2";
                case MemBank.User3:
                    return "用户区3";
                case MemBank.User4:
                    return "用户区4";
                case MemBank.User5:
                    return "用户区5";
                case MemBank.User6:
                    return "用户区6";
                case MemBank.User7:
                    return "用户区7";
                case MemBank.User8:
                    return "用户区8";
                case MemBank.User9:
                    return "用户区9";
                case MemBank.User10:
                    return "用户区10";
                case MemBank.User11:
                    return "用户区11";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
