﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZRM100_Net.GJB
{
    public enum SortRule
    {
        Math1_NoMath0,
        MathNothing_NoMath0,
        Math1_NoNothing,
        Math0_NoMath1
    }

    public class SortRuleItem
    {
        public static readonly SortRuleItem[] Options = new SortRuleItem[] {
            new SortRuleItem(SortRule.Math1_NoMath0),
            new SortRuleItem(SortRule.MathNothing_NoMath0),
            new SortRuleItem(SortRule.Math1_NoNothing),
            new SortRuleItem(SortRule.Math0_NoMath1) };

        SortRule m_value;

        public SortRuleItem(SortRule value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return SortRuleToString(m_value);
        }

        public static string SortRuleToString(SortRule value)
        {
            switch (value)
            {
                case SortRule.Math1_NoMath0:
                    return "匹配置1,不匹配置0";
                case SortRule.MathNothing_NoMath0:
                    return "不匹配置0";
                case SortRule.Math1_NoNothing:
                    return "匹配置1";
                case SortRule.Math0_NoMath1:
                    return "匹配置0,不匹配置1";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
