﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.GJB
{
    public enum LinkM
    {
        FM0,
        Miller2,
        Miller4,
        Miller8
    }

    public class LinkMItem
    {
        public static readonly LinkMItem[] Options = new LinkMItem[] {
            new LinkMItem(LinkM.FM0),
            new LinkMItem(LinkM.Miller2),
            new LinkMItem(LinkM.Miller4),
            new LinkMItem(LinkM.Miller8) };

        LinkM m_value;

        public LinkM Value
        {
            get { return m_value; }
        }

        public LinkMItem(LinkM value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return LinkMToString(m_value);
        }

        public static string LinkMToString(LinkM value)
        {
            switch (value)
            {
                case LinkM.FM0:
                    return "FM0";
                case LinkM.Miller2:
                    return "Miller2";
                case LinkM.Miller4:
                    return "Miller4";
                case LinkM.Miller8:
                    return "Miller8";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }

        public static LinkMItem OptionFromValue(LinkM m)
        {
            foreach (LinkMItem item in Options)
            {
                if (item.Value == m)
                    return item;
            }
            return null;
        }
    }
}
