﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.GJB
{
    public enum LockCfg
    {
        Membank,
        SecurityMode
    }
}
