﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.GJB
{
    public enum LinkBLF
    {
        F_80KHz,
        F_160KHz,
        F_320KHz,
        F_640KHz
    }

    public class LinkBLFItem
    {
        public static readonly LinkBLFItem[] Options = new LinkBLFItem[] {
            new LinkBLFItem(LinkBLF.F_80KHz),
            new LinkBLFItem(LinkBLF.F_160KHz),
            new LinkBLFItem(LinkBLF.F_320KHz),
            new LinkBLFItem(LinkBLF.F_640KHz) };

        public static readonly LinkBLFItem[] Options1 = new LinkBLFItem[] {
            Options[0],
            Options[1],
            Options[2] };

        public static readonly LinkBLFItem[] Options2 = new LinkBLFItem[] {
            Options[1],
            Options[2],
            Options[3] };

        LinkBLF m_value;

        public LinkBLF Value
        {
            get { return m_value; }
        }

        public LinkBLFItem(LinkBLF value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return LinkBLFToString(m_value);
        }

        public static string LinkBLFToString(LinkBLF value)
        {
            switch (value)
            {
                case LinkBLF.F_80KHz:
                    return "80 Khz";
                case LinkBLF.F_160KHz:
                    return "160 Khz";
                case LinkBLF.F_320KHz:
                    return "320 Khz";
                case LinkBLF.F_640KHz:
                    return "640 Khz";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }

        public static LinkBLFItem OptionFromValue(LinkBLF blf)
        {
            foreach (LinkBLFItem item in Options)
            {
                if (item.Value == blf)
                    return item;
            }
            return null;
        }
    }
}
