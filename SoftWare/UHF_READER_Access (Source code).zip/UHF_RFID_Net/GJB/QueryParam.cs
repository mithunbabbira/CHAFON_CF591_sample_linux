﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net.GJB
{
    /// <summary>
    /// Query参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct QueryParam
    {
        /// <summary>
        ///00b：所有标签参与此次盘点
        ///01b：匹配标志是1b的标签参与此次盘点
        ///10b：匹配标志是0b的标签参与此次盘点
        ///11b：保留
        /// </summary>
        private byte m_condition;

        /// <summary>
        /// 0:S0
        /// 1:S1
        /// 2:S2
        /// 3:S3
        /// </summary>
        private byte m_session;

        /// <summary>
        /// 0:目标0b
        /// 1:目标1b
        /// </summary>
        private byte m_target;

        /// <summary>
        ///00b：所有标签参与此次盘点
        ///01b：匹配标志是1b的标签参与此次盘点
        ///10b：匹配标志是0b的标签参与此次盘点
        ///11b：保留
        /// </summary>
        public QueryCond Condition
        {
            get { return (QueryCond)m_condition; }
            set { m_condition = (byte)value; }
        }

        /// <summary>
        /// 会话，盘点循环所在的会话号
        /// </summary>
        public QuerySession Session
        {
            get { return (QuerySession)m_session; }
            set { m_session = (byte)value; }
        }

        /// <summary>
        /// 0x00：盘点标志为0b；0x01：盘点标志为1b
        /// </summary>
        public QueryTarget Target
        {
            get { return (QueryTarget)m_target; }
            set { m_target = (byte)value; }
        }

    }
}
