﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net.ISO
{
    /// <summary>
    /// 国标ISO18000-6C锁定命令参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct PermalockParam
    {
        /// <summary>
        ///00b：Read
        ///01b：Lock
        /// </summary>
        byte m_readlock;

        /// <summary>
        /// 0:RFU
        /// 1:EPC
        /// 2:TID
        /// 3:USER
        /// </summary>
        byte m_membank;

        ushort m_blockPtr;

        byte m_blockRange;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 247)]
        byte[] m_mask;

        /// <summary>
        /// true: Read;
        /// false: Permalock
        /// </summary>
        public bool IsPermalock
        {
            get { return m_readlock != 0; }
            set { m_readlock = (byte)(value ? 1 : 0); }
        }

        public MemBank MemBank
        {
            get { return (MemBank)m_membank; }
            set { m_membank = (byte)value; }
        }

        public ushort BlockPtr
        {
            get { return m_blockPtr; }
            set { m_blockPtr = value; }
        }

        public byte BlockRange
        {
            get { return m_blockRange; }
            set { m_blockRange = value; }
        }

        public byte[] MaskData
        {
            get { return m_mask; }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");
                m_mask = value;
            }
        }
    }
}
