﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.ISO
{
    public enum LinkTari
    {
        T_6_25,
        T_12_5,
        T_25
    }

    public class LinkTariItem
    {
        public static readonly LinkTariItem[] Options = new LinkTariItem[] {
            new LinkTariItem(LinkTari.T_6_25),
            new LinkTariItem(LinkTari.T_12_5) };

        LinkTari m_value;

        public LinkTari Value
        {
            get { return m_value; }
        }

        public LinkTariItem(LinkTari value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return LinkTariToString(m_value);
        }

        public static string LinkTariToString(LinkTari value)
        {
            switch (value)
            {
                case LinkTari.T_6_25:
                    return "6.25 us";
                case LinkTari.T_12_5:
                    return "12.5 us";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }

        public static LinkTariItem OptionFromValue(LinkTari tc)
        {
            foreach (LinkTariItem item in Options)
            {
                if (item.Value == tc)
                    return item;
            }
            return null;
        }
    }
}
