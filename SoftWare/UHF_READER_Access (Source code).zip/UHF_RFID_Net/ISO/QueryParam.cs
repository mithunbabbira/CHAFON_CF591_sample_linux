﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net.ISO
{
    /// <summary>
    /// Query参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct QueryParam
    {
        /// <summary>
        ///00b：ALL
        ///01b：ALL
        ///10b：~SL
        ///11b：SL
        /// </summary>
        private byte m_sel;

        /// <summary>
        /// 0:S0
        /// 1:S1
        /// 2:S2
        /// 3:S3
        /// </summary>
        private byte m_session;

        /// <summary>
        /// 0:A
        /// 1:B
        /// </summary>
        private byte m_target;

        /// <summary>
        ///00b：ALL
        ///01b：ALL
        ///10b：~SL
        ///11b：SL
        /// </summary>
        public QuerySel Sel
        {
            get { return (QuerySel)m_sel; }
            set { m_sel = (byte)value; }
        }

        /// <summary>
        /// 0:S0
        /// 1:S1
        /// 2:S2
        /// 3:S3
        /// </summary>
        public QuerySession Session
        {
            get { return (QuerySession)m_session; }
            set { m_session = (byte)value; }
        }

        /// <summary>
        /// 0:A
        /// 1:B
        /// </summary>
        public QueryTarget Target
        {
            get { return (QueryTarget)m_target; }
            set { m_target = (byte)value; }
        }
    }
}
