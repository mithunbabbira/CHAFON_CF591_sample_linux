﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.ISO
{
    public enum LinkDR
    {
        DR_8,
        DR_64_3
    }

    public class LinkDRItem
    {
        public static readonly LinkDRItem[] Options = new LinkDRItem[] {
            new LinkDRItem(LinkDR.DR_8),
            new LinkDRItem(LinkDR.DR_64_3) };

        LinkDR m_value;

        public LinkDR Value
        {
            get { return m_value; }
        }

        public LinkDRItem(LinkDR value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return LinkDRToString(m_value);
        }

        public static string LinkDRToString(LinkDR value)
        {
            switch (value)
            {
                case LinkDR.DR_8:
                    return "8";
                case LinkDR.DR_64_3:
                    return "64/3";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }

        public static LinkDRItem OptionFromValue(LinkDR m)
        {
            foreach (LinkDRItem item in Options)
            {
                if (item.Value == m)
                    return item;
            }
            return null;
        }
    }
}
