﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.ISO
{
    public enum LinkMode
    {
        /// <summary>
        /// 0: RTcal=2.5*Tari, Modulation=DSB, DR=8, Tari=6.25, TRcal=32.0=2.048 RTcal, BLF=250
        /// </summary>
        Mode0,
        /// <summary>
        /// 1: RTcal=2.5Tari, Modulation=DSB, DR=8, Tari=6.25, TRcal=25.0=1.6 RTcal, BLF=320
        /// </summary>
        Mode1,
        /// <summary>
        /// 2: RTcal=2.5Tari, Modulation=DSB, DR=64/3, Tari=6.25, TRcal=33.3=2.1312 RTcal, BLF=640
        /// </summary>
        Mode2,
        /// <summary>
        /// 3: RTcal=2.5Tari, Modulation=DSB, DR=8, Tari=12.5, TRcal=50.0=1.6 RTcal, BLF=160
        /// </summary>
        Mode3,
        /// <summary>
        /// 4: RTcal=2.5*Tari, Modulation=DSB, DR=64/3, Tari=12.5, TRcal=85.3=2.7296 RTcal, BLF=250
        /// </summary>
        Mode4,
        /// <summary>
        /// 5: RTcal=2.5Tari, Modulation=DSB, DR=64/3, Tari=12.5, TRcal=66.7=2.1344 RTcal, BLF=320
        /// </summary>
        Mode5,
        /// <summary>
        /// 6: RTcal=2.5Tari, Modulation=DSB, DR=8, Tari=25, TRcal=125.0=2 RTcal, BLF=64
        /// </summary>
        Mode6,
        /// <summary>
        /// 7: RTcal=2.5Tari, Modulation=DSB, DR=64/3, Tari=25, TRcal=133.3=2.1328 RTcal, BLF=160
        /// </summary>
        Mode7,
        /// <summary>
        /// 8: RTcal=2.5*Tari, Modulation=DSB, DR=64/3, Tari=25, TRcal=85.3=1.3648 RTcal, BLF=250
        /// </summary>
        Mode8,
        /// <summary>
        /// 9: RTcal=2.5*Tari, Modulation=SSB, DR=8, Tari=6.25, TRcal=32.0=2.048 RTcal, BLF=250
        /// </summary>
        Mode9,
        /// <summary>
        /// 10: RTcal=2.5Tari, Modulation=SSB, DR=8, Tari=6.25, TRcal=25.0=1.6 RTcal, BLF=320
        /// </summary>
        Mode10,
        /// <summary>
        /// 11: RTcal=2.5Tari, Modulation=SSB, DR=64/3, Tari=6.25, TRcal=33.3=2.1312 RTcal, BLF=640
        /// </summary>
        Mode11,
        /// <summary>
        /// 12: RTcal=2.5Tari, Modulation=SSB, DR=8, Tari=12.5, TRcal=50.0=1.6 RTcal, BLF=160
        /// </summary>
        Mode12,
        /// <summary>
        /// 13: RTcal=2.5*Tari, Modulation=SSB, DR=64/3, Tari=12.5, TRcal=85.3=2.7296 RTcal, BLF=250
        /// </summary>
        Mode13,
        /// <summary>
        /// 14: RTcal=2.5Tari, Modulation=SSB, DR=64/3, Tari=12.5, TRcal=66.7=2.1344 RTcal, BLF=320
        /// </summary>
        Mode14,
        /// <summary>
        /// 15: RTcal=2.5Tari, Modulation=SSB, DR=8, Tari=25, TRcal=125.0=2 RTcal, BLF=64
        /// </summary>
        Mode15,
        /// <summary>
        /// 16: RTcal=2.5Tari, Modulation=SSB, DR=64/3, Tari=25, TRcal=133.3=2.1328 RTcal, BLF=160
        /// </summary>
        Mode16,
        /// <summary>
        /// 17: RTcal=2.5Tari, Modulation=SSB, DR=64/3, Tari=25, TRcal=85.3=1.3648 RTcal, BLF=250
        /// </summary>
        Mode17,
        /// <summary>
        /// 18: RTcal=2.5Tari, Modulation=PR, DR=8, Tari=12.5, TRcal=50.0=1.6 RTcal, BLF=160
        /// </summary>
        Mode18,
        /// <summary>
        /// 19: RTcal=2.5Tari, Modulation=PR, DR=8, Tari=25, TRcal=125.0=2 RTcal, BLF=64
        /// </summary>
        Mode19,
        /// <summary>
        /// 20: RTcal=2.5Tari, Modulation=PR, DR=64/3, Tari=25, TRcal=85.3=1.3648 RTcal, BLF=250
        /// </summary>
        Mode20
    }

    public class LinkModeItem
    {
        public static readonly LinkModeItem[] Options = new LinkModeItem[] {
            new LinkModeItem(LinkMode.Mode0, LinkModu.DSB_ASK, 6.25f, 2.5f, 2.048f, LinkDR.DR_8, 250),
            new LinkModeItem(LinkMode.Mode1, LinkModu.DSB_ASK, 6.25f, 2.5f, 1.6f, LinkDR.DR_8, 320),
            new LinkModeItem(LinkMode.Mode2, LinkModu.DSB_ASK, 6.25f, 2.5f, 2.1312f, LinkDR.DR_64_3, 640),
            new LinkModeItem(LinkMode.Mode3, LinkModu.DSB_ASK, 12.5f, 2.5f, 1.6f, LinkDR.DR_8, 160),
            new LinkModeItem(LinkMode.Mode4, LinkModu.DSB_ASK, 12.5f, 2.5f, 2.7296f, LinkDR.DR_64_3, 250),
            new LinkModeItem(LinkMode.Mode5, LinkModu.DSB_ASK, 12.5f, 2.5f, 2.1344f, LinkDR.DR_64_3, 320),
            new LinkModeItem(LinkMode.Mode6, LinkModu.DSB_ASK, 25f, 2.5f, 2f, LinkDR.DR_8, 64),
            new LinkModeItem(LinkMode.Mode7, LinkModu.DSB_ASK, 25f, 2.5f, 2.1328f, LinkDR.DR_64_3, 160),
            new LinkModeItem(LinkMode.Mode8, LinkModu.DSB_ASK, 25f, 2.5f, 1.3648f, LinkDR.DR_64_3, 250),
            new LinkModeItem(LinkMode.Mode9, LinkModu.SSB_ASK, 6.25f, 2.5f, 2.048f, LinkDR.DR_8, 250),
            new LinkModeItem(LinkMode.Mode10, LinkModu.SSB_ASK, 6.25f, 2.5f, 1.6f, LinkDR.DR_8, 320),
            new LinkModeItem(LinkMode.Mode11, LinkModu.SSB_ASK, 6.25f, 2.5f, 2.1312f, LinkDR.DR_64_3, 640),
            new LinkModeItem(LinkMode.Mode12, LinkModu.SSB_ASK, 12.5f, 2.5f, 1.6f, LinkDR.DR_8, 160),
            new LinkModeItem(LinkMode.Mode13, LinkModu.SSB_ASK, 12.5f, 2.5f, 2.7296f, LinkDR.DR_64_3, 250),
            new LinkModeItem(LinkMode.Mode14, LinkModu.SSB_ASK, 12.5f, 2.5f, 2.1344f, LinkDR.DR_64_3, 320),
            new LinkModeItem(LinkMode.Mode15, LinkModu.SSB_ASK, 25f, 2.5f, 2f, LinkDR.DR_8, 64),
            new LinkModeItem(LinkMode.Mode16, LinkModu.SSB_ASK, 25f, 2.5f, 2.1328f, LinkDR.DR_64_3, 160),
            new LinkModeItem(LinkMode.Mode17, LinkModu.SSB_ASK, 25f, 2.5f, 1.3648f, LinkDR.DR_64_3, 250),
            new LinkModeItem(LinkMode.Mode18, LinkModu.PR_ASK, 12.5f, 2.5f, 1.6f, LinkDR.DR_8, 160),
            new LinkModeItem(LinkMode.Mode19, LinkModu.PR_ASK, 25f, 2.5f, 2f, LinkDR.DR_8, 64),
            new LinkModeItem(LinkMode.Mode20, LinkModu.PR_ASK, 25f, 2.5f, 1.3648f, LinkDR.DR_64_3, 250) };

        public static readonly LinkModeItem[] OptionsStandard = new LinkModeItem[] {
            new LinkModeItem(LinkMode.Mode1, LinkModu.DSB_ASK, 6.25f, 2.5f, 1.6f, LinkDR.DR_8, 320),
            new LinkModeItem(LinkMode.Mode2, LinkModu.DSB_ASK, 6.25f, 2.5f, 2.1312f, LinkDR.DR_64_3, 640),
            new LinkModeItem(LinkMode.Mode3, LinkModu.DSB_ASK, 12.5f, 2.5f, 1.6f, LinkDR.DR_8, 160),
            new LinkModeItem(LinkMode.Mode4, LinkModu.DSB_ASK, 12.5f, 2.5f, 2.7296f, LinkDR.DR_64_3, 250) };

        LinkMode m_value;
        LinkModu m_modu;
        float m_fTari;
        float m_fRTcal;
        float m_fTRcal;
        LinkDR m_dr;
        int m_blf;

        public LinkMode Value
        {
            get { return m_value; }
        }

        public LinkModu Modu
        {
            get { return m_modu; }
        }

        public float Tari
        {
            get { return m_fTari; }
        }

        public float RTcal
        {
            get { return m_fRTcal; }
        }

        public float TRcal
        {
            get { return m_fTRcal; }
        }

        public LinkDR DR
        {
            get { return (LinkDR)m_dr; }
        }

        public int BLF
        {
            get { return m_blf; }
        }

        public LinkModeItem(LinkMode value, LinkModu modu, float tari, float rtcal, float trcal, LinkDR dr, int blf)
        {
            m_value = value;
            m_modu = modu;
            m_fTari = tari;
            m_fRTcal = rtcal;
            m_fTRcal = trcal;
            m_dr = dr;
            m_blf = blf;
        }

        public override string ToString()
        {
            return LinkModeToString(m_value);
        }

        public static string LinkModeToString(LinkMode value)
        {
            switch (value)
            {
                case LinkMode.Mode0:
                    return "模式0";
                case LinkMode.Mode1:
                    return "模式1";
                case LinkMode.Mode2:
                    return "模式2";
                case LinkMode.Mode3:
                    return "模式3";
                case LinkMode.Mode4:
                    return "模式4";
                case LinkMode.Mode5:
                    return "模式5";
                case LinkMode.Mode6:
                    return "模式6";
                case LinkMode.Mode7:
                    return "模式7";
                case LinkMode.Mode8:
                    return "模式8";
                case LinkMode.Mode9:
                    return "模式9";
                case LinkMode.Mode10:
                    return "模式10";
                case LinkMode.Mode11:
                    return "模式11";
                case LinkMode.Mode12:
                    return "模式12";
                case LinkMode.Mode13:
                    return "模式13";
                case LinkMode.Mode14:
                    return "模式14";
                case LinkMode.Mode15:
                    return "模式15";
                case LinkMode.Mode16:
                    return "模式16";
                case LinkMode.Mode17:
                    return "模式17";
                case LinkMode.Mode18:
                    return "模式18";
                case LinkMode.Mode19:
                    return "模式19";
                case LinkMode.Mode20:
                    return "模式20";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }

        public static LinkModeItem OptionFromValue(LinkMode m)
        {
            foreach (LinkModeItem item in Options)
            {
                if (item.Value == m)
                    return item;
            }
            return null;
        }

        public static LinkModeItem OptionFromRfParam(RfParam param, bool bStandard)
        {
            LinkModeItem[] items = bStandard ? OptionsStandard : Options;
            foreach (LinkModeItem item in items)
            {
                if (item.m_modu == param.Modu &&
                    item.m_dr == param.DR &&
                    Math.Abs(item.m_fTari - param.Tari) < 0.1f &&
                    Math.Abs(item.m_fRTcal - param.RTcal) < 0.1f &&
                    Math.Abs(item.m_fTRcal - param.TRcal) < 0.1f)
                    return item;
            }
            return null;
        }
    }
}
