﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.ISO
{
    public enum SelectTarget
    {
        S0,
        S1,
        S2,
        S3,
        SL,
        RFU1,
        RFU2,
        RFU3
    }

    public class SelectTargetItem
    {
        public static readonly SelectTargetItem[] Options = new SelectTargetItem[] {
            new SelectTargetItem(SelectTarget.S0),
            new SelectTargetItem(SelectTarget.S1),
            new SelectTargetItem(SelectTarget.S2),
            new SelectTargetItem(SelectTarget.S3),
            new SelectTargetItem(SelectTarget.SL) };

        SelectTarget m_value;

        public SelectTarget Value
        {
            get { return m_value; }
        }

        public SelectTargetItem(SelectTarget value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return SelectTargetToString(m_value);
        }

        public static string SelectTargetToString(SelectTarget value)
        {
            switch (value)
            {
                case SelectTarget.S0:
                    return "S0";
                case SelectTarget.S1:
                    return "S1";
                case SelectTarget.S2:
                    return "S2";
                case SelectTarget.S3:
                    return "S3";
                case SelectTarget.SL:
                    return "SL";
                case SelectTarget.RFU1:
                    return "101:RFU";
                case SelectTarget.RFU2:
                    return "110:RFU";
                case SelectTarget.RFU3:
                    return "111:RFU";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
