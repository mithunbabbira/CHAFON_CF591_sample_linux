﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.ISO
{
    public enum QueryTarget
    {
        A,
        B
    }

    public class QueryTargetItem
    {
        public static readonly QueryTargetItem[] Options = new QueryTargetItem[] {
            new QueryTargetItem(QueryTarget.A),
            new QueryTargetItem(QueryTarget.B) };

        QueryTarget m_value;

        public QueryTarget Value
        {
            get { return m_value; }
        }

        public QueryTargetItem(QueryTarget value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return QueryTargetToString(m_value);
        }

        public static string QueryTargetToString(QueryTarget value)
        {
            switch (value)
            {
                case QueryTarget.A:
                    return "A";
                case QueryTarget.B:
                    return "B";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
