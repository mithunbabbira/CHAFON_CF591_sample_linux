﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.ISO
{
    public enum QuerySel
    {
        All0,
        All1,
        Not_SL,
        SL,
    }

    public class QuerySelItem
    {
        public static readonly QuerySelItem[] Options = new QuerySelItem[] {
            new QuerySelItem(QuerySel.All0),
            new QuerySelItem(QuerySel.All1),
            new QuerySelItem(QuerySel.Not_SL),
            new QuerySelItem(QuerySel.SL) };

        QuerySel m_value;

        public QuerySel Value
        {
            get { return m_value; }
        }

        public QuerySelItem(QuerySel value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return QuerySelToString(m_value);
        }

        public static string QuerySelToString(QuerySel value)
        {
            switch (value)
            {
                case QuerySel.All0:
                    return "00:ALL";
                case QuerySel.All1:
                    return "01:ALL";
                case QuerySel.Not_SL:
                    return "~SL";
                case QuerySel.SL:
                    return "SL";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
