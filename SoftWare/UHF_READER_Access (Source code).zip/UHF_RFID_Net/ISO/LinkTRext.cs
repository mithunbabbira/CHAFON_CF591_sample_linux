﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.ISO
{
    public enum LinkTRext
    {
        NoTRext,
        HasTRext
    }

    public class LinkTRextItem
    {
        public static readonly LinkTRextItem[] Options = new LinkTRextItem[] {
            new LinkTRextItem(LinkTRext.NoTRext),
            new LinkTRextItem(LinkTRext.HasTRext) };

        LinkTRext m_value;

        public LinkTRext Value
        {
            get { return m_value; }
        }

        public LinkTRextItem(LinkTRext value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return LinkTRextToString(m_value);
        }

        public static string LinkTRextToString(LinkTRext value)
        {
            switch (value)
            {
                case LinkTRext.NoTRext:
                    return "No pilot tone";
                case LinkTRext.HasTRext:
                    return "Use pilot tone";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }

        public static LinkTRextItem OptionFromValue(LinkTRext m)
        {
            foreach (LinkTRextItem item in Options)
            {
                if (item.Value == m)
                    return item;
            }
            return null;
        }
    }
}
