﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net.ISO
{
    /// <summary>
    /// 国标ISO18000-6C射频参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct RfParam
    {
        float m_tari;

        float m_rtcal;

        float m_trcal;

        byte m_dr;

        byte m_miller;

        byte m_trext;

        byte m_modu;

        public float Tari
        {
            get { return m_tari; }
            set { m_tari = value; }
        }

        public float RTcal
        {
            get { return m_rtcal; }
            set { m_rtcal = value; }
        }

        public float TRcal
        {
            get { return m_trcal; }
            set { m_trcal = value; }
        }

        public LinkDR DR
        {
            get { return (LinkDR)m_dr; }
            set { m_dr = (byte)value; }
        }

        /// <summary>
        /// 反向链路编码方式：
        /// 1:miller2
        /// 2:miller4
        /// 3:miller8
        /// </summary>
        public LinkM Miller
        {
            get { return (LinkM)m_miller; }
            set { m_miller = (byte)value; }
        }

        /// <summary>
        /// 反向链路前导码是否使用长前导信号：
        /// 0：TRext=0b
        /// 1：TRext=1b
        /// </summary>
        public LinkTRext Trext
        {
            get { return (LinkTRext)m_trext; }
            set { m_trext = (byte)value; }
        }

        /// <summary>
        /// 前向链路调制方式
        /// </summary>
        public LinkModu Modu
        {
            get { return (LinkModu)m_modu; }
            set { m_modu = (byte)value; }
        }
    }
}
