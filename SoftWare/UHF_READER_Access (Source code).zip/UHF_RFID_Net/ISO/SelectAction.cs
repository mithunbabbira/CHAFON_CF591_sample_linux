﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.ISO
{
    public enum SelectAction
    {
        MAssert_NoMDeassert,
        MAssert_NoMNothing,
        MNothing_NoMDeassert,
        MNegate_NoMNothing,
        MDeassert_NoMAssert,
        MDeassert_NoMNothing,
        MNothing_NoMAssert,
        MNothing_NoMNegate
    }

    public class SelectActionItem
    {
        public static readonly SelectActionItem[] Options = new SelectActionItem[] {
            new SelectActionItem(SelectAction.MAssert_NoMDeassert),
            new SelectActionItem(SelectAction.MAssert_NoMNothing),
            new SelectActionItem(SelectAction.MNothing_NoMDeassert),
            new SelectActionItem(SelectAction.MNegate_NoMNothing),
            new SelectActionItem(SelectAction.MDeassert_NoMAssert),
            new SelectActionItem(SelectAction.MDeassert_NoMNothing),
            new SelectActionItem(SelectAction.MNothing_NoMAssert),
            new SelectActionItem(SelectAction.MNothing_NoMNegate) };

        SelectAction m_value;

        public SelectAction Value
        {
            get { return m_value; }
        }

        public SelectActionItem(SelectAction value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return SelectActionToString(m_value);
        }

        public static string SelectActionToString(SelectAction value)
        {
            switch (value)
            {
                case SelectAction.MAssert_NoMDeassert:
                    return "match set SL or A, else ~SL or B";
                case SelectAction.MAssert_NoMNothing:
                    return "match set SL or A";
                case SelectAction.MNothing_NoMDeassert:
                    return "not-match set ~SL or B";
                case SelectAction.MNegate_NoMNothing:
                    return "match negate SL or (A->B, B->A)";
                case SelectAction.MDeassert_NoMAssert:
                    return "match set ~SL or B, else SL or A";
                case SelectAction.MDeassert_NoMNothing:
                    return "match set ~SL or B";
                case SelectAction.MNothing_NoMAssert:
                    return "not-match set SL or A";
                case SelectAction.MNothing_NoMNegate:
                    return "not-match negate SL or (A->B, B->A)";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
