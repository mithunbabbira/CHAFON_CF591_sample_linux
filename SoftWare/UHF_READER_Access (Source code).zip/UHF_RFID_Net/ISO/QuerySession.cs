﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.ISO
{
    public enum QuerySession
    {
        S0,
        S1,
        S2,
        S3,
    }

    public class QuerySessionItem
    {
        public static readonly QuerySessionItem[] Options = new QuerySessionItem[] {
            new QuerySessionItem(QuerySession.S0),
            new QuerySessionItem(QuerySession.S1),
            new QuerySessionItem(QuerySession.S2),
            new QuerySessionItem(QuerySession.S3) };

        QuerySession m_value;

        public QuerySession Value
        {
            get { return m_value; }
        }

        public QuerySessionItem(QuerySession value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return QuerySessionToString(m_value);
        }

        public static string QuerySessionToString(QuerySession value)
        {
            switch (value)
            {
                case QuerySession.S0:
                    return "S0";
                case QuerySession.S1:
                    return "S1";
                case QuerySession.S2:
                    return "S2";
                case QuerySession.S3:
                    return "S3";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
