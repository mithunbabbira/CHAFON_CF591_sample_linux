﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.ISO
{
    public enum SelectTruncate
    {
        Disable,
        Enable
    }

    public class SelectTruncateItem
    {
        public static readonly SelectTruncateItem[] Options = new SelectTruncateItem[] {
            new SelectTruncateItem(SelectTruncate.Disable),
            new SelectTruncateItem(SelectTruncate.Enable) };

        SelectTruncate m_value;

        public SelectTruncate Value
        {
            get { return m_value; }
        }

        public SelectTruncateItem(SelectTruncate value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return SelectTruncateToString(m_value);
        }

        public static string SelectTruncateToString(SelectTruncate value)
        {
            switch (value)
            {
                case SelectTruncate.Disable:
                    return "Disable";
                case SelectTruncate.Enable:
                    return "Enable";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
