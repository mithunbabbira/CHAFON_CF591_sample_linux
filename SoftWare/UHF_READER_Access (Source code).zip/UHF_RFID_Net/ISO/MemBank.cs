﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net.ISO
{
    public enum MemBank
    {
        FileType,
        UII,
        TID,
        User
    }

    public class MemBankItem
    {
        public static readonly MemBankItem[] Options = new MemBankItem[] {
            new MemBankItem(MemBank.FileType),
            new MemBankItem(MemBank.UII),
            new MemBankItem(MemBank.TID),
            new MemBankItem(MemBank.User) };

        MemBank m_value;

        public MemBank Value
        {
            get { return m_value; }
        }

        public MemBankItem(MemBank value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return SelectMemBankToString(m_value);
        }

        public static string SelectMemBankToString(MemBank value)
        {
            switch (value)
            {
                case MemBank.FileType:
                    return "FileType";
                case MemBank.UII:
                    return "UII";
                case MemBank.TID:
                    return "TID";
                case MemBank.User:
                    return "User";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
