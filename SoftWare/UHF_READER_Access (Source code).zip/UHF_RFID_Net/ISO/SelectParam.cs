﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net.ISO
{
    /// <summary>
    /// Sort参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct SelectParam
    {
        private byte m_resv;

        /// <summary>
        ///00b：不截断
        ///01b：截断
        /// </summary>
        private byte m_trucate;

        /// <summary>
        ///000b：S0
        ///001b：S1
        ///010b：S2
        ///011b：S3
        ///100b：SL
        /// </summary>
        private byte m_target;

        private byte m_action;

        private byte m_membank;

        private ushort m_ptr;

        private byte m_len;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 255)]
        private byte[] m_mask;

        public byte Resv
        {
            get { return m_resv; }
            set { m_resv = value; }
        }

        /// <summary>
        /// false：不截断
        /// true：截断
        /// </summary>
        public bool Trucate
        {
            get { return m_trucate != 0; }
            set { m_trucate = (byte)(value ? 1 : 0); }
        }

        /// <summary>
        ///000b：S0
        ///001b：S1
        ///010b：S2
        ///011b：S3
        ///100b：SL
        /// </summary>
        public SelectTarget Target
        {
            get { return (SelectTarget)m_target; }
            set { m_target = (byte)value; }
        }

        public SelectAction Action
        {
            get { return (SelectAction)m_action; }
            set { m_action = (byte)value; }
        }

        public MemBank MemBank
        {
            get { return (MemBank)m_membank; }
            set { m_membank = (byte)value; }
        }

        public ushort MaskPtr
        {
            get { return m_ptr; }
            set { m_ptr = value; }
        }

        public byte MaskLen
        {
            get { return m_len; }
            set { m_len = value; }
        }

        public byte[] MaskData
        {
            get { return m_mask; }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");
                m_mask = value;
            }
        }
    }
}
