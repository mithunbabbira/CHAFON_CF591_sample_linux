﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HD17R01URNet
{
    public enum AuthKeyHash
    {
        NoHash,
        TID,
        Fac
    }

    public class AuthKeyHashItem
    {
        public static readonly AuthKeyHashItem[] Options = new AuthKeyHashItem[] {
            new AuthKeyHashItem(AuthKeyHash.NoHash),
            new AuthKeyHashItem(AuthKeyHash.TID),
            new AuthKeyHashItem(AuthKeyHash.Fac) };

        AuthKeyHash m_value;

        public AuthKeyHash Value
        {
            get { return m_value; }
        }

        public AuthKeyHashItem(AuthKeyHash value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return AuthKeyHashToString(m_value);
        }

        public static string AuthKeyHashToString(AuthKeyHash value)
        {
            switch (value)
            {
                case AuthKeyHash.NoHash:
                    return "不分散";
                case AuthKeyHash.TID:
                    return "TID";
                case AuthKeyHash.Fac:
                    return "手动输入";
            }
            return "未定义值：0x" + value.ToString("X02");
        }

        public static AuthKeyHashItem OptionFromValue(AuthKeyHash protocol)
        {
            foreach (AuthKeyHashItem item in Options)
            {
                if (item.Value == protocol)
                    return item;
            }
            return null;
        }
    }
}
