using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.ComponentModel;
using System.Threading;
using System.Diagnostics;
using System.Collections;
using System.Configuration;
using System.Xml;

namespace UHF_RFID_Net
{
    /// <summary>
    /// 与固件通信的类
    /// </summary>
    public unsafe class Reader
    {
        private static readonly byte[] s_arrEmpty = new byte[0];

        // 阅读器句柄
        IntPtr m_handler = IntPtr.Zero;


        // 当前阅读器状态，0：未打卡；1：按串口方式打卡；2：按网络方式打开 3：USB
        volatile int m_iState = 0;

        string m_ip = string.Empty;
        ushort m_netPort = 0;
        ushort m_usbindex = 0;
        string m_sport = string.Empty;

        //设备类型  1： MU910，912  2：MU904  3：914  4：804
        // 版本区别  MU910、912、904 只有一个天线  其他两个天线
        //           MU91X 系列默认掩码长度31字节
        //           只有MU804有带wifi模块功能。
        byte devicetpye = 0;

        // GB/T 29768协议对应的方法集合
        GBMember m_gb;
        // GJB 7377.1协议对应的方法集合
        GJBMember m_gjb;
        // ISO18000-63协议对应的方法集合
        ISOMember m_iso;
        // 测试命令对应的方法集合
        TestMember m_test;

        static Reader s_reader = null;

        public bool IsOpened
        {
            get { return m_iState != 0; }
        }

        public byte Devicetpye
        {
            get { return devicetpye; }
            set { devicetpye = value; }
        }

        public bool IsOpenedAsCom
        {
            get { return m_iState == 1; }
        }

        public bool IsOpenedAsNetwork
        {
            get { return m_iState == 2; }
        }

        public string IPAddress
        {
            get { return m_ip; }
        }

        public ushort NetPort
        {
            get { return m_netPort; }
        }

        public string PortName
        {
            get { return m_sport; }
        }

        /// <summary>
        /// GB/T 29768协议
        /// </summary>
        public GBMember GB
        {
            get { return m_gb; }
        }

        /// <summary>
        /// GJB 7377.1协议
        /// </summary>
        public GJBMember GJB
        {
            get { return m_gjb; }
        }

        /// <summary>
        /// ISO18000-63协议
        /// </summary>
        public ISOMember ISO
        {
            get { return m_iso; }
        }

        public TestMember Test
        {
            get { return m_test; }
        }

        public Reader()
        {
            m_gb = new GBMember(this);
            m_gjb = new GJBMember(this);
            m_iso = new ISOMember(this);
            m_test = new TestMember(this);
        }

        public void Open(string port,byte Baudrate)
        {
            if (port == null)
                throw new ArgumentNullException("port(port)");
            port = port.Trim();
            if (port.Length == 0)
                throw new ArgumentException("Serial Number is Null", "port(port)");
            if (m_iState != 0)
                throw new InvalidOperationException("Reader is already open");

            if (m_handler != IntPtr.Zero)
            {
                try { UHF_RFID_API.CloseDevice(m_handler); }
                catch { }
                m_handler = IntPtr.Zero;
                s_reader = null;
            }
            int state = UHF_RFID_API.OpenDevice(out m_handler,port,Baudrate);
            if (state != ReaderException.ERROR_SUCCESS)
            {
                m_handler = IntPtr.Zero;
                s_reader = null;
                throw new IOException("Port '" + port + "' Open fail");
            }
            s_reader = this;
            m_sport = port;
            m_iState = 1;
        }

        public void Open(string ip, ushort port, uint timeoutMs, bool throwExcpOnTimeout)
        {
            if (ip == null)
                throw new ArgumentNullException("ip(ipaddr)");
            ip = ip.Trim();
            if (ip.Length == 0)
                throw new ArgumentException("IPaddr is null", "ip(ipaddr)");
            if (port == 0)
                throw new ArgumentException("port is null", "port(port)");
            if (m_iState != 0)
                throw new InvalidOperationException("Reader is already open");

            if (m_handler != IntPtr.Zero)
            {
                try { UHF_RFID_API.CloseDevice(m_handler); }
                catch { }
                m_handler = IntPtr.Zero;
                s_reader = null;
            }

            int state = UHF_RFID_API.OpenNetConnection(out m_handler, ip, port, timeoutMs);
            if (state != ReaderException.ERROR_SUCCESS)
            {
                m_handler = IntPtr.Zero;
                s_reader = null;
                if (state == ReaderException.ERROR_CMD_COMM_TIMEOUT && !throwExcpOnTimeout)
                    return;
                throw new IOException("IP  '" + ip + "' Port " + port + " Connet Fail");
            }
            s_reader = this;
            m_ip = ip;
            m_netPort = port;
            m_iState = 2;
        }

        public void Close()
        {
            if (m_handler != IntPtr.Zero)
            {
                try { UHF_RFID_API.CloseDevice(m_handler); }
                catch { }
                m_handler = IntPtr.Zero;
                s_reader = null;
            }
            m_iState = 0;
        }

        public void Open(ushort index)
        {
            if (m_iState != 0)
                throw new InvalidOperationException("Reader is already open");

            if (m_handler != IntPtr.Zero)
            {
                try { UHF_RFID_API.CloseDevice(m_handler); }
                catch { }
                m_handler = IntPtr.Zero;
                s_reader = null;
            }

            int state = UHF_RFID_API.OpenHidConnection(out m_handler, index);
            if (state != ReaderException.ERROR_SUCCESS)
            {
                m_handler = IntPtr.Zero;
                s_reader = null;
                if (state == ReaderException.ERROR_CMD_COMM_TIMEOUT)
                    return;
            }
            s_reader = this;
            m_usbindex = index;
            m_iState = 3;
        }


        // 0:未找到设备
        // 1:一个设备
        public int CFHid_GetUsbCount()
        {
            int count = UHF_RFID_API.CFHid_GetUsbCount();
            return count;
        }

        public bool CFHid_GetUsbInfo(UInt16 iIndex, byte[] pucDeviceInfo)
        {
            bool jet = UHF_RFID_API.CFHid_GetUsbInfo(iIndex, pucDeviceInfo);
            return jet;
        }

        public bool CFHid_OpenDevice(UInt16 iIndex)
        {
            if (UHF_RFID_API.CFHid_OpenDevice(iIndex))
            {
                m_usbindex = iIndex;
                m_iState = 3;
                return true;
            }
            return false;
        }

        public bool CFHid_CloseDevice()
        {
            bool jet = UHF_RFID_API.CFHid_CloseDevice();
            m_iState = 0;
            return jet;
        }


        #region common methods

        public void RebootDevice()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            int state = UHF_RFID_API.RebootDevice(m_handler);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public DeviceInfo GetDeviceInfo()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            DeviceInfo info;
            //DegbugPrint("Start GetVer");
            int state = UHF_RFID_API.GetInfo(m_handler, out  info);
            //DegbugPrint("End GetVer");
            if (state == ReaderException.ERROR_SUCCESS)
                return info;
            throw new ReaderException(state);
        }


        public DeviceFullInfo GetDeviceFullInfo()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            DeviceFullInfo info;
            //DegbugPrint("Start GetVer");
            int state = UHF_RFID_API.GetDeviceInfo(m_handler, out info);
            //DegbugPrint("End GetVer");
            if (state == ReaderException.ERROR_SUCCESS)
                return info;
            throw new ReaderException(state);
        }


        public Devicepara GetDevicePara()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            Devicepara info;
            //DegbugPrint("Start GetVer");
            int state = UHF_RFID_API.GetDevicePara(m_handler, out info);
            //DegbugPrint("End GetVer");
            if (state == ReaderException.ERROR_SUCCESS)
                return info;
            throw new ReaderException(state);
        }


        public void SetDevicePara(Devicepara info)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            //DegbugPrint("Start GetVer");
            int state = UHF_RFID_API.SetDevicePara(m_handler, info);
            //DegbugPrint("End GetVer");
            if (state == ReaderException.ERROR_SUCCESS)
                return ;
            throw new ReaderException(state);
        }


        public PermissonPara GetPermissonPara()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            PermissonPara info;
            //DegbugPrint("Start GetVer");
            int state = UHF_RFID_API.GetPermissonPara(m_handler, out info);
            //DegbugPrint("End GetVer");
            if (state == ReaderException.ERROR_SUCCESS)
                return info;
            throw new ReaderException(state);
        }


        public void SetPermissonPara(PermissonPara info)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            //DegbugPrint("Start GetVer");
            int state = UHF_RFID_API.SetPermissonPara(m_handler, info);
            //DegbugPrint("End GetVer");
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }


        public LongPermissonPara GetLongPermissonPara()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            LongPermissonPara info;
            //DegbugPrint("Start GetVer");
            int state = UHF_RFID_API.GetLongPermissonPara(m_handler, out info);
            //DegbugPrint("End GetVer");
            if (state == ReaderException.ERROR_SUCCESS)
                return info;
            throw new ReaderException(state);
        }


        public void SetLongPermissonPara(LongPermissonPara info)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            //DegbugPrint("Start GetVer");
            int state = UHF_RFID_API.SetLongPermissonPara(m_handler, info);
            //DegbugPrint("End GetVer");
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }



        public GpioPara GetGpioPara()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            GpioPara info;
            //DegbugPrint("Start GetVer");
            int state = UHF_RFID_API.GetGpioPara(m_handler, out info);
            //DegbugPrint("End GetVer");
            if (state == ReaderException.ERROR_SUCCESS)
                return info;
            throw new ReaderException(state);
        }


        public void SetGpioPara(GpioPara info)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            //DegbugPrint("Start GetVer");
            int state = UHF_RFID_API.SetGpioPara(m_handler, info);
            //DegbugPrint("End GetVer");
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }


        public wifiPara GetwifiPara()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            wifiPara info;
            //DegbugPrint("Start GetVer");
            int state = UHF_RFID_API.GetwifiPara(m_handler, out info);
            //DegbugPrint("End GetVer");
            if (state == ReaderException.ERROR_SUCCESS)
                return info;
            throw new ReaderException(state);
        }


        public void SetwifiPara(wifiPara info)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            //DegbugPrint("Start GetVer");
            int state = UHF_RFID_API.SetwifiPara(m_handler, info);
            //DegbugPrint("End GetVer");
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }


        public ReaderStatus GetReaderStatus()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            ushort status;
            int state = UHF_RFID_API.GetDeviceSta(m_handler, out status);
            if (state == ReaderException.ERROR_SUCCESS)
                return (ReaderStatus)status;
            throw new ReaderException(state);
        }

        public void SetRfTxPower(byte txPower, byte reserved)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            int state = UHF_RFID_API.SetRFPower(m_handler, txPower, reserved);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public byte GetRfTxPower(out byte reserved)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            byte txPower;
            int state = UHF_RFID_API.GetRFPower(m_handler, out txPower, out reserved);
            if (state == ReaderException.ERROR_SUCCESS)
                return txPower;
            throw new ReaderException(state);
        }



        public void Release_Relay(byte time)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            int state = UHF_RFID_API.Release_Relay(m_handler, time);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }


        public void Close_Relay(byte time)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            int state = UHF_RFID_API.Close_Relay(m_handler, time);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }


        public void SetFrequency(FreqInfo frqInfo)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            int state = UHF_RFID_API.SetFreq(m_handler, ref frqInfo);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public FreqInfo GetFrequency()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            FreqInfo freq;
            int state = UHF_RFID_API.GetFreq(m_handler, out freq);
            if (state == ReaderException.ERROR_SUCCESS)
                return freq;
            throw new ReaderException(state);
        }

        public void SetAntenna(ref byte antenna)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            int state = UHF_RFID_API.SetAntenna(m_handler, ref antenna);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public byte GetAntenna()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            byte antenna;
            int state = UHF_RFID_API.GetAntenna(m_handler, out antenna);
            if (state == ReaderException.ERROR_SUCCESS)
                return antenna;
            throw new ReaderException(state);
        }

        public void SetModu(LinkModu modu)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            int state = UHF_RFID_API.SetModu(m_handler, (byte)modu);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public LinkModu GetModu()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            byte modu;
            int state = UHF_RFID_API.GetModu(m_handler, out modu);
            if (state == ReaderException.ERROR_SUCCESS)
                return (LinkModu)modu;
            throw new ReaderException(state);
        }

        public void SetRfidProtocol(Protocol protocol)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            int state = UHF_RFID_API.SetRFIDType(m_handler, (byte)protocol);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public Protocol GetRfidProtocol()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            byte proto;
            int state = UHF_RFID_API.GetRFIDType(m_handler, out proto);
            if (state == ReaderException.ERROR_SUCCESS)
                return (Protocol)proto;
            throw new ReaderException(state);
        }

        public void SaveSetting()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            int state = UHF_RFID_API.SaveSetting(m_handler);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public void RestoreSetting()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            int state = UHF_RFID_API.RestoreSetting(m_handler);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public void SetRFIcReg(ushort addr, byte value)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            RfIcReg[] items = new RfIcReg[1] { new RfIcReg(addr, value) };
            SetRFIcReg(items);
        }

        public void SetRFIcReg(RfIcReg[] regs)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            if (regs.Length == 0)
                return;

            int offset = 0;
            int left = regs.Length;
            fixed (RfIcReg* pBuf = regs)
            {
                do
                {
                    byte len = (byte)(left > 84 ? 84 : left);
                    int state = UHF_RFID_API.SetRFIcReg(m_handler, pBuf + offset, len);
                    if (state != ReaderException.ERROR_SUCCESS)
                        throw new ReaderException(state);
                    offset += len;
                    left -= len;
                } while (left > 0);
            }
        }

        public ushort GetRFIcReg(ushort addr)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            RfIcReg[] items = new RfIcReg[1] { new RfIcReg(addr, 0) };
            GetRFIcReg(items);
            return items[0].Value;
        }

        public void GetRFIcReg(RfIcReg[] regs)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            if (regs.Length == 0)
                return;

            int offset = 0;
            int left = regs.Length;
            fixed (RfIcReg* pBuf = regs)
            {
                do
                {
                    byte len = (byte)(left > 84 ? 84 : left);
                    int state = UHF_RFID_API.GetRFIcReg(m_handler, pBuf + offset, len);
                    if (state != ReaderException.ERROR_SUCCESS)
                        throw new ReaderException(state);
                    offset += len;
                    left -= len;
                } while (left > 0);
            }
        }


        public NetInfo GetNetInfo()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            NetInfo info;
            int state = UHF_RFID_API.GetNetInfo(m_handler, out info);
            if (state == ReaderException.ERROR_SUCCESS)
            {
                return info;
            }
            throw new ReaderException(state);
        }

        public void SetNetInfo(NetInfo info)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            int state = UHF_RFID_API.SetNetInfo(m_handler, info);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }



        public RemoteNetInfo GetRemoteNetInfo()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            RemoteNetInfo info;
            int state = UHF_RFID_API.GetRemoteNetInfo(m_handler, out info);
            if (state == ReaderException.ERROR_SUCCESS)
            {
                return info;
            }
            throw new ReaderException(state);
        }

        public void SetRemoteNetInfo(RemoteNetInfo info)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            int state = UHF_RFID_API.SetRemoteNetInfo(m_handler, info);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }



        public void SetTemperature(byte tempLimit, byte resv)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            int state = UHF_RFID_API.SetTemperature(m_handler, tempLimit, resv);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public byte GetTemperature(out byte tempLimit)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            byte tempCur;
            int state = UHF_RFID_API.GetTemperature(m_handler, out tempCur, out tempLimit);
            if (state == ReaderException.ERROR_SUCCESS)
                return tempCur;
            throw new ReaderException(state);
        }

        public DeltaPara GetPowerDelta()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            DeltaPara info;
            int state = UHF_RFID_API.GetPowerDelta(m_handler, out info);
            if (state == ReaderException.ERROR_SUCCESS)
            {
                return info;
            }
            throw new ReaderException(state);
        }

        public void SetPowerDelta(DeltaPara info)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            int state = UHF_RFID_API.SetPowerDelta(m_handler, info);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public ushort GetSleepTime()
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            ushort sleepTime;
            int state = UHF_RFID_API.GetSleepTime(m_handler, out sleepTime);
            if (state == ReaderException.ERROR_SUCCESS)
                return sleepTime;
            throw new ReaderException(state);
        }

        public void SetSleepTime(ushort sleepTime, byte resv)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            int state = UHF_RFID_API.SetSleepTime(m_handler, sleepTime, resv);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public void GetNetworkInfo(out long ipAddr, out long ipMask, out long ipGateway, out ushort port)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            uint ip, mask, gateway;
            int state = UHF_RFID_API.GetNetworkInfo(m_handler, out ip, out mask, out gateway, out port);
            if (state == ReaderException.ERROR_SUCCESS)
            {
                ipAddr = ip & 0xFFFFFFFF;
                ipMask = mask & 0xFFFFFFFF;
                ipGateway = gateway & 0xFFFFFFFF;
                return;
            }
            throw new ReaderException(state);
        }

        public void SetNetworkInfo(long ipAddr, long ipMask, long ipGateway, ushort port)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            int state = UHF_RFID_API.SetNetworkInfo(m_handler, (uint)ipAddr, (uint)ipMask, (uint)ipGateway, port);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public byte GetDuty(out int delayTime)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            byte interval;
            int state = UHF_RFID_API.GetDuty(m_handler, out interval, out delayTime);
            if (state == ReaderException.ERROR_SUCCESS)
                return interval;
            throw new ReaderException(state);
        }

        public void SetDuty(byte interval, int delayTime)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            int state = UHF_RFID_API.SetDuty(m_handler, interval, delayTime);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        /// <summary>
        /// 下发固件升级数据，当固件数据较长时，需要多次调用该目录，每次下发的数据不能超过254字节
        /// </summary>
        /// <param name="type">是否还有后续数据：
        /// 0：数据部分为固件数据，且还有后续数据；
        /// 1：数据部分为固件数据，且没有后续数据，所有固件数据都已传输完成；
        /// 2：升级固件开始命令</param>
        /// <param name="length">下发的数据长度</param>
        /// <param name="pParam">下发的固件数据</param>
        /// <param name="timeout">等待下位机响应的超时时间</param>
        /// <param name="throwExcpOnTimeout">等待超时后是否抛出异常，true：抛出异常；false：不抛出异常</param>
        /// <returns>如果执行成功，则返回true，如果throwExcpOnTimeout为false并且发生超时，则返回false，否则抛出异常</returns>
        public bool Update(ushort type, int length, byte[] pParam, ushort timeout, bool throwExcpOnTimeout)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            if (length > 0)
            {
                if (pParam == null)
                    throw new ArgumentNullException("pParam");
                if (length > pParam.Length)
                    throw new ArgumentException("参数长度大于参数数据长度", "length");
                if (length > 65530)
                    throw new ArgumentException("一次发送的参数长度不能超出65530字节");
            }

            int state = UHF_RFID_API.Update(m_handler, type, (ushort)length, pParam, timeout);
            // 如果执行成功，则返回true
            if (state == ReaderException.ERROR_SUCCESS)
                return true;
            // 如果错误类型是超时，并且不抛出异常，则返回false
            if (state == ReaderException.ERROR_CMD_COMM_TIMEOUT && !throwExcpOnTimeout)
                return false;
            // 否则抛出异常
            switch (state)
            {
                case 0x00:
                    throw new ReaderException(state, "固件太大");
                case 0x01:
                    throw new ReaderException(state, "固件写入错误");
                case 0x02:
                    throw new ReaderException(state, "传输已取消");
                case 0x03:
                    throw new ReaderException(state, "传输数据丢失");
                case 0x04:
                    throw new ReaderException(state, "固件接收失败");
            }
            throw new ReaderException(state);
        }

        /// <summary>
        /// 接收固件升级数据
        /// </summary>
        /// <param name="type">是否还有后续数据：
        /// 0x10：请求发送固件命令；
        /// 0x11：发送升级结果命令</param>
        /// <param name="status">升级状态：
        /// 0x00：固件升级成功
        /// 0x01：固件太大
        /// 0x02：固件写入错误
        /// 0x03：传输已取消
        /// 0x04：传输数据丢失
        /// 0x05：固件接收失败
        /// 0x06：升级失败，系统已恢复</param>
        /// <param name="timeout">等待下位机响应的超时时间</param>
        public void RecvUpdate(ushort type, out byte status, ushort timeout)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            int state = UHF_RFID_API.RecvUpdate(m_handler, type, out status, timeout);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }



        public bool SendSingeFrame(ushort type, int length, byte[] pParam, ushort timeout, bool throwExcpOnTimeout)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            if (length > 0)
            {
                if (pParam == null)
                    throw new ArgumentNullException("pParam");
                if (length > pParam.Length)
                    throw new ArgumentException("参数长度大于参数数据长度", "length");
            }
            int state = UHF_RFID_API.SendSingeFrame(m_handler, type, (ushort)length, pParam, timeout);
            // 如果执行成功，则返回true
            if (state == ReaderException.ERROR_SUCCESS)
                return true;
            // 如果错误类型是超时，并且不抛出异常，则返回false
            if (state == ReaderException.ERROR_CMD_COMM_TIMEOUT && !throwExcpOnTimeout)
                return false;
            // 否则抛出异常
            switch (state)
            {
                case 0x00:
                    throw new ReaderException(state, "固件太大");
            }
            throw new ReaderException(state);
        }

        public void RecvSingeFrame(ushort type, out byte status, ushort timeout, out int len, byte[] data)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");

            int state = UHF_RFID_API.RecvSingeFrame(m_handler, type, out status, timeout,out len, data);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }


        public void SelectOrSortSet(byte proto, SelectSortParam param)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            int state = UHF_RFID_API.SelectOrSortSet(m_handler, proto, ref param);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public SelectSortParam SelectOrSortGet(byte proto)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            SelectSortParam param;
            int state = UHF_RFID_API.SelectOrSortGet(m_handler, proto, out param);
            if (state == ReaderException.ERROR_SUCCESS)
                return param;
            throw new ReaderException(state);
        }

        public void QueryCfgSet(byte proto, UHF_RFID_Net.QueryParam param)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            int state = UHF_RFID_API.QueryCfgSet(m_handler, proto, ref param);
            if (state == ReaderException.ERROR_SUCCESS)
                return;
            throw new ReaderException(state);
        }

        public QueryParam QueryCfgGet(byte proto)
        {
            if (m_iState == 0)
                throw new InvalidOperationException("Reader is not open");
            QueryParam param;
            int state = UHF_RFID_API.QueryCfgGet(m_handler, proto, out param);
            if (state == ReaderException.ERROR_SUCCESS)
                return param;
            throw new ReaderException(state);
        }

        #endregion

        #region GBMember internal class

        public class GBMember
        {
            Reader m_owner;

            public GBMember(Reader owner)
            {
                m_owner = owner;
            }

            public void SetRfParam(GB.RfParam param)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_SetRFParam(m_owner.m_handler, ref param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public GB.RfParam GetRfParam()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                GB.RfParam param;
                int state = UHF_RFID_API.UHF_RFID_GB_GetRFParam(m_owner.m_handler, out param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return param;
                throw new ReaderException(state);
            }

            public void SetSortParam(GB.SortParam param)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_SetSortPRM(m_owner.m_handler, ref param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public GB.SortParam GetSortParam()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                GB.SortParam param;
                int state = UHF_RFID_API.UHF_RFID_GB_GetSortPRM(m_owner.m_handler, out param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return param;
                throw new ReaderException(state);
            }

            public void SetQueryParam(GB.QueryParam param)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_SetQueryPRM(m_owner.m_handler, ref param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public GB.QueryParam GetQueryParam()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                GB.QueryParam param;
                int state = UHF_RFID_API.UHF_RFID_GB_GetQueryPRM(m_owner.m_handler, out param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return param;
                throw new ReaderException(state);
            }

            public void SetCoilParam(byte cin, byte ccn, byte reserved)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_SetCoilPRM(m_owner.m_handler, cin, ccn, reserved);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void GetCoilParam(out byte cin, out byte ccn, out byte reserved)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_GetCoilPRM(m_owner.m_handler, out cin, out ccn, out reserved);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void ISO_SaveSetting()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_SaveSetting(m_owner.m_handler);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void Inventory(byte invCount, uint invParam)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_InventoryContinue(m_owner.m_handler, invCount, invParam);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagItem GetTagUii(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagInfo info;
                int state = UHF_RFID_API.UHF_RFID_GB_GetTagUii(m_owner.m_handler, out info, timeoutMs);
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagItem(info);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                throw new ReaderException(state);
            }

            public void InventoryStop(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_InventoryStop(m_owner.m_handler, timeoutMs);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void SetSortMask(ushort maskPtr, byte maskBits, byte[] mask)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_SetSortMask(m_owner.m_handler, maskPtr, maskBits, mask);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void ReadTag(byte[] accPwd, GB.MemBank memBank, ushort wordPtr, ushort wordCount)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_ReadTag(m_owner.m_handler, 0, accPwd, (byte)memBank, wordPtr, wordCount);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagRespItem GetReadResp(out byte btWordsCount, byte[] arrData, ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.UHF_RFID_GB_GetReadTagResp(m_owner.m_handler, out info, out btWordsCount, arrData, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }

            public void WriteTag(byte[] accPwd, GB.MemBank memBank, ushort wordPtr, byte[] writeData)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");
                if (writeData == null)
                    throw new ArgumentNullException("writeData");
                if (writeData.Length == 0)
                    return;
                if ((writeData.Length & 1) != 0)
                    throw new ArgumentException("写入数据的字节长度必须是2的倍数", "writeData");

               int state = UHF_RFID_API.UHF_RFID_GB_WriteTag(m_owner.m_handler, 0, accPwd,
                            (byte)memBank, wordPtr, (byte)(writeData.Length >> 1), writeData);
               if (state == ReaderException.ERROR_SUCCESS)
                   return;
               throw new ReaderException(state);
            }

            public TagRespItem GetWriteResp(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.UHF_RFID_GB_GetTagResp(m_owner.m_handler, 0x3F, out info, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }

            public ushort EraseTag(byte[] accPwd, GB.MemBank memBank, ushort wordPtr, byte wordCount)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_EraseTag(m_owner.m_handler, 0, accPwd, (byte)memBank, wordPtr, wordCount);
                if (state == ReaderException.ERROR_SUCCESS)
                    return wordCount;
                throw new ReaderException(state);
            }

            public TagRespItem GetEraseResp(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.UHF_RFID_GB_GetTagResp(m_owner.m_handler, 0x40, out info, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }

            public void LockTag(byte[] accPwd, GB.MemBank memBank, GB.LockCfg config, byte action)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_LockTag(m_owner.m_handler, accPwd, (byte)memBank, (byte)config, action);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagRespItem GetLockResp(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.UHF_RFID_GB_GetTagResp(m_owner.m_handler, 0x41, out info, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }

            public void KillTag(byte[] accPwd)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_KillTag(m_owner.m_handler, accPwd);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagRespItem GetKillResp(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.UHF_RFID_GB_GetTagResp(m_owner.m_handler, 0x42, out info, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }

            /*public byte[] GetSecurityParam(out byte[] tid)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                byte[] sprm = new byte[6];
                tid = new byte[12];
                int state = UHF_RFID_API.UHF_RFID_GB_Sparm(m_owner.m_handler, sprm, tid);
                if (state == ReaderException.ERROR_SUCCESS)
                    return sprm;
                throw new ReaderException(state);
            }

            public void MutualAuth()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_MSAuth(m_owner.m_handler);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public ushort SingleCmd(SingleCmdOption option, byte count, ushort bitsLen, byte[] data, byte[] reData)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");
                if (bitsLen >= 256 * 8)
                    throw new ArgumentException("单条命令发送的数据位长度必须小于 2048 bit", "bitsLen");
                if (bitsLen > data.Length * 8)
                    throw new ArgumentException("单条命令发送的数据位长度超出实际数据长度", "bitsLen");

                ushort relen;
                int state = UHF_RFID_API.UHF_RFID_GB_TestTrans(m_owner.m_handler, 0, count, bitsLen, data, out relen, reData);
                if (state == ReaderException.ERROR_SUCCESS)
                    return relen;
                throw new ReaderException(state);
            }*/
        }

        #endregion

        #region GJBMember internal class

        public class GJBMember
        {
            Reader m_owner;

            public GJBMember(Reader owner)
            {
                m_owner = owner;
            }

            public void SetRfParam(GJB.RfParam param)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GJB_SetRFParam(m_owner.m_handler, ref param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public GJB.RfParam GetRfParam()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                GJB.RfParam param;
                int state = UHF_RFID_API.UHF_RFID_GJB_GetRFParam(m_owner.m_handler, out param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return param;
                throw new ReaderException(state);
            }

            public void SetSortParam(GJB.SortParam param)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GJB_SetSortPRM(m_owner.m_handler, ref param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public GJB.SortParam GetSortParam()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                GJB.SortParam param;
                int state = UHF_RFID_API.UHF_RFID_GJB_GetSortPRM(m_owner.m_handler, out param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return param;
                throw new ReaderException(state);
            }

            public void SetQueryParam(GJB.QueryParam param)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GJB_SetQueryPRM(m_owner.m_handler, ref param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public GJB.QueryParam GetQueryParam()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                GJB.QueryParam param;
                int state = UHF_RFID_API.UHF_RFID_GJB_GetQueryPRM(m_owner.m_handler, out param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return param;
                throw new ReaderException(state);
            }

            public void SetCoilParam(byte cin, byte ccn, byte reserved)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_SetCoilPRM(m_owner.m_handler, cin, ccn, reserved);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void GetCoilParam(out byte cin, out byte ccn, out byte reserved)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_GetCoilPRM(m_owner.m_handler, out cin, out ccn, out reserved);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void ISO_SaveSetting()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_SaveSetting(m_owner.m_handler);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void Inventory(byte invCount, uint invParam)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_InventoryContinue(m_owner.m_handler, invCount, invParam);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagItem GetTagUii(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagInfo info;
                int state = UHF_RFID_API.UHF_RFID_GB_GetTagUii(m_owner.m_handler, out info, timeoutMs);
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagItem(info);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                throw new ReaderException(state);
            }

            public void InventoryStop(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_InventoryStop(m_owner.m_handler, timeoutMs);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void SetSortMask(ushort maskPtr, byte maskBits, byte[] mask)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_SetSortMask(m_owner.m_handler, maskPtr, maskBits, mask);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void ReadTag(byte[] accPwd, GJB.MemBank memBank, ushort wordPtr, ushort wordCount)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_ReadTag(m_owner.m_handler, 0, accPwd, (byte)memBank, wordPtr, wordCount);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagRespItem GetReadResp(out byte btWordsCount, byte[] arrData, ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.UHF_RFID_GB_GetReadTagResp(m_owner.m_handler, out info, out btWordsCount, arrData, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }

            public void WriteTag(byte[] accPwd, GJB.MemBank memBank, ushort wordPtr, byte[] writeData)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");
                if (writeData == null)
                    throw new ArgumentNullException("writeData");
                if (writeData.Length == 0)
                    return;
                if ((writeData.Length & 1) != 0)
                    throw new ArgumentException("写入数据的字节长度必须是2的倍数", "writeData");

                int state = UHF_RFID_API.UHF_RFID_GB_WriteTag(m_owner.m_handler, 0, accPwd,
                             (byte)memBank, wordPtr, (byte)(writeData.Length >> 1), writeData);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagRespItem GetWriteResp(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.UHF_RFID_GB_GetTagResp(m_owner.m_handler, 0x3F, out info, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }

            public ushort EraseTag(byte[] accPwd, GJB.MemBank memBank, ushort wordPtr, byte wordCount)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_EraseTag(m_owner.m_handler, 0, accPwd, (byte)memBank, wordPtr, wordCount);
                if (state == ReaderException.ERROR_SUCCESS)
                    return wordCount;
                throw new ReaderException(state);
            }

            public TagRespItem GetEraseResp(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.UHF_RFID_GB_GetTagResp(m_owner.m_handler, 0x40, out info, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }

            public void LockTag(byte[] accPwd, GJB.MemBank memBank, GJB.LockCfg config, byte action)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_LockTag(m_owner.m_handler, accPwd, (byte)memBank, (byte)config, action);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagRespItem GetLockResp(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.UHF_RFID_GB_GetTagResp(m_owner.m_handler, 0x41, out info, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }

            public void KillTag(byte[] accPwd)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_GB_KillTag(m_owner.m_handler, accPwd);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagRespItem GetKillResp(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.UHF_RFID_GB_GetTagResp(m_owner.m_handler, 0x42, out info, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }
        }

        #endregion

        #region ISOMember internal class

        public class ISOMember
        {
            Reader m_owner;

            public ISOMember(Reader owner)
            {
                m_owner = owner;
            }

            public void SetRfParam(byte proto, byte param)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.SetRFParam(m_owner.m_handler, proto, param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public byte GetRfParam(byte proto)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                byte param;
                int state = UHF_RFID_API.GetRFParam(m_owner.m_handler, proto, out param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return param;
                throw new ReaderException(state);
            }

            public void SetSelectParam(ISO.SelectParam param)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.SetSelectPRM(m_owner.m_handler, ref param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public ISO.SelectParam GetSelectParam()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                ISO.SelectParam param;
                int state = UHF_RFID_API.GetSelectPRM(m_owner.m_handler, out param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return param;
                throw new ReaderException(state);
            }

            public void SetQueryParam(ISO.QueryParam param)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.SetQueryPRM(m_owner.m_handler, ref param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public ISO.QueryParam GetQueryParam()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                ISO.QueryParam param;
                int state = UHF_RFID_API.GetQueryPRM(m_owner.m_handler, out param);
                if (state == ReaderException.ERROR_SUCCESS)
                    return param;
                throw new ReaderException(state);
            }

            public void SetCoilParam(byte Q, byte reserved)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.SetCoilPRM(m_owner.m_handler, Q, reserved);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void GetCoilParam(out byte Q, out byte reserved)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.GetCoilPRM(m_owner.m_handler, out Q, out reserved);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void ISO_SaveSetting()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.SaveSetting(m_owner.m_handler);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void Inventory(byte invCount, uint invParam)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.InventoryContinue(m_owner.m_handler, invCount, invParam);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagItem GetTagUii(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagInfo info;
                int state = UHF_RFID_API.GetTagUii(m_owner.m_handler, out info, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagItem(info);
                if (state == ReaderException.ERROR_CMD_RESP_CRC_ERROR)   //过滤CRC错误
                    return new TagItem(info);
                throw new ReaderException(state);
            }

            public void InventoryStop(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.InventoryStop(m_owner.m_handler, timeoutMs);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void SetSelectMask(ushort maskPtr, byte maskBits, byte[] mask)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.SetSelectMask(m_owner.m_handler, maskPtr, maskBits, mask);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void ReadTag(byte[] accPwd, ISO.MemBank memBank, ushort wordPtr, ushort wordCount)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.ReadTag(m_owner.m_handler, 0, accPwd,
                         (byte)memBank, wordPtr, wordCount);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagRespItem GetReadResp(out byte btWordsCount, byte[] arrData, ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.GetReadTagResp(m_owner.m_handler, out info, out btWordsCount, arrData, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }

            public void WriteTag(byte[] accPwd, ISO.MemBank memBank, ushort wordPtr, byte[] writeData)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");
                if (writeData == null)
                    throw new ArgumentNullException("writeData");
                if (writeData.Length == 0)
                    return;
                if ((writeData.Length & 1) != 0)
                    throw new ArgumentException("写入数据的字节长度必须是2的倍数", "writeData");

                int state = UHF_RFID_API.WriteTag(m_owner.m_handler, 0, accPwd,
                             (byte)memBank, wordPtr, (byte)(writeData.Length >> 1), writeData);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagRespItem GetWriteResp(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.GetTagResp(m_owner.m_handler, 0x04, out info, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }

            public void LockTag(byte[] accPwd, byte erea, byte action)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.LockTag(m_owner.m_handler, accPwd, erea, action);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagRespItem GetLockResp(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.GetTagResp(m_owner.m_handler, 0x05, out info, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }

            public void KillTag(byte[] killPwd)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.KillTag(m_owner.m_handler, killPwd);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public TagRespItem GetKillResp(ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.TagResp info;
                int state = UHF_RFID_API.GetTagResp(m_owner.m_handler, 0x06, out info, timeoutMs);
                if (state == ReaderException.ERROR_CMD_NO_TAG)
                    return null;
                if (state == ReaderException.ERROR_SUCCESS)
                    return new TagRespItem(info);
                throw new ReaderException(state);
            }





            /*public void BlockWriteTag(byte[] accPwd,
                ISO.MemBank memBank, ushort wordPtr, byte[] writeData)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");
                if (writeData == null)
                    throw new ArgumentNullException("writeData");
                if (writeData.Length == 0)
                    return;
                if ((writeData.Length & 1) != 0)
                    throw new ArgumentException("写入数据的字节长度必须是2的倍数", "writeData");

                int wordCount = writeData.Length / 2;
                int offset = 0;
                do
                {
                    ushort words = (ushort)(wordCount > 122 ? 122 : wordCount);
                    int state;
                    fixed (byte* pData = writeData)
                    {
                        state = UHF_RFID_API.BlockWriteTag(m_owner.m_handler, 0, accPwd,
                            (byte)memBank, (ushort)(wordPtr + offset * 2), ref words, pData + offset * 2);
                    }
                    if (state != ReaderException.ERROR_SUCCESS)
                        throw new ReaderException(state);

                    offset += words;
                    wordCount -= words;
                } while (wordCount > 0);
                //return offset;
            }

            public void BlockEraseTag(byte[] accPwd, ISO.MemBank memBank, ushort wordPtr, ushort wordCount)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.BlockEraseTag(m_owner.m_handler, 0, accPwd, (byte)memBank, wordPtr, ref wordCount);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public byte[] BlockPermalock(byte[] accPwd, ISO.PermalockParam prm, out ushort rspBitLen)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                byte[] rspData = new byte[31];
                byte bits = (byte)(rspData .Length * 8);
                int state = UHF_RFID_API.BlockPermalock(m_owner.m_handler, accPwd, ref prm, ref bits, rspData);
                if (state == ReaderException.ERROR_SUCCESS)
                {
                    rspBitLen = bits;
                    int bytes = (bits + 7) / 8;
                    if (bytes == rspData.Length)
                        return rspData;
                    byte[] rspData2 = new byte[bytes];
                    Array.Copy(rspData, rspData2, bytes);
                    return rspData2;
                }
                throw new ReaderException(state);
            }

            public byte[] GetSecurityParam(out byte[] tid)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                byte[] sprm = new byte[6];
                tid = new byte[12];
                int state = UHF_RFID_API.Sparm(m_owner.m_handler, sprm, tid);
                if (state == ReaderException.ERROR_SUCCESS)
                    return sprm;
                throw new ReaderException(state);
            }

            public void MutualAuth()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.MSAuth(m_owner.m_handler);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public ushort SingleCmd(SingleCmdOption option, byte count, ushort bitsLen, byte[] data, byte[] reData)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");
                if (bitsLen >= 256 * 8)
                    throw new ArgumentException("单条命令发送的数据位长度必须小于 2048 bit", "bitsLen");
                if (bitsLen > data.Length * 8)
                    throw new ArgumentException("单条命令发送的数据位长度超出实际数据长度", "bitsLen");

                ushort relen;
                int state = UHF_RFID_API.TestTrans(m_owner.m_handler, 0, count, bitsLen, data, out relen, reData);
                if (state == ReaderException.ERROR_SUCCESS)
                    return relen;
                throw new ReaderException(state);
            }*/
        }

        #endregion

        #region TestMember internal class

        public class TestMember
        {
            Reader m_owner;

            public TestMember(Reader owner)
            {
                m_owner = owner;
            }


            /*public void ChipInit()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_CP_Init(m_owner.m_handler);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void GbSensManualTest(GB.LinkBLF blf, GB.LinkM m, GB.LinkTRext trext, ushort rxDelay, 
                ushort rxLen, uint rxNum, out uint frame_err, out uint frame_num, out byte freqOffset)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.CP_Sensi_Prm_Typ prm = new UHF_RFID_API.CP_Sensi_Prm_Typ();
                prm.blf = (uint)blf;
                prm.miller = (byte)m;
                prm.trext = (byte)trext;
                prm.rxDelay = rxDelay;
                prm.rxLen = rxLen;
                prm.rxNum = rxNum;
                UHF_RFID_API.CP_Sensi_Result_Typ result;
                int state = UHF_RFID_API.UHF_RFID_CP_SensTest(m_owner.m_handler, (byte)Protocol.GB_T_29768, ref prm, out result);
                if (state == ReaderException.ERROR_SUCCESS)
                {
                    frame_err = result.frame_err;
                    frame_num = result.frame_total;
                    freqOffset = result.freqOffset;
                    return;
                }
                throw new ReaderException(state);
            }

            public void GjbSensManualTest(GJB.LinkBLF blf, GJB.LinkM m, GJB.LinkTRext trext, ushort rxDelay,
                ushort rxLen, uint rxNum, out uint frame_err, out uint frame_num, out byte freqOffset)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.CP_Sensi_Prm_Typ prm = new UHF_RFID_API.CP_Sensi_Prm_Typ();
                prm.blf = (uint)blf;
                prm.miller = (byte)m;
                prm.trext = (byte)trext;
                prm.rxDelay = rxDelay;
                prm.rxLen = rxLen;
                prm.rxNum = rxNum;
                UHF_RFID_API.CP_Sensi_Result_Typ result;
                int state = UHF_RFID_API.UHF_RFID_CP_SensTest(m_owner.m_handler, (byte)Protocol.GJB_7377_1, ref prm, out result);
                if (state == ReaderException.ERROR_SUCCESS)
                {
                    frame_err = result.frame_err;
                    frame_num = result.frame_total;
                    freqOffset = result.freqOffset;
                    return;
                }
                throw new ReaderException(state);
            }

            public void IsoSensManualTest(uint blf, ISO.LinkM m, ISO.LinkTRext trext, ushort rxDelay,
                ushort rxLen, ushort rxNum, out uint frame_err, out uint frame_num, out byte freqOffset)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.CP_Sensi_Prm_Typ prm = new UHF_RFID_API.CP_Sensi_Prm_Typ();
                prm.blf = blf;
                prm.miller = (byte)m;
                prm.trext = (byte)trext;
                prm.rxDelay = rxDelay;
                prm.rxLen = rxLen;
                prm.rxNum = rxNum;
                UHF_RFID_API.CP_Sensi_Result_Typ result;
                int state = UHF_RFID_API.UHF_RFID_CP_SensTest(m_owner.m_handler, (byte)Protocol.ISO_18000_63, ref prm, out result);
                if (state == ReaderException.ERROR_SUCCESS)
                {
                    frame_err = result.frame_err;
                    frame_num = result.frame_total;
                    freqOffset = result.freqOffset;
                    return;
                }
                throw new ReaderException(state);
            }

            public void SensAutoTest(Protocol proto, ushort rxDelay, ushort rxLen, ushort rxNum)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.CP_Sensi_Prm_Typ prm = new UHF_RFID_API.CP_Sensi_Prm_Typ();
                prm.rxDelay = rxDelay;
                prm.rxLen = rxLen;
                prm.rxNum = rxNum;
                UHF_RFID_API.CP_Sensi_Result_Typ result;
                int state = UHF_RFID_API.UHF_RFID_CP_SensTest(m_owner.m_handler, (byte)proto, ref prm, out result);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public byte[] GbQuery(byte txPower, FreqInfo freq, GB.LinkTc tc, LinkModu modu, byte depth)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                byte[] resp = new byte[3];
                int state = UHF_RFID_API.UHF_RFID_CP_Query(m_owner.m_handler, (byte)Protocol.GB_T_29768,
                    (byte)txPower, ref freq, (byte)tc, (byte)modu, depth, (byte)resp.Length, resp);
                if (state == ReaderException.ERROR_SUCCESS)
                    return resp;
                throw new ReaderException(state);
            }

            public byte[] GjbQuery(byte txPower, FreqInfo freq, GJB.LinkTc tc, LinkModu modu, byte depth)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                byte[] resp = new byte[3];
                int state = UHF_RFID_API.UHF_RFID_CP_Query(m_owner.m_handler, (byte)Protocol.GJB_7377_1,
                    (byte)txPower, ref freq, (byte)tc, (byte)modu, depth, (byte)resp.Length, resp);
                if (state == ReaderException.ERROR_SUCCESS)
                    return resp;
                throw new ReaderException(state);
            }

            public byte[] IsoQuery(byte txPower, FreqInfo freq, ISO.LinkTari tari, LinkModu modu, byte depth)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                byte[] resp = new byte[3];
                int state = UHF_RFID_API.UHF_RFID_CP_Query(m_owner.m_handler, (byte)Protocol.ISO_18000_63,
                    (byte)txPower, ref freq, (byte)tari, (byte)modu, depth, (byte)resp.Length, resp);
                if (state == ReaderException.ERROR_SUCCESS)
                    return resp;
                throw new ReaderException(state);
            }

            public byte[] ManualSJC(byte i_start, byte i_stop, byte q_start, byte q_stop, int timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.IQ_Axial_Typ prm = new UHF_RFID_API.IQ_Axial_Typ();
                prm.i_start = i_start;
                prm.i_stop = i_stop;
                prm.q_start = q_start;
                prm.q_stop = q_stop;
                int state = UHF_RFID_API.UHF_RFID_CP_ManuSJC(m_owner.m_handler, ref prm);
                if (state != ReaderException.ERROR_SUCCESS)
                    throw new ReaderException(state);

                byte[] buf = new byte[1024];
                int dataLen = 0;
                byte frame_no = 0;
                UHF_RFID_API.JSC_Data_Typ data;
                while (true)
                {
                    state = UHF_RFID_API.UHF_RFID_CP_GetSJCData(m_owner.m_handler, 0, out data, timeoutMs);
                    if (state != ReaderException.ERROR_SUCCESS)
                    {
                        if (state != ReaderException.ERROR_CMD_HAS_MORE_DATA)
                            throw new ReaderException(state);

                        if (data.number != frame_no)
                            throw new ReaderException(ReaderException.ERROR_CMD_RESP_FORMAT_ERROR);
                        frame_no++;

                        if (data.dataLen > 0)
                        {
                            if (dataLen + data.dataLen > buf.Length)
                            {
                                byte[] buf2 = new byte[dataLen > data.dataLen ? dataLen * 2 + data.dataLen : data.dataLen * 2];
                                Array.Copy(buf, buf2, dataLen);
                                buf = buf2;
                            }
                            Array.Copy(data.data, 0, buf, dataLen, data.dataLen);
                            dataLen += data.dataLen;
                            continue;
                        }
                    }

                    if (dataLen == 0)
                        return s_arrEmpty;
                    if (buf.Length == dataLen)
                        return buf;
                    byte[] buf3 = new byte[dataLen];
                    Array.Copy(buf, buf3, dataLen);
                    return buf3;
                }
            }

            public byte[] AutoSJC(byte i_origin, byte q_origin, byte size, byte step, int timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                UHF_RFID_API.JSC_AUTO_SCAN_PRM_Typ prm = new UHF_RFID_API.JSC_AUTO_SCAN_PRM_Typ();
                prm.i_origin = i_origin;
                prm.q_origin = q_origin;
                prm.size = size;
                prm.step = step;
                int state = UHF_RFID_API.UHF_RFID_CP_AutoSJC(m_owner.m_handler, ref prm);
                if (state != ReaderException.ERROR_SUCCESS)
                    throw new ReaderException(state);

                byte[] buf = new byte[1024];
                int dataLen = 0;
                byte frame_no = 0;
                UHF_RFID_API.JSC_Data_Typ data;
                while (true)
                {
                    state = UHF_RFID_API.UHF_RFID_CP_GetSJCData(m_owner.m_handler, 0, out data, timeoutMs);
                    if (state != ReaderException.ERROR_SUCCESS)
                    {
                        if (state != ReaderException.ERROR_CMD_HAS_MORE_DATA)
                            throw new ReaderException(state);

                        if (data.number != frame_no)
                            throw new ReaderException(ReaderException.ERROR_CMD_RESP_FORMAT_ERROR);
                        frame_no++;

                        if (data.dataLen > 0)
                        {
                            if (dataLen + data.dataLen > buf.Length)
                            {
                                byte[] buf2 = new byte[dataLen > data.dataLen ? dataLen * 2 + data.dataLen : data.dataLen * 2];
                                Array.Copy(buf, buf2, dataLen);
                                buf = buf2;
                            }
                            Array.Copy(data.data, 0, buf, dataLen, data.dataLen);
                            dataLen += data.dataLen;
                            continue;
                        }
                    }

                    if (dataLen == 0)
                        return s_arrEmpty;
                    if (buf.Length == dataLen)
                        return buf;
                    byte[] buf3 = new byte[dataLen];
                    Array.Copy(buf, buf3, dataLen);
                    return buf3;
                }
            }

            public void EnterShell()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_EnterShell(m_owner.m_handler);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public RfIcReg[] BatchReadWriteRegs(ReadWriteRegItem[] items)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");
                if (items.Length == 0)
                    return RfIcReg.EmptyArray;

                List<RfIcReg> regs = new List<RfIcReg>(items.Length);
                int index1 = 0;
                int index2 = 0;
                int offset = 0;
                int left = items.Length;

                fixed(ReadWriteRegItem *pBuf = items)
                {
                    do
                    {
                        byte len = (byte)(left > 36 ? 36 : left);
                        UHF_RFID_API.Read_Regs_Result_Typ result;
                        int state = UHF_RFID_API.UHF_RFID_TEST_BatchReadWriteRegs(m_owner.m_handler, len, pBuf + offset, out result);
                        if (state != ReaderException.ERROR_SUCCESS)
                            throw new ReaderException(state);
                        if (result.items != len)
                            throw new ReaderException(ReaderException.ERROR_CMD_INTERNAL_ERROR);

                        for (int i = 0; i < len && index1 < items.Length; index1++)
                        {
                            if (items[index1].IsWriteReg)
                                continue;
                            regs[index2] = new RfIcReg(items[index1].Addr, (byte)result.val[i]);
                            index2++;
                            i++;
                        }
                        offset += len;
                        left -= len;
                    } while (left > 0);
                }
                return regs.ToArray();
            }

            public void SetWatchCR(ushort count)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_SetWatchCR(m_owner.m_handler, count);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void StartWatchCR(ushort addr)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_SwitchWatchCR(m_owner.m_handler, addr, 1);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void StopWatchCR(ushort addr)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_SwitchWatchCR(m_owner.m_handler, addr, 0);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public CRLogItem[] ReadCRLog(ushort count, out uint loseCount)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");
                loseCount = 0;
                if (count == 0)
                    return CRLogItem.EmptyArray;

                CRLogItem[] items = new CRLogItem[count];
                int offset = 0;
                int left = count;

                fixed (CRLogItem* pBuf = items)
                {
                    do
                    {
                        ushort lose;
                        byte len = (byte)(left > 41 ? 41 : left);
                        int state = UHF_RFID_API.UHF_RFID_TEST_ReadCRLog(m_owner.m_handler, out lose, ref len, pBuf);
                        if (state != ReaderException.ERROR_SUCCESS)
                            throw new ReaderException(state);
                        loseCount += lose;
                        if (len == 0)
                            break;
                        offset += len;
                        left -= len;
                    } while (left > 0);
                }
                return items;
            }

            public void SetWatchInt(ushort count)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_SetWatchInt(m_owner.m_handler, count);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void StartWatchInt()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_SwitchWatchInt(m_owner.m_handler, 1);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void StopWatchInt()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_SwitchWatchInt(m_owner.m_handler, 0);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public IntStatusItem[] ReadIntStatus(ushort count, out uint loseCount)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");
                loseCount = 0;
                if (count == 0)
                    return IntStatusItem.EmptyArray;

                IntStatusItem[] items = new IntStatusItem[count];
                int offset = 0;
                int left = count;

                fixed (IntStatusItem* pBuf = items)
                {
                    do
                    {
                        ushort lose;
                        byte len = (byte)(left > 62 ? 62 : left);
                        int state = UHF_RFID_API.UHF_RFID_TEST_ReadIntStatus(m_owner.m_handler, out lose, ref len, pBuf);
                        if (state != ReaderException.ERROR_SUCCESS)
                            throw new ReaderException(state);
                        loseCount += lose;
                        if (len == 0)
                            break;
                        offset += len;
                        left -= len;
                    } while (left > 0);
                }
                return items;
            }

            public void SetWatchFifo(ushort wLen)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_SetWatchFifo(m_owner.m_handler, wLen);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void StartWatchFifo()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_SwitchWatchFifo(m_owner.m_handler, 1);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void StopWatchFifo()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_SwitchWatchFifo(m_owner.m_handler, 0);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public byte[] ReadFifo(ushort len, out uint loseCount)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                loseCount = 0;
                if (len == 0)
                    return s_arrEmpty;

                byte[] data = new byte[len];
                int offset = 0;
                int left = len;

                fixed (byte* pBuf = data)
                {
                    do
                    {
                        uint lose;
                        byte len2 = (byte)(left > 249 ? 249 : left);
                        int state = UHF_RFID_API.UHF_RFID_TEST_ReadFifo(m_owner.m_handler, out lose, ref len2, pBuf);
                        if (state != ReaderException.ERROR_SUCCESS)
                            throw new ReaderException(state);
                        loseCount += lose;
                        if (len == 0)
                            break;
                        offset += len2;
                        left -= len2;
                    } while (left > 0);
                }
                if (offset != data.Length)
                    throw new ReaderException(ReaderException.ERROR_CMD_INTERNAL_ERROR);
                return data;
            }

            public void SetLogLen(ushort len)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_SetLogLen(m_owner.m_handler, len);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void SwitchUseSelect(bool use)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_SwitchSelect(m_owner.m_handler, (byte)(use ? 1 : 0));
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void ContinueSend(ushort time, bool bUseRnd, byte data)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_ContinueSendData(m_owner.m_handler, time, (byte)(bUseRnd ? 1 : 0), data);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }*/

            public void ReadLog()
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                byte[] arr = new byte[253];
                int state = UHF_RFID_API.UHF_RFID_TEST_ReadLog(m_owner.m_handler);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public byte[] GetReadLogResp(out byte len, ushort timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                byte[] arr = new byte[253];
                int state = UHF_RFID_API.UHF_RFID_TEST_GetReadLogResp(m_owner.m_handler, out len, arr, timeoutMs);
                // 返回空数组表示读取完成
                if (state == ReaderException.ERROR_CMD_NOMORE_DATA)
                    return s_arrEmpty;
                if (state == ReaderException.ERROR_SUCCESS)
                    return (len == 0 ? s_arrEmpty : arr);
                throw new ReaderException(state);
            }

            public void Test1(byte[] pParam, int length)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");
                if (pParam == null)
                    throw new ArgumentNullException("pParam");
                if (length > pParam.Length)
                    throw new ArgumentException("参数长度大于参数数据长度", "length");
                if (length > 255)
                    throw new ArgumentException("一次发送的参数长度不能超出255字节");

                int state = UHF_RFID_API.UHF_RFID_TEST_Test1(m_owner.m_handler, (byte)length, pParam);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public byte[] Test2(byte[] pParam, int length)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");
                if (pParam == null)
                    throw new ArgumentNullException("pParam");
                if (length > pParam.Length)
                    throw new ArgumentException("参数长度大于参数数据长度", "length");
                if (length > 255)
                    throw new ArgumentException("一次发送的参数长度不能超出255字节");

                byte[] resp = new byte[255];
                byte respLen = 255;
                int state = UHF_RFID_API.UHF_RFID_TEST_Test2(m_owner.m_handler, (byte)length, pParam, ref respLen, resp);
                if (state == ReaderException.ERROR_SUCCESS)
                {
                    if (respLen == 0)
                        return s_arrEmpty;

                    if (resp.Length != respLen)
                    {
                        byte[] arr = new byte[respLen];
                        Array.Copy(resp, arr, respLen);
                        resp = arr;
                    }
                    return resp;
                }
                throw new ReaderException(state);
            }

            public sbyte TestTxPower(byte power, int timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                sbyte result;
                int state = UHF_RFID_API.UHF_RFID_TEST_TestTxPower(m_owner.m_handler, power, timeoutMs, out result);
                if (state == ReaderException.ERROR_SUCCESS)
                    return result;
                throw new ReaderException(state);
            }

            public void TestSJC(int timeoutMs, out byte i_origin, out byte q_origin, out byte size, out byte step)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_TestSJC(m_owner.m_handler, timeoutMs, out i_origin, out q_origin, out size, out step);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public void TestFreqCfg(uint freq, int timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_TestFreqCfg(m_owner.m_handler, freq, timeoutMs);
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }

            public Int16 TestBlPower(byte power, int timeoutMs)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                Int16 result;
                int state = UHF_RFID_API.UHF_RFID_TEST_TestBlPower(m_owner.m_handler, power, timeoutMs, out result);
                if (state == ReaderException.ERROR_SUCCESS)
                    return result;
                throw new ReaderException(state);
            }

            public void TestSensitivity(byte interval, uint count, int timeoutMs, string path)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");
                if (count == 0)
                    throw new ArgumentException("测试次数必须大于0", "count");

                int state = UHF_RFID_API.UHF_RFID_TEST_TestSensitivity(m_owner.m_handler, interval, count, timeoutMs, path);
                if (state != ReaderException.ERROR_SUCCESS)
                    throw new ReaderException(state);
            }

            public void SwitchRfPower(bool open)
            {
                if (m_owner.m_iState == 0)
                    throw new InvalidOperationException("Reader is not open");

                int state = UHF_RFID_API.UHF_RFID_TEST_SwitchRfPower(m_owner.m_handler, (byte)(open ? 1 : 0));
                if (state == ReaderException.ERROR_SUCCESS)
                    return;
                throw new ReaderException(state);
            }
        }

        #endregion
    }
}
