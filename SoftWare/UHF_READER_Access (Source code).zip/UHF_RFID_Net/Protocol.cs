﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net
{
    public enum Protocol
    {
        ISO_18000_63,
        GB_T_29768,
        GJB_7377_1
    }

    public class ProtocolItem
    {
        public static readonly ProtocolItem[] Options = new ProtocolItem[] {
            new ProtocolItem(Protocol.ISO_18000_63),
            new ProtocolItem(Protocol.GB_T_29768),
            new ProtocolItem(Protocol.GJB_7377_1) };

        Protocol m_value;

        public Protocol Value
        {
            get { return m_value; }
        }

        public ProtocolItem(Protocol value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return ProtocolToString(m_value);
        }

        public static string ProtocolToString(Protocol value)
        {
            switch (value)
            {
                case Protocol.ISO_18000_63:
                    return "ISO 18000-63";
                case Protocol.GB_T_29768:
                    return "GB/T 29768";
                case Protocol.GJB_7377_1:
                    return "GJB 7377.1";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }

        public static ProtocolItem OptionFromValue(Protocol protocol)
        {
            foreach (ProtocolItem item in Options)
            {
                if (item.Value == protocol)
                    return item;
            }
            return null;
        }
    }
}
