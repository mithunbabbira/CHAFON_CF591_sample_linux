using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net
{
    unsafe class UHF_RFID_API
    {
        /// <summary>
        /// 盘点到的标签项
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct TagInfo
        {
            /// <summary>
            /// 标签序号
            /// </summary>
            private ushort m_no;
            /// <summary>
            /// RSSI，单位：0.1dBm
            /// </summary>
            private short m_rssi;
            /// <summary>
            /// 天线索引
            /// </summary>
            private byte m_ant;
            /// <summary>
            /// 信道
            /// </summary>
            private byte m_channel;
            /// <summary>
            /// CRC
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            private byte[] m_crc;
            /// <summary>
            /// 标签的PC或编码长度+编码头数据
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            private byte[] m_pc;
            /// <summary>
            /// code中有效数据的长度
            /// </summary>
            private byte m_len;
            /// <summary>
            /// 标签的响应数据，长度255个byte
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 255)]
            private byte[] m_code;

            /// <summary>
            /// 标签序号
            /// </summary>
            public ushort NO
            {
                get { return m_no; }
            }

            /// <summary>
            /// 标签的PC或编码长度+编码头数据，长度2个byte
            /// </summary>
            public byte[] PC
            {
                get { return m_pc; }
            }

            /// <summary>
            /// code中有效数据的长度
            /// </summary>
            public byte CodeLength
            {
                get { return m_len; }
            }

            /// <summary>
            /// 标签的响应数据，长度255个byte
            /// </summary>
            public byte[] Code
            {
                get { return m_code; }
            }

            /// <summary>
            /// RSSI，单位：0.1dBm
            /// </summary>
            public short Rssi
            {
                get { return m_rssi; }
            }

            /// <summary>
            /// 天线接口序号
            /// </summary>
            public byte Antenna
            {
                get { return m_ant; }
            }

            /// <summary>
            /// 信道
            /// </summary>
            public byte Channel
            {
                get { return m_channel; }
            }

            /// <summary>
            /// CRC
            /// </summary>
            public byte[] CRC
            {
                get { return m_crc; }
            }

        }

        [StructLayout(LayoutKind.Sequential)]
        public struct TagResp
        {
            /// <summary>
            /// 标签状态
            /// </summary>
            byte m_tagStatus;
            /// <summary>
            /// 天线索引
            /// </summary>
            byte m_ant;
            /// <summary>
            /// CRC
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            byte[] m_crc;
            /// <summary>
            /// 标签的PC或编码长度+编码头数据
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            byte[] m_pc;
            /// <summary>
            /// code中有效数据的长度
            /// </summary>
            byte m_codeLen;
            /// <summary>
            /// 标签的响应数据，长度255个byte
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 255)]
            byte[] m_code;

            /// <summary>
            /// 标签状态
            /// </summary>
            public byte TagStatus
            {
                get { return m_tagStatus; }
            }

            /// <summary>
            /// 标签的PC或编码长度+编码头数据，长度2个byte
            /// </summary>
            public byte[] PC
            {
                get { return m_pc; }
            }

            /// <summary>
            /// code中有效数据的长度
            /// </summary>
            public byte CodeLength
            {
                get { return m_codeLen; }
            }

            /// <summary>
            /// 标签的响应数据，长度255个byte
            /// </summary>
            public byte[] Code
            {
                get { return m_code; }
            }

            /// <summary>
            /// 天线接口序号
            /// </summary>
            public byte Antenna
            {
                get { return m_ant; }
            }

            /// <summary>
            /// CRC
            /// </summary>
            public byte[] CRC
            {
                get { return m_crc; }
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct CP_Sensi_Prm_Typ
        {
            public uint blf;
            public byte miller;
            public byte trext;
            public ushort rxDelay;
            public ushort rxLen;
            public uint rxNum;
            byte autoMode;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct CP_Sensi_Result_Typ
        {
            public uint frame_err;
            public uint frame_total;
            public uint blf;
            public byte miller;
            public byte trext;
            public byte freqOffset;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct IQ_Axial_Typ
        {
            public byte i_start;
            public byte i_stop;
            public byte q_start;
            public byte q_stop;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct JSC_AUTO_SCAN_PRM_Typ
        {
            public byte i_origin;
            public byte q_origin;
            public byte size;
            public byte step;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct JSC_Data_Typ
        {
            public byte number;
            public byte dataLen;

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 253)]
            public byte[] data;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct Read_Regs_Result_Typ
        {
            public byte items;
            public ushort regs;

            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 126)]
            public ushort[] val;
        }

        [DllImport("UHFPrimeReader.dll", CharSet = CharSet.Ansi)]
        public static extern int OpenDevice(out IntPtr m_hPort, string strComPort,byte Baudrate);

        [DllImport("UHFPrimeReader.dll", CharSet = CharSet.Ansi)]
        public static extern int OpenNetConnection(out IntPtr handler, string ip, ushort port, uint timeoutMs);

        [DllImport("UHFPrimeReader.dll", CharSet = CharSet.Ansi)]
        public static extern int OpenHidConnection(out IntPtr handler,ushort index);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int CloseDevice(IntPtr m_hPort);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int CFHid_GetUsbCount();

        [DllImport("UHFPrimeReader.dll")]
        public static extern bool CFHid_GetUsbInfo(UInt16 iIndex, byte[] pucDeviceInfo);

        [DllImport("UHFPrimeReader.dll")]
        public static extern bool CFHid_OpenDevice(UInt16 iIndex);

        [DllImport("UHFPrimeReader.dll")]
        public static extern bool CFHid_CloseDevice();          // 可以直接用CloseDevice关闭，只是为了适配接口

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetInfo(IntPtr m_hPort, out DeviceInfo devInfo);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetDeviceInfo(IntPtr m_hPort, out DeviceFullInfo devInfo);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetDevicePara(IntPtr m_hPort, out Devicepara devInfo);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetDevicePara(IntPtr m_hPort,  Devicepara devInfo);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetPermissonPara(IntPtr m_hPort, out PermissonPara PermissonPara);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetPermissonPara(IntPtr m_hPort, PermissonPara PermissonPara);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetLongPermissonPara(IntPtr m_hPort, out LongPermissonPara PermissonPara);
        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetLongPermissonPara(IntPtr m_hPort, LongPermissonPara PermissonPara);
        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetGpioPara(IntPtr m_hPort, out GpioPara GpioPara);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetGpioPara(IntPtr m_hPort, GpioPara GpioPara);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetwifiPara(IntPtr m_hPort, out wifiPara wifiPara);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetwifiPara(IntPtr m_hPort, wifiPara wifiPara);
        [DllImport("UHFPrimeReader.dll")]
        public static extern int RebootDevice(IntPtr m_hPort);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetDeviceSta(IntPtr m_hPort, out ushort info1);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetRFPower(IntPtr hComm, byte power, byte reserved);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetRFPower(IntPtr hComm, out byte power, out byte reserved);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int Release_Relay(IntPtr hComm, byte time);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int Close_Relay(IntPtr hComm, byte time);


        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetFreq(IntPtr hComm, ref FreqInfo frqInfo);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetFreq(IntPtr hComm, out FreqInfo freqInfo);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetAntenna(IntPtr hComm, ref byte antenna);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetAntenna(IntPtr hComm, out byte antenna);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetModu(IntPtr hComm, byte modu);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetModu(IntPtr hComm, out byte modu);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetRFIDType(IntPtr hComm, byte type);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetRFIDType(IntPtr hComm, out byte type);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SaveSetting(IntPtr hComm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int RestoreSetting(IntPtr hComm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetRFIcReg(IntPtr hComm, [In] RfIcReg* regs, byte regNum);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetRFIcReg(IntPtr hComm, [In, Out] RfIcReg* regs, byte regNum);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetNetInfo(IntPtr handler,out NetInfo tempLimit);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetNetInfo(IntPtr handler, NetInfo resv);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetRemoteNetInfo(IntPtr handler, out RemoteNetInfo tempLimit);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetRemoteNetInfo(IntPtr handler, RemoteNetInfo resv);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetTemperature(IntPtr handler, out byte tempCur, out byte tempLimit);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetTemperature(IntPtr handler, byte tempLimit, byte resv);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetPowerDelta(IntPtr handler, out DeltaPara tempLimit);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetPowerDelta(IntPtr handler, DeltaPara resv);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetSleepTime(IntPtr handler, out ushort sleepTime);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetSleepTime(IntPtr handler, ushort sleepTime, byte resv);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetNetworkInfo(IntPtr handler, out uint ip, out uint mask, out uint ipGateway, out ushort port);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetNetworkInfo(IntPtr handler, uint ip, uint mask, uint ipGateway, ushort port);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetDuty(IntPtr handler, out byte interval, out int delayTime);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetDuty(IntPtr handler, byte interval, int delayTime);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int Update(IntPtr hComm, ushort type, ushort len, [In] byte[] pParam, ushort timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int RecvUpdate(IntPtr hComm, ushort type, out byte status, ushort timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SendSingeFrame(IntPtr hComm, ushort type, ushort len, [In] byte[] pParam, ushort timeout);
        [DllImport("UHFPrimeReader.dll")]
        public static extern int RecvSingeFrame(IntPtr hComm, ushort type, out byte status, ushort timeout,out int len,[Out] byte[] data);
        [DllImport("UHFPrimeReader.dll")]
        public static extern int SelectOrSortSet(IntPtr hComm, byte prot, [In] ref SelectSortParam param);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SelectOrSortGet(IntPtr hComm, byte proto, out SelectSortParam param);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int QueryCfgSet(IntPtr hComm, byte proto, [In] ref UHF_RFID_Net.QueryParam param);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int QueryCfgGet(IntPtr hComm, byte proto, out QueryParam param);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_SetRFParam(IntPtr hComm, ref GB.RfParam prm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_GetRFParam(IntPtr hComm, out GB.RfParam prm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_GetSortPRM(IntPtr hComm, out GB.SortParam sortParam);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_SetSortPRM(IntPtr hComm, [In] ref GB.SortParam sortParam);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_GetQueryPRM(IntPtr hComm, out GB.QueryParam queryParam);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_SetQueryPRM(IntPtr hComm, ref GB.QueryParam queryParam);

        [DllImport("UHFPrimeReader.dll", EntryPoint="UHF_RFID_GB_SetRFParam")]
        public static extern int UHF_RFID_GJB_SetRFParam(IntPtr hComm, ref GJB.RfParam prm);

        [DllImport("UHFPrimeReader.dll", EntryPoint = "UHF_RFID_GB_GetRFParam")]
        public static extern int UHF_RFID_GJB_GetRFParam(IntPtr hComm, out GJB.RfParam prm);

        [DllImport("UHFPrimeReader.dll", EntryPoint = "UHF_RFID_GB_GetSortPRM")]
        public static extern int UHF_RFID_GJB_GetSortPRM(IntPtr hComm, out GJB.SortParam sortParam);

        [DllImport("UHFPrimeReader.dll", EntryPoint = "UHF_RFID_GB_SetSortPRM")]
        public static extern int UHF_RFID_GJB_SetSortPRM(IntPtr hComm, [In] ref GJB.SortParam sortParam);

        [DllImport("UHFPrimeReader.dll", EntryPoint = "UHF_RFID_GB_GetQueryPRM")]
        public static extern int UHF_RFID_GJB_GetQueryPRM(IntPtr hComm, out GJB.QueryParam queryParam);

        [DllImport("UHFPrimeReader.dll", EntryPoint = "UHF_RFID_GB_SetQueryPRM")]
        public static extern int UHF_RFID_GJB_SetQueryPRM(IntPtr hComm, ref GJB.QueryParam queryParam);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_SetCoilPRM(IntPtr hComm, byte cin, byte ccn, byte reserved);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_GetCoilPRM(IntPtr hComm, out byte cin, out byte ccn, out byte reserved);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_SaveSetting(IntPtr hComm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_InventoryContinue(IntPtr hComm, byte invCount, uint invParam);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_GetTagUii(IntPtr hComm, out TagInfo tag_info, ushort timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_InventoryStop(IntPtr hComm, ushort timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_ReadTag(IntPtr hComm, byte option, [In] byte[] accPwd, byte memBank, ushort wordPtr, ushort wordCount);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_GetReadTagResp(IntPtr hComm, out TagResp resp, out byte wordCount, [Out] byte[] readData, ushort timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_GetTagResp(IntPtr hComm, byte cmd, out TagResp resp, ushort timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_WriteTag(IntPtr hComm, byte option, [In] byte[] accPwd, byte memBank, ushort wordPtr, byte wordCount, [In] byte[] writeData);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_EraseTag(IntPtr hComm, byte option, [In] byte[] accPwd, byte memBank, ushort wordPtr, byte wordCount);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_LockTag(IntPtr hComm, [In] byte[] accPwd, byte memBank, byte config, byte action);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_KillTag(IntPtr hComm, [In] byte[] accPwd);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_Sparm(IntPtr hComm, [Out] byte[] secPara, [Out] byte[] TID);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_MSAuth(IntPtr hComm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_TestTrans(IntPtr hComm, byte option, byte count, ushort dataLen, [In] byte[] data, out ushort reLen, [Out] byte[] reData);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_GB_SetSortMask(IntPtr hComm, ushort maskPtr, byte maskBits, [In] byte[] mask);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetRFParam(IntPtr hComm, byte proto, byte prm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetRFParam(IntPtr hComm, byte proto, out byte prm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetSelectPRM(IntPtr hComm, ref ISO.SelectParam prm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetSelectPRM(IntPtr hComm, out ISO.SelectParam prm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetQueryPRM(IntPtr hComm, out ISO.QueryParam queryParam);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetQueryPRM(IntPtr hComm, [In] ref ISO.QueryParam queryParam);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetCoilPRM(IntPtr hComm, byte qVal, byte reserved);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetCoilPRM(IntPtr hComm, out byte pqVal, out byte reserved);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int ISO_SaveSetting(IntPtr hComm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int InventoryContinue(IntPtr hComm, byte invCount, uint invParam);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetTagUii(IntPtr hComm, out TagInfo tag_info, ushort timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int InventoryStop(IntPtr hComm, ushort timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int ReadTag(IntPtr hComm, byte option, [In] byte[] accPwd, byte memBank, ushort wordPtr, ushort wordCount);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetReadTagResp(IntPtr hComm, out TagResp resp, out byte wordCount, [Out] byte[] readData, ushort timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int GetTagResp(IntPtr hComm, ushort cmd, out TagResp resp, ushort timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int WriteTag(IntPtr hComm, byte option, [In] byte[] accPwd, byte memBank, ushort wordPtr, byte wordCount, [In] byte[] writeData);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int LockTag(IntPtr hComm, [In] byte[] accPwd, byte erea, byte action);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int KillTag(IntPtr hComm, [In] byte[] accPwd);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int BlockWriteTag(IntPtr hComm, byte option, [In] byte[] accPwd,
            byte memBank, ushort wordPtr, ref ushort wordCount, [In] byte* writeData);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int BlockEraseTag(IntPtr hComm, byte option, [In] byte[] accPwd, byte memBank, ushort wordPtr, ref ushort wordCount);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int BlockPermalock(IntPtr hComm, [In] byte[] accPwd, [In] ref ISO.PermalockParam prm, ref byte rspBitLen, [Out] byte[] rspData);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int Sparm(IntPtr hComm, [Out] byte[] secPara, [Out] byte[] TID);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int MSAuth(IntPtr hComm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int TestTrans(IntPtr hComm, byte option, byte count, ushort dataLen, [In] byte[] data, out ushort reLen, [Out] byte[] reData);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int SetSelectMask(IntPtr hComm, ushort maskPtr, byte maskBits, [In] byte[] mask);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_CP_Init(IntPtr hComm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_CP_SensTest(IntPtr hComm, byte protocolTyp, [In] ref CP_Sensi_Prm_Typ prm, out CP_Sensi_Result_Typ result);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_CP_Query(IntPtr hComm, byte btPrtclTyp, byte btPwr, [In] ref FreqInfo freq,
            byte btTariTc, byte modu, byte depth, byte rspLen, [Out] byte[] pRspData);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_CP_ManuSJC(IntPtr hComm, [In] ref IQ_Axial_Typ axial);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_CP_AutoSJC(IntPtr hComm, [In] ref JSC_AUTO_SCAN_PRM_Typ prm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_CP_GetSJCData(IntPtr hComm, byte btCmdTyp, out JSC_Data_Typ pRspData, int timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_EnterShell(IntPtr hComm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_BatchReadWriteRegs(IntPtr hComm, byte btCmdCnt, [In] ReadWriteRegItem* pCmds, out Read_Regs_Result_Typ pRslt);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_SetWatchCR(IntPtr hComm, ushort wCnt);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_SwitchWatchCR(IntPtr hComm, ushort wAddr, byte btCtrl);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_ReadCRLog(IntPtr hComm, out ushort loseCount, ref byte pItemsCnt, [Out] CRLogItem* pItems);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_SetWatchInt(IntPtr hComm, ushort wCnt);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_SwitchWatchInt(IntPtr hComm, byte btCtrl);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_ReadIntStatus(IntPtr hComm, out ushort loseCount, ref byte pItemsCnt, [Out] IntStatusItem* pItems);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_SetWatchFifo(IntPtr hComm, ushort wLen);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_SwitchWatchFifo(IntPtr hComm, byte btCtrl);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_ReadFifo(IntPtr hComm, out uint pLose, ref byte pDataLen, [Out] byte* pRspData);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_SetLogLen(IntPtr hComm, ushort wLen);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_ReadLog(IntPtr hComm);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_GetReadLogResp(IntPtr hComm, out byte pDataLen, [Out] byte[] pRspData, ushort timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_SwitchSelect(IntPtr hComm, byte use);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_ContinueSendData(IntPtr hComm, ushort wTime, byte btRnd, byte btData);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_Test1(IntPtr hComm, byte len, [In] byte[] pParam);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_Test2(IntPtr hComm, byte len, [In] byte[] pParam, [In, Out] ref byte pRespLen, [Out] byte[] pResp);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_TestTxPower(IntPtr hComm, byte power, int timeout, out sbyte pResult);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_TestSJC(IntPtr hComm, int timeout, out byte i_origin, out byte q_origin, out byte size, out byte step);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_TestFreqCfg(IntPtr hComm, uint freq, int timeout);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_TestBlPower(IntPtr hComm, byte power, int timeout, out Int16 pResult);

        [DllImport("UHFPrimeReader.dll", CharSet=CharSet.Unicode)]
        public static extern int UHF_RFID_TEST_TestSensitivity(IntPtr hComm, byte interval, uint count, int timeout, string path);

        [DllImport("UHFPrimeReader.dll")]
        public static extern int UHF_RFID_TEST_SwitchRfPower(IntPtr hComm, byte on);


        [DllImport("kernel32")]
        //                        读配置文件方法的6个参数：所在的分区（section）、键值、     初始缺省值、     StringBuilder、   参数长度上限、配置文件路径
        private static extern int GetPrivateProfileString(string section, string key, string deVal, StringBuilder retVal,
int size, string filePath);

        [DllImport("kernel32")]
        //                            写配置文件方法的4个参数：所在的分区（section）、  键值、     参数值、        配置文件路径
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        //保存参数
        public void SetValue(string section, string key, string value)
        {
            //获得当前路径，当前是在Debug路径下
            string strPath = Environment.CurrentDirectory + "\\system.ini";
            WritePrivateProfileString(section, key, value, strPath);
        }

        //读取参数
        public string GetValue(string section, string key)
        {
            StringBuilder sb = new StringBuilder(255);
            string strPath = Environment.CurrentDirectory + "\\system.ini";
            //最好初始缺省值设置为非空，因为如果配置文件不存在，取不到值，程序也不会报错
            GetPrivateProfileString(section, key, "配置文件不存在，未取到参数", sb, 255, strPath);
            return sb.ToString();
        }

        //删除参数
        public void DelValue(string section)
        {
            //获得当前路径，当前是在Debug路径下
            string strPath = Environment.CurrentDirectory + "\\system.ini";
            WritePrivateProfileString(section, null, null, strPath);
        }

    }
}
