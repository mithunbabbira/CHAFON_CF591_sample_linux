using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net
{
    public class ReaderException : Exception
    {
        /// <summary>
        /// 执行成功
        /// </summary>
        public static readonly int ERROR_SUCCESS = 0x00;
        /// <summary>
        /// 句柄错误
        /// </summary>
        public static readonly int ERROR_HANDLE_ERROR = -255;
        /// <summary>
        /// 打开串口或建立网络连接失败
        /// </summary>
        public static readonly int ERROR_OPEN_FAILED = -254;
        /// <summary>
        /// 动态库内部错误
        /// </summary>
        public static readonly int ERROR_DLL_INNER_ERROR = -253;
        /// <summary>
        /// 参数值错误或越界，或者模块不支持该参数值
        /// </summary>
        public static readonly int ERROR_CMD_PARAM_ERROR = -252;
        /// <summary>
        /// 序列号已存在
        /// </summary>
        public static readonly int ERROR_CMD_SERIAL_NUM_EXISTS = -251;
        /// <summary>
        /// 由于模块内部错误导致命令执行失败
        /// </summary>
        public static readonly int ERROR_CMD_INTERNAL_ERROR = -250;
        /// <summary>
        /// 没有盘点到标签或盘点已结束
        /// </summary>
        public static readonly int ERROR_CMD_NO_TAG = -249;
        /// <summary>
        /// 标签响应超时
        /// </summary>
        public static readonly int ERROR_CMD_TAG_RESP_TIMEOUT = -248;
        /// <summary>
        /// 解调标签数据错误
        /// </summary>
        public static readonly int ERROR_CMD_TAG_RESP_COLLISION = -247;
        /// <summary>
        /// 标签数据超出最大传输长度
        /// </summary>
        public static readonly int ERROR_CMD_CODE_OVERFLOW = -246;
        /// <summary>
        /// 认证失败
        /// </summary>
        public static readonly int ERROR_CMD_AUTH_FAILED = -245;
        /// <summary>
        /// 口令错误
        /// </summary>
        public static readonly int ERROR_CMD_PWD_ERROR = -244;
        /// <summary>
        /// SAM卡无响应
        /// </summary>
        public static readonly int ERROR_CMD_SAM_NO_RESP = -243;
        /// <summary>
        /// PSAM卡命令执行失败
        /// </summary>
        public static readonly int ERROR_CMD_SAM_CMD_FAILED = -242;
        /// <summary>
        /// 读写器响应格式错误
        /// </summary>
        public static readonly int ERROR_CMD_RESP_FORMAT_ERROR = -241;
        /// <summary>
        /// 命令执行成功，但是还有后续数据未传输完成
        /// </summary>
        public static readonly int ERROR_CMD_HAS_MORE_DATA = -240;
        /// <summary>
        /// 传入缓存太小，数据溢出
        /// </summary>
        public static readonly int ERROR_CMD_BUF_OVERFLOW = -239;
        /// <summary>
        /// 等待阅读器响应超时
        /// </summary>
        public static readonly int ERROR_CMD_COMM_TIMEOUT = -238;
        /// <summary>
        /// 向读写器写数据失败
        /// </summary>
        public static readonly int ERROR_CMD_COMM_WRITE_FAILED = -237;
        /// <summary>
        /// 从读写器读数据失败
        /// </summary>
        public static readonly int ERROR_CMD_COMM_READ_FAILED = -236;
        /// <summary>
        /// 所有数据已传输完毕
        /// </summary>
        public static readonly int ERROR_CMD_NOMORE_DATA = -235;
        /// <summary>
        /// 网络连接尚未建立
        /// </summary>
        public static readonly int ERROR_DLL_UNCONNECT = -234;
        /// <summary>
        /// 网络连接已经断开
        /// </summary>
        public static readonly int ERROR_DLL_DISCONNECT = -233;
        /// <summary>
        /// 接收响应CRC校验错误
        /// </summary>
        public static readonly int ERROR_CMD_RESP_CRC_ERROR = -232;

        /// <summary>
        /// 国标标签错误：供电不足，标签没有足够的能量完成操作
        /// </summary>
        public static readonly int ERROR_GB_TAG_LOW_POWER = -192;
        /// <summary>
        /// 国标标签错误：权限不足，未授权的访问
        /// </summary>
        public static readonly int ERROR_GB_TAG_OPR_LIMIT = -191;
        /// <summary>
        /// 国标标签错误：存储区溢出，或目标存储区不存在
        /// </summary>
        public static readonly int ERROR_GB_TAG_MEM_OVF = -190;
        /// <summary>
        /// 国标标签错误：存储区锁定，对被锁定为不可写的存储区进行写操作或者擦除操作，对被锁定为不可读的存储区进行读操作
        /// </summary>
        public static readonly int ERROR_GB_TAG_MEM_LCK = -189;
        /// <summary>
        /// 国标标签错误：口令错误，访问命令口令错误
        /// </summary>
        public static readonly int ERROR_GB_TAG_PWD_ERR = -188;
        /// <summary>
        /// 国标标签错误：鉴别失败，未通过鉴别
        /// </summary>
        public static readonly int ERROR_GB_TAG_AUTH_FAIL = -187;
        /// <summary>
        /// 国标标签错误：未知错误，发生不能确定的错误
        /// </summary>
        public static readonly int ERROR_GB_TAG_UNKNW_ERR = -186;
        
        /// <summary>
        /// ISO标签错误：其他错误
        /// </summary>
        public static readonly int ERROR_ISO_TAG_OTHER_ERR =-176;
        /// <summary>
        /// ISO标签错误：标签不支持该参数
        /// </summary>
        public static readonly int ERROR_ISO_TAG_NOT_SUPPORT =-175;
        /// <summary>
        /// ISO标签错误：权限不足
        /// </summary>
        public static readonly int ERROR_ISO_TAG_OPR_LIMIT =-174;
        /// <summary>
        /// ISO标签错误：存储区溢出
        /// </summary>
        public static readonly int ERROR_ISO_TAG_MEM_OVF =-173;
        /// <summary>
        /// ISO标签错误：存储区锁定
        /// </summary>
        public static readonly int ERROR_ISO_TAG_MEM_LCK =-172;
        /// <summary>
        /// ISO标签错误：标签加密套件错误
        /// </summary>
        public static readonly int ERROR_ISO_TAG_CRYPTO_ERR =-171;
        /// <summary>
        /// ISO标签错误：空口命令未封装
        /// </summary>
        public static readonly int ERROR_ISO_TAG_NOT_ENCAP =-170;
        /// <summary>
        /// ISO标签错误：标签响应缓存溢出
        /// </summary>
        public static readonly int ERROR_ISO_TAG_RESP_OVF =-169;
        /// <summary>
        /// ISO标签错误：标签处于安全超时状态
        /// </summary>
        public static readonly int ERROR_ISO_TAG_SEC_TIMEOUT =-168;
        /// <summary>
        /// ISO标签错误：供电不足
        /// </summary>
        public static readonly int ERROR_ISO_TAG_LOW_POWER =-167;
        /// <summary>
        /// ISO标签错误：标签响应未知错误
        /// </summary>
        public static readonly int ERROR_ISO_TAG_UNKNW_ERR =-166;
        /// <summary>
        /// ISO标签错误：传感器定时任务配置超出上限
        /// </summary>
        public static readonly int ERROR_ISO_TAG_SENSOR_CFG =-165;
        /// <summary>
        /// ISO标签错误：标签繁忙
        /// </summary>
        public static readonly int ERROR_ISO_TAG_TAG_BUSY =-164;
        /// <summary>
        /// ISO标签错误：传感器不支持该测量类型
        /// </summary>
        public static readonly int ERROR_ISO_TAG_MEASU_NOT_SUPPORT =-163;

        private static readonly ErrorItem[] s_arrErrs = new ErrorItem[] { 
         new ErrorItem(ERROR_SUCCESS, "执行成功"),
         new ErrorItem(ERROR_HANDLE_ERROR, "句柄错误或参数错误"),
         new ErrorItem(ERROR_OPEN_FAILED, "打开读写器失败"),
         new ErrorItem(ERROR_DLL_INNER_ERROR, "动态库内部错误"),
         new ErrorItem(ERROR_CMD_RESP_FORMAT_ERROR, "读写器响应数据格式错误"),
         new ErrorItem(ERROR_CMD_RESP_CRC_ERROR, "读写器响应CRC校验错误"),
         new ErrorItem(ERROR_CMD_BUF_OVERFLOW, "传入缓存太小，数据溢出"),
         new ErrorItem(ERROR_CMD_COMM_TIMEOUT, "Waiting for Reader TimeOut"),
         new ErrorItem(ERROR_CMD_COMM_WRITE_FAILED, "向读写器写入数据时发生错误"),
         new ErrorItem(ERROR_CMD_COMM_READ_FAILED, "从读写器读取数据时发生错误"),
         new ErrorItem(ERROR_CMD_HAS_MORE_DATA, "后续数据尚未传输完成"),
         new ErrorItem(ERROR_DLL_UNCONNECT, "网络连接尚未建立"),
         new ErrorItem(ERROR_DLL_DISCONNECT, "网络连接已经断开"),
         new ErrorItem(ERROR_CMD_PARAM_ERROR, "参数值错误或越界，或者模块不支持该参数值"),
         new ErrorItem(ERROR_CMD_SERIAL_NUM_EXISTS, "序列号已存在"),
         new ErrorItem(ERROR_CMD_INTERNAL_ERROR, "阅读器执行命令失败"),
         new ErrorItem(ERROR_CMD_NO_TAG, "没有盘点到标签"),
         new ErrorItem(ERROR_CMD_TAG_RESP_TIMEOUT, "等待标签响应超时"),
         new ErrorItem(ERROR_CMD_TAG_RESP_COLLISION, "解调标签数据错误"),
         new ErrorItem(ERROR_CMD_AUTH_FAILED, "认证失败"),
         new ErrorItem(ERROR_CMD_PWD_ERROR, "口令错误"),
         new ErrorItem(ERROR_CMD_SAM_NO_RESP, "访问PSAM时，PSAM没有响应"),
         new ErrorItem(ERROR_CMD_COMM_TIMEOUT, "访问PSAM时，PSAM返回错误响应"),
         new ErrorItem(ERROR_GB_TAG_LOW_POWER, "标签错误：供电不足，没有足够的能量完成操作"),
         new ErrorItem(ERROR_GB_TAG_OPR_LIMIT, "标签错误：权限不足，未授权的访问"),
         new ErrorItem(ERROR_GB_TAG_MEM_OVF, "标签错误：存储区溢出，或目标存储区不存在"),
         new ErrorItem(ERROR_GB_TAG_MEM_LCK, "标签错误：存储区锁定，对被锁定为不可写的存储区进行写操作或者擦除操作，对被锁定为不可读的存储区进行读操作"),
         new ErrorItem(ERROR_GB_TAG_PWD_ERR, "标签错误：口令错误，访问命令口令错误"),
         new ErrorItem(ERROR_GB_TAG_AUTH_FAIL, "标签错误：鉴别失败，未通过鉴别"),
         new ErrorItem(ERROR_GB_TAG_UNKNW_ERR, "标签错误：未知错误，发生不能确定的错误"),
         new ErrorItem(ERROR_ISO_TAG_OTHER_ERR, "标签错误：标签发生其他类型的错误"),
         new ErrorItem(ERROR_ISO_TAG_NOT_SUPPORT, "标签错误：标签不支持这些参数"),
         new ErrorItem(ERROR_ISO_TAG_OPR_LIMIT, "标签错误：权限不足，未授权的访问"),
         new ErrorItem(ERROR_ISO_TAG_MEM_OVF, "标签错误：存储区溢出，或目标存储区不存在"),
         new ErrorItem(ERROR_ISO_TAG_MEM_LCK, "标签错误：存储区被锁定"),
         new ErrorItem(ERROR_ISO_TAG_CRYPTO_ERR, "标签错误：加密套件错误"),
         new ErrorItem(ERROR_ISO_TAG_NOT_ENCAP, "标签错误：空口命令未封装"),
         new ErrorItem(ERROR_ISO_TAG_RESP_OVF, "标签错误：标签响应缓存移出"),
         new ErrorItem(ERROR_ISO_TAG_SEC_TIMEOUT, "标签错误：标签当前处于安全超时状态"),
         new ErrorItem(ERROR_ISO_TAG_LOW_POWER, "标签错误：供电不足，没有足够的能量完成操作"),
         new ErrorItem(ERROR_ISO_TAG_UNKNW_ERR, "标签错误：未知错误，发生不能确定的错误"),
         new ErrorItem(ERROR_ISO_TAG_SENSOR_CFG, "标签错误：传感器定时任务个数超出上限"),
         new ErrorItem(ERROR_ISO_TAG_TAG_BUSY, "标签错误：标签当前处于繁忙状态"),
         new ErrorItem(ERROR_ISO_TAG_MEASU_NOT_SUPPORT, "标签错误：传感器不支持该测量类型") };

        /// <summary>
        /// 错误码
        /// </summary>
        private int m_iErroCode = 0;

        /// <summary>
        /// 错误码
        /// </summary>
        public int ErrorCode
        {
            get { return m_iErroCode; }
        }

        public ReaderException()
            : this(ERROR_SUCCESS)
        {
        }

        public ReaderException(int errorCode)
            : this(errorCode, MessageFromErrorCode(errorCode))
        {
        }

        public ReaderException(int errorCode, string message)
            : base(message)
        {
            this.m_iErroCode = errorCode;
        }

        public static string MessageFromErrorCode(int errorCode)
        {
            for (int i = 0; i < s_arrErrs.Length; i++)
            {
                if (s_arrErrs[i].ErrorCode == errorCode)
                    return s_arrErrs[i].Message;
            }
            return "未知错误码：" + errorCode;
        }

        private struct ErrorItem
        {
            public int ErrorCode;
            public string Message;

            public ErrorItem(int errorCode, string message)
            {
                this.ErrorCode = errorCode;
                this.Message = message;
            }
        }
    }
}
