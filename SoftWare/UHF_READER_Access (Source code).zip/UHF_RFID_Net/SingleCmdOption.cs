﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net
{
    /// <summary>
    /// 命令接收选项
    /// </summary>
    [Flags]
    public enum SingleCmdOption : byte
    {
        /// <summary>
        /// 发送该空口命令之后，是否需要接收空口响应数据，0：不接收；1：接收
        /// </summary>
        NeedRecv = 0x01,
        /// <summary>
        /// 响应数据长度是否固件，0：不固定长度，1：固定长度
        /// </summary>
        RespFixedLen = 0x02,
        /// <summary>
        /// 发送该空口命令之前，是否需要先执行盘点和Get_RN操作，0：不需要；1：需要
        /// </summary>
        Inventory = 0x04,
        /// <summary>
        /// 向标签透传数据时，是否在发送数据后面追加句柄（handle），0：不追加；1：追加
        /// </summary>
        AppendTagHandler = 0x08,
        /// <summary>
        /// 向标签发送数据时，是否在发送数据后面追加CRC16，0：不追加；1：追加
        /// </summary>
        AppendCrc = 0x10,
        /// <summary>
        /// 是否需要检查标签响应数据CRC16，0：不检查；1：将标签响应最后两字节作为CRC16，并检查CRC16是否正确
        /// </summary>
        RecvHasCrc = 0x20
    }
}
