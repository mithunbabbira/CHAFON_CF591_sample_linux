using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace UHF_RFID_Net
{

    //[StructLayout(LayoutKind.Sequential)]
    //public struct PARA
    //{

    //    private byte RFIDPRO;
    //    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    //    private byte[] STRATFREI;
    //    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    //    private byte[] STRATFRED;
    //    [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
    //    private byte[] STEPFRE;
    //    private byte CN;
    //    private byte POWER;
    //    private byte ANTENNA;
    //    private byte REGION;
    //    private byte RESERVED;

    //}
    /// <summary>
    /// 设备参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct Devicepara
    {

        private byte DEVICEARRD;
        private byte RFIDPRO;
        private byte WORKMODE;
        private byte INTERFACE;
        private byte BAUDRATE;
        private byte WGSET;
        private byte ANT;
        private byte REGION;
        private ushort STRATFREI;
        private ushort STRATFRED;
        private ushort STEPFRE;
        private byte CN;
        private byte RFIDPOWER;
        private byte INVENTORYAREA;
        private byte QVALUE;
        private byte SESSION;
        private byte ACSADDR;
        private byte ACSDATALEN;
        private byte FILTERTIME;
        private byte TRIGGLETIME;
        private byte BUZZERTIME;
        private byte INTERNELTIME;
        public byte Addr
        {
            get { return DEVICEARRD; }
            set { DEVICEARRD = value; }
        }
        public byte Protocol
        {
            get { return RFIDPRO; }
            set { RFIDPRO = value; }
        }
        public byte Baud
        {
            get { return BAUDRATE; }
            set { BAUDRATE = value; }
        }
        public byte Workmode
        {
            get { return WORKMODE; }
            set { WORKMODE = value; }
        }
        public byte port
        {
            get { return INTERFACE; }
            set { INTERFACE = value; }
        }
        public byte wieggand
        {
            get { return WGSET; }
            set { WGSET = value; }
        }
        public byte Ant
        {
            get { return ANT; }
            set { ANT = value; }
        }
        public byte Region
        {
            get { return REGION; }
            set { REGION = value; }
        }
        public byte Channel
        {
            get { return CN; }
            set { CN = value; }
        }
        public byte Power
        {
            get { return RFIDPOWER; }
            set { RFIDPOWER = value; }
        }
        public byte Area
        {
            get { return INVENTORYAREA; }
            set { INVENTORYAREA = value; }
        }
        public byte Q
        {
            get { return QVALUE; }
            set { QVALUE = value; }
        }
        public byte Session
        {
            get { return SESSION; }
            set { SESSION = value; }
        }
        public byte Startaddr
        {
            get { return ACSADDR; }
            set { ACSADDR = value; }
        }
        public byte DataLen
        {
            get { return ACSDATALEN; }
            set { ACSDATALEN = value; }
        }
        public byte Filtertime
        {
            get { return FILTERTIME; }
            set { FILTERTIME = value; }
        }
        public byte Triggletime
        {
            get { return TRIGGLETIME; }
            set { TRIGGLETIME = value; }
        }
        public byte Buzzertime
        {
            get { return BUZZERTIME; }
            set { BUZZERTIME = value; }
        }
        public byte IntenelTime
        {
            get { return INTERNELTIME; }
            set { INTERNELTIME = value; }
        }

        public ushort StartFreq
        {
            get {

                return (ushort)(STRATFREI >> 8 | STRATFREI << 8);

            }
            set {
                STRATFREI = (ushort)(value >> 8 | value << 8);          //大小端转换
            }
        }
        public ushort StartFreqde
        {
            get { return (ushort)(STRATFRED >> 8 | STRATFRED << 8); }
            set {
                STRATFRED = (ushort)(value >> 8 | value << 8);          //大小端转换
            }
        }
        public ushort Stepfreq
        {
            get { return (ushort)(STEPFRE >> 8 | STEPFRE << 8); }
            set { STEPFRE = (ushort)(value >> 8 | value << 8);          //大小端转换 
                }
            }
    };

    /// <summary>
    /// 设备参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct PermissonPara
    {
        private byte CodeEn;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        private byte[] Code;
        private byte MaskEn;
        private byte StartAdd;
        private byte MaskLen;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        private byte[] MaskData;
        private byte MaskCondition;


        public byte CODEEN
        {
            get { return CodeEn; }
            set { CodeEn = value; }
        }
        public byte MASKEN
        {
            get { return MaskEn; }
            set { MaskEn = value; }
        }
        public byte STARTADD
        {
            get { return StartAdd; }
            set { StartAdd = value; }
        }
        public byte MASKLEN
        {
            get { return MaskLen; }
            set { MaskLen = value; }
        }
        public byte MASKCONDITION
        {
            get { return MaskCondition; }
            set { MaskCondition = value; }
        }

        /// <summary>
        /// 密码数据
        /// </summary>
        public byte[] CODE
        {
            get { return Code; }
            set
            {
                Code = value;
            }
        }


        /// <summary>
        /// 掩码数据
        /// </summary>
        public byte[] MASKDATA
        {
            get { return MaskData; }
            set
            {
                MaskData = value;
            }
        }
    };


    /// <summary>
    /// 设备参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct LongPermissonPara
    {
        private byte CodeEn;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        private byte[] Code;
        private byte MaskEn;
        private byte StartAdd;
        private byte MaskLen;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 31)]
        private byte[] MaskData;
        private byte MaskCondition;


        public byte CODEEN
        {
            get { return CodeEn; }
            set { CodeEn = value; }
        }
        public byte MASKEN
        {
            get { return MaskEn; }
            set { MaskEn = value; }
        }
        public byte STARTADD
        {
            get { return StartAdd; }
            set { StartAdd = value; }
        }
        public byte MASKLEN
        {
            get { return MaskLen; }
            set { MaskLen = value; }
        }
        public byte MASKCONDITION
        {
            get { return MaskCondition; }
            set { MaskCondition = value; }
        }

        /// <summary>
        /// 密码数据
        /// </summary>
        public byte[] CODE
        {
            get { return Code; }
            set
            {
                Code = value;
            }
        }


        /// <summary>
        /// 掩码数据
        /// </summary>
        public byte[] MASKDATA
        {
            get { return MaskData; }
            set
            {
                MaskData = value;
            }
        }
    };


    /// <summary>
    /// 设备参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct GpioPara
    {
        private byte KCEn;
        private byte RelayTime;
        private byte RelayPowerEn;
        private byte Trigglemode;
        private byte BufferEn;
        private byte ProtocolEn;
        private byte ProtocolType;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
        private byte[] ProtocolFormat;
        
        public byte KCEN
        {
            get { return KCEn; }
            set { KCEn = value; }
        }
        public byte RELAYTIME
        {
            get { return RelayTime; }
            set { RelayTime = value; }
        }
        public byte BUFFEREN
        {
            get { return BufferEn; }
            set { BufferEn = value; }
        }
        public byte PROTOCOLEN
        {
            get { return ProtocolEn; }
            set { ProtocolEn = value; }
        }
        public byte PROROCOLTYPE
        {
            get { return ProtocolType; }
            set { ProtocolType = value; }
        }
        public byte KCPowerEn
        {
            get { return RelayPowerEn; }
            set { RelayPowerEn = value; }
        }
        public byte TriggleMode
        {
            get { return Trigglemode; }
            set { Trigglemode = value; }
        }

        /// <summary>
        /// 协议格式
        /// </summary>
        public byte[] PROFORMAT
        {
            get { return ProtocolFormat; }
            set
            {
                ProtocolFormat = value;
            }
        }
    };


    /// <summary>
    /// 设备参数
    /// </summary>
    [StructLayout(LayoutKind.Sequential)]
    public struct wifiPara
    {
        private byte wifiEn;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        private byte[] SSID;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
        private byte[] PASSWORD;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        private byte[] IP;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        private byte[] PORT;


        public byte WiFiEn
        {
            get { return wifiEn; }
            set { wifiEn = value; }
        }
        public byte[] Ssid
        {
            get
            {
                return SSID;
            }
            set
            {
                SSID = value;
            }
        }
        public byte[] Password
        {
            get
            {
                return PASSWORD;
            }
            set
            {
                PASSWORD = value;
            }
        }

        public long wifi_ip
        {
            get
            {
                long temp;
                temp = IP[0];
                temp += IP[1] << 8;
                temp += IP[2] << 0x10;
                temp += IP[3] << 0x18;
                return temp & 0xFFFFFFFF;
            }
            set
            {
                IP = BitConverter.GetBytes(value);
            }
        }
        /// <summary>
        /// 设备端口号
        /// </summary>
        public ushort wifi_port
        {
            get
            {
                long temp;
                temp = PORT[0] << 8;
                temp += PORT[1];
                return (ushort)temp;
            }
            set
            {
                PORT = BitConverter.GetBytes(value);     // BitConverter 默认小端
                Array.Reverse(PORT);                     // 切换成大端
            }
        }

    };


    [StructLayout(LayoutKind.Sequential)]
    public struct DeviceFullInfo
    {
        /// <summary>
        /// 32字节软件型号和版本号，格式与硬件版本号相同
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        private byte[] m_devicehardVersion;

        /// <summary>
        /// 32字节硬件型号和版本号，软硬件型号和版本号为ASCII码，以’\0’为结尾
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        private byte[] m_devicefirmVersion;

        /// <summary>
        /// 12字节产品序列号
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        private byte[] m_deviceSN;

        /// <summary>
        /// 32字节软件型号和版本号，格式与硬件版本号相同
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        private byte[] m_hardVersion;

        /// <summary>
        /// 32字节硬件型号和版本号，软硬件型号和版本号为ASCII码，以’\0’为结尾
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        private byte[] m_firmVersion;

        /// <summary>
        /// 12字节产品序列号
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        private byte[] m_SN;

        /// <summary>
        /// 12字节参数
        /// </summary>
        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        //private byte[] m_PARA;



        /// <summary>
        /// 阅读器固件型号和版本号
        /// </summary>
        public string DeviceFirmwareVersion
        {
            get { return Encoding.ASCII.GetString(m_devicefirmVersion).Trim('\0'); }
        }

        /// <summary>
        /// 阅读器硬件型号和版本号
        /// </summary>
        public string DeviceHardwareVersion
        {
            get { return Encoding.ASCII.GetString(m_devicehardVersion).Trim('\0'); }
        }

        /// <summary>
        /// 12位产品序列号，十六进制格式字符串
        /// </summary>
        public byte[]  DeviceSN
        {
            get { return m_deviceSN; }
        }

        /// <summary>
        /// 阅读器固件型号和版本号
        /// </summary>
        public string FirmwareVersion
        {
            get { return Encoding.ASCII.GetString(m_firmVersion).Trim('\0'); }
        }

        /// <summary>
        /// 阅读器硬件型号和版本号
        /// </summary>
        public string HardwareVersion
        {
            get { return Encoding.ASCII.GetString(m_hardVersion).Trim('\0'); }
        }

        /// <summary>
        /// 12位产品序列号，十六进制格式字符串
        /// </summary>
        public string SN
        {
            get { return Encoding.ASCII.GetString(m_SN, 0, 12).Replace('\0', '*'); }
        }
    };

    [StructLayout(LayoutKind.Sequential)]
    public struct DeviceInfo
    {

        /// <summary>
        /// 32字节软件型号和版本号，格式与硬件版本号相同
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        private byte[] m_hardVersion;

        /// <summary>
        /// 32字节硬件型号和版本号，软硬件型号和版本号为ASCII码，以’\0’为结尾
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        private byte[] m_firmVersion;

        /// <summary>
        /// 12字节产品序列号
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        private byte[] m_SN;

        /// <summary>
        /// 12字节参数
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
        private byte[] m_PARA;


        /// <summary>
        /// 阅读器固件型号和版本号
        /// </summary>
        public string FirmwareVersion
        {
            get { return Encoding.ASCII.GetString(m_firmVersion).Trim('\0'); }
        }

        /// <summary>
        /// 阅读器硬件型号和版本号
        /// </summary>
        public string HardwareVersion
        {
            get { return Encoding.ASCII.GetString(m_hardVersion).Trim('\0'); }
        }

        /// <summary>
        /// 12位产品序列号，十六进制格式字符串
        /// </summary>
        public string SN
        {
            get { return Encoding.ASCII.GetString(m_SN, 0, 12).Replace('\0', '*'); }
        }
        /// <summary>
        ///  参数
        /// </summary>
        public string PARA
        {
            get { return Encoding.ASCII.GetString(m_PARA, 0, 12).Replace('\0', '*'); }
        }
    };


    [StructLayout(LayoutKind.Sequential)]
    public struct NetInfo
    {

        /// <summary>
        /// 设备IP地址
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        private byte[] IP;

        /// <summary>
        /// 设备mac地址
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        private byte[] MAC;

        /// <summary>
        /// 设备端口号
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        private byte[] Port;

        /// <summary>
        /// 子网掩码
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        private byte[] NetMask;


        /// <summary>
        /// 默认网关
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        private byte[] Gateway;

        /// <summary>
        /// 设备IP地址
        /// </summary>
        public long device_ip
        {
            get {
                long temp;
                temp = IP[0];
                temp += IP[1] << 8;
                temp += IP[2] << 0x10;
                temp += IP[3] << 0x18;
                //device_ip += IP[4] << 0x20;
                //device_ip += IP[5] << 0x38;
                //device_ip += IP[6] << 0x30;
                //device_ip += IP[7] << 0x38;
                return temp & 0xFFFFFFFF ;
            }
            set {
                IP = BitConverter.GetBytes(value);
                //IP[0] = (byte)value;
                //IP[1] = (byte)(value >> 8);
                //IP[2] = (byte)(value >> 0x10);
                //IP[3] = (byte)(value >> 0x18);
                //IP[4] = (byte)(value >> 0x20);
                //IP[5] = (byte)(value >> 0x28);
                //IP[6] = (byte)(value >> 0x30);
                //IP[7] = (byte)(value >> 0x38);

            }
        }

        /// <summary>
        /// 设备mac地址
        /// </summary>
        public byte[] device_mac
        {
            get
            {
                return MAC;
            }
            set
            {
                MAC = value;
            }
        }

        /// <summary>
        /// 设备端口号
        /// </summary>
        public ushort device_port
        {
            get {
                long temp;
                temp = Port[0] << 8;
                temp += Port[1];
                return (ushort)temp;
            }
            set {
                Port = BitConverter.GetBytes(value);     // BitConverter 默认小端
                Array.Reverse(Port);                     // 切换成大端
            }
        }
        /// <summary>
        ///  参数
        /// </summary>
        public long device_netmask
        {
            get
            {
                long temp;
                temp = NetMask[0];
                temp += NetMask[1] << 8;
                temp += NetMask[2] << 0x10;
                temp += NetMask[3] << 0x18;
                //device_ip += IP[4] << 0x20;
                //device_ip += IP[5] << 0x38;
                //device_ip += IP[6] << 0x30;
                //device_ip += IP[7] << 0x38;
                return temp & 0xFFFFFFFF;
            }
            set
            {
                NetMask = BitConverter.GetBytes(value);
                //IP[0] = (byte)value;
                //IP[1] = (byte)(value >> 8);
                //IP[2] = (byte)(value >> 0x10);
                //IP[3] = (byte)(value >> 0x18);
                //IP[4] = (byte)(value >> 0x20);
                //IP[5] = (byte)(value >> 0x28);
                //IP[6] = (byte)(value >> 0x30);
                //IP[7] = (byte)(value >> 0x38);

            }
        }

        public long device_GateWay
        {
            get
            {
                long temp;
                temp = Gateway[0];
                temp += Gateway[1] << 8;
                temp += Gateway[2] << 0x10;
                temp += Gateway[3] << 0x18;
                //device_ip += IP[4] << 0x20;
                //device_ip += IP[5] << 0x38;
                //device_ip += IP[6] << 0x30;
                //device_ip += IP[7] << 0x38;
                return temp & 0xFFFFFFFF;
            }
            set
            {
                Gateway = BitConverter.GetBytes(value);
                //IP[0] = (byte)value;
                //IP[1] = (byte)(value >> 8);
                //IP[2] = (byte)(value >> 0x10);
                //IP[3] = (byte)(value >> 0x18);
                //IP[4] = (byte)(value >> 0x20);
                //IP[5] = (byte)(value >> 0x28);
                //IP[6] = (byte)(value >> 0x30);
                //IP[7] = (byte)(value >> 0x38);

            }
        }
    };



    [StructLayout(LayoutKind.Sequential)]
    public struct RemoteNetInfo
    {
        private byte Enable;
        /// <summary>
        /// IP地址
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        private byte[] IP;


        /// <summary>
        /// 端口号
        /// </summary>
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        private byte[] Port;

        /// <summary>
        /// 子网掩码
        /// </summary>
        private byte HeartbeatTime;

        public byte ENABLE
        {
            get { return Enable; }
            set { Enable = value; }
        }
        public byte HEARTTIME
        {
            get { return HeartbeatTime; }
            set { HeartbeatTime = value; }
        }

        public long Remote_ip
        {
            get
            {
                long temp;
                temp = IP[0];
                temp += IP[1] << 8;
                temp += IP[2] << 0x10;
                temp += IP[3] << 0x18;
                return temp & 0xFFFFFFFF ;               //防止溢出
            }
            set
            {
                IP = BitConverter.GetBytes(value);
                //IP[0] = (byte)value;
                //IP[1] = (byte)(value >> 8);
                //IP[2] = (byte)(value >> 0x10);
                //IP[3] = (byte)(value >> 0x18);
                //IP[4] = (byte)(value >> 0x20);
                //IP[5] = (byte)(value >> 0x28);
                //IP[6] = (byte)(value >> 0x30);
                //IP[7] = (byte)(value >> 0x38);

            }
        }


        /// <summary>
        /// 设备端口号
        /// </summary>
        public ushort remote_port
        {
            get
            {
                long temp;
                temp = Port[0] << 8;
                temp += Port[1];
                return (ushort)temp;
            }
            set
            {
                Port = BitConverter.GetBytes(value);     // BitConverter 默认小端
                Array.Reverse(Port);                     // 切换成大端
            }
        }
    };


    [StructLayout(LayoutKind.Sequential, Pack = 1)]  //按照一字节对齐
    public struct DeltaPara
    {

        private byte DeltaPower;
        private byte Delta1;
        private byte Delta2;

        public byte DELTAPOWER
        {
            get { return DeltaPower; }
            set { DeltaPower = value; }
        }
        public byte DELTA1
        {
            get { return Delta1; }
            set { Delta1 = value; }
        }
        public byte DELTA2
        {
            get { return Delta2; }
            set { Delta2 = value; }
        }
    }
}
