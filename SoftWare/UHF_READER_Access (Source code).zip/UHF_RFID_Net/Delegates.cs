﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UHF_RFID_Net
{
    public delegate void SendRecvHandler(bool receive, byte[] data);
    public delegate void PrintHandler(byte[] data);
}
