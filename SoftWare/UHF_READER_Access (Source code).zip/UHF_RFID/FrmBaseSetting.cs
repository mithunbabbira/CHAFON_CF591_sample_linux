using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using UHF_RFID_Net;
using System.IO;
using System.Threading;

namespace YYF100
{
    public partial class FrmBaseSetting : Form
    {
        static readonly string[] s_strUpdateResult = new string[]{
                                    "固件升级成功",
                                    "固件太大",
                                    "固件写入错误",
                                    "传输已取消",
                                    "传输数据丢失",
                                    "固件接收失败",
                                    "升级失败，系统已恢复" };

        static readonly byte MODEM_SOH = 0x01;		/* 128字节数据块起始字符 */
        static readonly byte MODEM_STX = 0x02;		/* 1024字节数据块起始字符 */
        static readonly byte MODEM_EOT = 0x04;		/* 文件传输结束 */
        static readonly byte MODEM_ACK = 0x06;		/* 确认应答 */
        static readonly byte MODEM_NAK = 0x15;		/* 出现错误 */
        static readonly byte MODEM_CAN = 0x18;		/* 取消传输 */
        static readonly byte MODEM_C = 0x43;		/* 大写字母C */

        Reader m_reader;

        public Reader Reader
        {
            get { return m_reader; }
        }

        public FrmBaseSetting(Reader reader)
        {
            if (reader == null)
                throw new ArgumentNullException("reader");
            m_reader = reader;

            InitializeComponent();
        }

        private void FrmBaseSetting_Load(object sender, EventArgs e)
        {

        }

        private void btnGetVersion_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                DeviceInfo info = reader.GetDeviceInfo();

                lblVersion.Text = "硬件版本：" + info.HardwareVersion + "\r\n" +
                                  "软件版本：" + info.FirmwareVersion + "\r\n" +
                                  "  序列号：" + info.SN;

                MessageBox.Show(this, "开始获取阅读器版本信息获取成功", this.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "获取阅读器版本信息失败：" + ex.Message, this.Text);
            }
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                reader.RebootDevice();
                MessageBox.Show(this, "复位系统成功", this.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "复位系统失败：" + ex.Message, this.Text);
            }
        }

        private void btnResetToFactory_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                reader.RestoreSetting();
                MessageBox.Show(this, "恢复出厂成功", this.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "恢复出厂失败：" + ex.Message, this.Text);
            }
        }

        private void btnSaveParam_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                reader.SaveSetting();
                MessageBox.Show(this, "配置保存成功", this.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "保存配置失败：" + ex.Message, this.Text);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
           /* try
            {
                Reader reader = this.Reader;

                if (ofd.ShowDialog(this) != DialogResult.OK)
                    return;

                // 开始升级，超时时间为15秒钟
                reader.Update(2, 0, Util.EmptyArray, 15000,true);
                string port = reader.PortName;
                reader.Close();
                reader.Open(port);

                string res;
                using (FrmPrompt frmPrompt = new FrmPrompt())
                {
                    frmPrompt.Show(this);
                    frmPrompt.Update();
                    Application.DoEvents();

                    byte[] arrReadBuf = new byte[1024];
                    byte[] arrTxBuf = new byte[1024 + 16];
                    byte btType;
                    byte btStatus;
                    byte index = 1;
                    int tickStart;
                    string fileName = ofd.FileName;
                    using (FileStream fs = new FileStream(fileName, FileMode.Open))
                    {
                        tickStart = Environment.TickCount;
                        while (true)
                        {
                            try
                            {
                                // 接收读写器返回“请求发送固件”命令，超时时间为15秒
                                reader.RecvUpdate(out btType, out btStatus, 15000);
                                break;
                            }
                            catch (Exception ex)
                            {
                                // 等待读写器请求的超时时间为15秒
                                if (Environment.TickCount - tickStart >= 15000)
                                    throw ex;
                                continue;
                            }
                        }
                        if (btType != 0x10)
                            throw new Exception("等待读写器发送“请求发送固件”命令失败");

                        // 等待YModule协议的 'C' 字符
                        reader.Update(0xC0, 0, null, 15000);

                        // 封装YModem起始数据包
                        PackYModemFirstFrame(arrTxBuf, Path.GetFileName(fileName), (int)fs.Length);
                        // 下发YModem数据包，等待ACK的超时时间为15秒
                        reader.Update(0xC1, 128 + 5, arrTxBuf, 15000);

                        // 等待YModule协议的 'C' 字符
                        reader.Update(0xC0, 0, null, 15000);

                        int len = (int)(fs.Length - fs.Position);
                        while (len >= 1024)
                        {
                            fs.Read(arrReadBuf, 0, 1024);

                            // 封装YModem数据包，每次下发1024字节
                            PackYModem2(arrTxBuf, arrReadBuf, index);
                            index++;
                            // 下发YModem数据包，等待ACK的超时时间为15秒
                            reader.Update(0xC1, 1024 + 5, arrTxBuf, 15000);
                            len = (int)(fs.Length - fs.Position);
                        }

                        while (len >= 128)
                        {
                            fs.Read(arrReadBuf, 0, 128);

                            // 封装YModem数据包，每次下发128字节
                            PackYModem1(arrTxBuf, arrReadBuf, index);
                            index++;
                            // 下发YModem数据包，等待ACK的超时时间为15秒
                            reader.Update(0xC1, 128 + 5, arrTxBuf, 15000);
                            len = (int)(fs.Length - fs.Position);
                        }

                        if (len > 0)
                        {
                            fs.Read(arrReadBuf, 0, len);

                            for (int i = len; i < 128; i++)
                            {
                                arrReadBuf[i] = 0x1A;
                            }
                            // 封装YModem数据包，下发128字节，并且是最好一个数据包
                            PackYModem1(arrTxBuf, arrReadBuf, index);
                            // 下发YModem数据包，等待ACK的超时时间为15秒
                            reader.Update(0xC1, 128 + 5, arrTxBuf, 15000);
                        }

                        // 通知阅读器，所有数据已经下发完毕，超时时间为15秒
                        arrTxBuf[0] = MODEM_EOT;
                        reader.Update(0xC1, 1, arrTxBuf, 15000);

                        // 封装YModem结尾数据包
                        PackYModemLastFrame(arrTxBuf);
                        // 下发YModem数据包，等待ACK的超时时间为15秒
                        reader.Update(0xC1, 128 + 5, arrTxBuf, 15000);
                    }

                    tickStart = Environment.TickCount;
                    while (true)
                    {
                        // 接收读写器返回“请求发送固件”命令
                        try
                        {
                            // 接收读写器返回“升级结果”命令，超时时间为15秒
                            reader.RecvUpdate(out btType, out btStatus, 15000);
                            break;
                        }
                        catch (Exception ex)
                        {
                            // 等待读写器请求的超时时间为15秒
                            if (Environment.TickCount - tickStart >= 15000)
                                throw ex;
                            continue;
                        }
                    }
                    if (btType != 0x11)
                        throw new Exception("等待读写器发送“升级结果”命令失败");

                    if (btStatus == 0)
                        res = "固件升级成功。";
                    else
                        res = "固件升级错误，错误原因：" + UpdateStatusToString(btStatus);
                }
                MessageBox.Show(this, res, this.Text);
            }
            catch (FormatException ex1)
            {
                MessageBox.Show(this, "固件文件数据格式错误：" + ex1.Message, this.Text);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(this, "升级失败：" + ex2.Message, this.Text);
            }*/
        }

        /// <summary>
        /// 封装YModem起始数据包
        /// </summary>
        /// <param name="arrBuf"></param>
        private void PackYModemFirstFrame(byte[] arrTxBuf, string fileName, int size)
        {
            byte[] arr1 = Encoding.ASCII.GetBytes(fileName);
            byte[] arr2 = Encoding.ASCII.GetBytes(size.ToString());
            arrTxBuf[0] = MODEM_SOH; // SOH
            arrTxBuf[1] = 0;
            arrTxBuf[2] = 0xFF;
            Array.Copy(arr1, 0, arrTxBuf, 3, arr1.Length);
            arrTxBuf[arr1.Length + 3] = 0;
            Array.Copy(arr2, 0, arrTxBuf, arr1.Length + 4, arr2.Length);
            for (int i = arr1.Length + arr2.Length + 1; i < 128; i++)
            {
                arrTxBuf[i + 3] = 0;
            }
            ushort crc16 = Util.CalcCrc16(arrTxBuf, 3, 128);
            arrTxBuf[128 + 3] = (byte)(crc16 >> 8);
            arrTxBuf[128 + 4] = (byte)crc16;
        }

        /// <summary>
        /// 封装YModem结束数据包
        /// </summary>
        /// <param name="arrBuf"></param>
        private void PackYModemLastFrame(byte[] arrTxBuf)
        {
            arrTxBuf[0] = MODEM_SOH; // SOH
            arrTxBuf[1] = 0;
            arrTxBuf[2] = 0xFF;
            for (int i = 0; i < 128; i++)
            {
                arrTxBuf[i + 3] = 0;
            }
            ushort crc16 = Util.CalcCrc16(arrTxBuf, 3, 128);
            arrTxBuf[128 + 3] = (byte)(crc16 >> 8);
            arrTxBuf[128 + 4] = (byte)crc16;
        }

        /// <summary>
        /// 封装YModem数据包，每次下发128字节
        /// </summary>
        /// <param name="arrBuf"></param>
        /// <param name="list"></param>
        /// <param name="pos2"></param>
        /// <param name="index"></param>
        private void PackYModem1(byte[] arrTxBuf, byte[] arrReadBuf, byte index)
        {
            arrTxBuf[0] = MODEM_SOH; // SOH
            arrTxBuf[1] = index;
            arrTxBuf[2] = (byte)~index;
            Array.Copy(arrReadBuf, 0, arrTxBuf, 3, 128);
            ushort crc16 = Util.CalcCrc16(arrTxBuf, 3, 128);
            arrTxBuf[128 + 3] = (byte)(crc16 >> 8);
            arrTxBuf[128 + 4] = (byte)crc16;
        }

        /// <summary>
        /// 封装YModem数据包，每次下发1024字节
        /// </summary>
        /// <param name="arrBuf"></param>
        /// <param name="list"></param>
        /// <param name="pos"></param>
        /// <param name="index"></param>
        private void PackYModem2(byte[] arrTxBuf, byte[] arrReadBuf, byte index)
        {
            arrTxBuf[0] = MODEM_STX; // STX
            arrTxBuf[1] = index;
            arrTxBuf[2] = (byte)~index;
            Array.Copy(arrReadBuf, 0, arrTxBuf, 3, 1024);
            ushort crc16 = Util.CalcCrc16(arrTxBuf, 3, 1024);
            arrTxBuf[1024 + 3] = (byte)(crc16 >> 8);
            arrTxBuf[1024 + 4] = (byte)crc16;
        }

        private string UpdateStatusToString(byte btStatus)
        {
            if (btStatus < s_strUpdateResult.Length)
                return s_strUpdateResult[btStatus];
            return "未定义错误";
        }
    }
}
