using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using UHF_RFID_Net;

namespace YYF100
{
    public partial class FrmIsoSelect : Form
    {
        // select参数配置
        private UHF_RFID_Net.SelectSortParam m_SelectParam = new UHF_RFID_Net.SelectSortParam();
        // query参数配置
        private UHF_RFID_Net.QueryParam m_QueryParam = new UHF_RFID_Net.QueryParam();
        // 十六进制编辑时，数据中间的间隔字符
        private static readonly char[] s_arrSplit = new char[] { ' ', '\t' };

        Hashtable HT;

        public Hashtable ht
        {
            get { return (HT); }
            set { HT = value; }
        }

        public FrmIsoSelect(UHF_RFID_Net.SelectSortParam selectParam, UHF_RFID_Net.QueryParam queryParam)
        {
            InitializeComponent();
            m_SelectParam = selectParam;
            m_QueryParam = queryParam;

            cbxSelect_target.SelectedIndex = m_SelectParam.Target;
            cbxSelect_action.SelectedIndex = m_SelectParam.Action;
            cbxSelect_membank.SelectedIndex = m_SelectParam.MemBank >> 4;
            tbxSelect_point.Text = m_SelectParam.MaskPtr.ToString();
            cbxTruncate.SelectedIndex = m_SelectParam.Trucate == false ? 0 : 1;
            tbxSelect_mask.Text = "";
            if (m_SelectParam.MaskLen != 0)
                tbxSelect_mask.Text = Util.HexArrayToString(m_SelectParam.MaskData, 0, m_SelectParam.MaskLen);


            cmbSel.SelectedIndex = m_QueryParam.Sel;
            cmbSession.SelectedIndex = m_QueryParam.Session;
            cmbTarget.SelectedIndex = m_QueryParam.Target;
        }

        public UHF_RFID_Net.SelectSortParam IsoSelectParam
        {
            get { return m_SelectParam; }
        }

        public UHF_RFID_Net.QueryParam IsoQueryParam
        {
            get { return m_QueryParam; }
        }

        private void FormatText(TextBox txb)
        {
            string text = txb.Text;
            bool needFormat = false;
            for (int i = 0, l = 0; i < text.Length; i++)
            {
                int j = 0;
                for (; j < s_arrSplit.Length && s_arrSplit[j] != text[i]; j++) ;
                if (j >= s_arrSplit.Length)
                {
                    l++;
                    if (l > 2)
                    {
                        needFormat = true;
                        break;
                    }
                }
                else
                    l = 0;
            }
            if (needFormat)
            {
                if (txb.SelectionLength > 0)
                {
                    int pos = int.MaxValue;
                    text = Util.FormatHexString(text, ref pos);
                    txb.Text = text;
                    txb.SelectionStart = text.Length;
                    txb.SelectionLength = 0;
                }
                else
                {
                    int pos = txb.SelectionStart;
                    txb.Text = Util.FormatHexString(text, ref pos);
                    txb.SelectionStart = pos;
                    txb.SelectionLength = 0;
                }
            }
        }

        private void tbxSelect_mask_TextChanged(object sender, EventArgs e)
        {
            try
            {
                TextBox txb = sender as TextBox;
                if (txb == null)
                    return;

                FormatText(txb);

            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            try
            {
                m_SelectParam.Target = (byte)cbxSelect_target.SelectedIndex;
                m_SelectParam.Action = (byte)cbxSelect_action.SelectedIndex;
                m_SelectParam.MemBank = (byte)(cbxSelect_membank.SelectedIndex << 4);
                m_SelectParam.Trucate = cbxTruncate.SelectedIndex == 0 ? false : true;

                string ptr = tbxSelect_point.Text.Trim();
                if (ptr.Length == 0)
                    throw new Exception((string)HT["Text92"]);
                int ptr2 = Util.NumberFromString(ptr);
                if (ptr2 < 0 || ptr2 > 65535)
                    throw new Exception((string)HT["Text93"]);
                m_SelectParam.MaskPtr = (ushort)ptr2;

                byte[] data2 = Util.HexArrayFromString(tbxSelect_mask.Text.Trim());
                m_SelectParam.MaskLen = (byte)data2.Length;
                m_SelectParam.MaskData = data2;

                m_QueryParam.Sel = (byte)cmbSel.SelectedIndex;
                m_QueryParam.Session = (byte)cmbSession.SelectedIndex;
                m_QueryParam.Target = (byte)cmbTarget.SelectedIndex;

                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void FrmIsoSelect_Load(object sender, EventArgs e)
        {
          
        }
    }
}
