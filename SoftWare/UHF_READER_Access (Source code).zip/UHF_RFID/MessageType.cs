﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YYF100
{
    public enum MessageType
    {
        Info,
        Warning,
        Error
    }
}