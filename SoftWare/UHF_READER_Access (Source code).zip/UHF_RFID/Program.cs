using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using log4net;

namespace YYF100
{
    static class Program
    {
        /// <summary>
        /// 可执行文件所在目录
        /// </summary>
        public static string ExecutablePath = Path.GetDirectoryName(Application.ExecutablePath) + '\\';

        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            StartService sart = new StartService();
            sart.Start();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmMain());
            sart.Stop();
        }


        class StartService
        {
            private static ILog log = log4net.LogManager.GetLogger(typeof(StartService));
            public void Start()
            {
                Console.WriteLine("Starting WriteLine....");
                log.Info("Starting log.Info....");
                log.Error("Starting log.Error....");
            }

            public void Stop()
            {
                Console.WriteLine(" Stopping WriteLine....");
                log.Info("Stopping log.Info....");
                log.Error("Stopping log.Error....");
            }
        }
    }
}
