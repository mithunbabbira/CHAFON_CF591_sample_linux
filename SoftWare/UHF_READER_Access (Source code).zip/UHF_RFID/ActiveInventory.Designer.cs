namespace YYF100
{
    partial class ActiveInventory
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.sfd = new System.Windows.Forms.SaveFileDialog();
            this.activebtnSave = new System.Windows.Forms.Button();
            this.activebtnClear = new System.Windows.Forms.Button();
            this.txbPageLinesActive = new System.Windows.Forms.TextBox();
            this.activelabel6 = new System.Windows.Forms.Label();
            this.activelabel5 = new System.Windows.Forms.Label();
            this.lblInvTotalTimeActive1 = new System.Windows.Forms.Label();
            this.btnInventoryActive = new System.Windows.Forms.Button();
            this.activebtnNextPage = new System.Windows.Forms.Button();
            this.colNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activebtnPrevPage = new System.Windows.Forms.Button();
            this.colCw = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.activebtnLastPage = new System.Windows.Forms.Button();
            this.activebtnFirstPage = new System.Windows.Forms.Button();
            this.lsvTagsActive = new System.Windows.Forms.ListView();
            this.colCodeLen = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRssi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lblInvTimeActive1 = new System.Windows.Forms.Label();
            this.lblInvTotalCountActive1 = new System.Windows.Forms.Label();
            this.lblInvRateActive1 = new System.Windows.Forms.Label();
            this.lblInvCountActive = new System.Windows.Forms.Label();
            this.activelabe2 = new System.Windows.Forms.Label();
            this.activelabe3 = new System.Windows.Forms.Label();
            this.activelabe1 = new System.Windows.Forms.Label();
            this.activelblinvsum = new System.Windows.Forms.Label();
            this.activelabe4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblInvTotalTimeActive = new System.Windows.Forms.TextBox();
            this.lblInvTotalCountActive = new System.Windows.Forms.TextBox();
            this.lblInvTimeActive = new System.Windows.Forms.TextBox();
            this.lblInvRateActive = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // sfd
            // 
            this.sfd.Filter = "*.txt|*.txt|*.*|*.*";
            // 
            // activebtnSave
            // 
            this.activebtnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.activebtnSave.Location = new System.Drawing.Point(806, 334);
            this.activebtnSave.Name = "activebtnSave";
            this.activebtnSave.Size = new System.Drawing.Size(75, 23);
            this.activebtnSave.TabIndex = 73;
            this.activebtnSave.Text = "导出数据";
            this.activebtnSave.UseVisualStyleBackColor = true;
            this.activebtnSave.Click += new System.EventHandler(this.btnSaveActive_Click);
            // 
            // activebtnClear
            // 
            this.activebtnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.activebtnClear.Location = new System.Drawing.Point(712, 334);
            this.activebtnClear.Name = "activebtnClear";
            this.activebtnClear.Size = new System.Drawing.Size(88, 23);
            this.activebtnClear.TabIndex = 72;
            this.activebtnClear.Text = "清除数据";
            this.activebtnClear.UseVisualStyleBackColor = true;
            this.activebtnClear.Click += new System.EventHandler(this.btnClearActive_Click);
            // 
            // txbPageLinesActive
            // 
            this.txbPageLinesActive.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txbPageLinesActive.Location = new System.Drawing.Point(341, 337);
            this.txbPageLinesActive.Name = "txbPageLinesActive";
            this.txbPageLinesActive.Size = new System.Drawing.Size(46, 21);
            this.txbPageLinesActive.TabIndex = 69;
            this.txbPageLinesActive.Text = "30";
            // 
            // activelabel6
            // 
            this.activelabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.activelabel6.AutoSize = true;
            this.activelabel6.Location = new System.Drawing.Point(393, 340);
            this.activelabel6.Name = "activelabel6";
            this.activelabel6.Size = new System.Drawing.Size(17, 12);
            this.activelabel6.TabIndex = 70;
            this.activelabel6.Text = "条";
            // 
            // activelabel5
            // 
            this.activelabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.activelabel5.AutoSize = true;
            this.activelabel5.Location = new System.Drawing.Point(270, 340);
            this.activelabel5.Name = "activelabel5";
            this.activelabel5.Size = new System.Drawing.Size(65, 12);
            this.activelabel5.TabIndex = 68;
            this.activelabel5.Text = "每页显示：";
            // 
            // lblInvTotalTimeActive1
            // 
            this.lblInvTotalTimeActive1.AutoSize = true;
            this.lblInvTotalTimeActive1.Location = new System.Drawing.Point(272, 79);
            this.lblInvTotalTimeActive1.Name = "lblInvTotalTimeActive1";
            this.lblInvTotalTimeActive1.Size = new System.Drawing.Size(65, 12);
            this.lblInvTotalTimeActive1.TabIndex = 58;
            this.lblInvTotalTimeActive1.Text = "0000000000";
            this.lblInvTotalTimeActive1.Visible = false;
            // 
            // btnInventoryActive
            // 
            this.btnInventoryActive.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnInventoryActive.Location = new System.Drawing.Point(676, 14);
            this.btnInventoryActive.Name = "btnInventoryActive";
            this.btnInventoryActive.Size = new System.Drawing.Size(90, 65);
            this.btnInventoryActive.TabIndex = 62;
            this.btnInventoryActive.Text = "读取";
            this.btnInventoryActive.UseVisualStyleBackColor = true;
            this.btnInventoryActive.Click += new System.EventHandler(this.btnInventoryActive_Click);
            // 
            // activebtnNextPage
            // 
            this.activebtnNextPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.activebtnNextPage.Location = new System.Drawing.Point(132, 334);
            this.activebtnNextPage.Name = "activebtnNextPage";
            this.activebtnNextPage.Size = new System.Drawing.Size(61, 23);
            this.activebtnNextPage.TabIndex = 66;
            this.activebtnNextPage.Text = "下一页";
            this.activebtnNextPage.UseVisualStyleBackColor = true;
            this.activebtnNextPage.Click += new System.EventHandler(this.btnNextPageActive_Click);
            // 
            // colNum
            // 
            this.colNum.Tag = "activecolNum";
            this.colNum.Text = "序号";
            this.colNum.Width = 64;
            // 
            // colCode
            // 
            this.colCode.Tag = "activecolCode";
            this.colCode.Text = "编码";
            this.colCode.Width = 500;
            // 
            // colCount
            // 
            this.colCount.Tag = "activecolCount";
            this.colCount.Text = "次数(天线1/2/3/4)";
            this.colCount.Width = 150;
            // 
            // activebtnPrevPage
            // 
            this.activebtnPrevPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.activebtnPrevPage.Location = new System.Drawing.Point(65, 334);
            this.activebtnPrevPage.Name = "activebtnPrevPage";
            this.activebtnPrevPage.Size = new System.Drawing.Size(61, 23);
            this.activebtnPrevPage.TabIndex = 65;
            this.activebtnPrevPage.Text = "上一页";
            this.activebtnPrevPage.UseVisualStyleBackColor = true;
            this.activebtnPrevPage.Click += new System.EventHandler(this.btnPrevPageActive_Click);
            // 
            // colCw
            // 
            this.colCw.Tag = "activecolCw";
            this.colCw.Text = "数据长度";
            this.colCw.Width = 70;
            // 
            // activebtnLastPage
            // 
            this.activebtnLastPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.activebtnLastPage.Location = new System.Drawing.Point(199, 334);
            this.activebtnLastPage.Name = "activebtnLastPage";
            this.activebtnLastPage.Size = new System.Drawing.Size(56, 23);
            this.activebtnLastPage.TabIndex = 67;
            this.activebtnLastPage.Text = "尾页";
            this.activebtnLastPage.UseVisualStyleBackColor = true;
            this.activebtnLastPage.Click += new System.EventHandler(this.btnLastPageActive_Click);
            // 
            // activebtnFirstPage
            // 
            this.activebtnFirstPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.activebtnFirstPage.Location = new System.Drawing.Point(3, 334);
            this.activebtnFirstPage.Name = "activebtnFirstPage";
            this.activebtnFirstPage.Size = new System.Drawing.Size(56, 23);
            this.activebtnFirstPage.TabIndex = 64;
            this.activebtnFirstPage.Text = "首页";
            this.activebtnFirstPage.UseVisualStyleBackColor = true;
            this.activebtnFirstPage.Click += new System.EventHandler(this.btnFirstPageActive_Click);
            // 
            // lsvTagsActive
            // 
            this.lsvTagsActive.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lsvTagsActive.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colNum,
            this.colCode,
            this.colCodeLen,
            this.colCount,
            this.colRssi,
            this.colCw});
            this.lsvTagsActive.FullRowSelect = true;
            this.lsvTagsActive.GridLines = true;
            this.lsvTagsActive.HideSelection = false;
            this.lsvTagsActive.Location = new System.Drawing.Point(3, 120);
            this.lsvTagsActive.Name = "lsvTagsActive";
            this.lsvTagsActive.Size = new System.Drawing.Size(878, 209);
            this.lsvTagsActive.TabIndex = 63;
            this.lsvTagsActive.UseCompatibleStateImageBehavior = false;
            this.lsvTagsActive.View = System.Windows.Forms.View.Details;
            this.lsvTagsActive.DoubleClick += new System.EventHandler(this.lsvTagsActive_DoubleClick);
            // 
            // colCodeLen
            // 
            this.colCodeLen.Tag = "activecolCodeLen";
            this.colCodeLen.Text = "数据长度";
            // 
            // colRssi
            // 
            this.colRssi.Tag = "colRssia";
            this.colRssi.Text = "RSSI(dBm)";
            this.colRssi.Width = 120;
            // 
            // lblInvTimeActive1
            // 
            this.lblInvTimeActive1.AutoSize = true;
            this.lblInvTimeActive1.Location = new System.Drawing.Point(272, 39);
            this.lblInvTimeActive1.Name = "lblInvTimeActive1";
            this.lblInvTimeActive1.Size = new System.Drawing.Size(23, 12);
            this.lblInvTimeActive1.TabIndex = 54;
            this.lblInvTimeActive1.Text = "000";
            this.lblInvTimeActive1.Visible = false;
            // 
            // lblInvTotalCountActive1
            // 
            this.lblInvTotalCountActive1.AutoSize = true;
            this.lblInvTotalCountActive1.Location = new System.Drawing.Point(272, 59);
            this.lblInvTotalCountActive1.Name = "lblInvTotalCountActive1";
            this.lblInvTotalCountActive1.Size = new System.Drawing.Size(65, 12);
            this.lblInvTotalCountActive1.TabIndex = 56;
            this.lblInvTotalCountActive1.Text = "0000000000";
            this.lblInvTotalCountActive1.Visible = false;
            // 
            // lblInvRateActive1
            // 
            this.lblInvRateActive1.AutoSize = true;
            this.lblInvRateActive1.Location = new System.Drawing.Point(272, 19);
            this.lblInvRateActive1.Name = "lblInvRateActive1";
            this.lblInvRateActive1.Size = new System.Drawing.Size(23, 12);
            this.lblInvRateActive1.TabIndex = 52;
            this.lblInvRateActive1.Text = "000";
            this.lblInvRateActive1.Visible = false;
            // 
            // lblInvCountActive
            // 
            this.lblInvCountActive.AutoSize = true;
            this.lblInvCountActive.Font = new System.Drawing.Font("微软雅黑", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblInvCountActive.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.lblInvCountActive.Location = new System.Drawing.Point(28, 50);
            this.lblInvCountActive.Name = "lblInvCountActive";
            this.lblInvCountActive.Size = new System.Drawing.Size(130, 46);
            this.lblInvCountActive.TabIndex = 50;
            this.lblInvCountActive.Text = "00000";
            // 
            // activelabe2
            // 
            this.activelabe2.AutoSize = true;
            this.activelabe2.Location = new System.Drawing.Point(202, 43);
            this.activelabe2.Name = "activelabe2";
            this.activelabe2.Size = new System.Drawing.Size(65, 12);
            this.activelabe2.TabIndex = 53;
            this.activelabe2.Text = "识别时间：";
            // 
            // activelabe3
            // 
            this.activelabe3.AutoSize = true;
            this.activelabe3.Location = new System.Drawing.Point(203, 70);
            this.activelabe3.Name = "activelabe3";
            this.activelabe3.Size = new System.Drawing.Size(65, 12);
            this.activelabe3.TabIndex = 55;
            this.activelabe3.Text = "累计返回：";
            // 
            // activelabe1
            // 
            this.activelabe1.AutoSize = true;
            this.activelabe1.Location = new System.Drawing.Point(203, 17);
            this.activelabe1.Name = "activelabe1";
            this.activelabe1.Size = new System.Drawing.Size(65, 12);
            this.activelabe1.TabIndex = 51;
            this.activelabe1.Text = "识别速度：";
            // 
            // activelblinvsum
            // 
            this.activelblinvsum.AutoSize = true;
            this.activelblinvsum.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.activelblinvsum.ForeColor = System.Drawing.Color.DarkViolet;
            this.activelblinvsum.Location = new System.Drawing.Point(50, 19);
            this.activelblinvsum.Name = "activelblinvsum";
            this.activelblinvsum.Size = new System.Drawing.Size(88, 16);
            this.activelblinvsum.TabIndex = 49;
            this.activelblinvsum.Text = "盘点总数：";
            // 
            // activelabe4
            // 
            this.activelabe4.AutoSize = true;
            this.activelabe4.Location = new System.Drawing.Point(179, 94);
            this.activelabe4.Name = "activelabe4";
            this.activelabe4.Size = new System.Drawing.Size(89, 12);
            this.activelabe4.TabIndex = 57;
            this.activelabe4.Text = "累计运行时间：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblInvTotalTimeActive);
            this.groupBox1.Controls.Add(this.lblInvTimeActive1);
            this.groupBox1.Controls.Add(this.lblInvTotalCountActive);
            this.groupBox1.Controls.Add(this.activelabe4);
            this.groupBox1.Controls.Add(this.lblInvTimeActive);
            this.groupBox1.Controls.Add(this.activelabe1);
            this.groupBox1.Controls.Add(this.lblInvRateActive);
            this.groupBox1.Controls.Add(this.activelabe3);
            this.groupBox1.Controls.Add(this.activelabe2);
            this.groupBox1.Controls.Add(this.lblInvRateActive1);
            this.groupBox1.Controls.Add(this.lblInvTotalTimeActive1);
            this.groupBox1.Controls.Add(this.lblInvTotalCountActive1);
            this.groupBox1.Controls.Add(this.activelblinvsum);
            this.groupBox1.Controls.Add(this.lblInvCountActive);
            this.groupBox1.Location = new System.Drawing.Point(3, -3);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(389, 118);
            this.groupBox1.TabIndex = 74;
            this.groupBox1.TabStop = false;
            // 
            // lblInvTotalTimeActive
            // 
            this.lblInvTotalTimeActive.Location = new System.Drawing.Point(271, 90);
            this.lblInvTotalTimeActive.Name = "lblInvTotalTimeActive";
            this.lblInvTotalTimeActive.Size = new System.Drawing.Size(86, 21);
            this.lblInvTotalTimeActive.TabIndex = 78;
            this.lblInvTotalTimeActive.Text = "000000";
            // 
            // lblInvTotalCountActive
            // 
            this.lblInvTotalCountActive.Location = new System.Drawing.Point(271, 66);
            this.lblInvTotalCountActive.Name = "lblInvTotalCountActive";
            this.lblInvTotalCountActive.Size = new System.Drawing.Size(86, 21);
            this.lblInvTotalCountActive.TabIndex = 77;
            this.lblInvTotalCountActive.Text = "00000000";
            // 
            // lblInvTimeActive
            // 
            this.lblInvTimeActive.Location = new System.Drawing.Point(271, 39);
            this.lblInvTimeActive.Name = "lblInvTimeActive";
            this.lblInvTimeActive.Size = new System.Drawing.Size(86, 21);
            this.lblInvTimeActive.TabIndex = 76;
            this.lblInvTimeActive.Text = "000";
            // 
            // lblInvRateActive
            // 
            this.lblInvRateActive.Location = new System.Drawing.Point(271, 13);
            this.lblInvRateActive.Name = "lblInvRateActive";
            this.lblInvRateActive.Size = new System.Drawing.Size(86, 21);
            this.lblInvRateActive.TabIndex = 75;
            this.lblInvRateActive.Text = "000";
            // 
            // ActiveInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.activebtnSave);
            this.Controls.Add(this.activebtnClear);
            this.Controls.Add(this.txbPageLinesActive);
            this.Controls.Add(this.activelabel6);
            this.Controls.Add(this.activelabel5);
            this.Controls.Add(this.btnInventoryActive);
            this.Controls.Add(this.activebtnNextPage);
            this.Controls.Add(this.activebtnPrevPage);
            this.Controls.Add(this.activebtnLastPage);
            this.Controls.Add(this.activebtnFirstPage);
            this.Controls.Add(this.lsvTagsActive);
            this.Name = "ActiveInventory";
            this.Size = new System.Drawing.Size(884, 364);
            this.Load += new System.EventHandler(this.ActiveInventory_Load);
            this.Leave += new System.EventHandler(this.ActiveInventory_Leave);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SaveFileDialog sfd;
        private System.Windows.Forms.Button activebtnSave;
        private System.Windows.Forms.Button activebtnClear;
        private System.Windows.Forms.TextBox txbPageLinesActive;
        private System.Windows.Forms.Label activelabel6;
        private System.Windows.Forms.Label activelabel5;
        private System.Windows.Forms.Label lblInvTotalTimeActive1;
        private System.Windows.Forms.Button btnInventoryActive;
        private System.Windows.Forms.Button activebtnNextPage;
        private System.Windows.Forms.ColumnHeader colNum;
        private System.Windows.Forms.ColumnHeader colCode;
        private System.Windows.Forms.ColumnHeader colCount;
        private System.Windows.Forms.Button activebtnPrevPage;
        private System.Windows.Forms.ColumnHeader colCw;
        private System.Windows.Forms.Button activebtnLastPage;
        private System.Windows.Forms.Button activebtnFirstPage;
        private System.Windows.Forms.ListView lsvTagsActive;
        private System.Windows.Forms.ColumnHeader colRssi;
        private System.Windows.Forms.Label lblInvTimeActive1;
        private System.Windows.Forms.Label lblInvTotalCountActive1;
        private System.Windows.Forms.Label lblInvRateActive1;
        private System.Windows.Forms.Label lblInvCountActive;
        private System.Windows.Forms.Label activelabe2;
        private System.Windows.Forms.Label activelabe3;
        private System.Windows.Forms.Label activelabe1;
        private System.Windows.Forms.Label activelblinvsum;
        private System.Windows.Forms.Label activelabe4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox lblInvTotalTimeActive;
        private System.Windows.Forms.TextBox lblInvTotalCountActive;
        private System.Windows.Forms.TextBox lblInvTimeActive;
        private System.Windows.Forms.TextBox lblInvRateActive;
        private System.Windows.Forms.ColumnHeader colCodeLen;
    }
}
