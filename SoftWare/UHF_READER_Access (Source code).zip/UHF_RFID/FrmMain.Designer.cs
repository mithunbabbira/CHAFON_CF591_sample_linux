namespace YYF100
{
    partial class FrmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.tsMain = new System.Windows.Forms.ToolStrip();
            this.tsbExit = new System.Windows.Forms.ToolStripButton();
            this.tsbStandard = new System.Windows.Forms.ToolStripDropDownButton();
            this.tmiEpc = new System.Windows.Forms.ToolStripMenuItem();
            this.tmiGB = new System.Windows.Forms.ToolStripMenuItem();
            this.tmiGJB = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbSettings = new System.Windows.Forms.ToolStripDropDownButton();
            this.tmiBaseSetting = new System.Windows.Forms.ToolStripMenuItem();
            this.tmiRFSetting = new System.Windows.Forms.ToolStripMenuItem();
            this.tmiOtherSetting = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbAbout = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tslProto = new System.Windows.Forms.ToolStripLabel();
            this.txbLog = new System.Windows.Forms.TextBox();
            this.cmLog = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmiLogSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiLogClear = new System.Windows.Forms.ToolStripMenuItem();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.sfdLog = new System.Windows.Forms.SaveFileDialog();
            this.test_tabPage = new System.Windows.Forms.TabPage();
            this.testPanel1 = new YYF100.TestPanel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panelEpc = new YYF100.EpcPanel();
            this.tbcMain = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panelRFSetting = new YYF100.RFPanel();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panelInventory = new YYF100.InventoryPanel();
            this.AdvanceSettingPage = new System.Windows.Forms.TabPage();
            this.advanceSetting = new YYF100.AdvanceSetting();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.activeInventory = new YYF100.ActiveInventory();
            this.NetInfo = new System.Windows.Forms.TabPage();
            this.netSet = new YYF100.NetSet();
            this.Debug = new System.Windows.Forms.TabPage();
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.debugging_assistant1 = new YYF100.Debugging_assistant();
            this.tsMain.SuspendLayout();
            this.cmLog.SuspendLayout();
            this.test_tabPage.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tbcMain.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.AdvanceSettingPage.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.NetInfo.SuspendLayout();
            this.Debug.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsMain
            // 
            this.tsMain.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tsMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbExit,
            this.tsbStandard,
            this.tsbSettings,
            this.tsbAbout,
            this.toolStripSeparator1,
            this.tslProto});
            this.tsMain.Location = new System.Drawing.Point(0, 0);
            this.tsMain.Name = "tsMain";
            this.tsMain.Size = new System.Drawing.Size(184020, 1378);
            this.tsMain.TabIndex = 0;
            this.tsMain.Text = "主菜单";
            this.tsMain.Visible = false;
            // 
            // tsbExit
            // 
            this.tsbExit.Image = ((System.Drawing.Image)(resources.GetObject("tsbExit.Image")));
            this.tsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbExit.Name = "tsbExit";
            this.tsbExit.Size = new System.Drawing.Size(71, 1375);
            this.tsbExit.Text = "退出(&E)";
            this.tsbExit.Click += new System.EventHandler(this.tsbExit_Click);
            // 
            // tsbStandard
            // 
            this.tsbStandard.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tmiEpc,
            this.tmiGB,
            this.tmiGJB});
            this.tsbStandard.Image = ((System.Drawing.Image)(resources.GetObject("tsbStandard.Image")));
            this.tsbStandard.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbStandard.Name = "tsbStandard";
            this.tsbStandard.Size = new System.Drawing.Size(81, 1375);
            this.tsbStandard.Text = "标准(&B)";
            // 
            // tmiEpc
            // 
            this.tmiEpc.Checked = true;
            this.tmiEpc.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tmiEpc.Name = "tmiEpc";
            this.tmiEpc.Size = new System.Drawing.Size(179, 22);
            this.tmiEpc.Text = "ISO/IEC 18000-63";
            this.tmiEpc.ToolTipText = "ISO/IEC 18000-63";
            this.tmiEpc.Click += new System.EventHandler(this.tmiEpc_Click);
            // 
            // tmiGB
            // 
            this.tmiGB.Name = "tmiGB";
            this.tmiGB.Size = new System.Drawing.Size(179, 22);
            this.tmiGB.Text = "GB/T 29768";
            this.tmiGB.ToolTipText = "GB/T 29768";
            this.tmiGB.Click += new System.EventHandler(this.tmiGB_Click);
            // 
            // tmiGJB
            // 
            this.tmiGJB.Name = "tmiGJB";
            this.tmiGJB.Size = new System.Drawing.Size(179, 22);
            this.tmiGJB.Text = "GJB 7377-1";
            this.tmiGJB.ToolTipText = "GJB 7377-1";
            this.tmiGJB.Click += new System.EventHandler(this.tmiGJB_Click);
            // 
            // tsbSettings
            // 
            this.tsbSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tmiBaseSetting,
            this.tmiRFSetting,
            this.tmiOtherSetting});
            this.tsbSettings.Image = ((System.Drawing.Image)(resources.GetObject("tsbSettings.Image")));
            this.tsbSettings.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSettings.Name = "tsbSettings";
            this.tsbSettings.Size = new System.Drawing.Size(80, 1375);
            this.tsbSettings.Text = "设置(&S)";
            // 
            // tmiBaseSetting
            // 
            this.tmiBaseSetting.Name = "tmiBaseSetting";
            this.tmiBaseSetting.Size = new System.Drawing.Size(124, 22);
            this.tmiBaseSetting.Text = "基本设置";
            this.tmiBaseSetting.Click += new System.EventHandler(this.tmiBaseSetting_Click);
            // 
            // tmiRFSetting
            // 
            this.tmiRFSetting.Name = "tmiRFSetting";
            this.tmiRFSetting.Size = new System.Drawing.Size(124, 22);
            this.tmiRFSetting.Text = "射频参数";
            this.tmiRFSetting.Click += new System.EventHandler(this.tmiRFSetting_Click);
            // 
            // tmiOtherSetting
            // 
            this.tmiOtherSetting.Name = "tmiOtherSetting";
            this.tmiOtherSetting.Size = new System.Drawing.Size(124, 22);
            this.tmiOtherSetting.Text = "其他设置";
            this.tmiOtherSetting.Click += new System.EventHandler(this.tmiOtherSetting_Click);
            // 
            // tsbAbout
            // 
            this.tsbAbout.Image = ((System.Drawing.Image)(resources.GetObject("tsbAbout.Image")));
            this.tsbAbout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAbout.Name = "tsbAbout";
            this.tsbAbout.Size = new System.Drawing.Size(72, 1375);
            this.tsbAbout.Text = "关于(&A)";
            this.tsbAbout.Click += new System.EventHandler(this.tsbAbout_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 1378);
            // 
            // tslProto
            // 
            this.tslProto.Name = "tslProto";
            this.tslProto.Size = new System.Drawing.Size(92, 1375);
            this.tslProto.Text = "当前选择协议：";
            // 
            // txbLog
            // 
            this.txbLog.ContextMenuStrip = this.cmLog;
            this.txbLog.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txbLog.Location = new System.Drawing.Point(0, 477);
            this.txbLog.Margin = new System.Windows.Forms.Padding(1164, 361, 1164, 361);
            this.txbLog.Multiline = true;
            this.txbLog.Name = "txbLog";
            this.txbLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txbLog.Size = new System.Drawing.Size(1037, 183);
            this.txbLog.TabIndex = 4;
            // 
            // cmLog
            // 
            this.cmLog.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmLog.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiLogSaveAs,
            this.tsmiLogClear});
            this.cmLog.Name = "cmLog";
            this.cmLog.Size = new System.Drawing.Size(138, 48);
            // 
            // tsmiLogSaveAs
            // 
            this.tsmiLogSaveAs.Name = "tsmiLogSaveAs";
            this.tsmiLogSaveAs.Size = new System.Drawing.Size(137, 22);
            this.tsmiLogSaveAs.Text = "另存在(A)...";
            this.tsmiLogSaveAs.Click += new System.EventHandler(this.tsmiLogSaveAs_Click);
            // 
            // tsmiLogClear
            // 
            this.tsmiLogClear.Name = "tsmiLogClear";
            this.tsmiLogClear.Size = new System.Drawing.Size(137, 22);
            this.tsmiLogClear.Text = "清除(&C)";
            this.tsmiLogClear.Click += new System.EventHandler(this.tsmiLogClear_Click);
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.splitter1.Location = new System.Drawing.Point(0, 462);
            this.splitter1.Margin = new System.Windows.Forms.Padding(1164, 361, 1164, 361);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(1037, 15);
            this.splitter1.TabIndex = 3;
            this.splitter1.TabStop = false;
            this.splitter1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitter1_SplitterMoved);
            // 
            // sfdLog
            // 
            this.sfdLog.DefaultExt = "txt";
            this.sfdLog.Filter = "*.txt|*.txt|*.log|*.log|*.*|*.*";
            // 
            // test_tabPage
            // 
            this.test_tabPage.Controls.Add(this.testPanel1);
            this.test_tabPage.Location = new System.Drawing.Point(4, 22);
            this.test_tabPage.Margin = new System.Windows.Forms.Padding(491, 185, 491, 185);
            this.test_tabPage.Name = "test_tabPage";
            this.test_tabPage.Size = new System.Drawing.Size(1010, 436);
            this.test_tabPage.TabIndex = 5;
            this.test_tabPage.Text = "测试功能";
            this.test_tabPage.UseVisualStyleBackColor = true;
            // 
            // testPanel1
            // 
            this.testPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.testPanel1.Location = new System.Drawing.Point(0, 0);
            this.testPanel1.Margin = new System.Windows.Forms.Padding(1164, 361, 1164, 361);
            this.testPanel1.Name = "testPanel1";
            this.testPanel1.Size = new System.Drawing.Size(1010, 436);
            this.testPanel1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panelEpc);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(873, 289, 873, 289);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1010, 436);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "读写标签";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panelEpc
            // 
            this.panelEpc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelEpc.Location = new System.Drawing.Point(0, 0);
            this.panelEpc.Margin = new System.Windows.Forms.Padding(1164, 361, 1164, 361);
            this.panelEpc.Name = "panelEpc";
            this.panelEpc.Size = new System.Drawing.Size(1010, 436);
            this.panelEpc.StopOperation = false;
            this.panelEpc.TabIndex = 0;
            this.panelEpc.Visible = false;
            // 
            // tbcMain
            // 
            this.tbcMain.Controls.Add(this.tabPage5);
            this.tbcMain.Controls.Add(this.tabPage1);
            this.tbcMain.Controls.Add(this.AdvanceSettingPage);
            this.tbcMain.Controls.Add(this.tabPage3);
            this.tbcMain.Controls.Add(this.tabPage2);
            this.tbcMain.Controls.Add(this.test_tabPage);
            this.tbcMain.Controls.Add(this.NetInfo);
            this.tbcMain.Controls.Add(this.Debug);
            this.tbcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbcMain.Location = new System.Drawing.Point(19, 0);
            this.tbcMain.Margin = new System.Windows.Forms.Padding(655, 231, 655, 231);
            this.tbcMain.Name = "tbcMain";
            this.tbcMain.SelectedIndex = 0;
            this.tbcMain.Size = new System.Drawing.Size(1018, 462);
            this.tbcMain.TabIndex = 5;
            this.tbcMain.SelectedIndexChanged += new System.EventHandler(this.tbcMain_SelectedIndexChanged);
            this.tbcMain.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tbcMain_Selecting);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panelRFSetting);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(655, 231, 655, 231);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1010, 436);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "参数设置";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panelRFSetting
            // 
            this.panelRFSetting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelRFSetting.Location = new System.Drawing.Point(0, 0);
            this.panelRFSetting.Margin = new System.Windows.Forms.Padding(873, 289, 873, 289);
            this.panelRFSetting.Name = "panelRFSetting";
            this.panelRFSetting.Size = new System.Drawing.Size(1010, 436);
            this.panelRFSetting.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panelInventory);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(655, 231, 655, 231);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1010, 436);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "应答模式";
            // 
            // panelInventory
            // 
            this.panelInventory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInventory.Location = new System.Drawing.Point(0, 0);
            this.panelInventory.Margin = new System.Windows.Forms.Padding(275295, 25030, 275295, 25030);
            this.panelInventory.Name = "panelInventory";
            this.panelInventory.Size = new System.Drawing.Size(1010, 436);
            this.panelInventory.StopInventory = false;
            this.panelInventory.TabIndex = 2;
            this.panelInventory.Load += new System.EventHandler(this.panelInventory_Load);
            this.panelInventory.Click += new System.EventHandler(this.panelInventory_Click);
            // 
            // AdvanceSettingPage
            // 
            this.AdvanceSettingPage.Controls.Add(this.advanceSetting);
            this.AdvanceSettingPage.Location = new System.Drawing.Point(4, 22);
            this.AdvanceSettingPage.Margin = new System.Windows.Forms.Padding(28, 19, 28, 19);
            this.AdvanceSettingPage.Name = "AdvanceSettingPage";
            this.AdvanceSettingPage.Size = new System.Drawing.Size(1010, 436);
            this.AdvanceSettingPage.TabIndex = 8;
            this.AdvanceSettingPage.Text = "高级设置";
            this.AdvanceSettingPage.UseVisualStyleBackColor = true;
            // 
            // advanceSetting
            // 
            this.advanceSetting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.advanceSetting.Location = new System.Drawing.Point(0, 0);
            this.advanceSetting.Margin = new System.Windows.Forms.Padding(28, 19, 28, 19);
            this.advanceSetting.Name = "advanceSetting";
            this.advanceSetting.Size = new System.Drawing.Size(1010, 436);
            this.advanceSetting.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage3.Controls.Add(this.activeInventory);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(11276, 3362, 11276, 20024);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1010, 436);
            this.tabPage3.TabIndex = 6;
            this.tabPage3.Text = "主动模式";
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // activeInventory
            // 
            this.activeInventory.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.activeInventory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.activeInventory.Location = new System.Drawing.Point(0, 0);
            this.activeInventory.Margin = new System.Windows.Forms.Padding(275295, 25030, 275295, 25030);
            this.activeInventory.Name = "activeInventory";
            this.activeInventory.Size = new System.Drawing.Size(1010, 436);
            this.activeInventory.StopInventory = false;
            this.activeInventory.TabIndex = 0;
            // 
            // NetInfo
            // 
            this.NetInfo.Controls.Add(this.netSet);
            this.NetInfo.Location = new System.Drawing.Point(4, 22);
            this.NetInfo.Margin = new System.Windows.Forms.Padding(65, 38, 65, 38);
            this.NetInfo.Name = "NetInfo";
            this.NetInfo.Size = new System.Drawing.Size(1010, 436);
            this.NetInfo.TabIndex = 7;
            this.NetInfo.Text = "网络设置";
            this.NetInfo.UseVisualStyleBackColor = true;
            // 
            // netSet
            // 
            this.netSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.netSet.Location = new System.Drawing.Point(0, 0);
            this.netSet.Margin = new System.Windows.Forms.Padding(65, 38, 65, 38);
            this.netSet.Name = "netSet";
            this.netSet.Size = new System.Drawing.Size(1010, 436);
            this.netSet.TabIndex = 0;
            // 
            // Debug
            // 
            this.Debug.Controls.Add(this.debugging_assistant1);
            this.Debug.Location = new System.Drawing.Point(4, 22);
            this.Debug.Name = "Debug";
            this.Debug.Padding = new System.Windows.Forms.Padding(3);
            this.Debug.Size = new System.Drawing.Size(1010, 436);
            this.Debug.TabIndex = 9;
            this.Debug.Text = "Debug Assisant";
            this.Debug.UseVisualStyleBackColor = true;
            // 
            // splitter2
            // 
            this.splitter2.Location = new System.Drawing.Point(0, 0);
            this.splitter2.Margin = new System.Windows.Forms.Padding(206471, 20024, 206471, 20024);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(19, 462);
            this.splitter2.TabIndex = 6;
            this.splitter2.TabStop = false;
            // 
            // debugging_assistant1
            // 
            this.debugging_assistant1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.debugging_assistant1.Location = new System.Drawing.Point(3, 3);
            this.debugging_assistant1.Name = "debugging_assistant1";
            this.debugging_assistant1.Size = new System.Drawing.Size(1004, 430);
            this.debugging_assistant1.TabIndex = 0;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 660);
            this.Controls.Add(this.tbcMain);
            this.Controls.Add(this.splitter2);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.txbLog);
            this.Controls.Add(this.tsMain);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmMain";
            this.Text = "UHF RFID reader";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.tsMain.ResumeLayout(false);
            this.tsMain.PerformLayout();
            this.cmLog.ResumeLayout(false);
            this.test_tabPage.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tbcMain.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.AdvanceSettingPage.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.NetInfo.ResumeLayout(false);
            this.Debug.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tsMain;
        private System.Windows.Forms.ToolStripButton tsbExit;
        private System.Windows.Forms.ToolStripDropDownButton tsbStandard;
        private System.Windows.Forms.ToolStripDropDownButton tsbSettings;
        private System.Windows.Forms.ToolStripButton tsbAbout;
        private System.Windows.Forms.ToolStripMenuItem tmiEpc;
        private System.Windows.Forms.ToolStripMenuItem tmiGB;
        private System.Windows.Forms.ToolStripMenuItem tmiGJB;
        private System.Windows.Forms.ToolStripMenuItem tmiBaseSetting;
        private System.Windows.Forms.ToolStripMenuItem tmiRFSetting;
        private System.Windows.Forms.ToolStripMenuItem tmiOtherSetting;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.ToolStripLabel tslProto;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ContextMenuStrip cmLog;
        private System.Windows.Forms.ToolStripMenuItem tsmiLogSaveAs;
        private System.Windows.Forms.SaveFileDialog sfdLog;
        private System.Windows.Forms.ToolStripMenuItem tsmiLogClear;
        private System.Windows.Forms.TabPage test_tabPage;
        private TestPanel testPanel1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tbcMain;
        private System.Windows.Forms.TabPage tabPage5;
        private RFPanel panelRFSetting;
        private System.Windows.Forms.TabPage tabPage3;
        private YYF100.ActiveInventory activeInventory;
        private EpcPanel panelEpc;
        private System.Windows.Forms.TabPage tabPage1;
        private InventoryPanel panelInventory;
        //private ActiveInventory panelInventoryActive;
        private System.Windows.Forms.Splitter splitter2;
        public System.Windows.Forms.TextBox txbLog;
        private System.Windows.Forms.TabPage NetInfo;
        private NetSet netSet;
        private System.Windows.Forms.TabPage AdvanceSettingPage;
        private AdvanceSetting advanceSetting;
        private System.Windows.Forms.TabPage Debug;
        private Debugging_assistant debugging_assistant1;
    }
}

