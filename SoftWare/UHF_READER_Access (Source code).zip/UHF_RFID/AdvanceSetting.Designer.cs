namespace YYF100
{
    partial class AdvanceSetting
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.advgroupBox2 = new System.Windows.Forms.GroupBox();
            this.advcbxKCPowerEn = new System.Windows.Forms.CheckBox();
            this.txbProtocolFormat = new System.Windows.Forms.TextBox();
            this.advlabel5 = new System.Windows.Forms.Label();
            this.cmbProtocolType = new System.Windows.Forms.ComboBox();
            this.advcbxprotocolen = new System.Windows.Forms.CheckBox();
            this.advcbxbufferen = new System.Windows.Forms.CheckBox();
            this.txbrelaytime = new System.Windows.Forms.TextBox();
            this.advcbxKCEn = new System.Windows.Forms.CheckBox();
            this.advlabel4 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.advgroupBox1 = new System.Windows.Forms.GroupBox();
            this.txbMasklen = new System.Windows.Forms.TextBox();
            this.advlabel6 = new System.Windows.Forms.Label();
            this.cmbMaskCondition = new System.Windows.Forms.ComboBox();
            this.txbMaskData = new System.Windows.Forms.TextBox();
            this.advlabel10 = new System.Windows.Forms.Label();
            this.txbMaskStartAddr = new System.Windows.Forms.TextBox();
            this.advcbxMaskEn = new System.Windows.Forms.CheckBox();
            this.advlabel9 = new System.Windows.Forms.Label();
            this.txbPassword = new System.Windows.Forms.TextBox();
            this.advcbxCodeEn = new System.Windows.Forms.CheckBox();
            this.advlabel3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.advlabel2 = new System.Windows.Forms.Label();
            this.btnGetPermissonInfo = new System.Windows.Forms.Button();
            this.btnSetPermissonInfo = new System.Windows.Forms.Button();
            this.advgroupBox3 = new System.Windows.Forms.GroupBox();
            this.advrdbLowlevel = new System.Windows.Forms.RadioButton();
            this.advrdbhighlevel = new System.Windows.Forms.RadioButton();
            this.advlabel7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnGetGpioInfo = new System.Windows.Forms.Button();
            this.btnSetGpioInfo = new System.Windows.Forms.Button();
            this.advgroupBox2.SuspendLayout();
            this.advgroupBox1.SuspendLayout();
            this.advgroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // advgroupBox2
            // 
            this.advgroupBox2.Controls.Add(this.advrdbLowlevel);
            this.advgroupBox2.Controls.Add(this.btnGetGpioInfo);
            this.advgroupBox2.Controls.Add(this.advrdbhighlevel);
            this.advgroupBox2.Controls.Add(this.advlabel7);
            this.advgroupBox2.Controls.Add(this.advcbxKCPowerEn);
            this.advgroupBox2.Controls.Add(this.btnSetGpioInfo);
            this.advgroupBox2.Controls.Add(this.txbProtocolFormat);
            this.advgroupBox2.Controls.Add(this.advlabel5);
            this.advgroupBox2.Controls.Add(this.cmbProtocolType);
            this.advgroupBox2.Controls.Add(this.advcbxprotocolen);
            this.advgroupBox2.Controls.Add(this.advcbxbufferen);
            this.advgroupBox2.Controls.Add(this.txbrelaytime);
            this.advgroupBox2.Controls.Add(this.advcbxKCEn);
            this.advgroupBox2.Controls.Add(this.advlabel4);
            this.advgroupBox2.Controls.Add(this.label4);
            this.advgroupBox2.Location = new System.Drawing.Point(3, 207);
            this.advgroupBox2.Name = "advgroupBox2";
            this.advgroupBox2.Size = new System.Drawing.Size(802, 191);
            this.advgroupBox2.TabIndex = 11;
            this.advgroupBox2.TabStop = false;
            this.advgroupBox2.Text = "输出控制";
            // 
            // advcbxKCPowerEn
            // 
            this.advcbxKCPowerEn.AutoSize = true;
            this.advcbxKCPowerEn.Location = new System.Drawing.Point(524, 35);
            this.advcbxKCPowerEn.Margin = new System.Windows.Forms.Padding(4);
            this.advcbxKCPowerEn.Name = "advcbxKCPowerEn";
            this.advcbxKCPowerEn.Size = new System.Drawing.Size(104, 19);
            this.advcbxKCPowerEn.TabIndex = 30;
            this.advcbxKCPowerEn.Text = "继电器带电";
            this.advcbxKCPowerEn.UseVisualStyleBackColor = true;
            // 
            // txbProtocolFormat
            // 
            this.txbProtocolFormat.Location = new System.Drawing.Point(155, 120);
            this.txbProtocolFormat.Margin = new System.Windows.Forms.Padding(4);
            this.txbProtocolFormat.Name = "txbProtocolFormat";
            this.txbProtocolFormat.Size = new System.Drawing.Size(294, 25);
            this.txbProtocolFormat.TabIndex = 29;
            this.txbProtocolFormat.TextChanged += new System.EventHandler(this.txbPassword_TextChanged);
            this.txbProtocolFormat.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txbPassword_KeyDown);
            // 
            // advlabel5
            // 
            this.advlabel5.AutoSize = true;
            this.advlabel5.Location = new System.Drawing.Point(7, 131);
            this.advlabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.advlabel5.Name = "advlabel5";
            this.advlabel5.Size = new System.Drawing.Size(112, 15);
            this.advlabel5.TabIndex = 28;
            this.advlabel5.Text = "特定协议格式：";
            // 
            // cmbProtocolType
            // 
            this.cmbProtocolType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProtocolType.FormattingEnabled = true;
            this.cmbProtocolType.Items.AddRange(new object[] {
            "ModBus",
            "Https"});
            this.cmbProtocolType.Location = new System.Drawing.Point(155, 93);
            this.cmbProtocolType.Margin = new System.Windows.Forms.Padding(4);
            this.cmbProtocolType.Name = "cmbProtocolType";
            this.cmbProtocolType.Size = new System.Drawing.Size(179, 23);
            this.cmbProtocolType.TabIndex = 28;
            // 
            // advcbxprotocolen
            // 
            this.advcbxprotocolen.AutoSize = true;
            this.advcbxprotocolen.Location = new System.Drawing.Point(10, 99);
            this.advcbxprotocolen.Margin = new System.Windows.Forms.Padding(4);
            this.advcbxprotocolen.Name = "advcbxprotocolen";
            this.advcbxprotocolen.Size = new System.Drawing.Size(89, 19);
            this.advcbxprotocolen.TabIndex = 26;
            this.advcbxprotocolen.Text = "协议使能";
            this.advcbxprotocolen.UseVisualStyleBackColor = true;
            // 
            // advcbxbufferen
            // 
            this.advcbxbufferen.AutoSize = true;
            this.advcbxbufferen.Location = new System.Drawing.Point(10, 67);
            this.advcbxbufferen.Margin = new System.Windows.Forms.Padding(4);
            this.advcbxbufferen.Name = "advcbxbufferen";
            this.advcbxbufferen.Size = new System.Drawing.Size(89, 19);
            this.advcbxbufferen.TabIndex = 25;
            this.advcbxbufferen.Text = "缓存使能";
            this.advcbxbufferen.UseVisualStyleBackColor = true;
            // 
            // txbrelaytime
            // 
            this.txbrelaytime.Location = new System.Drawing.Point(333, 32);
            this.txbrelaytime.Margin = new System.Windows.Forms.Padding(4);
            this.txbrelaytime.Name = "txbrelaytime";
            this.txbrelaytime.Size = new System.Drawing.Size(102, 25);
            this.txbrelaytime.TabIndex = 24;
            this.txbrelaytime.Text = "3";
            // 
            // advcbxKCEn
            // 
            this.advcbxKCEn.AutoSize = true;
            this.advcbxKCEn.Location = new System.Drawing.Point(10, 35);
            this.advcbxKCEn.Margin = new System.Windows.Forms.Padding(4);
            this.advcbxKCEn.Name = "advcbxKCEn";
            this.advcbxKCEn.Size = new System.Drawing.Size(74, 19);
            this.advcbxKCEn.TabIndex = 23;
            this.advcbxKCEn.Text = "继电器";
            this.advcbxKCEn.UseVisualStyleBackColor = true;
            // 
            // advlabel4
            // 
            this.advlabel4.AutoSize = true;
            this.advlabel4.Location = new System.Drawing.Point(152, 37);
            this.advlabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.advlabel4.Name = "advlabel4";
            this.advlabel4.Size = new System.Drawing.Size(120, 15);
            this.advlabel4.TabIndex = 22;
            this.advlabel4.Text = "有效时间（S）：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 98);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 15);
            this.label4.TabIndex = 16;
            // 
            // advgroupBox1
            // 
            this.advgroupBox1.Controls.Add(this.txbMasklen);
            this.advgroupBox1.Controls.Add(this.advlabel6);
            this.advgroupBox1.Controls.Add(this.cmbMaskCondition);
            this.advgroupBox1.Controls.Add(this.btnGetPermissonInfo);
            this.advgroupBox1.Controls.Add(this.txbMaskData);
            this.advgroupBox1.Controls.Add(this.btnSetPermissonInfo);
            this.advgroupBox1.Controls.Add(this.advlabel10);
            this.advgroupBox1.Controls.Add(this.txbMaskStartAddr);
            this.advgroupBox1.Controls.Add(this.advcbxMaskEn);
            this.advgroupBox1.Controls.Add(this.advlabel9);
            this.advgroupBox1.Controls.Add(this.txbPassword);
            this.advgroupBox1.Controls.Add(this.advcbxCodeEn);
            this.advgroupBox1.Controls.Add(this.advlabel3);
            this.advgroupBox1.Controls.Add(this.label1);
            this.advgroupBox1.Controls.Add(this.advlabel2);
            this.advgroupBox1.Location = new System.Drawing.Point(3, 3);
            this.advgroupBox1.Name = "advgroupBox1";
            this.advgroupBox1.Size = new System.Drawing.Size(802, 203);
            this.advgroupBox1.TabIndex = 10;
            this.advgroupBox1.TabStop = false;
            this.advgroupBox1.Text = "读卡权限";
            // 
            // txbMasklen
            // 
            this.txbMasklen.Location = new System.Drawing.Point(524, 68);
            this.txbMasklen.Margin = new System.Windows.Forms.Padding(4);
            this.txbMasklen.Name = "txbMasklen";
            this.txbMasklen.Size = new System.Drawing.Size(102, 25);
            this.txbMasklen.TabIndex = 29;
            this.txbMasklen.Text = "0";
            // 
            // advlabel6
            // 
            this.advlabel6.AutoSize = true;
            this.advlabel6.Location = new System.Drawing.Point(414, 73);
            this.advlabel6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.advlabel6.Name = "advlabel6";
            this.advlabel6.Size = new System.Drawing.Size(82, 15);
            this.advlabel6.TabIndex = 28;
            this.advlabel6.Text = "掩码长度：";
            // 
            // cmbMaskCondition
            // 
            this.cmbMaskCondition.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMaskCondition.FormattingEnabled = true;
            this.cmbMaskCondition.Items.AddRange(new object[] {
            "10"});
            this.cmbMaskCondition.Location = new System.Drawing.Point(155, 144);
            this.cmbMaskCondition.Margin = new System.Windows.Forms.Padding(4);
            this.cmbMaskCondition.Name = "cmbMaskCondition";
            this.cmbMaskCondition.Size = new System.Drawing.Size(231, 23);
            this.cmbMaskCondition.TabIndex = 27;
            // 
            // txbMaskData
            // 
            this.txbMaskData.Location = new System.Drawing.Point(262, 103);
            this.txbMaskData.Margin = new System.Windows.Forms.Padding(4);
            this.txbMaskData.Name = "txbMaskData";
            this.txbMaskData.Size = new System.Drawing.Size(364, 25);
            this.txbMaskData.TabIndex = 26;
            this.txbMaskData.TextChanged += new System.EventHandler(this.txbPassword_TextChanged);
            this.txbMaskData.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txbPassword_KeyDown);
            // 
            // advlabel10
            // 
            this.advlabel10.AutoSize = true;
            this.advlabel10.Location = new System.Drawing.Point(129, 108);
            this.advlabel10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.advlabel10.Name = "advlabel10";
            this.advlabel10.Size = new System.Drawing.Size(122, 15);
            this.advlabel10.TabIndex = 25;
            this.advlabel10.Text = "掩码数据(HEX)：";
            // 
            // txbMaskStartAddr
            // 
            this.txbMaskStartAddr.Location = new System.Drawing.Point(262, 68);
            this.txbMaskStartAddr.Margin = new System.Windows.Forms.Padding(4);
            this.txbMaskStartAddr.Name = "txbMaskStartAddr";
            this.txbMaskStartAddr.Size = new System.Drawing.Size(102, 25);
            this.txbMaskStartAddr.TabIndex = 24;
            this.txbMaskStartAddr.Text = "0";
            // 
            // advcbxMaskEn
            // 
            this.advcbxMaskEn.AutoSize = true;
            this.advcbxMaskEn.Location = new System.Drawing.Point(10, 71);
            this.advcbxMaskEn.Margin = new System.Windows.Forms.Padding(4);
            this.advcbxMaskEn.Name = "advcbxMaskEn";
            this.advcbxMaskEn.Size = new System.Drawing.Size(89, 19);
            this.advcbxMaskEn.TabIndex = 23;
            this.advcbxMaskEn.Text = "掩码使能";
            this.advcbxMaskEn.UseVisualStyleBackColor = true;
            // 
            // advlabel9
            // 
            this.advlabel9.AutoSize = true;
            this.advlabel9.Location = new System.Drawing.Point(152, 73);
            this.advlabel9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.advlabel9.Name = "advlabel9";
            this.advlabel9.Size = new System.Drawing.Size(82, 15);
            this.advlabel9.TabIndex = 22;
            this.advlabel9.Text = "起始地址：";
            // 
            // txbPassword
            // 
            this.txbPassword.Location = new System.Drawing.Point(262, 28);
            this.txbPassword.Margin = new System.Windows.Forms.Padding(4);
            this.txbPassword.Name = "txbPassword";
            this.txbPassword.Size = new System.Drawing.Size(102, 25);
            this.txbPassword.TabIndex = 21;
            this.txbPassword.Text = "00 00 00 00";
            this.txbPassword.TextChanged += new System.EventHandler(this.txbPassword_TextChanged);
            this.txbPassword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txbPassword_KeyDown);
            // 
            // advcbxCodeEn
            // 
            this.advcbxCodeEn.AutoSize = true;
            this.advcbxCodeEn.Location = new System.Drawing.Point(10, 31);
            this.advcbxCodeEn.Margin = new System.Windows.Forms.Padding(4);
            this.advcbxCodeEn.Name = "advcbxCodeEn";
            this.advcbxCodeEn.Size = new System.Drawing.Size(89, 19);
            this.advcbxCodeEn.TabIndex = 20;
            this.advcbxCodeEn.Text = "密码使能";
            this.advcbxCodeEn.UseVisualStyleBackColor = true;
            // 
            // advlabel3
            // 
            this.advlabel3.AutoSize = true;
            this.advlabel3.Location = new System.Drawing.Point(7, 148);
            this.advlabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.advlabel3.Name = "advlabel3";
            this.advlabel3.Size = new System.Drawing.Size(106, 15);
            this.advlabel3.TabIndex = 18;
            this.advlabel3.Text = "条件（EPC）：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 98);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 15);
            this.label1.TabIndex = 16;
            // 
            // advlabel2
            // 
            this.advlabel2.AutoSize = true;
            this.advlabel2.Location = new System.Drawing.Point(152, 33);
            this.advlabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.advlabel2.Name = "advlabel2";
            this.advlabel2.Size = new System.Drawing.Size(92, 15);
            this.advlabel2.TabIndex = 8;
            this.advlabel2.Text = "密码(HEX)：";
            // 
            // btnGetPermissonInfo
            // 
            this.btnGetPermissonInfo.Location = new System.Drawing.Point(675, 48);
            this.btnGetPermissonInfo.Margin = new System.Windows.Forms.Padding(4);
            this.btnGetPermissonInfo.Name = "btnGetPermissonInfo";
            this.btnGetPermissonInfo.Size = new System.Drawing.Size(103, 28);
            this.btnGetPermissonInfo.TabIndex = 13;
            this.btnGetPermissonInfo.Text = "获取";
            this.btnGetPermissonInfo.UseVisualStyleBackColor = true;
            this.btnGetPermissonInfo.Click += new System.EventHandler(this.btnGetPermissonInfo_Click);
            // 
            // btnSetPermissonInfo
            // 
            this.btnSetPermissonInfo.Location = new System.Drawing.Point(675, 144);
            this.btnSetPermissonInfo.Margin = new System.Windows.Forms.Padding(4);
            this.btnSetPermissonInfo.Name = "btnSetPermissonInfo";
            this.btnSetPermissonInfo.Size = new System.Drawing.Size(103, 28);
            this.btnSetPermissonInfo.TabIndex = 14;
            this.btnSetPermissonInfo.Text = "设置";
            this.btnSetPermissonInfo.UseVisualStyleBackColor = true;
            this.btnSetPermissonInfo.Click += new System.EventHandler(this.btnSetPermissonInfo_Click);
            // 
            // advgroupBox3
            // 
            this.advgroupBox3.Controls.Add(this.label11);
            this.advgroupBox3.Location = new System.Drawing.Point(6, 416);
            this.advgroupBox3.Name = "advgroupBox3";
            this.advgroupBox3.Size = new System.Drawing.Size(802, 78);
            this.advgroupBox3.TabIndex = 15;
            this.advgroupBox3.TabStop = false;
            this.advgroupBox3.Text = "输入控制";
            this.advgroupBox3.Visible = false;
            // 
            // advrdbLowlevel
            // 
            this.advrdbLowlevel.AutoSize = true;
            this.advrdbLowlevel.Checked = true;
            this.advrdbLowlevel.Location = new System.Drawing.Point(334, 157);
            this.advrdbLowlevel.Name = "advrdbLowlevel";
            this.advrdbLowlevel.Size = new System.Drawing.Size(103, 19);
            this.advrdbLowlevel.TabIndex = 19;
            this.advrdbLowlevel.TabStop = true;
            this.advrdbLowlevel.Text = "低电平触发";
            this.advrdbLowlevel.UseVisualStyleBackColor = true;
            // 
            // advrdbhighlevel
            // 
            this.advrdbhighlevel.AutoSize = true;
            this.advrdbhighlevel.Location = new System.Drawing.Point(155, 157);
            this.advrdbhighlevel.Name = "advrdbhighlevel";
            this.advrdbhighlevel.Size = new System.Drawing.Size(103, 19);
            this.advrdbhighlevel.TabIndex = 18;
            this.advrdbhighlevel.Text = "高电平触发";
            this.advrdbhighlevel.UseVisualStyleBackColor = true;
            // 
            // advlabel7
            // 
            this.advlabel7.AutoSize = true;
            this.advlabel7.Location = new System.Drawing.Point(17, 159);
            this.advlabel7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.advlabel7.Name = "advlabel7";
            this.advlabel7.Size = new System.Drawing.Size(82, 15);
            this.advlabel7.TabIndex = 17;
            this.advlabel7.Text = "触发有效：";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 98);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 15);
            this.label11.TabIndex = 16;
            // 
            // btnGetGpioInfo
            // 
            this.btnGetGpioInfo.Location = new System.Drawing.Point(675, 29);
            this.btnGetGpioInfo.Margin = new System.Windows.Forms.Padding(4);
            this.btnGetGpioInfo.Name = "btnGetGpioInfo";
            this.btnGetGpioInfo.Size = new System.Drawing.Size(103, 28);
            this.btnGetGpioInfo.TabIndex = 30;
            this.btnGetGpioInfo.Text = "获取";
            this.btnGetGpioInfo.UseVisualStyleBackColor = true;
            this.btnGetGpioInfo.Click += new System.EventHandler(this.btnGetGpioInfo_Click);
            // 
            // btnSetGpioInfo
            // 
            this.btnSetGpioInfo.Location = new System.Drawing.Point(675, 125);
            this.btnSetGpioInfo.Margin = new System.Windows.Forms.Padding(4);
            this.btnSetGpioInfo.Name = "btnSetGpioInfo";
            this.btnSetGpioInfo.Size = new System.Drawing.Size(103, 28);
            this.btnSetGpioInfo.TabIndex = 31;
            this.btnSetGpioInfo.Text = "设置";
            this.btnSetGpioInfo.UseVisualStyleBackColor = true;
            this.btnSetGpioInfo.Click += new System.EventHandler(this.btnSetGpioInfo_Click);
            // 
            // AdvanceSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.advgroupBox3);
            this.Controls.Add(this.advgroupBox2);
            this.Controls.Add(this.advgroupBox1);
            this.Name = "AdvanceSetting";
            this.Size = new System.Drawing.Size(808, 526);
            this.Load += new System.EventHandler(this.AdvanceSetting_Load);
            this.advgroupBox2.ResumeLayout(false);
            this.advgroupBox2.PerformLayout();
            this.advgroupBox1.ResumeLayout(false);
            this.advgroupBox1.PerformLayout();
            this.advgroupBox3.ResumeLayout(false);
            this.advgroupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox advgroupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox advgroupBox1;
        private System.Windows.Forms.Label advlabel3;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Button btnGetPermissonInfo;
        public System.Windows.Forms.Button btnSetPermissonInfo;
        private System.Windows.Forms.Label advlabel2;
        private System.Windows.Forms.CheckBox advcbxCodeEn;
        private System.Windows.Forms.TextBox txbMaskData;
        private System.Windows.Forms.Label advlabel10;
        private System.Windows.Forms.TextBox txbMaskStartAddr;
        private System.Windows.Forms.CheckBox advcbxMaskEn;
        private System.Windows.Forms.Label advlabel9;
        private System.Windows.Forms.TextBox txbPassword;
        private System.Windows.Forms.TextBox txbrelaytime;
        private System.Windows.Forms.CheckBox advcbxKCEn;
        private System.Windows.Forms.Label advlabel4;
        private System.Windows.Forms.CheckBox advcbxprotocolen;
        private System.Windows.Forms.CheckBox advcbxbufferen;
        private System.Windows.Forms.TextBox txbProtocolFormat;
        private System.Windows.Forms.Label advlabel5;
        private System.Windows.Forms.TextBox txbMasklen;
        private System.Windows.Forms.Label advlabel6;
        public System.Windows.Forms.ComboBox cmbMaskCondition;
        public System.Windows.Forms.ComboBox cmbProtocolType;
        private System.Windows.Forms.CheckBox advcbxKCPowerEn;
        private System.Windows.Forms.GroupBox advgroupBox3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton advrdbLowlevel;
        private System.Windows.Forms.RadioButton advrdbhighlevel;
        private System.Windows.Forms.Label advlabel7;
        public System.Windows.Forms.Button btnGetGpioInfo;
        public System.Windows.Forms.Button btnSetGpioInfo;
    }
}
