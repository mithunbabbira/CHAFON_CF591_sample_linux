using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using UHF_RFID_Net;
using UHF_RFID.Properties;
using System.IO;
using System.IO.Ports;
using System.Runtime.InteropServices;
using System.Configuration;
using System.Collections;
using System.Xml;
using System.Diagnostics;

namespace YYF100
{
    public partial class RFPanel : UserControl
    {

        private static Dictionary<string, string> DicLanguage = new Dictionary<string, string>();
        FrmMain m_owner = null;
        bool m_bError = false;
        Reader m_reader = new Reader();
        Devicepara m_devicepara = new Devicepara();
        Protocol m_proto = (UHF_RFID_Net.Protocol)Settings.Default.Proto;


        //Devicepara devicepara = new Devicepara();

        //SerialPort serialport = new SerialPort();//定义串口对象

        volatile bool m_bClosed = false;


        // 盘点数据版本，表示标签列表中的数据是第几次盘点上来的
        internal int m_iInventoryDataVersion = 0;

        public Protocol Protocol
        {
            get { return m_proto; }
        }

        public Hashtable ht
        {
            get { return (m_owner == null ? null : m_owner.HT); }
        }

        public Hashtable HT
        {
            get { return (m_owner == null ? null : m_owner.HT); }
        }

        public Reader Reader
        {
            get { return m_reader; }
        }

        public Devicepara Devicepara
        {
            get { return m_devicepara; }
        }

        public bool IsClosed
        {
            get { return m_bClosed; }
        }

        public ShowTagItem[] TagItems
        {
            get { return m_owner.TagItems; }
        }


        public RFPanel()
        {
            InitializeComponent();

        }

        private void RFPanel_Load(object sender, EventArgs e)
        {
            try
            {
                // 初始化值
                rdbFcc.Tag = ChannelRegionItem.USARegion;
                rdbChn1.Tag = ChannelRegionItem.China1Region;
                rdbChn2.Tag = ChannelRegionItem.China2Region;
                rdbEts.Tag = ChannelRegionItem.Europe3Region;
                rdbKorea.Tag = ChannelRegionItem.KoreaRegion;
                rdbEU.Tag = ChannelRegionItem.EuropeRegion;
                rdbJapan.Tag = ChannelRegionItem.JapanRegion;
                rdbMalaysia.Tag = ChannelRegionItem.MalaysiaRegion;
                rdbFreqCustom.Tag = ChannelRegionItem.CustomRegion;

                Settings.Default.Upgrade();
                txbIPAddr.Text = Settings.Default.IPAddr;
                txbPort.Text = Settings.Default.Port.ToString();

                cmbGbModu.Items.Clear();
                cmbGbModu.Items.AddRange(LinkModuItem.GbOptions);
                cmbGbModu.SelectedIndex = 0;

                cmbTxPower.Text = Settings.Default.TxPower.ToString();
                cmbRegion.Text = Settings.Default.Region.ToString();
                cmbWorkmode.SelectedIndex = Settings.Default.Workmode;
                cmbWiggendOutMode.SelectedIndex = Settings.Default.Wieggand;

                rbnusb.PerformClick();          //默认设置USB


                Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                string languageType = config.AppSettings.Settings["Language"].Value;
                //bindCbox(languageType);
                MultiLanguage.SetLanguage(this);


                cmbLanguage.DroppedDown = !cmbLanguage.DroppedDown;          //模拟Dropdowm
                cmbLanguage.Text = languageType;
                cmbLanguage.DropDownStyle = ComboBoxStyle.DropDownList;
                cmbComBaud.DropDownStyle = ComboBoxStyle.DropDownList;

            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
            
        }

        internal void GetSettings()
        {
            Reader reader = this.Reader;
            if (reader == null || !reader.IsOpened)
                return;
            m_bError = false;
            if (this.Protocol == Protocol.ISO_18000_63)
                btnGetMode_Click(this, EventArgs.Empty);
            else if (this.Protocol == Protocol.GB_T_29768)
                btnGetLinkPrm_Click(this, EventArgs.Empty);
            else if (this.Protocol == Protocol.GJB_7377_1)
                btnGetLinkPrm_Click(this, EventArgs.Empty);
            if (m_bError)
                return;
            btnGetFreq_Click(this, EventArgs.Empty);
            if (m_bError)
                return;
            btnGetLinkPrm_Click(this, EventArgs.Empty);
            if (m_bError)
                return;
            btnGetAntenna_Click(this, EventArgs.Empty);
            if (m_bError)
                return;
            btnGetTxPower_Click(this, EventArgs.Empty);
        }

        internal void UpdateProto()
        {
            if (this.Protocol == Protocol.GB_T_29768)
            {
                cmbGbTc.Items.Clear();
                cmbGbTc.Items.AddRange(UHF_RFID_Net.GB.LinkTcItem.Options);
                cmbGbBlf.Items.Clear();
                cmbGbBlf.Items.AddRange(UHF_RFID_Net.GB.LinkBLFItem.Options);
                cmbGbM.Items.Clear();
                cmbGbM.Items.AddRange(UHF_RFID_Net.GB.LinkMItem.Options);
                cmbGbTrext.Items.Clear();
                cmbGbTrext.Items.AddRange(UHF_RFID_Net.GB.LinkTRextItem.Options);

                cmbGbTc.SelectedIndex = 0;
                cmbGbBlf.SelectedIndex = 3;
                cmbGbM.SelectedIndex = 1;
                cmbGbTrext.SelectedIndex = 1;

                //groupBox3.Visible = false;
                groupBox4.Visible = true;
                groupBox4.Top = groupBox2.Bottom + 10;
                //groupBox6.Top = groupBox4.Bottom + 10;
            }
            else if (this.Protocol == Protocol.GJB_7377_1)
            {

                cmbGbBlf.Items.Clear();
                //cmbGbBlf.Items.AddRange(UHF_RFID_Net.GJB.LinkBLFItem.Options);
                cmbGbTc.Items.Clear();
                cmbGbTc.Items.AddRange(UHF_RFID_Net.GJB.LinkTcItem.Options);
                cmbGbM.Items.Clear();
                cmbGbM.Items.AddRange(UHF_RFID_Net.GJB.LinkMItem.Options);
                cmbGbTrext.Items.Clear();
                cmbGbTrext.Items.AddRange(UHF_RFID_Net.GJB.LinkTRextItem.Options);

                cmbGbTc.SelectedIndex = 0;
                //cmbGbBlf.SelectedIndex = 3;
                cmbGbM.SelectedIndex = 1;
                cmbGbTrext.SelectedIndex = 1;

                //groupBox3.Visible = false;
                groupBox4.Visible = true;
                groupBox4.Top = groupBox2.Bottom + 10;
                //groupBox6.Top = groupBox4.Bottom + 10;
            }
            else
            {
                //groupBox3.Visible = false;
                groupBox4.Visible = false;
                //groupBox5.Visible = false;         // 不显示天线
                //groupBox3.Top = groupBox2.Bottom + 10;
                //groupBox6.Top = groupBox2.Bottom + 10;
            }
        }

        private void rdbFreq_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void cmbGbTc_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnGetFreq_Click(object sender, EventArgs e)
        {

        }

        private void btnSetFreq_Click(object sender, EventArgs e)
        {

        }

        private void btnGetMode_Click(object sender, EventArgs e)
        {

        }

        private void btnSetMode_Click(object sender, EventArgs e)
        {

        }

        private void btnGetLinkPrm_Click(object sender, EventArgs e)
        {

        }

        private void btnSetLinkPrm_Click(object sender, EventArgs e)
        {

        }

        private void btnGetAntenna_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                byte antenna;
                WriteLog(MessageType.Info, (string)ht["Text3"], null);
                using (FrmPrompt frmPrompt = new FrmPrompt())
                {
                    frmPrompt.PromptText = (string)ht["Text4"];
                    frmPrompt.FormText = (string)ht["Text9"];
                    frmPrompt.Show(this);
                    frmPrompt.Update();
                    Application.DoEvents();

                    antenna = reader.GetAntenna();
                }
                WriteLog(MessageType.Info, (string)ht["Text5"] + GetAntennaInfo(antenna), null);

                ckbAnt1.Checked = ((antenna & 1) != 0);
                ckbAnt2.Checked = ((antenna & 2) != 0);
                ckbAnt3.Checked = ((antenna & 4) != 0);
                ckbAnt4.Checked = ((antenna & 8) != 0);
                if ((antenna & 15) == 0)
                {
                    WriteLog(MessageType.Warning, (string)ht["Text6"], null);
                    MessageBox.Show(this, (string)ht["Text6"], this.Text);
                }
            }
            catch (Exception ex)
            {
                m_bError = true;
                WriteLog(MessageType.Error, (string)ht["Text7"], ex);
                MessageBox.Show(this, (string)ht["Text7"] + ex.Message, this.Text);
            }
        }

        private void btnSetAntenna_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                byte antenna = 0;
                if (ckbAnt1.Checked)
                    antenna |= 0x01;
                if (ckbAnt2.Checked)
                    antenna |= 0x02;
                if (ckbAnt3.Checked)
                    antenna |= 0x04;
                if (ckbAnt4.Checked)
                    antenna |= 0x08;
                if (antenna == 0)
                {
                    MessageBox.Show(this, (string)ht["Text8"], (string)ht["Text9"]);
                    return;
                }

                WriteLog(MessageType.Info, (string)ht["Text10"], null);
                reader.SetAntenna(ref antenna);
                WriteLog(MessageType.Info, (string)ht["Text11"] + GetAntennaInfo(antenna), null);

                ckbAnt1.Checked = ((antenna & 1) != 0);
                ckbAnt2.Checked = ((antenna & 2) != 0);
                ckbAnt3.Checked = ((antenna & 4) != 0);
                ckbAnt4.Checked = ((antenna & 8) != 0);
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text12"], ex);
                MessageBox.Show(this, (string)ht["Text12"] + ex.Message, this.Text);
            }
        }

        private void btnGetTxPower_Click(object sender, EventArgs e)
        {

        }

        private void ClearLinkMode()
        {
            //rdbLinkMode0.Checked = false;
            //rdbLinkMode1.Checked = false;
            //rdbLinkMode2.Checked = false;
            //rdbLinkMode3.Checked = false;
        }

        private string GetAntennaInfo(byte antenna)
        {
            StringBuilder sb = new StringBuilder((string)ht["Text13"], 32);
            int len = sb.Length;
            for (int i = 0; i < 4; i++)
            {
                if ((antenna & (1 << i)) != 0)
                {
                    sb.Append((string)ht["Text14"]);
                    sb.Append(i + 1);
                    sb.Append(',');
                }
            }
            if (sb.Length == len)
                return (string)ht["Text15"];

            sb.Length -= 1;
            return sb.ToString();
        }

        internal void SetOwner(FrmMain owner)
        {
            m_owner = owner;
        }

        public void WriteLog(MessageType type, string msg, Exception ex)
        {
            if (m_owner != null)
                m_owner.WriteLog(type, msg, ex);
        }
        // 页面顺序 
        // 应答-高级设置-主动-读写-测试-网络-Debug
        public void HideTabPage(int index)
        {
            if (m_owner != null)
                m_owner.HideTabPage(index);
        }


        private void btnSportOpen_Click(object sender, EventArgs e)
        {
            try
            {
                string port = cmbComPort.Text.Trim();
                if (m_reader.IsOpened)
                {
                    MessageBox.Show(this, (string)ht["Text17"], this.Text);
                    return;
                }
                //serialport.DataReceived += serialport_DataReceived;
                if (rbncom.Checked == true)     //用串口连接
                {
                    if (port.Length == 0)
                    {
                        MessageBox.Show(this, (string)ht["Text16"], this.Text);
                        return;
                    }

                    m_reader.Open(port, (byte)cmbComBaud.SelectedIndex);

                    WriteLog(MessageType.Info, (string)ht["Text1"] + port, null);
                    //WriteLog(MessageType.Info, "阅读器打开成功，串口号：" + port, null);
                    cmbComPort.Enabled = false;
                    btnSportOpen.Enabled = false;
                    groupNet.Enabled = false;
                }
                else if(rbnusb.Checked == true)   //HID 连接
                {
                    m_reader.Open((byte)cbxusbpath.SelectedIndex);     // 打开选中的路径
                    WriteLog(MessageType.Info, (string)ht["Text1"] + port, null);
                    //WriteLog(MessageType.Info, "阅读器打开成功，串口号：" + port, null);
                    cbxusbpath.Enabled = false;
                    btnSportOpen.Enabled = false;
                    groupNet.Enabled = false;
                }

                rbncom.Enabled = false;   //不允许切换连接方式
                rbnusb.Enabled = false;
            }
            catch (Exception ex)
            {
                try
                {
                    Reader reader = this.Reader;
                    if (reader.IsOpened)
                        reader.Close();
                }
                catch { }
                lblStatus.Text = "状态：未连接";
                lblVersion.Text = "硬件版本：---\r\n软件版本：---\r\n  序列号：---";

                WriteLog(MessageType.Error, (string)ht["Text18"], ex);
                cmbComPort.Enabled = true;
                btnSportOpen.Enabled = true;
                cbxusbpath.Enabled = true;
                MessageBox.Show(this, (string)ht["Text18"] + ex.Message, this.Text);
            }
            InitReader();
        }
        private void InitReader()
        {
            try
            {
                Reader reader = this.Reader;
                if (reader.IsOpened)
                {

                    /**
                     * 模块获取设备号
                     */
                    DeviceFullInfo info = m_reader.GetDeviceFullInfo();


                    if ("UHF Prime Reader" != info.DeviceFirmwareVersion.Substring(0, 16))
                    {
                        if ("UHF Access Reader" == info.DeviceFirmwareVersion.Substring(0, 17) || "UHF Desk Reader" == info.DeviceFirmwareVersion.Substring(0, 15))
                        {
                            if ("CP-205910" == info.DeviceHardwareVersion.Substring(0, 9) || "CP-206910" == info.DeviceHardwareVersion.Substring(0, 9))
                            {
                                reader.Devicetpye = 1;
                                HideTabPage(1);
                                HideTabPage(5);
                                HideTabPage(6);
                            }
                        }
                        else
                        {
                            btnSportClose.PerformClick();
                            btnDisConnect.PerformClick();
                            return;
                        }
                    }
                    else
                    {
#if false
                        if ("CP-202910" == info.DeviceHardwareVersion.Substring(0, 9) || "CP-202912" == info.DeviceHardwareVersion.Substring(0, 9))
                        {
                            reader.Devicetpye = 1;
                        }
                        else if ("CP-202904" == info.DeviceHardwareVersion.Substring(0, 9))
                        {
                            reader.Devicetpye = 2;
                        }
                        else if ("CP-202914" == info.DeviceHardwareVersion.Substring(0, 9))
                        {
                            reader.Devicetpye = 3;
                            groupBox5.Visible = true;            //天线默认不可见
                        }
                        else if ("CP-202804" == info.DeviceHardwareVersion.Substring(0, 9))
                        {
                            reader.Devicetpye = 4;
                            groupBox5.Visible = true;            //天线默认不可见
                        }
                        else               
                        {

                            btnSportClose.PerformClick();
                            btnDisConnect.PerformClick();
                            return;
                        }
#endif
                        btnSportClose.PerformClick();
                        btnDisConnect.PerformClick();
                        return;
                    }
                    tbxHardversion.Text = info.DeviceHardwareVersion;
                    tbxSoftversion.Text = info.DeviceFirmwareVersion;
                    tbxDeviceSN.Text = Util.HexArrayToString(info.DeviceSN);


                    btnOutputPara.Enabled = true;
                    btnInputPara.Enabled = true;
                    btnEnbableKC.Enabled = true;
                    btnDisableKC.Enabled = true;

                    groupBox9.Enabled = true;
                    groupBox8.Enabled = true;
                    groupBox5.Enabled = true;

                    btnGetAllPara.Enabled = true;
                    btnSetAllPara.Enabled = true;
                    btnSetDefaultPara.Enabled = true;



                    btnGetAllPara.PerformClick();                                         // 需要enbable后才能虚拟click按键
                    //WriteLog(MessageType.Info, (string)ht["Text19"], null);

                    //if (m_reader.IsOpenedAsNetwork)
                    //    lblStatus.Text = "状态：网络连接已建立";
                    //else
                    //    lblStatus.Text = "状态：串口已连接";


                }
            }
            catch (Exception ex)
            {

                btnSportClose.PerformClick();
                btnDisConnect.PerformClick();

                WriteLog(MessageType.Error, (string)ht["Text20"], ex);
                MessageBox.Show(this, (string)ht["Text20"] + ex.Message, this.Text);

                try { UpdateProto(); }
                catch (Exception ex2)
                {
                    WriteLog(MessageType.Error, (string)ht["Text21"], ex2);
                    MessageBox.Show(this, (string)ht["Text21"] + ex2.Message, this.Text);
                }
                return;
            }

            try
            {
                UpdateProto();

            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text22"], ex);
                MessageBox.Show(this, (string)ht["Text22"] + ex.Message, this.Text);
            }
            //panelRFSetting.GetSettings();     // 链路工作模式不显示，不需要用户设置
            //testPanel1.GetSettings();
        }

        private void btnSportClose_Click(object sender, EventArgs e)
        {
            try
            {
                WriteLog(MessageType.Info, (string)ht["Text23"], null);
                lblStatus.Text = "状态：未连接";
                lblVersion.Text = "硬件版本：---\r\n软件版本：---\r\n  序列号：---";

                cmbComPort.Enabled = true;
                btnSportOpen.Enabled = true;
                cbxusbpath.Enabled = true;
                groupNet.Enabled = true;
                
                rbncom.Enabled = true;   //允许切换连接方式
                rbnusb.Enabled = true;

                Reader reader = this.Reader;
                if (reader == null)
                    return;

                reader.Close();

                btnOutputPara.Enabled = false;
                btnInputPara.Enabled = false;
                btnEnbableKC.Enabled = false;
                btnDisableKC.Enabled = false;

                groupBox9.Enabled = false;
                groupBox8.Enabled = false;
                groupBox5.Enabled = false;

                btnGetAllPara.Enabled = false;
                btnSetAllPara.Enabled = false;
                btnSetDefaultPara.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }
        //Control.CheckForIllegalCrossThreadCalls = false;
        private void cmbComPort_DropDown(object sender, EventArgs e)
        {
            try
            {
                string[] ports = SerialPort.GetPortNames();
                Array.Sort(ports);
                if (IsPortsChanged(ports))
                {
                    cmbComPort.Items.Clear();
                    cmbComPort.Items.AddRange(ports);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private bool IsPortsChanged(string[] ports)
        {
            ComboBox.ObjectCollection items = cmbComPort.Items;
            if (items.Count != ports.Length)
                return true;

            for (int i = 0; i < ports.Length; i++)
            {
                if (string.Compare(items[i].ToString(), ports[i], StringComparison.OrdinalIgnoreCase) != 0)
                    return true;
            }
            return false;
        }



        private void cmbTxPower_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //private delegate void WriteLogHandler(MessageType type, string msg, Exception ex);

        //public void WriteLog(MessageType type, string msg, Exception ex)
        //{
        //    try
        //    {
        //        if (this.InvokeRequired)
        //        {
        //            this.BeginInvoke(new WriteLogHandler(WriteLog), type, msg, ex);
        //            return;
        //        }

        //        StringBuilder sb = new StringBuilder(128);
        //        sb.Append(DateTime.Now);
        //        sb.Append(", ");
        //        switch (type)
        //        {
        //            case MessageType.Info:
        //                sb.Append("信息：");
        //                break;
        //            case MessageType.Warning:
        //                sb.Append("警告：");
        //                break;
        //            case MessageType.Error:
        //                sb.Append("错误：");
        //                break;
        //        }
        //        if (msg.Length > 0)
        //            sb.Append(msg);
        //        if (ex != null)
        //            sb.Append(ex.Message);
        //        sb.Append("\r\n");

        //        string msg2 = sb.ToString();
        //        txbLog.AppendText(msg2);
        //        txbLog.SelectionLength = 0;
        //        txbLog.SelectionStart = txbLog.TextLength;
        //        txbLog.ScrollToCaret();
        //    }
        //    catch { }
        //}



        private void btnGetAllPara_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                WriteLog(MessageType.Info, (string)ht["Text19"], null);
                // 弹窗去除
                //using (FrmPrompt frmPrompt = new FrmPrompt())
                //{
                //    frmPrompt.PromptText = (string)ht["Text2"];
                //    frmPrompt.FormText = (string)ht["Text9"];
                //    frmPrompt.Show(this);
                //    frmPrompt.Update();
                //    Application.DoEvents();
                //    m_devicepara = reader.GetDevicePara();
                //}

                m_devicepara = reader.GetDevicePara();

                tbxDeviceAddr.Text = m_devicepara.Addr.ToString("X"); ;
                byte baud = m_devicepara.Baud;
                if (baud == 0)
                {
                    cmbSerialbaud.Text = (9600).ToString();
                }
                else if (baud == 1)
                {
                    cmbSerialbaud.Text = (19200).ToString();
                }
                else if (baud == 2)
                {
                    cmbSerialbaud.Text = (38400).ToString();
                }
                else if (baud == 3)
                {
                    cmbSerialbaud.Text = (57600).ToString();
                }
                else if (baud == 4)
                {
                    cmbSerialbaud.Text = (115200).ToString();
                }
                else
                {
                    WriteLog(MessageType.Info, (string)ht["Text24"] + baud, null);
                }
                byte workmode;
                workmode = m_devicepara.Workmode;
                if (workmode == 0)
                { 
                    cmbWorkmode.SelectedIndex = 0;
                }
                else if (workmode == 1)
                {
                    cmbWorkmode.SelectedIndex = 1;
                }
                else if (workmode == 2)
                {
                    cmbWorkmode.SelectedIndex = 2;
                }
                else {
                    //error
                }
                byte interport;
                interport = m_devicepara.port; ;
                if (interport == 0x80)
                {
                    cmbOutInterface.SelectedItem = "RS232";
                }
                else if (interport == 0x40)
                {
                    cmbOutInterface.SelectedItem = "RS485";
                }
                else if (interport == 0x20)
                {
                    cmbOutInterface.SelectedItem = "RJ45";
                }
                else if (interport == 0x10)
                {
                    cmbOutInterface.SelectedItem = "WiFi";
                }
                else if (interport == 0x01)
                {
                    cmbOutInterface.SelectedItem = "USB";
                }
                else if (interport == 0x02)
                {
                    cmbOutInterface.SelectedItem = "KeyBoard";
                }
                else if (interport == 0x04)
                {
                    cmbOutInterface.SelectedItem = "CDC_COM";
                }

                byte wieggand;
                wieggand = m_devicepara.wieggand; ;
                if ((wieggand >> 7) == 1)
                {
                    cmbOutInterface.SelectedItem = "Wieggand";
                }
                else 
                {
                    //cmbOutInterface.SelectedItem = "Wieggand";
                }

                if ((wieggand & 0x40) != 0)
                {
                    cmbWiegandMode.Text = "WG34";
                }
                else
                {
                    cmbWiegandMode.Text = "WG26";
                }

                if ((wieggand & 0x20) != 0)
                {
                    cmbWiggendOutMode.SelectedIndex = 0;
                }
                else
                {
                    cmbWiggendOutMode.SelectedIndex = 1;
                }

                FreqInfo freq = new FreqInfo();
                freq.Region = m_devicepara.Region;
                freq.StartFreq = (float)m_devicepara.StartFreq + (float)m_devicepara.StartFreqde / 1000.0f;
                freq.StepFreq = (ushort)m_devicepara.Stepfreq;
                freq.Count = m_devicepara.Channel;
                ChannelRegionItem region = ChannelRegionItem.OptionFromValue((ChannelRegion)freq.Region, !Settings.Default.IsTest);

                cmbFreqStart.Text = freq.StartFreq.ToString("F3");

                cmbFreqEnd.Text = (freq.StartFreq + freq.StepFreq*freq.Count).ToString("F3");

                switch (region.Value)
                {
                    case ChannelRegion.USA:
                        cmbRegion.Text = "USA";
                        break;
                    case ChannelRegion.China_1:
                            cmbRegion.Text = "China_1";
                    break;
                    case ChannelRegion.China_2:
                            cmbRegion.Text = "China_2";
                    break;
                    case ChannelRegion.Europe3:
                            cmbRegion.Text = "Europe3";
                    break;
                    case ChannelRegion.Korea:
                            cmbRegion.Text = "Korea";
                    break;
                    case ChannelRegion.Europe:
                            cmbRegion.Text = "Europe";
                    break;
                    case ChannelRegion.Japan:
                            cmbRegion.Text = "Japan";
                    break;
                    case ChannelRegion.Malaysia:
                            cmbRegion.Text = "Malaysia";
                    break;
                    default:
                        //rdbFreqCustom.Checked = true;
                        //cmbFreqStart.Text = freq.StartFreq.ToString("F3");
                        //txbChannelStep.Text = freq.StepFreq.ToString();
                        //cmbFreqEnd.Text = freq.Count.ToString();
                        return;
                }

                // 频率获取错误。1107

                    //ChannelItem item1 = null;
                    //ChannelCount item2 = null;
                    //foreach (ChannelItem item in cmbFreqStart.Items)
                    //{
                    //    if (Math.Abs(item.Freq - freq.StartFreq) < 0.01)
                    //    {
                    //        item1 = item;
                    //        break;
                    //    }
                    //}
                    //if (item1 != null)
                    //{
                    //    foreach (ChannelCount item in cmbFreqEnd.Items)
                    //    {
                    //        if (item.Count == freq.Count)
                    //        {
                    //            item2 = item;
                    //            break;
                    //        }
                    //    }
                    //}

                    //cmbFreqStart.SelectedItem = item1;
                    //cmbFreqEnd.SelectedItem = item2;
                //txbChannelStep.Text = freq.StepFreq.ToString();

                cmbTxPower.Text = m_devicepara.Power.ToString();
                byte area = m_devicepara.Area;
                if (area == 0)
                {
                    cmbInventoryArea.Text = "Reserve";
                }
                else if (area == 1)
                {
                    cmbInventoryArea.Text = "EPC";
                }
                else if (area == 2)
                {
                    cmbInventoryArea.Text = "TID";
                }
                else if (area == 3)
                {
                    cmbInventoryArea.Text = "User";
                }

                cmbQvalue.SelectedIndex = m_devicepara.Q;
                cmbSession.SelectedIndex = m_devicepara.Session;
                tbxInventoryStartAddr.Text = m_devicepara.Startaddr.ToString("D");   //用十进制显示
                tbxInventoryDataLen.Text = m_devicepara.DataLen.ToString("D");        // 用十进制显示

                tbxFilterTime.Text = m_devicepara.Filtertime.ToString();
                tbxTriggerTime.Text = m_devicepara.Triggletime.ToString();

                if (m_devicepara.Ant > 1)
                {
                    ckbAnt2.Checked = true;
                }
                else
                {
                    ckbAnt2.Checked = false;
                }


                if (m_devicepara.Buzzertime != 0)
                {
                    cbxBuzzerEn.Checked = true;
                }
                else
                {
                    cbxBuzzerEn.Checked = false;
                }

                tbxAnswerTime.Text = m_devicepara.IntenelTime.ToString("D");

                WriteLog(MessageType.Info, (string)ht["Text25"] , null);
            }
 
            catch (Exception ex)
            {
                m_bError = true;
                WriteLog(MessageType.Error, (string)ht["Text22"], ex);
                 MessageBox.Show(this, (string)ht["Text22"] + ex.Message, this.Text);
            }
    }


        private void btnSetAllPara_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                WriteLog(MessageType.Info, (string)ht["Text19"], null);
                //using (FrmPrompt frmPrompt = new FrmPrompt())
                //{
                //    frmPrompt.PromptText = "获取读卡器设置...";
                //    frmPrompt.Show(this);
                //    frmPrompt.Update();
                //    Application.DoEvents();

                //    m_devicepara = reader.GetDevicePara();
                //}
                m_devicepara.Addr = (byte)Util.HexFromString(tbxDeviceAddr.Text);
                m_devicepara.Baud = (byte)cmbSerialbaud.SelectedIndex;
                m_devicepara.Protocol = 0;
                m_devicepara.Workmode = (byte)cmbWorkmode.SelectedIndex;
                m_devicepara.Region = (byte)cmbRegion.SelectedIndex;

                if (reader.Devicetpye == 3 || reader.Devicetpye == 4)   // 914或者804，两个天线
                {
                    if (ckbAnt2.Checked)                                //如果天线2勾选
                    {
                        m_devicepara.Ant = 3;
                    }
                    else
                    {
                        m_devicepara.Ant = 1;
                    }
                }
                else
                {
                    m_devicepara.Ant = 1;
                }
                m_devicepara.port = (byte)cmbOutInterface.SelectedIndex;
                if (m_devicepara.port == 0)
                {
                    m_devicepara.port = 0x80;
                    m_devicepara.wieggand = 0x00;
                }
                else if (m_devicepara.port == 1)
                {
                    m_devicepara.port = 0x40;
                    m_devicepara.wieggand = 0x00;
                }
                else if (m_devicepara.port == 2)
                {
                    m_devicepara.port = 0x20;
                    m_devicepara.wieggand = 0x00;
                }
                else if (m_devicepara.port == 4)   // Wifi
                {
                    m_devicepara.port = 0x10;
                    m_devicepara.wieggand = 0x00;
                }
                else if (m_devicepara.port == 5)   // USB
                {
                    m_devicepara.port = 0x01;
                    m_devicepara.wieggand = 0x00;
                }
                else if (m_devicepara.port == 6)   // Keyoard
                {
                    m_devicepara.port = 0x02;
                    m_devicepara.wieggand = 0x00;
                }
                else if (m_devicepara.port == 7)   // CDC_COM
                {
                    m_devicepara.port = 0x04;
                    m_devicepara.wieggand = 0x00;
                }
                else
                {
                    m_devicepara.port = 0x80;
                    m_devicepara.wieggand = 0x80;
                }

                if (cmbWiegandMode.SelectedIndex == 0)            // WG26
                {
                    m_devicepara.wieggand &= 0xBF;

                }
                else                                              // WG34
                {
                    m_devicepara.wieggand |= 0x40;
                }


                if (cmbWiggendOutMode.SelectedIndex == 0)
                {
                    m_devicepara.wieggand |= 0x20;            // 高字节在前
                }
                else
                {
                    m_devicepara.wieggand &= 0xDF;            // 低字节在前
                }

                FreqInfo info = new FreqInfo();

                ChannelRegionItem region = ChannelRegionItem.OptionFromValue(ChannelRegionItem.StringToRegion(cmbRegion.Text), !Settings.Default.IsTest);
                if (region == null)
                    return;

                float f_endfreq;
                float freq2;
                int step2;
                int count2;
                if (region.Value == 0)          // custom
                {
                    string starfreq = cmbFreqStart.Text.Trim();
                    if (starfreq.Length == 0)
                        throw new Exception((string)ht["Text26"]);
                    string step = (500).ToString();
                    string endfreq = cmbFreqEnd.Text.Trim();

                    if (!float.TryParse(starfreq, out freq2) || freq2 < 840 || freq2 > 960)
                        throw new Exception((string)ht["Text27"]);
                    if (!float.TryParse(endfreq, out f_endfreq) || f_endfreq < 840 || f_endfreq > 960)
                        throw new Exception((string)ht["Text27"]);
                    step2 = Util.NumberFromString(step);
                    if (step2 < 0 || step2 > 2000)
                        throw new Exception((string)ht["Text28"]);

                    count2 =(int) (f_endfreq - freq2)/ step2;
                    if (count2 < 1 || count2 > 50)
                        throw new Exception((string)ht["Text29"]);
                }
                else
                {
                    ChannelItem item = cmbFreqStart.SelectedItem as ChannelItem;
                    if (item == null)
                        throw new Exception((string)ht["Text30"]);
                    freq2 = item.Freq;
                    ChannelCount cnt = cmbFreqEnd.SelectedItem as ChannelCount;
                    if (cnt == null)
                        throw new Exception((string)ht["Text31"]);
                    count2 = cmbFreqEnd.SelectedIndex - cmbFreqStart.SelectedIndex + 1;
                    f_endfreq = freq2 + (region.FreqStep) * count2;
                }

                float i;
                i = freq2 * 1000;                                                   // 不能动

                m_devicepara.StartFreq = (ushort)freq2;
                m_devicepara.StartFreqde = (ushort)(i - ((int)freq2) * 1000);       // 精度问题，浮点数运算会丢失
                m_devicepara.Stepfreq = (ushort)region.FreqStep;
                m_devicepara.Channel = (byte)count2;


                m_devicepara.Power = (byte)Util.NumberFromString(cmbTxPower.Text);
                m_devicepara.Area = (byte)cmbInventoryArea.SelectedIndex;
                m_devicepara.Q = (byte)cmbQvalue.SelectedIndex;
                m_devicepara.Session = (byte)cmbSession.SelectedIndex;
                m_devicepara.Startaddr = (byte)Util.NumberFromString(tbxInventoryStartAddr.Text);
                m_devicepara.DataLen = (byte)Util.NumberFromString(tbxInventoryDataLen.Text);
                m_devicepara.Filtertime = (byte)Util.NumberFromString(tbxFilterTime.Text);
                m_devicepara.Triggletime = (byte)Util.NumberFromString(tbxTriggerTime.Text);
                m_devicepara.IntenelTime = (byte)Util.NumberFromString(tbxAnswerTime.Text);

                if (cbxBuzzerEn.Checked)
                {
                    m_devicepara.Buzzertime = 1;
                }
                else
                {
                    m_devicepara.Buzzertime = 0;
                }
                reader.SetDevicePara(m_devicepara);
                WriteLog(MessageType.Info, (string)ht["Text32"], null);
            }

            catch (Exception ex)
            {
                m_bError = true;
                WriteLog(MessageType.Error, (string)ht["Text33"], ex);
                MessageBox.Show(this, (string)ht["Text33"] + ex.Message, this.Text);
            }
        }

        private void tbxDeviceAddr_KeyPress(object sender, KeyPressEventArgs e)
        {

            e.Handled = !((e.KeyChar >= '0' && e.KeyChar <= '9') || (e.KeyChar >= 'a' && e.KeyChar <= 'f') || (e.KeyChar >= 'A' && e.KeyChar <= 'F'));
            if (e.KeyChar == (char)8)  //允许输入回退键
            {
                e.Handled = false;
            }
            if (e.KeyChar == 'x')  //允许输入‘x’
            {
                e.Handled = false;
            }
            if (e.KeyChar == 'X')  //允许输入'X'
            {
                e.Handled = false;
            }
        }

        private void tbxInventoryStartAddr_KeyPress(object sender, KeyPressEventArgs e)
        {

            e.Handled = !((e.KeyChar >= '0' && e.KeyChar <= '9') || (e.KeyChar >= 'a' && e.KeyChar <= 'f') || (e.KeyChar >= 'A' && e.KeyChar <= 'F'));
            if (e.KeyChar == (char)8)  //允许输入回退键
            {
                e.Handled = false;
            }
            if (e.KeyChar == 'x')  //允许输入‘x’
            {
                e.Handled = false;
            }
            if (e.KeyChar == 'X')  //允许输入'X'
            {
                e.Handled = false;
            }
        }

        private void tbxInventoryDataLen_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !((e.KeyChar >= '0' && e.KeyChar <= '9') || (e.KeyChar >= 'a' && e.KeyChar <= 'f') || (e.KeyChar >= 'A' && e.KeyChar <= 'F'));
            if (e.KeyChar == (char)8)  //允许输入回退键
            {
                e.Handled = false;
            }
            if (e.KeyChar == 'x')  //允许输入‘x’
            {
                e.Handled = false;
            }
            if (e.KeyChar == 'X')  //允许输入'X'
            {
                e.Handled = false;
            }
        }

        private void tbxTriggerTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !((e.KeyChar >= '0' && e.KeyChar <= '9'));
            if (e.KeyChar == (char)8)  //允许输入回退键
            {
                e.Handled = false;
            }
        }

        private void tbxTriggerTime_TextChanged(object sender, EventArgs e)
        {
            if (tbxTriggerTime.Text == "")
            {
                //tbxTriggerTime.Text = 0.ToString();
            }
            else
            {
                int number = int.Parse(tbxTriggerTime.Text);
                if ((number >= 3) && (number <= 255))
                {

                }
                else if (number < 3)
                {
                    number = 3;
                }
                else if (number > 255)
                {
                    number = 255;
                }
                tbxTriggerTime.Text = number.ToString();
            }

        }

        private void tbxInventoryDataLen_TextChanged(object sender, EventArgs e)
        {
            if (tbxTriggerTime.Text == "")
            {
                //tbxTriggerTime.Text = 0.ToString();
            }
            else
            {
                int number = int.Parse(tbxTriggerTime.Text);
                if ((number >= 0) && (number <= 255))
                {

                }
                else if (number > 255)
                {
                    number = 255;
                }
                tbxTriggerTime.Text = number.ToString();
            }
        }

        private void tbxFilterTime_TextChanged(object sender, EventArgs e)
        {
            if (tbxTriggerTime.Text == "")
            {
                //tbxTriggerTime.Text = 0.ToString();
            }
            else
            {
                int number = int.Parse(tbxTriggerTime.Text);
                if ((number >= 0) && (number <= 255))
                {

                }
                else if (number > 255)
                {
                    number = 255;
                }
                tbxTriggerTime.Text = number.ToString();
            }
        }

        private void tbxAnswerTime_TextChanged(object sender, EventArgs e)
        {
            if (tbxTriggerTime.Text == "")
            {
                //tbxTriggerTime.Text = 0.ToString();
            }
            else
            {
                int number = int.Parse(tbxTriggerTime.Text);
                if ((number >= 0) && (number <= 255))
                {

                }
                else if (number > 255)
                {
                    number = 255;
                }
                tbxTriggerTime.Text = number.ToString();
            }
        }

        private void tbxAnswerTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !((e.KeyChar >= '0' && e.KeyChar <= '9'));
            if (e.KeyChar == (char)8)  //允许输入回退键
            {
                e.Handled = false;
            }
        }

        private void tbxFilterTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !((e.KeyChar >= '0' && e.KeyChar <= '9'));
            if (e.KeyChar == (char)8)  //允许输入回退键
            {
                e.Handled = false;
            }
        }

        private void btnSetDefaultPara_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                reader.RebootDevice();
                WriteLog(MessageType.Info, (string)ht["Text34"], null);
                System.Threading.Thread.Sleep(3 * 1000);  //延时3毫秒
                //btnGetAllPara.PerformClick();
                MessageBox.Show(this, (string)ht["Text34"] + ": Please Relink the Reader", this.Text);
            }
            catch (Exception ex)
            {
                m_bError = true;
                WriteLog(MessageType.Error, (string)ht["Text35"], ex);
                MessageBox.Show(this, (string)ht["Text35"] + ex.Message, this.Text);
            }
        }

        private void cmbRegion_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                cmbFreqStart.Items.Clear();
                cmbFreqEnd.Items.Clear();


                ChannelRegionItem region = ChannelRegionItem.OptionFromValue(ChannelRegionItem.StringToRegion(cmbRegion.Text), !Settings.Default.IsTest);
                if (region == null)
                    return;

                if (region.Value == ChannelRegion.Custom)
                {
                    //label31.Text = "信道个数：";
                    cmbFreqStart.DropDownStyle = ComboBoxStyle.DropDown;
                    cmbFreqEnd.DropDownStyle = ComboBoxStyle.DropDown;
                    txbChannelStep.Visible = true;
                    lblChannelStep.Visible = true;
                    lblChannelStepUnit.Visible = true;
                }
                else
                {
                    //label31.Text = "结束频率：";
                    cmbFreqStart.DropDownStyle = ComboBoxStyle.DropDownList;
                    cmbFreqEnd.DropDownStyle = ComboBoxStyle.DropDownList;
                    txbChannelStep.Visible = true;
                    lblChannelStep.Visible = true;
                    lblChannelStepUnit.Visible = true;

                    cmbFreqStart.Items.AddRange(region.GetChannelItems());
                    cmbFreqEnd.Items.AddRange(region.GetChanelCounts());
                    txbChannelStep.Text = region.FreqStep.ToString();

                    if (cmbFreqStart.Items.Count > 0)
                        cmbFreqStart.SelectedIndex = 0;
                    if (cmbFreqEnd.Items.Count > 0)
                        cmbFreqEnd.SelectedIndex = cmbFreqEnd.Items.Count - 1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }


        private string SelectPath() //弹出一个选择目录的对话框
        {
            FolderBrowserDialog path = new FolderBrowserDialog();
            path.ShowDialog();
            return path.SelectedPath;
        }

        private string SelectFile() //弹出一个选择文件的对话框
        {
            OpenFileDialog file = new OpenFileDialog();
            file.Filter = "Savedpara|*.ini";
            file.ShowDialog();
            return file.FileName;
            //return file.SafeFileName; //仅显示文件名
        }

        private void btnOutputPara_Click(object sender, EventArgs e)
        {

            string strPath = SelectPath() + "\\Savedpara.ini";
            //string strPath = Environment.CurrentDirectory + "\\system.ini";
            WritePrivateProfileString("基本参数", "波特率", cmbSerialbaud.Text, strPath);
            WritePrivateProfileString("基本参数", "输出功率", cmbTxPower.Text, strPath);
            WritePrivateProfileString("基本参数", "设备地址（HEX）", tbxDeviceAddr.Text, strPath);
            WritePrivateProfileString("基本参数", "工作频段", cmbRegion.Text, strPath);
            WritePrivateProfileString("基本参数", "起始地址",cmbFreqStart.Text, strPath);
            WritePrivateProfileString("基本参数", "结束地址", cmbFreqEnd.Text, strPath);
            WritePrivateProfileString("基本参数", "单频点", rdbPointFreq.Checked.ToString(), strPath);

            WritePrivateProfileString("基本参数", "工作模式", cmbWorkmode.Text, strPath);
            WritePrivateProfileString("基本参数", "输出接口", cmbOutInterface.Text, strPath);
            WritePrivateProfileString("基本参数", "询查区域（号码）", cmbInventoryArea.Text, strPath);
            WritePrivateProfileString("基本参数", "起始地址（HEX）", tbxInventoryStartAddr.Text, strPath);
            WritePrivateProfileString("基本参数", "字节长度（HEX）", tbxInventoryDataLen.Text, strPath);
            WritePrivateProfileString("基本参数", "过滤时间（S）", tbxFilterTime.Text, strPath);
            WritePrivateProfileString("基本参数", "触发时间（S）", tbxTriggerTime.Text, strPath);

            WritePrivateProfileString("基本参数", "Q值", cmbQvalue.Text, strPath);
            WritePrivateProfileString("基本参数", "Session", cmbSession.Text, strPath);
            WritePrivateProfileString("基本参数", "韦根输出", cmbWiegandMode.Text, strPath);
            WritePrivateProfileString("基本参数", "韦根输出", cmbWiggendOutMode.Text, strPath);
            WritePrivateProfileString("基本参数", "询查最大时间（*100mS）", tbxAnswerTime.Text, strPath);
            WritePrivateProfileString("基本参数", "蜂鸣器使能", cbxBuzzerEn.Checked.ToString(), strPath);

            WritePrivateProfileString("基本参数", "天线1", ckbAnt1.Checked.ToString(), strPath);
            WritePrivateProfileString("基本参数", "天线2", ckbAnt2.Checked.ToString(), strPath);
            WritePrivateProfileString("基本参数", "天线3", ckbAnt3.Checked.ToString(), strPath);
            WritePrivateProfileString("基本参数", "天线4", ckbAnt4.Checked.ToString(), strPath);
            WriteLog(MessageType.Info, (string)ht["Text36"], null);
        }
        private void btnInputPara_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder(255);
            string strPath = SelectFile();
            //string strPath = Environment.CurrentDirectory + "\\system.ini";
            //最好初始缺省值设置为非空，因为如果配置文件不存在，取不到值，程序也不会报错
            GetPrivateProfileString("基本参数", "波特率", (string)ht["Text38"], sb, 255, strPath);
            cmbSerialbaud.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "输出功率", (string)ht["Text38"], sb, 255, strPath);
            cmbTxPower.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "设备地址（HEX）", (string)ht["Text38"], sb, 255, strPath);
            tbxDeviceAddr.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "工作频段", (string)ht["Text38"], sb, 255, strPath);
            cmbRegion.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "起始地址", (string)ht["Text38"], sb, 255, strPath);
            cmbFreqStart.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "结束地址", (string)ht["Text38"], sb, 255, strPath);
            cmbFreqEnd.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "单频点", (string)ht["Text38"], sb, 255, strPath);
            rdbPointFreq.Checked = Convert.ToBoolean(sb.ToString());


            GetPrivateProfileString("基本参数", "工作模式", (string)ht["Text38"], sb, 255, strPath);
            cmbWorkmode.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "输出接口", (string)ht["Text38"], sb, 255, strPath);
            cmbOutInterface.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "询查区域（号码）", (string)ht["Text38"], sb, 255, strPath);
            cmbInventoryArea.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "起始地址（HEX）", (string)ht["Text38"], sb, 255, strPath);
            tbxInventoryStartAddr.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "字节长度（HEX）", (string)ht["Text38"], sb, 255, strPath);
            tbxInventoryDataLen.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "过滤时间（S）", (string)ht["Text38"], sb, 255, strPath);
            tbxFilterTime.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "触发时间（S）", (string)ht["Text38"], sb, 255, strPath);
            tbxTriggerTime.Text = sb.ToString();

            GetPrivateProfileString("基本参数", "Q值", (string)ht["Text38"], sb, 255, strPath);
            cmbQvalue.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "Session", (string)ht["Text38"], sb, 255, strPath);
            cmbSession.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "韦根输出", (string)ht["Text38"], sb, 255, strPath);
            cmbWiegandMode.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "韦根输出", (string)ht["Text38"], sb, 255, strPath);
            cmbWiggendOutMode.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "询查最大时间（*100mS）", (string)ht["Text38"], sb, 255, strPath);
            tbxAnswerTime.Text = sb.ToString();
            GetPrivateProfileString("基本参数", "蜂鸣器使能", (string)ht["Text38"], sb, 255, strPath);
            cbxBuzzerEn.Checked = Convert.ToBoolean(sb.ToString());

            GetPrivateProfileString("基本参数", "天线1", (string)ht["Text38"], sb, 255, strPath);
            ckbAnt1.Checked = Convert.ToBoolean(sb.ToString());
            GetPrivateProfileString("基本参数", "天线2", (string)ht["Text38"], sb, 255, strPath);
            ckbAnt1.Checked = Convert.ToBoolean(sb.ToString());
            GetPrivateProfileString("基本参数", "天线3", (string)ht["Text38"], sb, 255, strPath);
            ckbAnt1.Checked = Convert.ToBoolean(sb.ToString());
            GetPrivateProfileString("基本参数", "天线4", (string)ht["Text38"], sb, 255, strPath);
            ckbAnt1.Checked = Convert.ToBoolean(sb.ToString());

            WriteLog(MessageType.Info, (string)ht["Text37"], null);
        }


        [DllImport("kernel32")]
        //                        读配置文件方法的6个参数：所在的分区（section）、键值、     初始缺省值、     StringBuilder、   参数长度上限、配置文件路径
        private static extern int GetPrivateProfileString(string section, string key, string deVal, StringBuilder retVal,
int size, string filePath);

        [DllImport("kernel32")]
        //                            写配置文件方法的4个参数：所在的分区（section）、  键值、     参数值、        配置文件路径
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        //保存参数
        public void SetValue(string section, string key, string value)
        {
            //获得当前路径，当前是在Debug路径下
            string strPath = Environment.CurrentDirectory + "\\system.ini";
            WritePrivateProfileString(section, key, value, strPath);
        }

        //读取参数
        public string GetValue(string section, string key)
        {
            StringBuilder sb = new StringBuilder(255);
            string strPath = Environment.CurrentDirectory + "\\system.ini";
            //最好初始缺省值设置为非空，因为如果配置文件不存在，取不到值，程序也不会报错
            GetPrivateProfileString(section, key, (string)ht["Text38"], sb, 255, strPath);
            return sb.ToString();
        }

        //删除参数
        public void DelValue(string section)
        {
            //获得当前路径，当前是在Debug路径下
            string strPath = Environment.CurrentDirectory + "\\system.ini";
            WritePrivateProfileString(section, null, null, strPath);
        }

        private void cmbWorkmode_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbWorkmode.SelectedIndex == 0)            // 应答
            {
                cmbInventoryArea.Enabled = false;
                tbxInventoryStartAddr.Enabled = false;
                tbxInventoryDataLen.Enabled = false;
                tbxFilterTime.Enabled = false;
                tbxTriggerTime.Enabled = false;
                cmbQvalue.Enabled = false;
                cmbSession.Enabled = false;
                cmbWiegandMode.Enabled = false;
                cmbWiggendOutMode.Enabled = false;
                tbxAnswerTime.Enabled = false;
            }
            else if (cmbWorkmode.SelectedIndex == 1)       // 主动
            {
                cmbInventoryArea.Enabled = true;
                tbxInventoryStartAddr.Enabled = true;
                tbxInventoryDataLen.Enabled = true;
                tbxFilterTime.Enabled = true;
                tbxTriggerTime.Enabled = true;
                cmbQvalue.Enabled = true;
                cmbSession.Enabled = true;
                cmbWiegandMode.Enabled = true;
                cmbWiggendOutMode.Enabled = true;
                tbxAnswerTime.Enabled = true;
            }
            else                                          // 触发
            {
                cmbInventoryArea.Enabled = true;
                tbxInventoryStartAddr.Enabled = true;
                tbxInventoryDataLen.Enabled = true;
                tbxFilterTime.Enabled = true;
                tbxTriggerTime.Enabled = true;
                cmbQvalue.Enabled = true;
                cmbSession.Enabled = true;
                cmbWiegandMode.Enabled = true;
                cmbWiggendOutMode.Enabled = true;
                tbxAnswerTime.Enabled = true;
            }
        }

        private void cmbLanguage_SelectedValueChanged(object sender, EventArgs e)
        {

            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            string languageType = config.AppSettings.Settings["Language"].Value;
            if(string.Equals(languageType,cmbLanguage.Text))                                    // 增加判断是否一致
            {
                return;
            }
            config.AppSettings.Settings["Language"].Value = cmbLanguage.Text.ToString();
            config.Save();
            MultiLanguage.SetLanguage(this);
            MessageBox.Show(this, (string)ht["Text39"] );
        }

        private void btnSportOpen_MouseHover(object sender, EventArgs e)
        {
            if (btnSportOpen.Text.Length > 6)
            {
                // 创建the ToolTip 
                ToolTip toolTip1 = new ToolTip();

                // 设置显示样式
                toolTip1.AutoPopDelay = 5000;//提示信息的可见时间
                toolTip1.InitialDelay = 500;//事件触发多久后出现提示
                toolTip1.ReshowDelay = 500;//指针从一个控件移向另一个控件时，经过多久才会显示下一个提示框
                toolTip1.ShowAlways = true;//是否显示提示框

                //  设置伴随的对象.
                toolTip1.SetToolTip(this.btnSportOpen, btnSportOpen.Text);//设置提示按钮和提示内容
            }
        }

        private void cmbLanguage_DropDown(object sender, EventArgs e)
        {
            try
            {
                Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                string languageType = config.AppSettings.Settings["Language"].Value;
                string[] sr;
                string s = null;   //s用来存储文件名
                string path = AppDomain.CurrentDomain.BaseDirectory + "Languages\\" ;
                DirectoryInfo d = new DirectoryInfo(path);
                FileInfo[] files = d.GetFiles("*.xml");
                //List<string> lstr = new List<string>();
                //Array.Sort(files);                 // 进行排序
                cmbLanguage.Items.Clear();
                foreach (FileInfo file in files)  // foreach遍历文件夹
                {
                        sr = file.Name.Split('.');
                        s = sr[0];
                        cmbLanguage.Items.Add(s);   //将文件夹内的XML文件依次显示
                }
                cmbLanguage.Text = languageType;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void label2_MouseHover(object sender, EventArgs e)
        {
            if (label2.Text.Length > 6)
            {
                // 创建the ToolTip 
                ToolTip toolTip1 = new ToolTip();

                // 设置显示样式
                toolTip1.AutoPopDelay = 5000;//提示信息的可见时间
                toolTip1.InitialDelay = 500;//事件触发多久后出现提示
                toolTip1.ReshowDelay = 500;//指针从一个控件移向另一个控件时，经过多久才会显示下一个提示框
                toolTip1.ShowAlways = true;//是否显示提示框

                //  设置伴随的对象.
                toolTip1.SetToolTip(this.label2, label2.Text);//设置提示按钮和提示内容
            }
        }

        public void bindCbox(string language)
        {

            IList<Info> infoList = new List<Info>();
            Info info1 = new Info() { Id = "1", Name = (string)ht["strAnsmode"] };
            Info info2 = new Info() { Id = "2", Name = (string)ht["strAutmode"] };
            Info info3 = new Info() { Id = "3", Name = (string)ht["strtrimode"] };
            infoList.Add(info1);
            infoList.Add(info2);
            infoList.Add(info3);
            cmbWorkmode.DataSource = infoList;
            cmbWorkmode.ValueMember = "Id";
            cmbWorkmode.DisplayMember = "Name";

            IList<Info> infoList1 = new List<Info>();
            Info info4 = new Info() { Id = "1", Name = (string)ht["strMSBmode"] };
            Info info5 = new Info() { Id = "2", Name = (string)ht["strLSBmode"] };
            infoList1.Add(info4);
            infoList1.Add(info5);
            cmbWiggendOutMode.DataSource = infoList1;
            cmbWiggendOutMode.ValueMember = "Id";
            cmbWiggendOutMode.DisplayMember = "Name";

        }

        private void rdbPointFreq_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbPointFreq.Checked == true)                    // 单频点
            {
                cmbFreqEnd.Text = cmbFreqStart.Text;
            }
            else                                                 // 多频点
            {
                cmbFreqEnd.SelectedIndex = 0;
            }
        }

        private void cmbFreqEnd_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbFreqEnd.SelectedIndex < cmbFreqStart.SelectedIndex)
            {
                cmbFreqEnd.SelectedIndex = cmbFreqStart.SelectedIndex;
            }
        }

        private void cmbFreqStart_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cmbFreqStart.SelectedIndex == 0)                            // 防止初始化的时候改变
            {

            }
            else
            {
                if (cmbFreqEnd.SelectedIndex < cmbFreqStart.SelectedIndex)
                {
                    cmbFreqStart.SelectedIndex = cmbFreqEnd.SelectedIndex;
                }
            }

        }

        private void btnSetTxPower_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                string txpower = cmbTxPower.Text.Trim();
                if (txpower.Length == 0)
                    throw new Exception((string)ht["Text100"]);
                int txpower2 = Util.NumberFromString(txpower);
                if (txpower2 < 10 || txpower2 > 34)
                    throw new Exception((string)ht["Text101"]);

                Settings.Default.TxPower = (byte)txpower2;
                Settings.Default.Save();

                WriteLog(MessageType.Info, (string)ht["Text102"], null);
                reader.SetRfTxPower((byte)txpower2, 0);
                WriteLog(MessageType.Info, (string)ht["Text103"], null);
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text104"], ex);
                MessageBox.Show(this, (string)ht["Text104"] + ex.Message, this.Text);
            }
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                string ip = txbIPAddr.Text.Trim();
                if (ip.Length == 0)
                {
                    MessageBox.Show(this, (string)ht["Text120"], this.Text);
                    return;
                }
                System.Net.IPAddress ip2;
                if (!System.Net.IPAddress.TryParse(ip, out ip2))
                {
                    MessageBox.Show(this, (string)ht["Text121"], this.Text);
                    return;
                }
                string port = txbPort.Text.Trim();
                if (port.Length == 0)
                {
                    MessageBox.Show(this, (string)ht["Text122"], this.Text);
                    return;
                }
                ushort port2;
                if (!ushort.TryParse(port, out port2) || port2 == 0)
                {
                    MessageBox.Show(this, (string)ht["Text123"], this.Text);
                    return;
                }
                if (m_reader.IsOpened)
                {
                    MessageBox.Show(this, (string)ht["Text124"], this.Text);
                    return;
                }

                m_reader.Open(ip, port2, 3000, true);   // 3000ms等待时间

                WriteLog(MessageType.Info, (string)ht["Text125"] + ip2.ToString() + (string)ht["Text126"] + port2.ToString(), null);
                //cmbComPort.Enabled = false;
                //cmbComBaud.Enabled = false;
                //btnSportClose.Enabled = false;
                //btnSportOpen.Enabled = false;
                txbIPAddr.Enabled = false;
                txbPort.Enabled = false;
                btnConnect.Enabled = false;

                gpbCom.Enabled = false;

                Settings.Default.IPAddr = ip2.ToString();
                Settings.Default.Port = port2.ToString();
                Settings.Default.Save();

            }
            catch (Exception ex)
            {
                try
                {
                    Reader reader = this.Reader;
                    if (reader.IsOpened)
                        reader.Close();
                }
                catch { }
                lblStatus.Text = "状态：未连接";
                lblVersion.Text = "硬件版本：---\r\n软件版本：---\r\n  序列号：---";

                WriteLog(MessageType.Error, (string)ht["Text127"], ex);
                cmbComPort.Enabled = true;
                cmbComBaud.Enabled = true;
                txbIPAddr.Enabled = true;
                txbPort.Enabled = true;
                btnSportOpen.Enabled = true;
                btnConnect.Enabled = true;
                btnSportClose.Enabled = true;
                MessageBox.Show(this, (string)ht["Text127"] + ex.Message, this.Text);
            }
            InitReader();
        }

        private void btnDisConnect_Click(object sender, EventArgs e)
        {
            try
            {
                WriteLog(MessageType.Info, (string)ht["Text118"], null);
                //cmbComPort.Enabled = true;
                //cmbComBaud.Enabled = true;

                txbIPAddr.Enabled = true;
                txbPort.Enabled = true;
                gpbCom.Enabled = true;
                btnSportOpen.Enabled = true;
                btnConnect.Enabled = true;
                btnSportClose.Enabled = true;

                Reader reader = this.Reader;
                if (reader == null)
                    return;

                reader.Close();

                btnOutputPara.Enabled = false;
                btnInputPara.Enabled = false;
                btnEnbableKC.Enabled = false;
                btnDisableKC.Enabled = false;

                groupBox9.Enabled = false;
                groupBox8.Enabled = false;
                groupBox5.Enabled = false;

                btnGetAllPara.Enabled = false;
                btnSetAllPara.Enabled = false;
                btnSetDefaultPara.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnScannet_Click(object sender, EventArgs e)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "ScanTool\\" + "ScanTool.exe";
            Process p = Process.Start(path);
            p.WaitForExit();//本行代码不是必须，但是很关键，限制等待外部程序退出后才能往下执行
        }

        private void btnEnbableKC_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception("Reader not connected");
                WriteLog(MessageType.Info, "Set device Close_Realy", null);
                byte time = 0;        // time means Close Second  ,0-alltime
                reader.Close_Relay(time);
                WriteLog(MessageType.Info, "Set device Close_Realy Success", null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnDisableKC_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception("Reader not connected");
                WriteLog(MessageType.Info, "Set device Release_Realy", null);
                byte time = 0;        // time means Close Second  ,0-alltime
                reader.Release_Relay(time);
                WriteLog(MessageType.Info, "Set device Release_Realy Success", null);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void rbncom_Click(object sender, EventArgs e)
        {
            label2.Visible = true;
            label3.Visible = true;
            cmbComBaud.Visible = true;
            cmbComPort.Visible = true;

            btnScanUsb.Visible = false;
            label32.Visible = false;
            cbxusbpath.Visible = false;
        }

        private void rbnusb_CheckedChanged(object sender, EventArgs e)
        {
            label2.Visible = false;
            label3.Visible = false;
            cmbComBaud.Visible = false;
            cmbComPort.Visible = false;

            btnScanUsb.Visible = true;
            label32.Visible = true;
            cbxusbpath.Visible = true;
        }

        private void btnScanUsb_Click(object sender, EventArgs e)
        {
            string strSN = "";
            byte[] arrBuffer = new byte[256];
            string flag = "";
            int iHidNumber = 0;
            UInt16 iIndex = 0;
            cbxusbpath.Items.Clear();
            iHidNumber = m_reader.CFHid_GetUsbCount();
            for (iIndex = 0; iIndex < iHidNumber; iIndex++)
            {
                m_reader.CFHid_GetUsbInfo(iIndex, arrBuffer);
                strSN = System.Text.Encoding.Default.GetString(arrBuffer).Replace("\0","");
                flag = strSN.Substring(strSN.Length - 3);
                if (flag == "kbd")    //键盘
                {
                    cbxusbpath.Items.Add("\\Keyboard-can'topen");
                }
                else                    // HID
                {
                    cbxusbpath.Items.Add("\\USB-open");
                }
                strSN = "";                   //需要清零
                arrBuffer = new byte[256];   //需要清零
            }
            if (iHidNumber > 0)
                cbxusbpath.SelectedIndex = 0;
        }
    }

    public class Info
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
