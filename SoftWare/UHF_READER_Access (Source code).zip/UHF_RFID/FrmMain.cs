using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using UHF_RFID_Net;
using UHF_RFID.Properties;
using System.IO;
using System.Configuration;
using System.Xml;
using System.Collections;
using log4net;

namespace YYF100
{
    public partial class FrmMain : Form
    {
        private static ILog log = log4net.LogManager.GetLogger(typeof(FrmMain));

        Protocol m_proto = (UHF_RFID_Net.Protocol)(-1);

        Reader m_reader = new Reader();

        Hashtable ht = new Hashtable();

        volatile bool m_bClosed = false;

        // 盘点数据版本，表示标签列表中的数据是第几次盘点上来的
        internal int m_iInventoryDataVersion = 0;

        private String strVersion = "UHF Access Reader V1.2 ";

        public Protocol Protocol
        {
            get { return m_proto; }
        }

        public Reader Reader
        {
            get { return m_reader; }
        }

        public Hashtable HT
        {
            get { return ht; }
        }

        public bool IsClosed
        {
            get { return m_bClosed; }
        }

        public ShowTagItem[] TagItems
        {
            get { return panelInventory.TagItems; }
        }

        public FrmMain()
        {
            InitializeComponent();
            //this.AutoScrollMinSize = new Size(1014, 506);
        }

        private void FrmMain_Load(object sender, EventArgs e )
        {
            try
            {
                MultiLanguage.SetLanguage(this);
                Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                string languageType = config.AppSettings.Settings["Language"].Value;
                string path = AppDomain.CurrentDomain.BaseDirectory + "Languages\\" + languageType + ".xml";
                string frmName = "Systemdata";
                XmlDocument xmldoc = new XmlDocument();
                xmldoc.Load(path);
                //获取节点列表 
                XmlElement root = xmldoc.DocumentElement;
                XmlNodeList topM = root.SelectNodes("Form[Name= '" + frmName + "']/Controls/Control");
                // 获取节点并保存，通过hash表进行搜索
                foreach (XmlElement element in topM)
                {
                    string id = element.Attributes["name"].Value;
                    string domainName = element.InnerText;
                    ht.Add(id, domainName);
                }



                panelEpc.Dock = DockStyle.Fill;
                panelEpc.Visible = true;
                panelRFSetting.SetOwner(this);   //设置父窗口
                panelInventory.SetOwner(panelRFSetting);
                activeInventory.SetOwner(panelRFSetting);
                panelEpc.SetOwner(panelRFSetting);
                testPanel1.SetOwner(panelRFSetting);
                netSet.SetOwner(panelRFSetting);
                advanceSetting.SetOwner(panelRFSetting);
                debugging_assistant1.SetOwner(panelRFSetting);

                panelRFSetting.bindCbox(languageType);



                // 绑定数据源
                IList<Info> infoList = new List<Info>();
                Info info1 = new Info() { Id = "1", Name = (string)ht["strPasswordOrMaskMatched"] };
                Info info2 = new Info() { Id = "2", Name = (string)ht["strPasswordAndMaskMatched"] };
                infoList.Add(info1);
                infoList.Add(info2);
                advanceSetting.cmbMaskCondition.DataSource = infoList;
                advanceSetting.cmbMaskCondition.ValueMember = "Id";
                advanceSetting.cmbMaskCondition.DisplayMember = "Name";


                switch ((UHF_RFID_Net.Protocol)Settings.Default.Proto)
                {
                    case Protocol.GB_T_29768:
                        tmiGB.PerformClick();
                        break;
                    case Protocol.GJB_7377_1:
                        tmiGJB.PerformClick();
                        break;
                    default:
                        tmiEpc.PerformClick();
                        break;
                }

                if (!Settings.Default.IsTest)
                    tbcMain.TabPages.Remove(this.test_tabPage);
            }
            catch (Exception ex)
            {
                try { if (tbcMain.TabPages.Count > 2) tbcMain.TabPages.RemoveAt(2); }
                catch { }

                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            m_bClosed = true;
            panelInventory.StopInventory = true;
            panelEpc.StopOperation = true;
        }

        private void splitter1_SplitterMoved(object sender, SplitterEventArgs e)
        {
            try
            {
                //this.AutoScrollMinSize = new Size(1034, 500);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void tsbExit_Click(object sender, EventArgs e)
        {
            try
            {
                m_bClosed = true;
                Application.Exit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void tmiEpc_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_proto == Protocol.ISO_18000_63)
                    return;
                Reader reader = this.Reader;
                if (reader != null && reader.IsOpened)
                    reader.SetRfidProtocol(UHF_RFID_Net.Protocol.ISO_18000_63);
                string proto = ProtocolItem.ProtocolToString(UHF_RFID_Net.Protocol.ISO_18000_63);
                tslProto.Text = "当前选择协议：" + proto;
                //this.Text = strVersion + proto;
                this.Text = strVersion;
                m_proto = Protocol.ISO_18000_63;

                panelRFSetting.UpdateProto();
                panelInventory.SetProtocol(m_proto);
                panelEpc.Visible = true;

                tmiEpc.Checked = true;
                tmiGB.Checked = false;
                tmiGJB.Checked = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void tmiGB_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_proto == Protocol.GB_T_29768)
                    return;
                Reader reader = this.Reader;
                if (reader != null && reader.IsOpened)
                    reader.SetRfidProtocol(UHF_RFID_Net.Protocol.GB_T_29768);
                string proto = ProtocolItem.ProtocolToString(UHF_RFID_Net.Protocol.GB_T_29768);
                tslProto.Text = "当前选择协议：" + proto;
                this.Text = strVersion;

                m_proto = Protocol.GB_T_29768;

                panelRFSetting.UpdateProto();
                panelInventory.SetProtocol(m_proto);
                panelEpc.Visible = false;

                tmiEpc.Checked = false;
                tmiGB.Checked = true;
                tmiGJB.Checked = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void tmiGJB_Click(object sender, EventArgs e)
        {
            try
            {
                if (m_proto == Protocol.GJB_7377_1)
                    return;
                Reader reader = this.Reader;
                if (reader != null && reader.IsOpened)
                    reader.SetRfidProtocol(UHF_RFID_Net.Protocol.GJB_7377_1);
                string proto = ProtocolItem.ProtocolToString(UHF_RFID_Net.Protocol.GJB_7377_1);
                tslProto.Text = "当前选择协议：" + proto;
                this.Text = strVersion;

                m_proto = Protocol.GJB_7377_1;

                panelRFSetting.UpdateProto();
                panelInventory.SetProtocol(m_proto);
                panelEpc.Visible = false;

                tmiEpc.Checked = false;
                tmiGB.Checked = false;
                tmiGJB.Checked = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void tmiBaseSetting_Click(object sender, EventArgs e)
        {
            try
            {
                using (FrmBaseSetting frmBaseSetting = new FrmBaseSetting(this.Reader))
                {
                    frmBaseSetting.ShowDialog(this);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void tmiRFSetting_Click(object sender, EventArgs e)
        {
            try
            {
                using (FrmEpcSetting frmEpcSetting = new FrmEpcSetting(this.Reader))
                {
                    frmEpcSetting.ShowDialog(this);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void tmiOtherSetting_Click(object sender, EventArgs e)
        {
            try
            {
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void tsbAbout_Click(object sender, EventArgs e)
        {
            try
            {
                using (FrmAbout frmAbout = new FrmAbout())
                {
                    frmAbout.ShowDialog(this);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void tsmiLogSaveAs_Click(object sender, EventArgs e)
        {
            try
            {
                if (sfdLog.ShowDialog(this) == DialogResult.OK)
                {
                    using (TextWriter tw = new StreamWriter(sfdLog.FileName, true, Encoding.Default))
                    {
                        tw.WriteLine(txbLog.Text);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void tsmiLogClear_Click(object sender, EventArgs e)
        {
            try
            {
                txbLog.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        //private void btnSportOpen_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        string port = panelRFSetting.cmbComPort.Text.Trim();
        //        if (port.Length == 0)
        //        {
        //            MessageBox.Show(this, (string)ht["Text16"], this.Text);
        //            return;
        //        }
        //        if (m_reader.IsOpened)
        //        {
        //            MessageBox.Show(this, (string)ht["Text17"], this.Text);
        //            return;
        //        }

        //        m_reader.Open(port);

        //        WriteLog(MessageType.Info, "阅读器打开成功，串口号：" + port, null);
        //        panelRFSetting.cmbComPort.Enabled = false;
        //        panelRFSetting.btnSportOpen.Enabled = false;
        //    }
        //    catch (Exception ex)
        //    {
        //        try
        //        {
        //            Reader reader = this.Reader;
        //            if (reader.IsOpened)
        //                reader.Close();
        //        }
        //        catch { }
        //        panelRFSetting.lblStatus.Text = "状态：未连接";
        //        panelRFSetting.lblVersion.Text = "硬件版本：---\r\n软件版本：---\r\n  序列号：---";

        //        WriteLog(MessageType.Error, "(string)ht["Text18"]", ex);
        //        panelRFSetting.cmbComPort.Enabled = true;
        //        panelRFSetting.btnSportOpen.Enabled = true;
        //        MessageBox.Show(this, "(string)ht["Text18"]" + ex.Message, this.Text);
        //    }
        //    InitReader();
        //}


        //private void btnUpdatePara_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        panelRFSetting.btnGetFreq.PerformClick();   //模拟获取频率按键   
        //        panelRFSetting.btnGetAntenna.PerformClick();
        //        panelRFSetting.btnGetTxPower.PerformClick();
        //    }
        //    catch (Exception ex)
        //    {
        //        try
        //        {
        //            Reader reader = this.Reader;
        //            if (reader.IsOpened)
        //                reader.Close();
        //        }
        //        catch { }
        //        panelRFSetting.lblStatus.Text = "状态：未连接";
        //        panelRFSetting.lblVersion.Text = "硬件版本：---\r\n软件版本：---\r\n  序列号：---";

        //        WriteLog(MessageType.Error, "(string)ht["Text18"]", ex);
        //        panelRFSetting.cmbComPort.Enabled = true;
        //        panelRFSetting.btnSportOpen.Enabled = true;
        //        MessageBox.Show(this, "(string)ht["Text18"]" + ex.Message, this.Text);
        //    }

        //}

        //private void InitReader()
        //{
        //    try
        //    {
        //        Reader reader = this.Reader;
        //        if (reader.IsOpened)
        //        {
        //            reader.SetRfidProtocol(m_proto);
        //            tslProto.Text = "当前选择协议：" + ProtocolItem.ProtocolToString(m_proto);
        //            panelInventory.SetProtocol(m_proto);

        //            switch (m_proto)
        //            {
        //                case UHF_RFID_Net.Protocol.ISO_18000_63:
        //                    panelEpc.Visible = true;

        //                    tmiEpc.Checked = true;
        //                    tmiGB.Checked = false;
        //                    tmiGJB.Checked = false;
        //                    break;
        //                case UHF_RFID_Net.Protocol.GB_T_29768:
        //                    panelEpc.Visible = false;

        //                    tmiGB.Checked = true;
        //                    tmiEpc.Checked = false;
        //                    tmiGJB.Checked = false;
        //                    break;
        //                case UHF_RFID_Net.Protocol.GJB_7377_1:
        //                    panelEpc.Visible = false;

        //                    tmiGJB.Checked = true;
        //                    tmiEpc.Checked = false;
        //                    tmiGB.Checked = false;
        //                    break;
        //            }


        //            DeviceInfo info = m_reader.GetDeviceInfo();
        //            panelRFSetting.lblVersion.Text = "硬件版本：" + info.HardwareVersion + "\r\n" +
        //                              "软件版本：" + info.FirmwareVersion + "\r\n" +
        //                              "  序列号：" + info.SN;

        //            panelRFSetting.btnGetFreq.PerformClick();   //模拟获取频率按键   
        //            panelRFSetting.btnGetAntenna.PerformClick();
        //            panelRFSetting.btnGetTxPower.PerformClick();

        //            //byte txpower = info.PARA[8];
        //            //panelRFSetting.cmbTxPower.Text = txpower.ToString();

        //            //Settings.Default.TxPower = txpower;
        //            //Settings.Default.Save();

        //            //byte antenna = info.PARA[9];
        //            //panelRFSetting.ckbAnt1.Checked = ((antenna & 1) != 0);
        //            //panelRFSetting.ckbAnt2.Checked = ((antenna & 2) != 0);
        //            //panelRFSetting.ckbAnt3.Checked = ((antenna & 4) != 0);
        //            //panelRFSetting.ckbAnt4.Checked = ((antenna & 8) != 0);


        //            if (m_reader.IsOpenedAsNetwork)
        //                panelRFSetting.lblStatus.Text = "状态：网络连接已建立";
        //            else
        //                panelRFSetting.lblStatus.Text = "状态：串口已连接";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        WriteLog(MessageType.Error, (string)ht["Text20"], ex);
        //        MessageBox.Show(this, (string)ht["Text20"] + ex.Message, this.Text);

        //        try { panelRFSetting.UpdateProto(); }
        //        catch (Exception ex2)
        //        {
        //            WriteLog(MessageType.Error, (string)ht["Text21"], ex2);
        //            MessageBox.Show(this, (string)ht["Text21"] + ex2.Message, this.Text);
        //        }
        //        return;
        //    }

        //    try
        //    {
        //        panelRFSetting.UpdateProto();

        //    }
        //    catch (Exception ex)
        //    {
        //        WriteLog(MessageType.Error, (string)ht["Text22"], ex);
        //        MessageBox.Show(this, (string)ht["Text22"] + ex.Message, this.Text);
        //    }
        //    //panelRFSetting.GetSettings();     // 链路工作模式不显示，不需要用户设置
        //    //testPanel1.GetSettings();
        //}

        //private void btnSportClose_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        WriteLog(MessageType.Info, (string)ht["Text23"], null);
        //        panelRFSetting.lblStatus.Text = "状态：未连接";
        //        panelRFSetting.lblVersion.Text = "硬件版本：---\r\n软件版本：---\r\n  序列号：---";

        //        panelRFSetting.cmbComPort.Enabled = true;
        //        panelRFSetting.btnSportOpen.Enabled = true;

        //        Reader reader = this.Reader;
        //        if (reader == null)
        //            return;

        //        reader.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(this, ex.Message, this.Text);
        //    }
        //}

        //private void cmbComPort_DropDown(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        string[] ports = SerialPort.GetPortNames();
        //        Array.Sort(ports);
        //        if (IsPortsChanged(ports))
        //        {
        //            panelRFSetting.cmbComPort.Items.Clear();
        //            panelRFSetting.cmbComPort.Items.AddRange(ports);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(this, ex.Message, this.Text);
        //    }
        //}

        //private bool IsPortsChanged(string[] ports)
        //{
        //    ComboBox.ObjectCollection items = panelRFSetting.cmbComPort.Items;
        //    if (items.Count != ports.Length)
        //        return true;

        //    for (int i = 0; i < ports.Length; i++)
        //    {
        //        if (string.Compare(items[i].ToString(), ports[i], StringComparison.OrdinalIgnoreCase) != 0)
        //            return true;
        //    }
        //    return false;
        //}

        private delegate void WriteLogHandler(MessageType type, string msg, Exception ex);

        public void WriteLog(MessageType type, string msg, Exception ex)
        {
            try
            {
                if (this.InvokeRequired)
                {
                    this.BeginInvoke(new WriteLogHandler(WriteLog), type, msg, ex);
                    return;
                }

                StringBuilder sb = new StringBuilder(128);
                sb.Append(DateTime.Now);
                sb.Append(", ");
                switch (type)
                {
                    case MessageType.Info:
                        sb.Append((string)ht["Text94"]);
                        log.Info(msg);
                        break;
                    case MessageType.Warning:
                        sb.Append((string)ht["Text95"]);
                        log.Warn(msg);
                        break;
                    case MessageType.Error:
                        sb.Append((string)ht["Text96"]);
                        log.Error(msg);
                        break;
                }
                if (msg.Length > 0)
                    sb.Append(msg);
                if (ex != null)
                    sb.Append(ex.Message);
                sb.Append("\r\n");

                string msg2 = sb.ToString();
                txbLog.AppendText(msg2);
                txbLog.SelectionLength = 0;
                txbLog.SelectionStart = txbLog.TextLength;
                txbLog.ScrollToCaret();
            }
            catch { }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void panelRFSetting_Load(object sender, EventArgs e)
        {

        }

        private void testPanel1_Load(object sender, EventArgs e)
        {

        }

        private void panelRFSetting_Load_1(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void panelInventory_Load(object sender, EventArgs e)
        {

        }

        private void tbcMain_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            //MultiLanguage.SetLanguage(panelRFSetting);
        }

        private void panelInventory_Click(object sender, EventArgs e)
        {

        }

        private void tbcMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tbcMain.SelectedTab == tabPage1)//进行tabpage位置判断  应答读卡
            {
                MultiLanguage.SetLanguage(panelInventory);
                //功能代码  
            }
            if (tbcMain.SelectedTab == tabPage3)//进行tabpage位置判断  主动模式
            {
                MultiLanguage.SetLanguage(activeInventory);
                //功能代码  
            }
            if (tbcMain.SelectedTab == tabPage2)//进行tabpage位置判断  读写epc
            {
                MultiLanguage.SetLanguage(panelEpc);
                //功能代码  
            }
            if (tbcMain.SelectedTab == test_tabPage)//进行tabpage位置判断  
            {
                MultiLanguage.SetLanguage(testPanel1);
                //功能代码  
            }
            if (tbcMain.SelectedTab == NetInfo)//进行tabpage位置判断  
            {
                MultiLanguage.SetLanguage(netSet);
                //功能代码  
            }
            if (tbcMain.SelectedTab ==  AdvanceSettingPage)//进行tabpage位置判断  
            {
                MultiLanguage.SetLanguage(advanceSetting);
                //功能代码  
            }

            
        }
        /// <summary>
        /// 在读卡器未连接前，不能切换页面。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void tbcMain_Selecting(object sender, TabControlCancelEventArgs e)
        {
            Reader reader = panelRFSetting.Reader;
            if (reader == null || !reader.IsOpened)
            {
                e.Cancel = true;   //取消操作
                //MessageBox.Show("对不起,您没有此权限");
            }
        }

        // 页面顺序 
        // 应答-高级设置-主动-读写-测试-网络-Debug
        public void HideTabPage(int index)
        {
            switch (index)
            {
             case 0:         //
                {
                        tabPage1.Parent = null;
                          break;
                }
            case 1:         //
                {
                        AdvanceSettingPage.Parent = null;
                        break;
                }
            case 2:
                {
                        tabPage3.Parent = null;
                        break;
                }
            case 3:
                {
                        tabPage2.Parent = null;
                        break;
                }
            case 4:
                {
                        test_tabPage.Parent = null;
                        break;
                }
            case 5:
                {
                        NetInfo.Parent = null;
                        break;
                }
            case 6:
                {
                        Debug.Parent = null;
                        break;
                }
                default:
                    break;
            }
        }

    }
}
