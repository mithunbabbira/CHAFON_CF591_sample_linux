using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using UHF_RFID_Net;
using System.Collections.Specialized;
using System.Threading;
using UHF_RFID.Properties;
using System.Configuration;
using System.IO;
using System.Collections;

namespace YYF100
{
    public partial class ActiveInventory : UserControl
    {

        RFPanel m_owner = null;



        private static readonly int FLAG_IN_INVENTORY = BitVector32.CreateMask();
        private static readonly int FLAG_STOP_INVENTORY = BitVector32.CreateMask(FLAG_IN_INVENTORY);

        // 停止盘点等待的时间
        private static readonly ushort s_usStopInventoryTimeout = 10000;

        /// <summary>
        /// 每页显示的行数
        /// </summary>
        int m_iPageLines = 30;
        /// <summary>
        /// 当前显示的行
        /// </summary>
        int m_iPageIndex = 0;

        // 标识集合
        BitVector32 m_flags = new BitVector32();

        // 标签数据，用于查找相同的标签项
        Dictionary<byte[], ShowTagItem> m_tags = new Dictionary<byte[], ShowTagItem>(1024, new TagCodeCompare());
        // 标签数据，用于标签按接收次序排序
        List<ShowTagItem> m_tags2 = new List<ShowTagItem>(1024);
        // 标签盘点响应总个数
        int m_iInvTagCount = 0;
        // 标签盘点总时间
        int m_iInvTimeMs = 1;
        // 开始盘点的时间
        int m_iInvStartTick = 0;

        // 盘点类型
        private byte m_btInvType = 0;
        // 盘点类型参数
        private uint m_uiInvParam = 0;

        // 是否正在显示标签数据，如果正在显示则为1，否则为0
        private int m_iShowingTag = 0;

        // 是否只更新列，如果是则为1 ，如果不是则为0；表示有没有更新的EPC号码
        private int m_iShowRow = 0;


        // 盘点线程
        Thread m_thInventory = null;
        // 盘点时候的协议
        Protocol m_proto = Protocol.ISO_18000_63;

        private UHF_RFID_Net.SelectSortParam[] m_SelectSortParam = new UHF_RFID_Net.SelectSortParam[3];

        private UHF_RFID_Net.QueryParam[] m_QueryParam = new UHF_RFID_Net.QueryParam[3];

        public Protocol Protocol
        {
            get { return (m_owner == null ? Protocol.ISO_18000_63 : m_owner.Protocol); }
        }

        public Hashtable ht
        {
            get { return (m_owner == null ? null : m_owner.HT); }
        }

        public Reader Reader
        {
            get { return (m_owner == null ? null : m_owner.Reader); }
        }
        protected bool InInventory
        {
            get { return m_flags[FLAG_IN_INVENTORY]; }
            set { m_flags[FLAG_IN_INVENTORY] = value; }
        }

        public bool StopInventory
        {
            get { return m_flags[FLAG_STOP_INVENTORY]; }
            set { m_flags[FLAG_STOP_INVENTORY] = value; }
        }


        private void CloseInventoryThread()
        {
            try
            {
                StopInventory = true;
                if (!m_thInventory.Join(4000))
                    m_thInventory.Abort();
            }
            catch { }
        }

        public ActiveInventory()
        {
            InitializeComponent();
        }

        private void OnInventoryEnd()
        {
            InInventory = false;
            StopInventory = true;
            btnInventoryActive.Enabled = true;
            //reader.ISO.InventoryStop(s_iStopInventoryTimeout);
            btnInventoryActive.Text = (string)ht["Text55"];

            WriteLog(MessageType.Info, (string)ht["Text56"], null);
        }

        private void DoStopInventory()
        {
            try
            {
                InInventory = false;
                StopInventory = true;
                btnInventoryActive.Enabled = true;
                try
                {
                    Reader reader = this.Reader;
                    if (reader != null)
                    {
                        if (m_proto == Protocol.ISO_18000_63)
                            reader.ISO.InventoryStop(s_usStopInventoryTimeout);
                        else if (m_proto == Protocol.GB_T_29768)
                            reader.GB.InventoryStop(s_usStopInventoryTimeout);
                        else if (m_proto == Protocol.GJB_7377_1)
                            reader.GJB.InventoryStop(s_usStopInventoryTimeout);
                    }
                }
                catch (Exception) { };
            }
            catch { }
            try
            {
                this.BeginInvoke(new ThreadStart(OnInventoryEnd));
            }
            catch { }
        }


        private void UpdatePageIndex()
        {
            int count = m_tags.Count;
            int pageCount = count / m_iPageLines;
            if (count == 0)
            {
                m_iPageIndex = 0;
                return;
            }

            if (m_iPageIndex < 0)
                m_iPageIndex = 0;
            else if (m_iPageIndex > count)
                m_iPageIndex = count - 1;
        }


        private void ShowTag()
        {
            try
            {
                if (this.InvokeRequired)
                {
                    // 如果当前已经正在显示标签，则不用再次调用ShowTag
                    if (Interlocked.Exchange(ref m_iShowingTag, 1) == 1)
                        return;

                    // 显示标签
                    this.BeginInvoke(new ThreadStart(ShowTag));
                    return;
                }

                ListViewItem[] lvItems;
                int totalCount;
                int tagCount;
                int pageIndex;
                int pageLines;
                int totalTimeMs;
                lock (m_tags)
                {
                    UpdatePageIndex();
                    if (m_iPageLines == 0)
                    {
                        Interlocked.Exchange(ref m_iShowingTag, 0);
                        return;
                    }
                    tagCount = m_tags2.Count;
                    totalCount = m_iInvTagCount;
                    totalTimeMs = m_iInvTimeMs;
                    pageIndex = m_iPageIndex;
                    pageLines = m_iPageLines;

                    int index = m_iPageIndex;
                    int count = tagCount - m_iPageIndex;
                    lvItems = new ListViewItem[m_iPageLines > count ? count : m_iPageLines];
                    int i = 0;
                    for (; i < m_iPageLines && index < tagCount; i++, index++)
                    {
                        ShowTagItem sitem = m_tags2[index];
                        ListViewItem lvItem = new ListViewItem((index + 1).ToString());
                        lvItem.Tag = sitem;
                        lvItem.SubItems.Add(Util.HexArrayToString(sitem.Code));
                        lvItem.SubItems.Add(sitem.LEN.ToString());    //显示长度不显示信道
                        lvItem.SubItems.Add(sitem.CountsToString());
                        lvItem.SubItems.Add((sitem.Rssi / 10).ToString());
                        lvItem.SubItems.Add(sitem.Channel.ToString());
                        lvItems[i] = lvItem;
                    }
                }

                if (lvItems.Length != lsvTagsActive.Items.Count)
                {
                    lsvTagsActive.Items.Clear();
                    lsvTagsActive.Items.AddRange(lvItems);
                }
                else
                {
                    //lsvTags.BeginUpdate();

                    for (int i = 0; i < lvItems.Length; i++)             //只对第三列进行刷新
                    {
                        lsvTagsActive.Items[i].SubItems[2].Text = lvItems[i].SubItems[2].Text;          // count
                        lsvTagsActive.Items[i].SubItems[3].Text = lvItems[i].SubItems[3].Text;          // Rssi
                        lsvTagsActive.Items[i].SubItems[4].Text = lvItems[i].SubItems[4].Text;          // channel

                    }
                    //lsvTags.EndUpdate();

                }
                lblInvCountActive.Text = tagCount.ToString();
                lblInvTotalCountActive.Text = totalCount.ToString();
                lblInvTotalTimeActive.Text = lblInvTimeActive.Text = (totalTimeMs / 1000f).ToString(".000") + "s";
                lblInvRateActive.Text = (totalCount * 1000.0f / totalTimeMs).ToString(".000") + "/s";
                Interlocked.Exchange(ref m_iShowingTag, 0);
                lblInvCountActive.Update();
            }
            catch (Exception ex)
            {
                try { Interlocked.Exchange(ref m_iShowingTag, 0); }
                catch { }
                WriteLog(MessageType.Error, (string)ht["Text50"], ex);
            }
        }



        /// <summary>
        /// 盘点线程主函数
        /// </summary>
        private void InventoryThread()
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                {
                    MessageBox.Show(this, (string)ht["Text2"], (string)ht["Text9"]);
                    //DoStopInventory();
                    return;
                }

                lock (m_tags)
                {
                    m_tags.Clear();
                    m_tags2.Clear();
                }
                ShowTag();

                m_iInvTagCount = 0;
                m_iInvStartTick = Environment.TickCount;

                while (!StopInventory)
                {
                    TagItem item;
                    try
                    {
                        if (m_proto == Protocol.ISO_18000_63)
                            item = reader.ISO.GetTagUii(1000);
                        else if (m_proto == Protocol.GB_T_29768)
                            item = reader.GB.GetTagUii(1000);
                        else if (m_proto == Protocol.GJB_7377_1)
                            item = reader.GJB.GetTagUii(1000);
                        else
                            break;
                    }
                    catch (ReaderException ex)
                    {
                        if (ex.ErrorCode == ReaderException.ERROR_CMD_COMM_TIMEOUT ||
                            ex.ErrorCode == ReaderException.ERROR_CMD_RESP_FORMAT_ERROR)
                        {
                            if (this.m_owner != null && this.m_owner.IsClosed)
                            {
                                DoStopInventory();
                                return;
                            }
                            continue;
                        }
                        throw ex;
                    }
                    if (item == null)
                        break;

                    if (item.Antenna == 0 || item.Antenna > 4)
                        continue;
                    //m_test_flag++;
                    lock (m_tags)
                    {
                        ShowTagItem sitem;                                  // 一个标签的结构体
                        if (m_tags.TryGetValue(item.Code, out sitem))        //判断是否已经盘点出来 根据EPC号码
                        {
                            sitem.IncCount(item);
                            m_iShowRow = 1;
                        }
                        else
                        {
                            sitem = new ShowTagItem(item);
                            m_tags.Add(item.Code, sitem);                  // 保存到字典
                            m_tags2.Add(sitem);                            // 保存到列表
                            m_iShowRow = 0;
                        }
                        m_iInvTagCount++;
                        m_iInvTimeMs = Environment.TickCount - m_iInvStartTick + 1;
                    }
                    ShowTag();
                }
                ShowTag();   //将上下位机的时序差导致的未显示的标签显示
                //WriteLog(MessageType.Info, "标签数="+ m_test_flag, null);
                this.BeginInvoke(new ThreadStart(OnInventoryEnd));
            }
            catch (Exception ex)
            {
                try
                {
                    WriteLog(MessageType.Error, (string)ht["Text44"], ex);
                }
                catch { }
                DoStopInventory();
            }
        }

        private void WriteLog(MessageType type, string msg, Exception ex)
        {
            if (m_owner != null)
                m_owner.WriteLog(type, msg, ex);
        }

        private void btnInventoryActive_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                {
                    MessageBox.Show(this, (string)ht["Text2"], (string)ht["Text9"]);
                    return;
                }

                if (InInventory)
                {
                    StopInventory = true;
                    CloseInventoryThread();
                    btnInventoryActive.Text = (string)ht["Text55"];
                    return;
                }
                btnInventoryActive.Text = (string)ht["Text91"];
                InInventory = true;
                StopInventory = false;
                //m_test_flag = 0;
                // 盘点轮数+1
                if (m_owner != null)
                    m_owner.m_iInventoryDataVersion++;

                m_thInventory = new Thread(InventoryThread);
                m_thInventory.Start();
            }
            catch (Exception ex)
            {
                InInventory = false;
                StopInventory = true;
                btnInventoryActive.Text = (string)ht["Text55"];

                WriteLog(MessageType.Error, (string)ht["Text44"], ex);
                MessageBox.Show(this, (string)ht["Text44"] + ex.Message, (string)ht["Text9"]);
            }
        }

        private void SaveTags(string fileName)
        {
            StringBuilder sb = new StringBuilder(128);
            foreach (ColumnHeader item in lsvTagsActive.Columns)
            {
                sb.Append(item.Text);
                sb.Append(',');
            }
            if (sb.Length > 0)
                sb.Length -= 1;
            using (TextWriter tw = new StreamWriter(fileName, false, Encoding.Default))
            {
                tw.WriteLine(sb.ToString());

                int i = 0;
                foreach (ShowTagItem item in m_tags2)
                {
                    sb.Length = 0;
                    sb.Append(i++);
                    sb.Append(',');
                    sb.Append(Util.HexArrayToString(item.Code));
                    sb.Append(',');
                    sb.Append(item.LEN.ToString("D"));
                    sb.Append(',');
                    sb.Append(item.CountsToString());
                    sb.Append(',');
                    sb.Append((item.Rssi / 10).ToString());
                    sb.Append(',');
                    sb.Append(item.Channel.ToString());
                    //sb.Append(',');
                    //sb.Append(Util.HexArrayToString(item.CRC));
                    tw.WriteLine(sb.ToString());
                }
            }
        }

        private void btnSaveActive_Click(object sender, EventArgs e)
        {
            try
            {
                if (sfd.ShowDialog(this) == DialogResult.OK)
                    SaveTags(sfd.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private bool UpdatePageLines()
        {
            string text = txbPageLinesActive.Text.Trim();
            int lines;

            if (text.Length == 0)
                throw new Exception((string)ht["Text47"]);
            if (!int.TryParse(text, out lines))
                throw new Exception((string)ht["Text48"]);
            if (lines < 0 || lines > 65535)
                throw new Exception((string)ht["Text49"]);

            if (m_iPageLines == lines)
                return false;

            m_iPageLines = lines;
            return true;
        }

        internal void SetOwner(RFPanel owner)
        {
            m_owner = owner;
        }

        private void btnLastPageActive_Click(object sender, EventArgs e)
        {
            try
            {
                UpdatePageLines();
                lock (m_tags)
                {
                    m_iPageIndex = m_tags.Count / m_iPageLines * m_iPageLines;
                }
                ShowTag();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnNextPageActive_Click(object sender, EventArgs e)
        {
            try
            {
                UpdatePageLines();
                lock (m_tags)
                {
                    if (m_iPageIndex + m_iPageLines < m_tags.Count)
                        m_iPageIndex += m_iPageLines;
                    else
                        m_iPageIndex = m_tags.Count / m_iPageLines * m_iPageLines;
                }
                ShowTag();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnPrevPageActive_Click(object sender, EventArgs e)
        {
            try
            {
                UpdatePageLines();
                if (m_iPageIndex > m_iPageLines)
                    m_iPageIndex -= m_iPageLines;
                else
                    m_iPageIndex = 0;
                ShowTag();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnFirstPageActive_Click(object sender, EventArgs e)
        {
            try
            {
                UpdatePageLines();
                m_iPageIndex = 0;
                ShowTag();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnClearActive_Click(object sender, EventArgs e)
        {
            try
            {
                lsvTagsActive.Items.Clear();
                lblInvCountActive.Text = "00000";
                lblInvRateActive.Text = "000";
                lblInvTimeActive.Text = "000";
                lblInvTotalCountActive.Text = "0000000000";
                lblInvTotalTimeActive.Text = "0000000000";

                lock (m_tags)
                {
                    m_tags.Clear();
                    m_tags2.Clear();

                    m_iPageIndex = 0;
                    m_iInvTagCount = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, (string)ht["Text9"]);
            }
        }

        private void ActiveInventory_Load(object sender, EventArgs e)
        {
            //try
            //{
            //    MultiLanguage.SetLanguage(this);
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(this, ex.Message, this.Text);
            //}
        }

        private void ActiveInventory_Leave(object sender, EventArgs e)
        {
            try
            {
                if (InInventory)
                {
                    StopInventory = true;
                    CloseInventoryThread();
                    btnInventoryActive.Text = (string)ht["Text55"];
                    return;
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show(this, ex.Message, (string)ht["Text9"]);
                return;
            }
        }

        private void lsvTagsActive_DoubleClick(object sender, EventArgs e)
        {
 
            if (lsvTagsActive.SelectedItems.Count > 0)
            {
                try
                {
                    NetInfo netInfo = new NetInfo();
                    string ip = lsvTagsActive.SelectedItems[0].SubItems[0].Text.ToString();//选中行的第一列的值
                    string y = lsvTagsActive.SelectedItems[0].SubItems[1].Text.ToString();//选中行的第二列的值
                    string z = lsvTagsActive.SelectedItems[0].SubItems[2].Text.ToString();//选中行的第三列的值
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
            }
            }
        }
}
