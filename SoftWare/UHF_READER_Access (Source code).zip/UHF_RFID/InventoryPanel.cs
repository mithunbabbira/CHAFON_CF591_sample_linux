using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using UHF_RFID_Net;
using System.Collections.Specialized;
using System.Threading;
using UHF_RFID.Properties;
using System.Configuration;
using System.IO;
using System.Collections;

namespace YYF100
{
    public partial class InventoryPanel : UserControl
    {
        private static readonly int FLAG_IN_INVENTORY = BitVector32.CreateMask();
        private static readonly int FLAG_STOP_INVENTORY = BitVector32.CreateMask(FLAG_IN_INVENTORY);

        // 停止盘点等待的时间
        private static readonly ushort s_usStopInventoryTimeout = 10000;

        RFPanel m_owner = null;
        /// <summary>
        /// 每页显示的行数
        /// </summary>
        int m_iPageLines = 30;
        /// <summary>
        /// 当前显示的行
        /// </summary>
        int m_iPageIndex = 0;
        Devicepara deviceparat = new Devicepara();
        // 标识集合
        BitVector32 m_flags = new BitVector32();

        // 标签数据，用于查找相同的标签项，只是用来查找是否有相同卡号
        Dictionary<byte[], ShowTagItem> m_tags = new Dictionary<byte[], ShowTagItem>(1024, new TagCodeCompare());
        // 标签数据，用于标签按接收次序排序
        List<ShowTagItem> m_tags2 = new List<ShowTagItem>(1024);
        // 标签盘点响应总个数
        int m_iInvTagCount = 0;
        // 标签盘点总时间
        int m_iInvTimeMs = 1;
        // 开始盘点的时间
        int m_iInvStartTick = 0;

        // 盘点类型
        private byte m_btInvType = 0;
        // 盘点类型参数
        private uint m_uiInvParam = 0;

        // 是否正在显示标签数据，如果正在显示则为1，否则为0
        private int m_iShowingTag = 0;
        // 是否只更新列，如果是则为1 ，如果不是则为0；表示有没有更新的EPC号码
        private int m_iShowRow = 0;

        // 盘点线程
        Thread m_thInventory = null;
        // 盘点时候的协议
        Protocol m_proto = Protocol.ISO_18000_63;

        private UHF_RFID_Net.SelectSortParam[] m_SelectSortParam = new UHF_RFID_Net.SelectSortParam[3];

        private UHF_RFID_Net.QueryParam[] m_QueryParam = new UHF_RFID_Net.QueryParam[3];

        public Protocol Protocol
        {
            get { return (m_owner == null ? Protocol.ISO_18000_63 : m_owner.Protocol); }
        }

        public Hashtable ht
        {
            get { return (m_owner == null ? null : m_owner.HT); }
        }

        public Reader Reader
        {
            get { return (m_owner == null ? null : m_owner.Reader); }
        }
        public Devicepara Devicepara
        {
            get { return (m_owner == null ? deviceparat : m_owner.Devicepara); }
        }

        protected bool InInventory
        {
            get { return m_flags[FLAG_IN_INVENTORY]; }
            set { m_flags[FLAG_IN_INVENTORY] = value; }
        }

        public bool StopInventory
        {
            get { return m_flags[FLAG_STOP_INVENTORY]; }
            set { m_flags[FLAG_STOP_INVENTORY] = value; }
        }

        public ShowTagItem[] TagItems
        {
            get { lock(m_tags) { return m_tags2.ToArray(); } }
        }

        public InventoryPanel()
        {
            InitializeComponent();
        }

        private void EpcPanel_Load(object sender, EventArgs e)
        {
            try
            {
                //MultiLanguage.SetLanguage(this);
                InventoryTargetItem.Protocol = this.Protocol;
                Reader reader = this.Reader;
                Devicepara devicepara = this.Devicepara;
                switch (Settings.Default.InvTypeCfg)
                {
                    //case 0:
                    //    rdbScene0.Checked = true;
                    //    break;
                    case 1:
                        rdbScene1.Checked = true;
                        txbInvTime.Text = Settings.Default.InvParam.ToString();
                        break;
                    case 2:
                        rdbScene2.Checked = true;
                        txbInvCount.Text = Settings.Default.InvParam.ToString();
                        break;
                }
                m_iPageLines = Settings.Default.Lines;
                txbPageLines.Text = m_iPageLines.ToString();

                devicepara = reader.GetDevicePara();
                if (devicepara.Workmode == 0)
                {
                    cmbInventoryArea.SelectedIndex = devicepara.Area;
                    cmbQvalue.SelectedIndex = devicepara.Q;
                    cmbSession.SelectedIndex = devicepara.Session;
                }
                else
                {
                    cmbInventoryArea.SelectedIndex = 1;
                    cmbQvalue.SelectedIndex = 4;
                    cmbSession.SelectedIndex = 0;
                }
            }
            catch (ConfigurationErrorsException ex)
            {
                try
                {
                    Configuration cfg = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal);
                    if (cfg != null)
                        File.Delete(cfg.FilePath);
                }
                catch { }
                MessageBox.Show(this, ex.Message, this.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }
        //int m_test_flag = 0;
        private void btnInventory_Click(object sender, EventArgs e)
        {
            try
            {
                Devicepara devicepara = this.Devicepara;      // 获取当前设备参数
                Reader reader = this.Reader;
                if (reader == null)
                {
                    MessageBox.Show(this, (string)ht["Text2"], (string)ht["Text9"]);
                    return;
                }

                if (InInventory)
                {
                    StopInventory = true;
                    CloseInventoryThread();
                    switch (m_proto)
                    {
                        case Protocol.ISO_18000_63:
                            reader.ISO.InventoryStop(s_usStopInventoryTimeout);
                            break;
                        case Protocol.GB_T_29768:
                            reader.GB.InventoryStop(s_usStopInventoryTimeout);
                            break;
                        case Protocol.GJB_7377_1:
                            reader.GJB.InventoryStop(s_usStopInventoryTimeout);
                            break;
                    }
                    btnInventory.Text = (string)ht["Text45"];
                    return;
                }

                devicepara.Area = (byte)cmbInventoryArea.SelectedIndex;
                devicepara.Q = (byte)cmbQvalue.SelectedIndex;
                devicepara.Session = (byte)cmbSession.SelectedIndex;
                devicepara.Startaddr = (byte)Util.NumberFromString(tbxInventoryStartAddr.Text);   // 用十进制
                devicepara.DataLen = (byte)Util.NumberFromString(tbxInventoryDataLen.Text);       // 用十进制
                devicepara.IntenelTime = (byte)Util.NumberFromString(tbxAnswerTime.Text);         // 新增与 1019@余流威
                if (cmbInventoryArea.SelectedIndex == 0)   //Reverse
                {

                }
                else if (cmbInventoryArea.SelectedIndex == 1)  // epc
                {

                }
                else if (cmbInventoryArea.SelectedIndex == 2)  // TID
                {

                }
                else                                          // user
                {

                }
                reader.SetDevicePara(devicepara);
                WriteLog(MessageType.Info, (string)ht["Text32"], null);

                byte invTypeCfg;
                //if (rdbScene0.Checked)     // 循环盘点
                //{
                //    invTypeCfg = 0;
                //    m_btInvType = 0;
                //    m_uiInvParam = 0;
                //}
                if (rdbScene1.Checked)          // 按照时间盘点
                {
                    invTypeCfg = 1;
                    m_btInvType = 0;
                    string text = txbInvTime.Text.Trim();
                    if (!uint.TryParse(text, out m_uiInvParam))
                    {
                        throw new Exception((string)ht["Text40"]);
                    }
                }
                else if (rdbScene2.Checked)          // 按照次数盘点
                {
                    invTypeCfg = 2;
                    m_btInvType = 1;
                    string text = txbInvCount.Text.Trim();
                    if (!uint.TryParse(text, out m_uiInvParam) ||
                        m_uiInvParam == 0)
                        throw new Exception((string)ht["Text41"]);
                }
                else if (rdbScene4.Checked)           // 自定义盘点
                {
                    //// ISO
                    //if ((m_protoMask & 1) == 1)
                    //{
                    //reader.SelectOrSortSet(0, m_SelectSortParam[0]);
                    //}
                    //// GB
                    //if ((m_protoMask & 2) == 2)
                    //{
                    //    reader.SelectOrSortSet(1, m_SelectSortParam[1]);
                    //}
                    //// GJB
                    //if ((m_protoMask & 4) == 4)
                    //{
                    //    reader.SelectOrSortSet(2, m_SelectSortParam[2]);
                    //}

                    invTypeCfg = 4;
                    m_btInvType = 3;
                    m_uiInvParam = 0;
                    string text = txb_userTime.Text.Trim();
                    if (!uint.TryParse(text, out m_uiInvParam) ||
                        m_uiInvParam > 255)
                        throw new Exception((string)ht["Text42"]);
                }
                else
                    return;

                // 将数据保存到配置文件
                Settings.Default.InvTypeCfg = invTypeCfg;
                Settings.Default.InvParam = m_uiInvParam;
                Settings.Default.Save();

                m_proto = this.Protocol;

                btnInventory.Text = (string)ht["Text91"];
                WriteLog(MessageType.Info, (string)ht["Text43"], null);
                InInventory = true;
                StopInventory = false;
                //m_test_flag = 0;
                // 盘点轮数+1
                if (m_owner != null)
                    m_owner.m_iInventoryDataVersion++;

                m_thInventory = new Thread(InventoryThread);
                m_thInventory.Start();
            }
            catch (Exception ex)
            {
                InInventory = false;
                StopInventory = true;
                btnInventory.Text = (string)ht["Text45"];

                WriteLog(MessageType.Error, (string)ht["Text44"], ex);
                MessageBox.Show(this, (string)ht["Text44"] + ex.Message, (string)ht["Text9"]);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                lsvTags.Items.Clear();
                lblInvCount.Text = "00000";
                lblInvRate.Text = "000";
                lblInvTime.Text = "000";
                lblInvTotalCount.Text = "0000000000";
                lblInvTotalTime.Text = "0000000000";

                lock (m_tags)
                {
                    m_tags.Clear();
                    m_tags2.Clear();

                    m_iPageIndex = 0;
                    m_iInvTagCount = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, (string)ht["Text9"]);
            }
        }

        private void CloseInventoryThread()
        {
            try
            {
                StopInventory = true;
                if (!m_thInventory.Join(4000))
                    m_thInventory.Abort();
            }
            catch { }
        }

        private void OnInventoryEnd()
        {
            InInventory = false;
            StopInventory = true;
            btnInventory.Enabled = true;
            //reader.ISO.InventoryStop(s_iStopInventoryTimeout);
            btnInventory.Text = (string)ht["Text45"];

            WriteLog(MessageType.Info, (string)ht["Text46"], null);
        }

        /// <summary>
        /// 盘点线程主函数
        /// </summary>
        private void InventoryThread()
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                {
                    DoStopInventory();
                    return;
                }

                if (m_proto == Protocol.ISO_18000_63)
                    reader.ISO.Inventory(m_btInvType, m_uiInvParam);
                else if (m_proto == Protocol.GB_T_29768)
                    reader.GB.Inventory(m_btInvType, m_uiInvParam);
                else if (m_proto == Protocol.GJB_7377_1)
                    reader.GJB.Inventory(m_btInvType, m_uiInvParam);
                else
                {
                    DoStopInventory();
                    return;
                }

                lock (m_tags)
                {
                    m_tags.Clear();
                    m_tags2.Clear();
                }
                ShowTag();

                m_iInvTagCount = 0;
                m_iInvStartTick = Environment.TickCount;

                while (!StopInventory)
                {
                    TagItem item;             //接收标签数据
                    try
                    {
                        if (m_proto == Protocol.ISO_18000_63)
                            item = reader.ISO.GetTagUii(1000);
                        else if (m_proto == Protocol.GB_T_29768)
                            item = reader.GB.GetTagUii(1000);
                        else if (m_proto == Protocol.GJB_7377_1)
                            item = reader.GJB.GetTagUii(1000);
                        else
                            break;
                        
                    }
                    catch (ReaderException ex)
                    {
                        if (ex.ErrorCode == ReaderException.ERROR_CMD_COMM_TIMEOUT ||
                            ex.ErrorCode == ReaderException.ERROR_CMD_RESP_FORMAT_ERROR)
                        {
                            if (this.m_owner != null && this.m_owner.IsClosed)
                            {
                                DoStopInventory();
                                return;
                            }
                            continue;
                        }
                        throw ex;
                    }
                    if (item == null)     // 为空 表示周围没有标签或者指令结束
                        break;
                    
                    if (item.Antenna == 0 || item.Antenna > 4)
                        continue;
                    //m_test_flag++;
                    lock (m_tags)                                           // 加锁，防止被其他线程改变
                    {
                        ShowTagItem sitem;                                  // 一个标签的结构体
                        if (m_tags.TryGetValue(item.Code, out sitem))        //判断是否已经盘点出来 根据EPC号码，sitem的值从m_tag中取出
                        {
                            sitem.IncCount(item);                            // 转换成 ShowTagItem 结构体，并保存，这里m_tag2为什么会更新？？
                                                                             //Console.WriteLine("sitem：" + sitem.Counts);
                                                                             //Console.WriteLine("mtag2：" + m_tags2[0].Counts);
                            m_iShowRow = 1;
                        }
                        else
                        {
                            sitem = new ShowTagItem(item);
                            m_tags.Add(item.Code, sitem);                  // 保存到字典
                            m_tags2.Add(sitem);                            // 保存到列表
                            m_iShowRow = 0;
                        }
                        m_iInvTagCount++;
                        m_iInvTimeMs = Environment.TickCount - m_iInvStartTick + 1;
                    }
                    ShowTag();
                }
                ShowTag();   //将上下位机的时序差导致的未显示的标签显示
                //WriteLog(MessageType.Info, "标签数="+ m_test_flag, null);
                this.BeginInvoke(new ThreadStart(OnInventoryEnd));
            }
            catch (Exception ex)
            {
                try
                {
                    WriteLog(MessageType.Error, (string)ht["Text44"], ex);
                }
                catch { }
                DoStopInventory();
            }
        }

        private void DoStopInventory()
        {
            try
            {
                InInventory = false;
                StopInventory = true;
                btnInventory.Enabled = true;
                try
                {
                    Reader reader = this.Reader;
                    if (reader != null)
                    {
                        if (m_proto == Protocol.ISO_18000_63)
                            reader.ISO.InventoryStop(s_usStopInventoryTimeout);
                        else if (m_proto == Protocol.GB_T_29768)
                            reader.GB.InventoryStop(s_usStopInventoryTimeout);
                        else if (m_proto == Protocol.GJB_7377_1)
                            reader.GJB.InventoryStop(s_usStopInventoryTimeout);
                    }
                }
                catch (Exception) { };
            }
            catch { }
            try
            {
                this.BeginInvoke(new ThreadStart(OnInventoryEnd));
            }
            catch { }
        }

        private void btnFirstPage_Click(object sender, EventArgs e)
        {
            try
            {
                UpdatePageLines();
                m_iPageIndex = 0;
                ShowTag();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnPrevPage_Click(object sender, EventArgs e)
        {
            try
            {
                UpdatePageLines();
                if (m_iPageIndex > m_iPageLines)
                    m_iPageIndex -= m_iPageLines;
                else
                    m_iPageIndex = 0;
                ShowTag();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnNextPage_Click(object sender, EventArgs e)
        {
            try
            {
                UpdatePageLines();
                lock (m_tags)
                {
                    if (m_iPageIndex + m_iPageLines < m_tags.Count)
                        m_iPageIndex += m_iPageLines;
                    else
                        m_iPageIndex = m_tags.Count / m_iPageLines * m_iPageLines;
                }
                ShowTag();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnLastPage_Click(object sender, EventArgs e)
        {
            try
            {
                UpdatePageLines();
                lock (m_tags)
                {
                    m_iPageIndex = m_tags.Count / m_iPageLines * m_iPageLines;
                }
                ShowTag();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (sfd.ShowDialog(this) == DialogResult.OK)
                    SaveTags(sfd.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }


        private void txbPageLines_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    if (UpdatePageLines())
                    {
                        Settings.Default.Lines = m_iPageLines;
                        Settings.Default.Save();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, (string)ht["Text9"]);
            }
        }

        private void txbPageLines_Leave(object sender, EventArgs e)
        {
            try
            {
                if (UpdatePageLines())
                {
                    Settings.Default.Lines = m_iPageLines;
                    Settings.Default.Save();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private bool UpdatePageLines()
        {
            string text = txbPageLines.Text.Trim();
            int lines;

            if (text.Length == 0)
                throw new Exception((string)ht["Text47"]);
            if (!int.TryParse(text, out lines))
                throw new Exception((string)ht["Text48"]);
            if (lines < 0 || lines > 65535)
                throw new Exception((string)ht["Text49"]);

            if (m_iPageLines == lines)
                return false;

            m_iPageLines = lines;
            return true;
        }

        private void UpdatePageIndex()
        {
            int count = m_tags.Count;
            int pageCount = count / m_iPageLines;
            if (count == 0)
            {
                m_iPageIndex = 0;
                return;
            }

            if (m_iPageIndex < 0)
                m_iPageIndex = 0;
            else if (m_iPageIndex > count)
                m_iPageIndex = count - 1;
        }

        private void SaveTags(string fileName)
        {
            StringBuilder sb = new StringBuilder(128);
            foreach (ColumnHeader item in lsvTags.Columns)
            {
                sb.Append(item.Text);
                sb.Append(',');
            }
            if (sb.Length > 0)
                sb.Length -= 1;
            using (TextWriter tw = new StreamWriter(fileName, false, Encoding.Default))
            {
                tw.WriteLine(sb.ToString());

                int i = 0;
                foreach (ShowTagItem item in m_tags2)
                {
                    sb.Length = 0;
                    sb.Append(i++);
                    sb.Append(',');
                    sb.Append(Util.HexArrayToString(item.Code));
                    sb.Append(',');
                    sb.Append(item.LEN.ToString("D"));
                    sb.Append(',');
                    sb.Append(item.CountsToString());
                    sb.Append(',');
                    sb.Append((item.Rssi / 10).ToString());
                    sb.Append(',');
                    sb.Append(item.Channel.ToString());
                    //sb.Append(',');
                    //sb.Append(Util.HexArrayToString(item.CRC));
                    tw.WriteLine(sb.ToString());
                }
            }
        }

        internal void SetOwner(RFPanel owner)
        {
            m_owner = owner;
        }

        public void SetProtocol(Protocol proto)
        {
            //colPC.Text = "PC";
            InventoryTargetItem.Protocol = this.Protocol;
        }

        private void ShowTag()
        {
            try
            {
                if (this.InvokeRequired)
                {
                    // 如果当前已经正在显示标签，则不用再次调用ShowTag
                    if (Interlocked.Exchange(ref m_iShowingTag, 1) == 1)
                        return;
                
                    // 显示标签
                    this.BeginInvoke(new ThreadStart(ShowTag));
                    return;
                }

                ListViewItem[] lvItems;
                int totalCount;
                int tagCount;
                int pageIndex;
                int pageLines;
                int totalTimeMs;
                lock (m_tags)
                {
                    UpdatePageIndex();
                    if (m_iPageLines == 0)
                    {
                        Interlocked.Exchange(ref m_iShowingTag, 0);
                        return;
                    }
                    tagCount = m_tags2.Count;            // 盘点到卡片的个数
                    totalCount = m_iInvTagCount;         // 盘点的次数
                    totalTimeMs = m_iInvTimeMs;          // 盘点时间
                    pageIndex = m_iPageIndex;           // 显示的行数
                    pageLines = m_iPageLines;           // 每页显示的行数

                    int index = m_iPageIndex;
                    int count = tagCount - m_iPageIndex;
                    lvItems = new ListViewItem[m_iPageLines > count ? count : m_iPageLines];       //按照每页显示的最大行数进行显示
                    int i = 0;
                    for (; i < m_iPageLines && index < tagCount; i++, index++)              
                    {
                        ShowTagItem sitem = m_tags2[index];
                        ListViewItem lvItem = new ListViewItem((index + 1).ToString());
                        lvItem.Tag = sitem;
                        lvItem.SubItems.Add(Util.HexArrayToString(sitem.Code));
                        //lvItem.SubItems.Add(Util.HexArrayToString(sitem.PC));
                        lvItem.SubItems.Add(sitem.LEN.ToString());    //显示长度不显示信道
                        lvItem.SubItems.Add(sitem.CountsToString());
                        lvItem.SubItems.Add((sitem.Rssi/10).ToString());
                        lvItem.SubItems.Add(sitem.Channel.ToString());
                        //lvItem.SubItems.Add(Util.HexArrayToString(sitem.CRC));
                        lvItems[i] = lvItem;
                    }

                    if (lvItems.Length != lsvTags.Items.Count)
                    {
                        lsvTags.Items.Clear();
                        lsvTags.Items.AddRange(lvItems);
                    }
                    else
                    {
                        //lsvTags.BeginUpdate();
                        if (lsvTags.Items[0].SubItems[0].Text == lvItems[0].SubItems[0].Text)    // 行-列-.text
                        {
                            for (int j = 0; j < lvItems.Length; j++)             //只对第三列进行刷新
                            {
                                lsvTags.Items[j].SubItems[2].Text = lvItems[j].SubItems[2].Text;          // count
                                lsvTags.Items[j].SubItems[3].Text = lvItems[j].SubItems[3].Text;          // Rssi
                                lsvTags.Items[j].SubItems[4].Text = lvItems[j].SubItems[4].Text;          // channel
                            }
                        }
                        else
                        {
                            lsvTags.Items.Clear();
                            lsvTags.Items.AddRange(lvItems);
                        }

                        //m_iShowRow = 0;
                        //lsvTags.EndUpdate();
                    }
                }

                lblInvCount.Text = tagCount.ToString();
                lblInvTotalCount.Text = totalCount.ToString();
                lblInvTotalTime.Text = lblInvTime.Text = (totalTimeMs / 1000f).ToString(".000") + "s";
                lblInvRate.Text = (totalCount * 1000.0f / totalTimeMs).ToString(".000") + "/s";
                Interlocked.Exchange(ref m_iShowingTag, 0);
                lblInvCount.Update();
            }
            catch (Exception ex)
            {
                try { Interlocked.Exchange(ref m_iShowingTag, 0); }
                catch { }
                WriteLog(MessageType.Error, (string)ht["Text50"], ex);
            }
        }

        private void WriteLog(MessageType type, string msg, Exception ex)
        {
            if (m_owner != null)
                m_owner.WriteLog(type, msg, ex);
        }

        private void btnISOSelect_Click(object sender, EventArgs e)
        {

            byte proto = 0;  //ISO
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                m_SelectSortParam[proto] = reader.SelectOrSortGet(proto);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, (string)ht["Text51"] + ex.Message, this.Text);
                return;
            }

            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                m_QueryParam[proto] = reader.QueryCfgGet(proto);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, (string)ht["Text52"] + ex.Message, this.Text);
                return;
            }

            try
            {
                using (FrmIsoSelect frmIsoSelect = new FrmIsoSelect(m_SelectSortParam[proto], m_QueryParam[proto]))
                {
                    frmIsoSelect.ht = ht;
                    if (frmIsoSelect.ShowDialog(this) != DialogResult.OK)
                        return;
                    m_SelectSortParam[proto] = frmIsoSelect.IsoSelectParam;
                    WriteLog(MessageType.Info, "---" + m_SelectSortParam[proto].MaskLen + "[" + m_SelectSortParam[proto].MaskData[0] + " " + m_SelectSortParam[proto].MaskData[1] + "]", null);
                    m_QueryParam[proto] = frmIsoSelect.IsoQueryParam;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, (string)ht["Text9"]);
                return;
            }

            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                reader.SelectOrSortSet(proto, m_SelectSortParam[proto]);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, (string)ht["Text53"] + ex.Message, this.Text);
                return;
            }

            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                reader.QueryCfgSet(proto, m_QueryParam[proto]);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, (string)ht["Text54"] + ex.Message, this.Text);
                return;
            }
        }

        private void lsvTags_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lsvTags_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void lblUnit4_Click(object sender, EventArgs e)
        {

        }

        private void cmbInventoryArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (string.Equals(cmbInventoryArea.SelectedItem, "EPC"))
            {
                tbxInventoryStartAddr.Text = (00).ToString("D");
                tbxInventoryDataLen.Text = (12).ToString("D");
            }
            else if (string.Equals(cmbInventoryArea.SelectedItem, "Reserve"))
            {
                tbxInventoryStartAddr.Text = (00).ToString("D");
                tbxInventoryDataLen.Text = (08).ToString("D");
            }
            else if (string.Equals(cmbInventoryArea.SelectedItem, "TID"))
            {
                tbxInventoryStartAddr.Text = (04).ToString("D");
                tbxInventoryDataLen.Text = (08).ToString("D");
            }
            else
            {
                tbxInventoryStartAddr.Text = (00).ToString("D");
                tbxInventoryDataLen.Text = (00).ToString("D");
            }
        }

        private void InventoryPanel_Leave(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                {
                    //MessageBox.Show(this, (string)ht["Text2"], (string)ht["Text9"]);
                    return;
                }

                if (InInventory)
                {
                    StopInventory = true;
                    CloseInventoryThread();
                    switch (m_proto)
                    {
                        case Protocol.ISO_18000_63:
                            reader.ISO.InventoryStop(s_usStopInventoryTimeout);
                            break;
                        case Protocol.GB_T_29768:
                            reader.GB.InventoryStop(s_usStopInventoryTimeout);
                            break;
                        case Protocol.GJB_7377_1:
                            reader.GJB.InventoryStop(s_usStopInventoryTimeout);
                            break;
                    }
                    //btnInventory.Text = (string)ht["Text45"];
                    return;
                }

            }
            catch (Exception ex)
            {
                //MessageBox.Show(this, (string)ht["Text54"] + ex.Message, this.Text);
                return;
            }
        }
    }
}
