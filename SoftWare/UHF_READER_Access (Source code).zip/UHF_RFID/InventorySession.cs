﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YYF100
{
    public enum InventorySession
    {
        S0,
        S1,
        S2,
        S3
    }

    public class InventorySessionItem
    {
        public static readonly InventorySessionItem[] Options = new InventorySessionItem[] {
            new InventorySessionItem(InventorySession.S0),
            new InventorySessionItem(InventorySession.S1),
            new InventorySessionItem(InventorySession.S2),
            new InventorySessionItem(InventorySession.S3) };

        InventorySession m_value;

        public InventorySession Value
        {
            get { return m_value; }
        }

        public InventorySessionItem(InventorySession value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return InventorySessionToString(m_value);
        }

        public static string InventorySessionToString(InventorySession value)
        {
            switch (value)
            {
                case InventorySession.S0:
                    return "S0";
                case InventorySession.S1:
                    return "S1";
                case InventorySession.S2:
                    return "S2";
                case InventorySession.S3:
                    return "S3";
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
