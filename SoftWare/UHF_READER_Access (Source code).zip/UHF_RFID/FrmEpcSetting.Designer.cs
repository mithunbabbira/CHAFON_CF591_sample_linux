﻿namespace YYF100
{
    partial class FrmEpcSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSetLinkPrm = new System.Windows.Forms.Button();
            this.btnGetLinkPrm = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.cmbEpcLinkMode = new System.Windows.Forms.ComboBox();
            this.txbEpcTRcall = new System.Windows.Forms.TextBox();
            this.txbEpcDr = new System.Windows.Forms.TextBox();
            this.txbEpcRTcall = new System.Windows.Forms.TextBox();
            this.txbEcpModu = new System.Windows.Forms.TextBox();
            this.txbEpcBlf = new System.Windows.Forms.TextBox();
            this.txbEpcTari = new System.Windows.Forms.TextBox();
            this.cmbEpcTrext = new System.Windows.Forms.ComboBox();
            this.cmbEpcM = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbChannelCount = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lblChannelCount = new System.Windows.Forms.Label();
            this.btnSetFreq = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGetFreq = new System.Windows.Forms.Button();
            this.cmbChannelRegion = new System.Windows.Forms.ComboBox();
            this.cmbChannelStart = new System.Windows.Forms.ComboBox();
            this.txbChannelStep = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblChannelStepUnit = new System.Windows.Forms.Label();
            this.groupBox10.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSetLinkPrm
            // 
            this.btnSetLinkPrm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetLinkPrm.Location = new System.Drawing.Point(200, 259);
            this.btnSetLinkPrm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSetLinkPrm.Name = "btnSetLinkPrm";
            this.btnSetLinkPrm.Size = new System.Drawing.Size(81, 28);
            this.btnSetLinkPrm.TabIndex = 23;
            this.btnSetLinkPrm.Text = "设置(&H)";
            this.btnSetLinkPrm.UseVisualStyleBackColor = true;
            this.btnSetLinkPrm.Click += new System.EventHandler(this.btnSetLinkPrm_Click);
            // 
            // btnGetLinkPrm
            // 
            this.btnGetLinkPrm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetLinkPrm.Location = new System.Drawing.Point(62, 259);
            this.btnGetLinkPrm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnGetLinkPrm.Name = "btnGetLinkPrm";
            this.btnGetLinkPrm.Size = new System.Drawing.Size(81, 28);
            this.btnGetLinkPrm.TabIndex = 22;
            this.btnGetLinkPrm.Text = "获取(&G)";
            this.btnGetLinkPrm.UseVisualStyleBackColor = true;
            this.btnGetLinkPrm.Click += new System.EventHandler(this.btnGetLinkPrm_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(273, 487);
            this.btnClose.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(81, 28);
            this.btnClose.TabIndex = 2;
            this.btnClose.Text = "关闭";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // cmbEpcLinkMode
            // 
            this.cmbEpcLinkMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEpcLinkMode.FormattingEnabled = true;
            this.cmbEpcLinkMode.Location = new System.Drawing.Point(167, 20);
            this.cmbEpcLinkMode.Name = "cmbEpcLinkMode";
            this.cmbEpcLinkMode.Size = new System.Drawing.Size(120, 20);
            this.cmbEpcLinkMode.TabIndex = 1;
            this.cmbEpcLinkMode.SelectedIndexChanged += new System.EventHandler(this.cmbEpcLinkMode_SelectedIndexChanged);
            // 
            // txbEpcTRcall
            // 
            this.txbEpcTRcall.BackColor = System.Drawing.SystemColors.Window;
            this.txbEpcTRcall.Location = new System.Drawing.Point(167, 152);
            this.txbEpcTRcall.Name = "txbEpcTRcall";
            this.txbEpcTRcall.ReadOnly = true;
            this.txbEpcTRcall.Size = new System.Drawing.Size(120, 21);
            this.txbEpcTRcall.TabIndex = 14;
            // 
            // txbEpcDr
            // 
            this.txbEpcDr.BackColor = System.Drawing.SystemColors.Window;
            this.txbEpcDr.Location = new System.Drawing.Point(167, 179);
            this.txbEpcDr.Name = "txbEpcDr";
            this.txbEpcDr.ReadOnly = true;
            this.txbEpcDr.Size = new System.Drawing.Size(120, 21);
            this.txbEpcDr.TabIndex = 17;
            // 
            // txbEpcRTcall
            // 
            this.txbEpcRTcall.BackColor = System.Drawing.SystemColors.Window;
            this.txbEpcRTcall.Location = new System.Drawing.Point(167, 127);
            this.txbEpcRTcall.Name = "txbEpcRTcall";
            this.txbEpcRTcall.ReadOnly = true;
            this.txbEpcRTcall.Size = new System.Drawing.Size(120, 21);
            this.txbEpcRTcall.TabIndex = 11;
            // 
            // txbEcpModu
            // 
            this.txbEcpModu.BackColor = System.Drawing.SystemColors.Window;
            this.txbEcpModu.Location = new System.Drawing.Point(167, 46);
            this.txbEcpModu.Name = "txbEcpModu";
            this.txbEcpModu.ReadOnly = true;
            this.txbEcpModu.Size = new System.Drawing.Size(120, 21);
            this.txbEcpModu.TabIndex = 3;
            // 
            // txbEpcBlf
            // 
            this.txbEpcBlf.BackColor = System.Drawing.SystemColors.Window;
            this.txbEpcBlf.Location = new System.Drawing.Point(167, 73);
            this.txbEpcBlf.Name = "txbEpcBlf";
            this.txbEpcBlf.ReadOnly = true;
            this.txbEpcBlf.Size = new System.Drawing.Size(120, 21);
            this.txbEpcBlf.TabIndex = 5;
            // 
            // txbEpcTari
            // 
            this.txbEpcTari.BackColor = System.Drawing.SystemColors.Window;
            this.txbEpcTari.Location = new System.Drawing.Point(167, 100);
            this.txbEpcTari.Name = "txbEpcTari";
            this.txbEpcTari.ReadOnly = true;
            this.txbEpcTari.Size = new System.Drawing.Size(120, 21);
            this.txbEpcTari.TabIndex = 8;
            // 
            // cmbEpcTrext
            // 
            this.cmbEpcTrext.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEpcTrext.FormattingEnabled = true;
            this.cmbEpcTrext.Location = new System.Drawing.Point(167, 232);
            this.cmbEpcTrext.Name = "cmbEpcTrext";
            this.cmbEpcTrext.Size = new System.Drawing.Size(146, 20);
            this.cmbEpcTrext.TabIndex = 21;
            // 
            // cmbEpcM
            // 
            this.cmbEpcM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEpcM.FormattingEnabled = true;
            this.cmbEpcM.Location = new System.Drawing.Point(167, 206);
            this.cmbEpcM.Name = "cmbEpcM";
            this.cmbEpcM.Size = new System.Drawing.Size(120, 20);
            this.cmbEpcM.TabIndex = 19;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(96, 23);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(65, 12);
            this.label37.TabIndex = 0;
            this.label37.Text = "链路模式：";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(48, 49);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(113, 12);
            this.label38.TabIndex = 2;
            this.label38.Text = "前向链路调制方式：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 182);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 12);
            this.label9.TabIndex = 16;
            this.label9.Text = "反向链路速率因子(DR)：";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(42, 130);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(119, 12);
            this.label23.TabIndex = 10;
            this.label23.Text = "反向校准符(RTcal)：";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(42, 155);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(119, 12);
            this.label19.TabIndex = 13;
            this.label19.Text = "前向校准符(TRcal)：";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(42, 76);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(119, 12);
            this.label39.TabIndex = 4;
            this.label39.Text = "反向链路频率(BLF)：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 235);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(155, 12);
            this.label10.TabIndex = 20;
            this.label10.Text = "反向链路前导信号(TRext)：";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(30, 209);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(131, 12);
            this.label15.TabIndex = 18;
            this.label15.Text = "反向链路编码方式(M)：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 103);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(149, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "前向链路基准时间(Tari)：";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(96, 49);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(65, 12);
            this.label35.TabIndex = 2;
            this.label35.Text = "起始频率：";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.lblChannelStepUnit);
            this.groupBox10.Controls.Add(this.label6);
            this.groupBox10.Controls.Add(this.cmbChannelCount);
            this.groupBox10.Controls.Add(this.label2);
            this.groupBox10.Controls.Add(this.lblChannelCount);
            this.groupBox10.Controls.Add(this.btnSetFreq);
            this.groupBox10.Controls.Add(this.label1);
            this.groupBox10.Controls.Add(this.label35);
            this.groupBox10.Controls.Add(this.btnGetFreq);
            this.groupBox10.Controls.Add(this.cmbChannelRegion);
            this.groupBox10.Controls.Add(this.cmbChannelStart);
            this.groupBox10.Controls.Add(this.txbChannelStep);
            this.groupBox10.Location = new System.Drawing.Point(12, 15);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(342, 165);
            this.groupBox10.TabIndex = 0;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "工作频率";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(293, 49);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 12);
            this.label6.TabIndex = 4;
            this.label6.Text = "MHz";
            // 
            // cmbChannelCount
            // 
            this.cmbChannelCount.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbChannelCount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChannelCount.FormattingEnabled = true;
            this.cmbChannelCount.Location = new System.Drawing.Point(167, 99);
            this.cmbChannelCount.Name = "cmbChannelCount";
            this.cmbChannelCount.Size = new System.Drawing.Size(120, 20);
            this.cmbChannelCount.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(96, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "信道间隔：";
            // 
            // lblChannelCount
            // 
            this.lblChannelCount.AutoSize = true;
            this.lblChannelCount.Location = new System.Drawing.Point(96, 102);
            this.lblChannelCount.Name = "lblChannelCount";
            this.lblChannelCount.Size = new System.Drawing.Size(65, 12);
            this.lblChannelCount.TabIndex = 5;
            this.lblChannelCount.Text = "信道个数：";
            // 
            // btnSetFreq
            // 
            this.btnSetFreq.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetFreq.Location = new System.Drawing.Point(200, 126);
            this.btnSetFreq.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSetFreq.Name = "btnSetFreq";
            this.btnSetFreq.Size = new System.Drawing.Size(81, 28);
            this.btnSetFreq.TabIndex = 8;
            this.btnSetFreq.Text = "设置(&H)";
            this.btnSetFreq.UseVisualStyleBackColor = true;
            this.btnSetFreq.Click += new System.EventHandler(this.btnSetFreq_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(120, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "地域：";
            // 
            // btnGetFreq
            // 
            this.btnGetFreq.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetFreq.Location = new System.Drawing.Point(62, 126);
            this.btnGetFreq.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnGetFreq.Name = "btnGetFreq";
            this.btnGetFreq.Size = new System.Drawing.Size(81, 28);
            this.btnGetFreq.TabIndex = 7;
            this.btnGetFreq.Text = "获取(&G)";
            this.btnGetFreq.UseVisualStyleBackColor = true;
            this.btnGetFreq.Click += new System.EventHandler(this.btnGetFreq_Click);
            // 
            // cmbChannelRegion
            // 
            this.cmbChannelRegion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbChannelRegion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChannelRegion.FormattingEnabled = true;
            this.cmbChannelRegion.Location = new System.Drawing.Point(167, 20);
            this.cmbChannelRegion.Name = "cmbChannelRegion";
            this.cmbChannelRegion.Size = new System.Drawing.Size(120, 20);
            this.cmbChannelRegion.TabIndex = 1;
            this.cmbChannelRegion.SelectedIndexChanged += new System.EventHandler(this.cmbChannelRegion_SelectedIndexChanged);
            // 
            // cmbChannelStart
            // 
            this.cmbChannelStart.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbChannelStart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChannelStart.FormattingEnabled = true;
            this.cmbChannelStart.Location = new System.Drawing.Point(167, 46);
            this.cmbChannelStart.Name = "cmbChannelStart";
            this.cmbChannelStart.Size = new System.Drawing.Size(120, 20);
            this.cmbChannelStart.TabIndex = 3;
            // 
            // txbChannelStep
            // 
            this.txbChannelStep.BackColor = System.Drawing.SystemColors.Window;
            this.txbChannelStep.Location = new System.Drawing.Point(167, 72);
            this.txbChannelStep.Name = "txbChannelStep";
            this.txbChannelStep.Size = new System.Drawing.Size(120, 21);
            this.txbChannelStep.TabIndex = 3;
            this.txbChannelStep.Visible = false;
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(293, 130);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(17, 12);
            this.label24.TabIndex = 12;
            this.label24.Text = "us";
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(293, 155);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(17, 12);
            this.label21.TabIndex = 15;
            this.label21.Text = "us";
            // 
            // label40
            // 
            this.label40.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(293, 76);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(23, 12);
            this.label40.TabIndex = 6;
            this.label40.Text = "KHz";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(293, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(17, 12);
            this.label7.TabIndex = 9;
            this.label7.Text = "us";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbEpcLinkMode);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label40);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label39);
            this.groupBox1.Controls.Add(this.btnSetLinkPrm);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.btnGetLinkPrm);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.txbEpcTRcall);
            this.groupBox1.Controls.Add(this.label37);
            this.groupBox1.Controls.Add(this.txbEpcDr);
            this.groupBox1.Controls.Add(this.cmbEpcM);
            this.groupBox1.Controls.Add(this.txbEpcRTcall);
            this.groupBox1.Controls.Add(this.cmbEpcTrext);
            this.groupBox1.Controls.Add(this.txbEcpModu);
            this.groupBox1.Controls.Add(this.txbEpcTari);
            this.groupBox1.Controls.Add(this.txbEpcBlf);
            this.groupBox1.Location = new System.Drawing.Point(12, 186);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(342, 294);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "链路参数";
            // 
            // lblChannelStepUnit
            // 
            this.lblChannelStepUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblChannelStepUnit.AutoSize = true;
            this.lblChannelStepUnit.Location = new System.Drawing.Point(293, 75);
            this.lblChannelStepUnit.Name = "lblChannelStepUnit";
            this.lblChannelStepUnit.Size = new System.Drawing.Size(23, 12);
            this.lblChannelStepUnit.TabIndex = 4;
            this.lblChannelStepUnit.Text = "KHz";
            this.lblChannelStepUnit.Visible = false;
            // 
            // FrmEpcSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(366, 522);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.groupBox10);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "FrmEpcSetting";
            this.Text = "射频参数设置 - ISO/IEC18000-63";
            this.Load += new System.EventHandler(this.FrmEpcSetting_Load);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSetLinkPrm;
        private System.Windows.Forms.Button btnGetLinkPrm;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox cmbEpcLinkMode;
        private System.Windows.Forms.TextBox txbEpcTRcall;
        private System.Windows.Forms.TextBox txbEpcDr;
        private System.Windows.Forms.TextBox txbEpcRTcall;
        private System.Windows.Forms.TextBox txbEcpModu;
        private System.Windows.Forms.TextBox txbEpcBlf;
        private System.Windows.Forms.TextBox txbEpcTari;
        private System.Windows.Forms.ComboBox cmbEpcTrext;
        private System.Windows.Forms.ComboBox cmbEpcM;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblChannelCount;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbChannelStart;
        private System.Windows.Forms.ComboBox cmbChannelCount;
        private System.Windows.Forms.Button btnSetFreq;
        private System.Windows.Forms.Button btnGetFreq;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbChannelRegion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txbChannelStep;
        private System.Windows.Forms.Label lblChannelStepUnit;
    }
}