using System;
using System.Collections.Generic;
using System.Text;

namespace YYF100
{
    class ChannelItem
    {
        public static readonly ChannelItem[] EmptyArray = new ChannelItem[0];

        float m_fFreq = 0;

        public float Freq
        {
            get { return m_fFreq; }
        }

        public ChannelItem(float freq)
        {
            m_fFreq = freq;
        }

        public override string ToString()
        {
            return m_fFreq.ToString("F3");
        }
    }
}
