namespace YYF100
{
    partial class NetSet
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.txbNETPort = new System.Windows.Forms.TextBox();
            this.netlabel3 = new System.Windows.Forms.Label();
            this.txbNetIPAddr = new System.Windows.Forms.TextBox();
            this.netlabel1 = new System.Windows.Forms.Label();
            this.netgroupBox1 = new System.Windows.Forms.GroupBox();
            this.netlabel10 = new System.Windows.Forms.Label();
            this.txbGateway = new System.Windows.Forms.TextBox();
            this.netlabel9 = new System.Windows.Forms.Label();
            this.txbNetmask = new System.Windows.Forms.TextBox();
            this.netlabel4 = new System.Windows.Forms.Label();
            this.btnGetNetInfo = new System.Windows.Forms.Button();
            this.btnSetNetInfo = new System.Windows.Forms.Button();
            this.netlabel2 = new System.Windows.Forms.Label();
            this.txbNetMACAddr = new System.Windows.Forms.TextBox();
            this.txbRemoteNetIPAddr = new System.Windows.Forms.TextBox();
            this.netlabel8 = new System.Windows.Forms.Label();
            this.netlabel7 = new System.Windows.Forms.Label();
            this.txbRemoteNETPort = new System.Windows.Forms.TextBox();
            this.btnSetRemoteNetInfo = new System.Windows.Forms.Button();
            this.btnGetRemoteNetInfo = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txbHearttime = new System.Windows.Forms.TextBox();
            this.netlabel5 = new System.Windows.Forms.Label();
            this.netgroupBox2 = new System.Windows.Forms.GroupBox();
            this.cbxRemoteNetEn = new System.Windows.Forms.CheckBox();
            this.netlabel6 = new System.Windows.Forms.Label();
            this.netgroupBox3 = new System.Windows.Forms.GroupBox();
            this.cbxWIFIMode = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbxWIFItEn = new System.Windows.Forms.CheckBox();
            this.txbWIFIPORT = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.netlabel14 = new System.Windows.Forms.Label();
            this.netlabel13 = new System.Windows.Forms.Label();
            this.btnGetWIFIInfo = new System.Windows.Forms.Button();
            this.txbWIFIIPAddr = new System.Windows.Forms.TextBox();
            this.btnSetWIFIInfo = new System.Windows.Forms.Button();
            this.txbWIFIPASSWORD = new System.Windows.Forms.TextBox();
            this.netlabel12 = new System.Windows.Forms.Label();
            this.netlabel11 = new System.Windows.Forms.Label();
            this.txbWIFISSID = new System.Windows.Forms.TextBox();
            this.netgroupBox1.SuspendLayout();
            this.netgroupBox2.SuspendLayout();
            this.netgroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // txbNETPort
            // 
            this.txbNETPort.Location = new System.Drawing.Point(282, 104);
            this.txbNETPort.Name = "txbNETPort";
            this.txbNETPort.Size = new System.Drawing.Size(78, 21);
            this.txbNETPort.TabIndex = 7;
            this.txbNETPort.Text = "2022";
            // 
            // netlabel3
            // 
            this.netlabel3.AutoSize = true;
            this.netlabel3.Location = new System.Drawing.Point(223, 108);
            this.netlabel3.Name = "netlabel3";
            this.netlabel3.Size = new System.Drawing.Size(53, 12);
            this.netlabel3.TabIndex = 6;
            this.netlabel3.Text = "端口号：";
            // 
            // txbNetIPAddr
            // 
            this.txbNetIPAddr.Location = new System.Drawing.Point(76, 50);
            this.txbNetIPAddr.Name = "txbNetIPAddr";
            this.txbNetIPAddr.Size = new System.Drawing.Size(130, 21);
            this.txbNetIPAddr.TabIndex = 5;
            this.txbNetIPAddr.Text = "192.168.1.200";
            this.txbNetIPAddr.TextChanged += new System.EventHandler(this.txbNetIPAddr_TextChanged);
            // 
            // netlabel1
            // 
            this.netlabel1.AutoSize = true;
            this.netlabel1.Location = new System.Drawing.Point(5, 54);
            this.netlabel1.Name = "netlabel1";
            this.netlabel1.Size = new System.Drawing.Size(53, 12);
            this.netlabel1.TabIndex = 4;
            this.netlabel1.Text = "IP地址：";
            // 
            // netgroupBox1
            // 
            this.netgroupBox1.Controls.Add(this.netlabel10);
            this.netgroupBox1.Controls.Add(this.txbGateway);
            this.netgroupBox1.Controls.Add(this.netlabel9);
            this.netgroupBox1.Controls.Add(this.txbNetmask);
            this.netgroupBox1.Controls.Add(this.netlabel4);
            this.netgroupBox1.Controls.Add(this.btnGetNetInfo);
            this.netgroupBox1.Controls.Add(this.btnSetNetInfo);
            this.netgroupBox1.Controls.Add(this.netlabel2);
            this.netgroupBox1.Controls.Add(this.txbNETPort);
            this.netgroupBox1.Controls.Add(this.netlabel3);
            this.netgroupBox1.Controls.Add(this.txbNetMACAddr);
            this.netgroupBox1.Controls.Add(this.netlabel1);
            this.netgroupBox1.Controls.Add(this.txbNetIPAddr);
            this.netgroupBox1.Location = new System.Drawing.Point(13, 27);
            this.netgroupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.netgroupBox1.Name = "netgroupBox1";
            this.netgroupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.netgroupBox1.Size = new System.Drawing.Size(530, 150);
            this.netgroupBox1.TabIndex = 8;
            this.netgroupBox1.TabStop = false;
            this.netgroupBox1.Text = "网络参数";
            // 
            // netlabel10
            // 
            this.netlabel10.AutoSize = true;
            this.netlabel10.Location = new System.Drawing.Point(4, 108);
            this.netlabel10.Name = "netlabel10";
            this.netlabel10.Size = new System.Drawing.Size(65, 12);
            this.netlabel10.TabIndex = 18;
            this.netlabel10.Text = "默认网关：";
            // 
            // txbGateway
            // 
            this.txbGateway.Location = new System.Drawing.Point(76, 104);
            this.txbGateway.Name = "txbGateway";
            this.txbGateway.Size = new System.Drawing.Size(130, 21);
            this.txbGateway.TabIndex = 19;
            this.txbGateway.Text = "192.168.1.1";
            // 
            // netlabel9
            // 
            this.netlabel9.AutoSize = true;
            this.netlabel9.Location = new System.Drawing.Point(5, 81);
            this.netlabel9.Name = "netlabel9";
            this.netlabel9.Size = new System.Drawing.Size(65, 12);
            this.netlabel9.TabIndex = 16;
            this.netlabel9.Text = "子网掩码：";
            // 
            // txbNetmask
            // 
            this.txbNetmask.Location = new System.Drawing.Point(76, 77);
            this.txbNetmask.Name = "txbNetmask";
            this.txbNetmask.Size = new System.Drawing.Size(130, 21);
            this.txbNetmask.TabIndex = 17;
            this.txbNetmask.Text = "255.255.255.0";
            // 
            // netlabel4
            // 
            this.netlabel4.AutoSize = true;
            this.netlabel4.Location = new System.Drawing.Point(364, 108);
            this.netlabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.netlabel4.Name = "netlabel4";
            this.netlabel4.Size = new System.Drawing.Size(59, 12);
            this.netlabel4.TabIndex = 15;
            this.netlabel4.Text = "(0~65535)";
            // 
            // btnGetNetInfo
            // 
            this.btnGetNetInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetNetInfo.Location = new System.Drawing.Point(435, 32);
            this.btnGetNetInfo.Name = "btnGetNetInfo";
            this.btnGetNetInfo.Size = new System.Drawing.Size(77, 22);
            this.btnGetNetInfo.TabIndex = 13;
            this.btnGetNetInfo.Text = "获取";
            this.btnGetNetInfo.UseVisualStyleBackColor = true;
            this.btnGetNetInfo.Click += new System.EventHandler(this.btnGetNetInfo_Click);
            // 
            // btnSetNetInfo
            // 
            this.btnSetNetInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetNetInfo.Location = new System.Drawing.Point(435, 63);
            this.btnSetNetInfo.Name = "btnSetNetInfo";
            this.btnSetNetInfo.Size = new System.Drawing.Size(77, 22);
            this.btnSetNetInfo.TabIndex = 14;
            this.btnSetNetInfo.Text = "设置";
            this.btnSetNetInfo.UseVisualStyleBackColor = true;
            this.btnSetNetInfo.Click += new System.EventHandler(this.btnSetNetInfo_Click);
            // 
            // netlabel2
            // 
            this.netlabel2.AutoSize = true;
            this.netlabel2.Location = new System.Drawing.Point(4, 28);
            this.netlabel2.Name = "netlabel2";
            this.netlabel2.Size = new System.Drawing.Size(59, 12);
            this.netlabel2.TabIndex = 8;
            this.netlabel2.Text = "MAC地址：";
            // 
            // txbNetMACAddr
            // 
            this.txbNetMACAddr.Location = new System.Drawing.Point(76, 24);
            this.txbNetMACAddr.Name = "txbNetMACAddr";
            this.txbNetMACAddr.ReadOnly = true;
            this.txbNetMACAddr.Size = new System.Drawing.Size(130, 21);
            this.txbNetMACAddr.TabIndex = 9;
            this.txbNetMACAddr.Text = "AC-21-11-12-12-12";
            this.txbNetMACAddr.TextChanged += new System.EventHandler(this.txbNetMACAddr_TextChanged);
            // 
            // txbRemoteNetIPAddr
            // 
            this.txbRemoteNetIPAddr.Location = new System.Drawing.Point(64, 53);
            this.txbRemoteNetIPAddr.Name = "txbRemoteNetIPAddr";
            this.txbRemoteNetIPAddr.Size = new System.Drawing.Size(130, 21);
            this.txbRemoteNetIPAddr.TabIndex = 5;
            this.txbRemoteNetIPAddr.Text = "192.168.1.100";
            // 
            // netlabel8
            // 
            this.netlabel8.AutoSize = true;
            this.netlabel8.Location = new System.Drawing.Point(5, 57);
            this.netlabel8.Name = "netlabel8";
            this.netlabel8.Size = new System.Drawing.Size(53, 12);
            this.netlabel8.TabIndex = 4;
            this.netlabel8.Text = "远程IP：";
            // 
            // netlabel7
            // 
            this.netlabel7.AutoSize = true;
            this.netlabel7.Location = new System.Drawing.Point(212, 57);
            this.netlabel7.Name = "netlabel7";
            this.netlabel7.Size = new System.Drawing.Size(65, 12);
            this.netlabel7.TabIndex = 6;
            this.netlabel7.Text = "远程端口：";
            // 
            // txbRemoteNETPort
            // 
            this.txbRemoteNETPort.Location = new System.Drawing.Point(271, 53);
            this.txbRemoteNETPort.Name = "txbRemoteNETPort";
            this.txbRemoteNETPort.Size = new System.Drawing.Size(78, 21);
            this.txbRemoteNETPort.TabIndex = 7;
            this.txbRemoteNETPort.Text = "5000";
            // 
            // btnSetRemoteNetInfo
            // 
            this.btnSetRemoteNetInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetRemoteNetInfo.Location = new System.Drawing.Point(435, 63);
            this.btnSetRemoteNetInfo.Name = "btnSetRemoteNetInfo";
            this.btnSetRemoteNetInfo.Size = new System.Drawing.Size(77, 22);
            this.btnSetRemoteNetInfo.TabIndex = 14;
            this.btnSetRemoteNetInfo.Text = "设置";
            this.btnSetRemoteNetInfo.UseVisualStyleBackColor = true;
            this.btnSetRemoteNetInfo.Click += new System.EventHandler(this.btnSetRemoteNetInfo_Click);
            // 
            // btnGetRemoteNetInfo
            // 
            this.btnGetRemoteNetInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetRemoteNetInfo.Location = new System.Drawing.Point(435, 32);
            this.btnGetRemoteNetInfo.Name = "btnGetRemoteNetInfo";
            this.btnGetRemoteNetInfo.Size = new System.Drawing.Size(77, 22);
            this.btnGetRemoteNetInfo.TabIndex = 13;
            this.btnGetRemoteNetInfo.Text = "获取";
            this.btnGetRemoteNetInfo.UseVisualStyleBackColor = true;
            this.btnGetRemoteNetInfo.Click += new System.EventHandler(this.btnGetRemoteNetInfo_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(352, 57);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 12);
            this.label5.TabIndex = 15;
            this.label5.Text = "(0~65535)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 12);
            this.label4.TabIndex = 16;
            // 
            // txbHearttime
            // 
            this.txbHearttime.Location = new System.Drawing.Point(130, 86);
            this.txbHearttime.Name = "txbHearttime";
            this.txbHearttime.Size = new System.Drawing.Size(64, 21);
            this.txbHearttime.TabIndex = 19;
            this.txbHearttime.Text = "1";
            // 
            // netlabel5
            // 
            this.netlabel5.AutoSize = true;
            this.netlabel5.Location = new System.Drawing.Point(4, 90);
            this.netlabel5.Name = "netlabel5";
            this.netlabel5.Size = new System.Drawing.Size(65, 12);
            this.netlabel5.TabIndex = 18;
            this.netlabel5.Text = "心跳时间：";
            // 
            // netgroupBox2
            // 
            this.netgroupBox2.Controls.Add(this.cbxRemoteNetEn);
            this.netgroupBox2.Controls.Add(this.netlabel6);
            this.netgroupBox2.Controls.Add(this.netlabel5);
            this.netgroupBox2.Controls.Add(this.txbHearttime);
            this.netgroupBox2.Controls.Add(this.label4);
            this.netgroupBox2.Controls.Add(this.label5);
            this.netgroupBox2.Controls.Add(this.btnGetRemoteNetInfo);
            this.netgroupBox2.Controls.Add(this.btnSetRemoteNetInfo);
            this.netgroupBox2.Controls.Add(this.txbRemoteNETPort);
            this.netgroupBox2.Controls.Add(this.netlabel7);
            this.netgroupBox2.Controls.Add(this.netlabel8);
            this.netgroupBox2.Controls.Add(this.txbRemoteNetIPAddr);
            this.netgroupBox2.Location = new System.Drawing.Point(13, 185);
            this.netgroupBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.netgroupBox2.Name = "netgroupBox2";
            this.netgroupBox2.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.netgroupBox2.Size = new System.Drawing.Size(530, 121);
            this.netgroupBox2.TabIndex = 9;
            this.netgroupBox2.TabStop = false;
            this.netgroupBox2.Text = "远程参数";
            // 
            // cbxRemoteNetEn
            // 
            this.cbxRemoteNetEn.AutoSize = true;
            this.cbxRemoteNetEn.Location = new System.Drawing.Point(8, 20);
            this.cbxRemoteNetEn.Name = "cbxRemoteNetEn";
            this.cbxRemoteNetEn.Size = new System.Drawing.Size(72, 16);
            this.cbxRemoteNetEn.TabIndex = 21;
            this.cbxRemoteNetEn.Text = "发送使能";
            this.cbxRemoteNetEn.UseVisualStyleBackColor = true;
            // 
            // netlabel6
            // 
            this.netlabel6.AutoSize = true;
            this.netlabel6.Location = new System.Drawing.Point(199, 90);
            this.netlabel6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.netlabel6.Name = "netlabel6";
            this.netlabel6.Size = new System.Drawing.Size(95, 12);
            this.netlabel6.TabIndex = 20;
            this.netlabel6.Text = "(0~255)单位*5秒";
            // 
            // netgroupBox3
            // 
            this.netgroupBox3.Controls.Add(this.cbxWIFIMode);
            this.netgroupBox3.Controls.Add(this.label1);
            this.netgroupBox3.Controls.Add(this.cbxWIFItEn);
            this.netgroupBox3.Controls.Add(this.txbWIFIPORT);
            this.netgroupBox3.Controls.Add(this.label3);
            this.netgroupBox3.Controls.Add(this.netlabel14);
            this.netgroupBox3.Controls.Add(this.netlabel13);
            this.netgroupBox3.Controls.Add(this.btnGetWIFIInfo);
            this.netgroupBox3.Controls.Add(this.txbWIFIIPAddr);
            this.netgroupBox3.Controls.Add(this.btnSetWIFIInfo);
            this.netgroupBox3.Controls.Add(this.txbWIFIPASSWORD);
            this.netgroupBox3.Controls.Add(this.netlabel12);
            this.netgroupBox3.Controls.Add(this.netlabel11);
            this.netgroupBox3.Controls.Add(this.txbWIFISSID);
            this.netgroupBox3.Location = new System.Drawing.Point(13, 314);
            this.netgroupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.netgroupBox3.Name = "netgroupBox3";
            this.netgroupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.netgroupBox3.Size = new System.Drawing.Size(530, 155);
            this.netgroupBox3.TabIndex = 23;
            this.netgroupBox3.TabStop = false;
            this.netgroupBox3.Text = "WIFI";
            this.netgroupBox3.Visible = false;
            // 
            // cbxWIFIMode
            // 
            this.cbxWIFIMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxWIFIMode.FormattingEnabled = true;
            this.cbxWIFIMode.Items.AddRange(new object[] {
            "SmartConfig",
            "SerialConfig"});
            this.cbxWIFIMode.Location = new System.Drawing.Point(103, 18);
            this.cbxWIFIMode.Name = "cbxWIFIMode";
            this.cbxWIFIMode.Size = new System.Drawing.Size(135, 20);
            this.cbxWIFIMode.TabIndex = 27;
            this.cbxWIFIMode.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(361, 130);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 12);
            this.label1.TabIndex = 26;
            this.label1.Text = "(0~65535)";
            // 
            // cbxWIFItEn
            // 
            this.cbxWIFItEn.AutoSize = true;
            this.cbxWIFItEn.Location = new System.Drawing.Point(8, 20);
            this.cbxWIFItEn.Name = "cbxWIFItEn";
            this.cbxWIFItEn.Size = new System.Drawing.Size(72, 16);
            this.cbxWIFItEn.TabIndex = 21;
            this.cbxWIFItEn.Text = "WIFI使能";
            this.cbxWIFItEn.UseVisualStyleBackColor = true;
            // 
            // txbWIFIPORT
            // 
            this.txbWIFIPORT.Location = new System.Drawing.Point(280, 126);
            this.txbWIFIPORT.Name = "txbWIFIPORT";
            this.txbWIFIPORT.Size = new System.Drawing.Size(78, 21);
            this.txbWIFIPORT.TabIndex = 25;
            this.txbWIFIPORT.Text = "5000";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 12);
            this.label3.TabIndex = 16;
            // 
            // netlabel14
            // 
            this.netlabel14.AutoSize = true;
            this.netlabel14.Location = new System.Drawing.Point(212, 130);
            this.netlabel14.Name = "netlabel14";
            this.netlabel14.Size = new System.Drawing.Size(65, 12);
            this.netlabel14.TabIndex = 24;
            this.netlabel14.Text = "远程端口：";
            // 
            // netlabel13
            // 
            this.netlabel13.AutoSize = true;
            this.netlabel13.Location = new System.Drawing.Point(5, 130);
            this.netlabel13.Name = "netlabel13";
            this.netlabel13.Size = new System.Drawing.Size(53, 12);
            this.netlabel13.TabIndex = 22;
            this.netlabel13.Text = "远程IP：";
            // 
            // btnGetWIFIInfo
            // 
            this.btnGetWIFIInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetWIFIInfo.Location = new System.Drawing.Point(435, 54);
            this.btnGetWIFIInfo.Name = "btnGetWIFIInfo";
            this.btnGetWIFIInfo.Size = new System.Drawing.Size(77, 22);
            this.btnGetWIFIInfo.TabIndex = 13;
            this.btnGetWIFIInfo.Text = "获取";
            this.btnGetWIFIInfo.UseVisualStyleBackColor = true;
            // 
            // txbWIFIIPAddr
            // 
            this.txbWIFIIPAddr.Location = new System.Drawing.Point(76, 126);
            this.txbWIFIIPAddr.Name = "txbWIFIIPAddr";
            this.txbWIFIIPAddr.Size = new System.Drawing.Size(130, 21);
            this.txbWIFIIPAddr.TabIndex = 23;
            this.txbWIFIIPAddr.Text = "192.168.1.100";
            // 
            // btnSetWIFIInfo
            // 
            this.btnSetWIFIInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetWIFIInfo.Location = new System.Drawing.Point(435, 85);
            this.btnSetWIFIInfo.Name = "btnSetWIFIInfo";
            this.btnSetWIFIInfo.Size = new System.Drawing.Size(77, 22);
            this.btnSetWIFIInfo.TabIndex = 14;
            this.btnSetWIFIInfo.Text = "设置";
            this.btnSetWIFIInfo.UseVisualStyleBackColor = true;
            // 
            // txbWIFIPASSWORD
            // 
            this.txbWIFIPASSWORD.Location = new System.Drawing.Point(76, 87);
            this.txbWIFIPASSWORD.Name = "txbWIFIPASSWORD";
            this.txbWIFIPASSWORD.Size = new System.Drawing.Size(230, 21);
            this.txbWIFIPASSWORD.TabIndex = 7;
            this.txbWIFIPASSWORD.Text = "12345678";
            // 
            // netlabel12
            // 
            this.netlabel12.AutoSize = true;
            this.netlabel12.Location = new System.Drawing.Point(4, 90);
            this.netlabel12.Name = "netlabel12";
            this.netlabel12.Size = new System.Drawing.Size(65, 12);
            this.netlabel12.TabIndex = 6;
            this.netlabel12.Text = "WIFI密码：";
            // 
            // netlabel11
            // 
            this.netlabel11.AutoSize = true;
            this.netlabel11.Location = new System.Drawing.Point(5, 57);
            this.netlabel11.Name = "netlabel11";
            this.netlabel11.Size = new System.Drawing.Size(65, 12);
            this.netlabel11.TabIndex = 4;
            this.netlabel11.Text = "路由SSID：";
            // 
            // txbWIFISSID
            // 
            this.txbWIFISSID.Location = new System.Drawing.Point(76, 53);
            this.txbWIFISSID.Name = "txbWIFISSID";
            this.txbWIFISSID.Size = new System.Drawing.Size(230, 21);
            this.txbWIFISSID.TabIndex = 5;
            this.txbWIFISSID.Text = "administer";
            // 
            // NetSet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.netgroupBox3);
            this.Controls.Add(this.netgroupBox2);
            this.Controls.Add(this.netgroupBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "NetSet";
            this.Size = new System.Drawing.Size(561, 483);
            this.Load += new System.EventHandler(this.NetSet_Load);
            this.netgroupBox1.ResumeLayout(false);
            this.netgroupBox1.PerformLayout();
            this.netgroupBox2.ResumeLayout(false);
            this.netgroupBox2.PerformLayout();
            this.netgroupBox3.ResumeLayout(false);
            this.netgroupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txbNETPort;
        private System.Windows.Forms.Label netlabel3;
        private System.Windows.Forms.TextBox txbNetIPAddr;
        private System.Windows.Forms.Label netlabel1;
        private System.Windows.Forms.Label netlabel2;
        private System.Windows.Forms.TextBox txbNetMACAddr;
        public System.Windows.Forms.Button btnGetNetInfo;
        public System.Windows.Forms.Button btnSetNetInfo;
        private System.Windows.Forms.Label netlabel4;
        private System.Windows.Forms.Label netlabel10;
        private System.Windows.Forms.TextBox txbGateway;
        private System.Windows.Forms.Label netlabel9;
        private System.Windows.Forms.TextBox txbNetmask;
        private System.Windows.Forms.TextBox txbRemoteNetIPAddr;
        private System.Windows.Forms.Label netlabel8;
        private System.Windows.Forms.Label netlabel7;
        private System.Windows.Forms.TextBox txbRemoteNETPort;
        public System.Windows.Forms.Button btnSetRemoteNetInfo;
        public System.Windows.Forms.Button btnGetRemoteNetInfo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txbHearttime;
        private System.Windows.Forms.Label netlabel5;
        private System.Windows.Forms.Label netlabel6;
        private System.Windows.Forms.CheckBox cbxRemoteNetEn;
        private System.Windows.Forms.ComboBox cbxWIFIMode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbxWIFItEn;
        private System.Windows.Forms.TextBox txbWIFIPORT;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label netlabel14;
        private System.Windows.Forms.Label netlabel13;
        public System.Windows.Forms.Button btnGetWIFIInfo;
        private System.Windows.Forms.TextBox txbWIFIIPAddr;
        public System.Windows.Forms.Button btnSetWIFIInfo;
        private System.Windows.Forms.TextBox txbWIFIPASSWORD;
        private System.Windows.Forms.Label netlabel12;
        private System.Windows.Forms.Label netlabel11;
        private System.Windows.Forms.TextBox txbWIFISSID;
        public System.Windows.Forms.GroupBox netgroupBox3;
        public System.Windows.Forms.GroupBox netgroupBox1;
        public System.Windows.Forms.GroupBox netgroupBox2;
    }
}
