using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using UHF_RFID_Net;
using UHF_RFID.Properties;
using UHF_RFID_Net.ISO;
using System.Collections;

namespace YYF100
{
    public partial class FrmEpcSetting : Form
    {
        Reader m_reader;

        // 父窗口
        RFPanel m_owner = null;

        internal void SetOwner(RFPanel owner)
        {
            m_owner = owner;
        }

        public Hashtable ht
        {
            get { return (m_owner == null ? null : m_owner.HT); }
        }

        public Reader Reader
        {
            get { return m_reader; }
        }

        public FrmEpcSetting(Reader reader)
        {
            if (reader == null)
                throw new ArgumentNullException("reader");
            m_reader = reader;

            InitializeComponent();
        }

        private void FrmEpcSetting_Load(object sender, EventArgs e)
        {
            try
            {
                cmbChannelRegion.Items.Clear();
                cmbChannelRegion.Items.AddRange(Settings.Default.IsTest ? ChannelRegionItem.Options : ChannelRegionItem.OptionsStandard);
                cmbEpcLinkMode.Items.Clear();
                cmbEpcLinkMode.Items.AddRange(Settings.Default.IsTest ? LinkModeItem.Options : LinkModeItem.OptionsStandard);
                cmbEpcM.Items.Clear();
                cmbEpcM.Items.AddRange(LinkMItem.Options);
                cmbEpcTrext.Items.Clear();
                cmbEpcTrext.Items.AddRange(LinkTRextItem.Options);

                cmbChannelRegion.SelectedIndex = 0;
                cmbEpcLinkMode.SelectedIndex = 2;
                cmbEpcM.SelectedIndex = 2;
                cmbEpcTrext.SelectedIndex = 1;

                if (m_reader.IsOpened)
                {
                    btnGetFreq_Click(this, EventArgs.Empty);
                    btnGetLinkPrm_Click(this, EventArgs.Empty);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnGetFreq_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                FreqInfo freq = reader.GetFrequency();

                ChannelRegionItem region = ChannelRegionItem.OptionFromValue((ChannelRegion)freq.Region, !Settings.Default.IsTest);
                if (region == null || region.Value == ChannelRegion.Custom)
                {
                    cmbChannelRegion.SelectedItem = ChannelRegionItem.CustomRegion;
                    cmbChannelStart.Text = freq.StartFreq.ToString("F3");
                    txbChannelStep.Text = freq.StepFreq.ToString();
                    cmbChannelCount.Text = freq.Count.ToString();
                }
                else
                {
                    cmbChannelRegion.SelectedItem = region;

                    ChannelItem item1 = null;
                    ChannelCount item2 = null;
                    foreach (ChannelItem item in cmbChannelStart.Items)
                    {
                        if (Math.Abs(item.Freq - freq.StartFreq) < 0.01)
                        {
                            item1 = item;
                            break;
                        }
                    }
                    if (item1 != null)
                    {
                        foreach (ChannelCount item in cmbChannelCount.Items)
                        {
                            if (item.Count == freq.Count)
                            {
                                item2 = item;
                                break;
                            }
                        }
                    }

                    cmbChannelStart.SelectedItem = item1;
                    cmbChannelCount.SelectedItem = item2;
                    txbChannelStep.Text = freq.StepFreq.ToString();
                }

                if (sender != this)
                    MessageBox.Show(this, "阅读器射频工作频率获取成功", this.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "阅读器射频工作频率获取失败：" + ex.Message, this.Text);
            }
        }

        private void btnSetFreq_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                ChannelRegionItem region = cmbChannelRegion.SelectedItem as ChannelRegionItem;
                if (region == null)
                    throw new Exception("请选择地域");

                float freq2;
                int step2;
                int count2;
                if (region.Value == ChannelRegion.Custom)
                {
                    string freq = cmbChannelStart.Text.Trim();
                    if (freq.Length == 0)
                        throw new Exception((string)ht["Text26"]);
                    string step = txbChannelStep.Text.Trim();
                    if (step.Length == 0)
                        throw new Exception("请输入信道间隔频率");
                    string count = cmbChannelCount.Text.Trim();
                    if (count.Length == 0)
                        throw new Exception("请输入信道个数");

                    if (!float.TryParse(freq, out freq2) || freq2 < 840 || freq2 > 960)
                        throw new Exception((string)ht["Text27"]);
                    step2 = Util.NumberFromString(step);
                    if (step2 < 0 || step2 > 2000)
                        throw new Exception((string)ht["Text28"]);
                    count2 = Util.NumberFromString(count);
                    if (count2 < 1 || count2 > 50)
                        throw new Exception((string)ht["Text29"]);
                }
                else
                {
                    ChannelItem item = cmbChannelStart.SelectedItem as ChannelItem;
                    if (item == null)
                        throw new Exception((string)ht["Text30"]);
                    freq2 = item.Freq;
                    ChannelCount cnt = cmbChannelCount.SelectedItem as ChannelCount;
                    if (cnt == null)
                        throw new Exception((string)ht["Text31"]);
                    count2 = cnt.Count;
                    step2 = region.FreqStep;
                }

                FreqInfo info = new FreqInfo();
                info.Region = (byte)region.Value;
                info.StartFreq = freq2;
                info.StepFreq = (ushort)step2;
                info.Count = (byte)count2;
                reader.SetFrequency(info);

                MessageBox.Show(this, "阅读器射频工作频率设置成功", this.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "阅读器射频工作频率设置失败：" + ex.Message, this.Text);
            }
        }

        private void cmbChannelRegion_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                cmbChannelStart.Items.Clear();
                cmbChannelCount.Items.Clear();
                
                ChannelRegionItem region = cmbChannelRegion.SelectedItem as ChannelRegionItem;
                if (region == null)
                    return;

                if (region.Value == ChannelRegion.Custom)
                {
                    lblChannelCount.Text = "信道个数：";
                    cmbChannelStart.DropDownStyle = ComboBoxStyle.DropDown;
                    cmbChannelCount.DropDownStyle = ComboBoxStyle.DropDown;
                    txbChannelStep.Visible = true;
                    lblChannelStepUnit.Visible = true;
                }
                else
                {
                    lblChannelCount.Text = "结束频率：";
                    cmbChannelStart.DropDownStyle = ComboBoxStyle.DropDownList;
                    cmbChannelCount.DropDownStyle = ComboBoxStyle.DropDownList;
                    txbChannelStep.Visible = false;
                    lblChannelStepUnit.Visible = false;

                    cmbChannelStart.Items.AddRange(region.GetChannelItems());
                    cmbChannelCount.Items.AddRange(region.GetChanelCounts());
                    txbChannelStep.Text = region.FreqStep.ToString();

                    if (cmbChannelStart.Items.Count > 0)
                        cmbChannelStart.SelectedIndex = 0;
                    if (cmbChannelCount.Items.Count > 0)
                        cmbChannelCount.SelectedIndex = cmbChannelCount.Items.Count - 1;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnGetLinkPrm_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSetLinkPrm_Click(object sender, EventArgs e)
        {
            
        }

        private void cmbEpcLinkMode_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                LinkModeItem mode = cmbEpcLinkMode.SelectedItem as LinkModeItem;
                if (mode == null)
                    return;

                txbEcpModu.Text = LinkModuItem.OptionFromValue(mode.Modu).ToString();
                txbEpcBlf.Text = mode.BLF.ToString();
                txbEpcTari.Text = mode.Tari.ToString("F2");
                txbEpcRTcall.Text = (mode.RTcal * mode.Tari).ToString("F1");
                txbEpcTRcall.Text = (mode.TRcal * mode.RTcal * mode.Tari).ToString("F1");
                txbEpcDr.Text = LinkDRItem.OptionFromValue(mode.DR).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, string.Empty + ex.Message, this.Text);
            }
        }
    }
}
