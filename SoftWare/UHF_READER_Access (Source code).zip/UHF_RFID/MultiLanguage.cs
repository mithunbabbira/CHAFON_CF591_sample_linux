using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Xml;

namespace YYF100
{
    public static class MultiLanguage
    {
        private static Dictionary<string, string> DicLanguage = new Dictionary<string, string>();

        private static Dictionary<string, string> ReadXMLText(string frmName, string language)
        {
            try
            {
                Dictionary<string, string> DicLang = new Dictionary<string, string>();
                XmlDocument doc = new XmlDocument();
                string path = AppDomain.CurrentDomain.BaseDirectory + "Languages\\" + language + ".xml";
                if (File.Exists(path))
                    doc.Load(path);
                else
                    return null;
                XmlElement root = doc.DocumentElement;
                XmlNodeList nodeList = root.SelectNodes("Form[Name='" + frmName + "']/Controls/Control");
                foreach (XmlNode node in nodeList)
                {
                    DicLang.Add(node.Attributes["name"].Value, node.InnerText);
                }
                return DicLang;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void SetLanguage(ContainerControl form)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            string languageType = config.AppSettings.Settings["Language"].Value;
            DicLanguage = ReadXMLText(form.Name, languageType);
            if (DicLanguage == null) return;
            form.Text = GetLanguage(form.Name);
            SetMenuLanguage(form);
            SetControlsLanguage(form.Controls);
        }


        //public static void GetSysdata(Systemdata form)
        //{
        //    Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
        //    string languageType = config.AppSettings.Settings["Language"].Value;
        //    DicLanguage = ReadXMLText(form.ToString(), languageType);
        //    if (DicLanguage == null) return;
        //    //form = GetLanguage(form);
        //    //SetMenuLanguage(form);
        //    SetControlsLanguage(form);
        //}

        private static string GetLanguage(string name)
        {
            if (DicLanguage.ContainsKey(name))
                return DicLanguage[name];
            else
                return null;
        }


        private static void SetMenuLanguage(ContainerControl form)
        {
            FieldInfo[] fieldInfos = form.GetType().GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
            for (int i = 0; i < fieldInfos.Length; i++)
            {
                switch (fieldInfos[i].FieldType.Name)
                {
                    case "MenuStrip":
                        {
                            MenuStrip menuStrip = (MenuStrip)fieldInfos[i].GetValue(form);
                            foreach (ToolStripMenuItem menuItem in menuStrip.Items)
                            {
                                GetSetMenuStripItems(menuItem);
                            }
                            break;
                        }
                    case "ContextMenuStrip":
                        {
                            ContextMenuStrip menuStrip = (ContextMenuStrip)fieldInfos[i].GetValue(form);
                            foreach (ToolStripMenuItem menuItem in menuStrip.Items)
                            {
                                GetSetMenuStripItems(menuItem);
                            }
                            break;
                        }
                    case "ToolStrip":
                        {
                            ToolStrip menuStrip = (ToolStrip)fieldInfos[i].GetValue(form);
                            foreach (ToolStripItem item in menuStrip.Items)
                            {
                                string text = GetLanguage(item.Name);
                                if (!string.IsNullOrEmpty(text)) item.Text = text;
                            }
                            break;
                        }
                    case "StatusStrip":
                        {
                            StatusStrip statusStrip = (StatusStrip)fieldInfos[i].GetValue(form);
                            foreach (ToolStripItem item in statusStrip.Items)
                            {
                                string text = GetLanguage(item.Name);
                                if (!string.IsNullOrEmpty(text)) item.Text = text;
                            }
                            break;
                        }
                    case "ListView":
                        {
                            ListView listview = (ListView)fieldInfos[i].GetValue(form);
                            foreach (ColumnHeader item in listview.Columns)
                            {
                                string text = GetLanguage(item.Tag.ToString());
                                if (!string.IsNullOrEmpty(text))
                                    item.Text = text;
                            }
                            break;
                        }
                    case "TabControl":
                        {
                            TabControl tabControl = (TabControl)fieldInfos[i].GetValue(form);
                            foreach (TabPage item in tabControl.Controls)
                            {
                                string text = GetLanguage(item.Name);
                                if (!string.IsNullOrEmpty(text))
                                    item.Text = text;
                            }
                            break;
                        }
                }
            }
        }

        private static void GetSetMenuStripItems(ToolStripMenuItem menuItem)
        {
            string text = GetLanguage(menuItem.Name);
            if (!string.IsNullOrEmpty(text)) menuItem.Text = text;
            foreach (ToolStripMenuItem item in menuItem.DropDownItems)
            {
                text = GetLanguage(item.Name);
                if (!string.IsNullOrEmpty(text)) item.Text = text;
                if (item.DropDownItems != null) GetSetMenuStripItems(item);
            }
        }

        private static void SetControlsLanguage(Control.ControlCollection controls)
        {
            foreach (Control item in controls)
            {
                string text = GetLanguage(item.Name);
                if (!string.IsNullOrEmpty(text)) item.Text = text;
                if (item.Controls.Count > 0)
                    SetControlsLanguage(item.Controls);
            }
        }

        //private static void SetControlsLanguage(Systemdata controls)
        //{
        //    controls.strAnsmode  = GetLanguage(controls.strAnsmode.ToString());
        //    //foreach (Systemdata item in controls)
        //    //{
        //    //    string text = GetLanguage(item.Name);
        //    //    if (!string.IsNullOrEmpty(text))
        //    //        item.Text = text;
        //    //    if (item.Controls.Count > 0)
        //    //        SetControlsLanguage(item.Controls);
        //    //}
        //}

        public static string GetOtherLanguage(string name)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            string languageType = config.AppSettings.Settings["Language"].Value;
            string value = "";
            XmlDocument doc = new XmlDocument();
            string path = AppDomain.CurrentDomain.BaseDirectory + "Languages\\OtherLanguage.xml";
            if (File.Exists(path))
                doc.Load(path);
            else
                return null;
            XmlElement root = doc.DocumentElement;
            XmlNodeList nodeList = root.SelectNodes("/OtherLanguage/Text");
            foreach (XmlNode node in nodeList)
            {
                if (node.Attributes["name"].Value == name)
                {
                    if (languageType == EnumLanaguage.Chinese.ToString())
                        value = node.Attributes["ch-z"].Value;
                    else
                        value = node.Attributes["en"].Value;
                }
            }
            return value;
        }
    }

    public enum EnumLanaguage
    {
        [Description("中文")]
        Chinese,
        [Description("英文")]
        English
    }

}
