using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using UHF_RFID_Net;

namespace YYF100
{
    public partial class AdvanceSetting : UserControl
    {

        RFPanel m_owner = null;


        internal void SetOwner(RFPanel owner)
        {
            m_owner = owner;
        }

        public Hashtable ht
        {
            get { return (m_owner == null ? null : m_owner.HT); }
        }

        public Reader Reader
        {
            get { return (m_owner == null ? null : m_owner.Reader); }
        }


        // 当前是否正在处理十斤进制格式化输入
        bool m_bChangeText = false;
        private static readonly char[] s_arrSplit = new char[] { ' ', '\t' };

        public AdvanceSetting()
        {
            InitializeComponent();

        }

        private void WriteLog(MessageType type, string msg, Exception ex)
        {
            if (m_owner != null)
                m_owner.WriteLog(type, msg, ex);
        }

        private void btnSetAdvanceInfo_Click(object sender, EventArgs e)
        {

        }

        private void btnGetAdvanceInfo_Click(object sender, EventArgs e)
        {

        }

        private void txbPassword_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (m_bChangeText)
                    return;
                TextBox txb = sender as TextBox;
                if (txb == null || txb.SelectionLength > 0)
                    return;
                m_bChangeText = true;

                if (e.KeyCode == Keys.Delete)
                {
                    int pos = txb.SelectionStart;
                    if (pos + 1 < txb.TextLength && txb.Text[pos] == ' ')
                    {
                        e.Handled = true;
                        txb.Text = txb.Text.Remove(pos + 1, 1);
                        txb.SelectionStart = pos;
                        //FormatText(txb);
                    }
                }
                else if (e.KeyCode == Keys.Back)
                {
                    int pos = txb.SelectionStart;
                    if (pos > 1 && pos <= txb.TextLength && txb.Text[pos - 1] == ' ')
                    {
                        e.Handled = true;
                        txb.Text = txb.Text.Remove(pos - 2, 1);
                        txb.SelectionStart = pos - 1;
                        //FormatText(txb);
                    }
                }

                m_bChangeText = false;
            }
            catch (Exception ex)
            {
                m_bChangeText = false;
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }


        private void FormatText(TextBox txb)
        {
            string text = txb.Text;
            bool needFormat = false;
            for (int i = 0, l = 0; i < text.Length; i++)
            {
                int j = 0;
                for (; j < s_arrSplit.Length && s_arrSplit[j] != text[i]; j++) ;
                if (j >= s_arrSplit.Length)
                {
                    l++;
                    if (l > 2)
                    {
                        needFormat = true;
                        break;
                    }
                }
                else
                    l = 0;
            }
            if (needFormat)
            {
                if (txb.SelectionLength > 0)
                {
                    int pos = int.MaxValue;
                    text = Util.FormatHexString(text, ref pos);
                    txb.Text = text;
                    txb.SelectionStart = text.Length;
                    txb.SelectionLength = 0;
                }
                else
                {
                    int pos = txb.SelectionStart;
                    txb.Text = Util.FormatHexString(text, ref pos);
                    txb.SelectionStart = pos;
                    txb.SelectionLength = 0;
                }
            }
        }


        private void txbPassword_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (m_bChangeText)
                    return;
                TextBox txb = sender as TextBox;
                if (txb == null)
                    return;
                m_bChangeText = true;

                FormatText(txb);

                m_bChangeText = false;
            }
            catch (Exception ex)
            {
                m_bChangeText = false;
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void AdvanceSetting_Load(object sender, EventArgs e)
        {
            // 绑定数据源
            //IList<Info> infoList = new List<Info>();
            //Info info1 = new Info() { Id = "1", Name = (string)ht["strPasswordOrMaskMatched"] };
            //Info info2 = new Info() { Id = "2", Name = (string)ht["strPasswordAndMaskMatched"] };
            //infoList.Add(info1);
            //infoList.Add(info2);
            //cmbMaskCondition.DataSource = infoList;
            //cmbMaskCondition.ValueMember = "Id";
            //cmbMaskCondition.DisplayMember = "Name";

            //IList<Info> infoList1 = new List<Info>();
            //Info info3 = new Info() { Id = "1", Name = (string)ht["strMSBmode"] };
            //Info info4 = new Info() { Id = "2", Name = (string)ht["strLSBmode"] };
            //infoList.Add(info1);
            //infoList.Add(info2);
            //cmbProtocolType.DataSource = infoList1;
            //cmbProtocolType.ValueMember = "Id";
            //cmbProtocolType.DisplayMember = "Name";
            cmbMaskCondition.SelectedIndex = 0;
            cmbProtocolType.SelectedIndex = 0;
        }

        private void btnGetGpioInfo_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                GpioPara Info = reader.GetGpioPara();
                WriteLog(MessageType.Info, (string)ht["Text115"], null);

                if (Info.KCEN == 0)
                {
                    advcbxKCEn.Checked = false;
                }
                else
                {
                    advcbxKCEn.Checked = true;
                }

                if (Info.BUFFEREN == 0)
                {
                    advcbxbufferen.Checked = false;
                }
                else
                {
                    advcbxbufferen.Checked = true;
                }

                if (Info.PROTOCOLEN == 0)
                {
                    advcbxprotocolen.Checked = false;
                }
                else
                {
                    advcbxprotocolen.Checked = true;
                }

                if (Info.KCPowerEn == 1)
                {
                    advcbxKCPowerEn.Checked = true;
                }
                else
                {
                    advcbxKCPowerEn.Checked = false;
                }

                if (Info.TriggleMode == 1)
                {
                    advrdbhighlevel.Checked = true;
                }
                else
                {
                    advrdbLowlevel.Checked = true;
                }

                txbProtocolFormat.Text = Util.HexArrayToString(Info.PROFORMAT);
                txbrelaytime.Text = Info.RELAYTIME.ToString();

                if (Info.PROROCOLTYPE > 1)
                {
                    cmbProtocolType.SelectedIndex = 0;
                }
                else
                {
                    cmbProtocolType.SelectedIndex = Info.PROROCOLTYPE;
                }
                WriteLog(MessageType.Info, (string)ht["Text116"], null);

            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text117"], ex);
                MessageBox.Show(this, (string)ht["Text117"] + ex.Message, this.Text);
            }
        }
    

        private void btnSetGpioInfo_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                GpioPara Info = new GpioPara();


                if (advcbxKCEn.Checked)
                {
                    Info.KCEN = 1;
                }
                else
                {
                    Info.KCEN = 0;
                }

                if (advcbxbufferen.Checked)
                {
                    Info.BUFFEREN = 1;
                }
                else
                {
                    Info.BUFFEREN = 0;
                }

                if (advcbxprotocolen.Checked)
                {
                    Info.PROTOCOLEN = 1;
                }
                else
                {
                    Info.PROTOCOLEN = 0;
                }

                if (advcbxKCPowerEn.Checked)
                {
                    Info.KCPowerEn = 1;
                }
                else
                {
                    Info.KCPowerEn = 0;
                }

                if (advrdbhighlevel.Checked)
                {
                    Info.TriggleMode = 1;
                }
                else
                {
                    Info.TriggleMode = 0;
                }

                Info.RELAYTIME = (byte)Util.NumberFromString(txbrelaytime.Text);
                Info.PROFORMAT = Util.HexArrayFromString(txbProtocolFormat.Text.PadRight(35, '0'));    //自动补齐
                if (cmbProtocolType.SelectedIndex > 1)     //防止越界
                {
                    Info.PROROCOLTYPE = 0;
                }
                else
                {
                    Info.PROROCOLTYPE = (byte)cmbProtocolType.SelectedIndex;
                }

                // 发送数据
                reader.SetGpioPara(Info);
                WriteLog(MessageType.Info, (string)ht["Text113"], null);
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text114"], ex);
                MessageBox.Show(this, (string)ht["Text114"] + ex.Message, this.Text);
            }
        }

        private void btnGetPermissonInfo_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);
                WriteLog(MessageType.Info, (string)ht["Text115"], null);
                if (reader.Devicetpye == 1 || reader.Devicetpye == 3)
                {
                    LongPermissonPara Info = reader.GetLongPermissonPara();
                    if (Info.CODEEN == 0)
                    {
                        advcbxCodeEn.Checked = false;
                    }
                    else
                    {
                        advcbxCodeEn.Checked = true;
                    }

                    if (Info.MASKEN == 0)
                    {
                        advcbxMaskEn.Checked = false;
                    }
                    else
                    {
                        advcbxMaskEn.Checked = true;
                    }

                    txbPassword.Text = Util.HexArrayToString(Info.CODE);
                    txbMaskStartAddr.Text = Info.STARTADD.ToString();
                    txbMasklen.Text = Info.MASKLEN.ToString();
                    byte len;
                    len = Info.MASKLEN;
                    if (len >= 31)
                    {
                        txbMaskData.Text = Util.HexArrayToString(Info.MASKDATA).Substring(0, 92);
                    }
                    else
                    {
                        txbMaskData.Text = Util.HexArrayToString(Info.MASKDATA).Substring(0, 3 * len);
                    }
                    if (Info.MASKCONDITION > 1)
                    {
                        cmbMaskCondition.SelectedIndex = 0;
                    }
                    else
                    {
                        cmbMaskCondition.SelectedIndex = Info.MASKCONDITION;
                    }
                }
                else
                {
                    PermissonPara Info = reader.GetPermissonPara();
                    if (Info.CODEEN == 0)
                    {
                        advcbxCodeEn.Checked = false;
                    }
                    else
                    {
                        advcbxCodeEn.Checked = true;
                    }

                    if (Info.MASKEN == 0)
                    {
                        advcbxMaskEn.Checked = false;
                    }
                    else
                    {
                        advcbxMaskEn.Checked = true;
                    }

                    txbPassword.Text = Util.HexArrayToString(Info.CODE);
                    txbMaskStartAddr.Text = Info.STARTADD.ToString();
                    txbMasklen.Text = Info.MASKLEN.ToString();
                    byte len;
                    len = Info.MASKLEN;
                    if (len >= 12)
                    {
                        txbMaskData.Text = Util.HexArrayToString(Info.MASKDATA).Substring(0, 35);
                    }
                    else
                    {
                        txbMaskData.Text = Util.HexArrayToString(Info.MASKDATA).Substring(0, 3 * len);
                    }
                    if (Info.MASKCONDITION > 1)
                    {
                        cmbMaskCondition.SelectedIndex = 0;
                    }
                    else
                    {
                        cmbMaskCondition.SelectedIndex = Info.MASKCONDITION;
                    }
                }
                WriteLog(MessageType.Info, (string)ht["Text116"], null);

            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text117"], ex);
                MessageBox.Show(this, (string)ht["Text117"] + ex.Message, this.Text);
            }
        }

        private void btnSetPermissonInfo_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);
                if (reader.Devicetpye == 1 || reader.Devicetpye == 3)
                {
                    LongPermissonPara Info = new LongPermissonPara();

                    if (advcbxCodeEn.Checked)
                    {
                        Info.CODEEN = 1;
                    }
                    else
                    {
                        Info.CODEEN = 0;
                    }

                    if (advcbxMaskEn.Checked)
                    {
                        Info.MASKEN = 1;
                    }
                    else
                    {
                        Info.MASKEN = 0;
                    }

                    Info.CODE = Util.HexArrayFromString(txbPassword.Text);
                    WriteLog(MessageType.Info, (string)ht["Text117"] + txbPassword.Text, null);
                    Info.STARTADD = (byte)Util.NumberFromString(txbMaskStartAddr.Text);
                    Info.MASKLEN = (byte)Util.NumberFromString(txbMasklen.Text);
                    Info.MASKDATA = Util.HexArrayFromString(txbMaskData.Text.PadRight(92, '0'));    //自动补齐
                    Info.MASKCONDITION = (byte)cmbMaskCondition.SelectedIndex;

                    // 发送数据
                    reader.SetLongPermissonPara(Info);
                }
                else
                {
                    PermissonPara Info = new PermissonPara();

                    if (advcbxCodeEn.Checked)
                    {
                        Info.CODEEN = 1;
                    }
                    else
                    {
                        Info.CODEEN = 0;
                    }

                    if (advcbxMaskEn.Checked)
                    {
                        Info.MASKEN = 1;
                    }
                    else
                    {
                        Info.MASKEN = 0;
                    }

                    Info.CODE = Util.HexArrayFromString(txbPassword.Text);
                    WriteLog(MessageType.Info, (string)ht["Text117"] + txbPassword.Text, null);
                    Info.STARTADD = (byte)Util.NumberFromString(txbMaskStartAddr.Text);
                    Info.MASKLEN = (byte)Util.NumberFromString(txbMasklen.Text);
                    Info.MASKDATA = Util.HexArrayFromString(txbMaskData.Text.PadRight(35, '0'));    //自动补齐
                    Info.MASKCONDITION = (byte)cmbMaskCondition.SelectedIndex;

                    // 发送数据
                    reader.SetPermissonPara(Info);
                }

                WriteLog(MessageType.Info, (string)ht["Text113"], null);
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text114"], ex);
                MessageBox.Show(this, (string)ht["Text114"] + ex.Message, this.Text);
            }
        }
    }
}
