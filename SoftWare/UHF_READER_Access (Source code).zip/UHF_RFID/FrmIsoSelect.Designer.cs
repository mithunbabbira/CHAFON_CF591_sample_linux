namespace YYF100
{
    partial class FrmIsoSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbTarget = new System.Windows.Forms.ComboBox();
            this.lblTarget = new System.Windows.Forms.Label();
            this.cmbSession = new System.Windows.Forms.ComboBox();
            this.lblSession = new System.Windows.Forms.Label();
            this.cmbSel = new System.Windows.Forms.ComboBox();
            this.lblSel = new System.Windows.Forms.Label();
            this.gbxSelectCfg = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbxTruncate = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbxSelect_mask = new System.Windows.Forms.TextBox();
            this.lblSelect_mask = new System.Windows.Forms.Label();
            this.tbxSelect_point = new System.Windows.Forms.TextBox();
            this.lblSelect_point = new System.Windows.Forms.Label();
            this.cbxSelect_membank = new System.Windows.Forms.ComboBox();
            this.lblSelect_membank = new System.Windows.Forms.Label();
            this.cbxSelect_action = new System.Windows.Forms.ComboBox();
            this.lblSelect_action = new System.Windows.Forms.Label();
            this.cbxSelect_target = new System.Windows.Forms.ComboBox();
            this.lblSelect_Target = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.gbxSelectCfg.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbTarget);
            this.groupBox2.Controls.Add(this.lblTarget);
            this.groupBox2.Controls.Add(this.cmbSession);
            this.groupBox2.Controls.Add(this.lblSession);
            this.groupBox2.Controls.Add(this.cmbSel);
            this.groupBox2.Controls.Add(this.lblSel);
            this.groupBox2.Location = new System.Drawing.Point(3, 171);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox2.Size = new System.Drawing.Size(685, 64);
            this.groupBox2.TabIndex = 86;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Query Para";
            // 
            // cmbTarget
            // 
            this.cmbTarget.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTarget.FormattingEnabled = true;
            this.cmbTarget.Items.AddRange(new object[] {
            "A",
            "B"});
            this.cmbTarget.Location = new System.Drawing.Point(511, 25);
            this.cmbTarget.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbTarget.Name = "cmbTarget";
            this.cmbTarget.Size = new System.Drawing.Size(45, 23);
            this.cmbTarget.TabIndex = 30;
            // 
            // lblTarget
            // 
            this.lblTarget.AutoSize = true;
            this.lblTarget.Location = new System.Drawing.Point(427, 30);
            this.lblTarget.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTarget.Name = "lblTarget";
            this.lblTarget.Size = new System.Drawing.Size(70, 15);
            this.lblTarget.TabIndex = 29;
            this.lblTarget.Text = "Target：";
            // 
            // cmbSession
            // 
            this.cmbSession.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSession.FormattingEnabled = true;
            this.cmbSession.Items.AddRange(new object[] {
            "S0",
            "S1",
            "S2",
            "S3"});
            this.cmbSession.Location = new System.Drawing.Point(288, 25);
            this.cmbSession.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbSession.Name = "cmbSession";
            this.cmbSession.Size = new System.Drawing.Size(45, 23);
            this.cmbSession.TabIndex = 32;
            // 
            // lblSession
            // 
            this.lblSession.AutoSize = true;
            this.lblSession.Location = new System.Drawing.Point(208, 30);
            this.lblSession.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSession.Name = "lblSession";
            this.lblSession.Size = new System.Drawing.Size(78, 15);
            this.lblSession.TabIndex = 31;
            this.lblSession.Text = "Session：";
            // 
            // cmbSel
            // 
            this.cmbSel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSel.FormattingEnabled = true;
            this.cmbSel.Items.AddRange(new object[] {
            "ALL",
            "ALL",
            "~SL",
            "SL"});
            this.cmbSel.Location = new System.Drawing.Point(75, 26);
            this.cmbSel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbSel.Name = "cmbSel";
            this.cmbSel.Size = new System.Drawing.Size(56, 23);
            this.cmbSel.TabIndex = 28;
            // 
            // lblSel
            // 
            this.lblSel.AutoSize = true;
            this.lblSel.Location = new System.Drawing.Point(21, 31);
            this.lblSel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSel.Name = "lblSel";
            this.lblSel.Size = new System.Drawing.Size(46, 15);
            this.lblSel.TabIndex = 27;
            this.lblSel.Text = "Sel：";
            // 
            // gbxSelectCfg
            // 
            this.gbxSelectCfg.Controls.Add(this.label2);
            this.gbxSelectCfg.Controls.Add(this.cbxTruncate);
            this.gbxSelectCfg.Controls.Add(this.label1);
            this.gbxSelectCfg.Controls.Add(this.tbxSelect_mask);
            this.gbxSelectCfg.Controls.Add(this.lblSelect_mask);
            this.gbxSelectCfg.Controls.Add(this.tbxSelect_point);
            this.gbxSelectCfg.Controls.Add(this.lblSelect_point);
            this.gbxSelectCfg.Controls.Add(this.cbxSelect_membank);
            this.gbxSelectCfg.Controls.Add(this.lblSelect_membank);
            this.gbxSelectCfg.Controls.Add(this.cbxSelect_action);
            this.gbxSelectCfg.Controls.Add(this.lblSelect_action);
            this.gbxSelectCfg.Controls.Add(this.cbxSelect_target);
            this.gbxSelectCfg.Controls.Add(this.lblSelect_Target);
            this.gbxSelectCfg.Location = new System.Drawing.Point(3, 5);
            this.gbxSelectCfg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbxSelectCfg.Name = "gbxSelectCfg";
            this.gbxSelectCfg.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbxSelectCfg.Size = new System.Drawing.Size(685, 159);
            this.gbxSelectCfg.TabIndex = 85;
            this.gbxSelectCfg.TabStop = false;
            this.gbxSelectCfg.Text = "Select Para";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(449, 80);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 15);
            this.label2.TabIndex = 93;
            this.label2.Text = "bit";
            // 
            // cbxTruncate
            // 
            this.cbxTruncate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTruncate.FormattingEnabled = true;
            this.cbxTruncate.Items.AddRange(new object[] {
            "NO",
            "YES"});
            this.cbxTruncate.Location = new System.Drawing.Point(113, 116);
            this.cbxTruncate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxTruncate.Name = "cbxTruncate";
            this.cbxTruncate.Size = new System.Drawing.Size(103, 23);
            this.cbxTruncate.TabIndex = 92;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 121);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 15);
            this.label1.TabIndex = 91;
            this.label1.Text = "Truncate：";
            // 
            // tbxSelect_mask
            // 
            this.tbxSelect_mask.Location = new System.Drawing.Point(361, 116);
            this.tbxSelect_mask.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbxSelect_mask.Name = "tbxSelect_mask";
            this.tbxSelect_mask.Size = new System.Drawing.Size(292, 25);
            this.tbxSelect_mask.TabIndex = 90;
            this.tbxSelect_mask.TextChanged += new System.EventHandler(this.tbxSelect_mask_TextChanged);
            // 
            // lblSelect_mask
            // 
            this.lblSelect_mask.AutoSize = true;
            this.lblSelect_mask.Location = new System.Drawing.Point(259, 121);
            this.lblSelect_mask.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelect_mask.Name = "lblSelect_mask";
            this.lblSelect_mask.Size = new System.Drawing.Size(94, 15);
            this.lblSelect_mask.TabIndex = 89;
            this.lblSelect_mask.Text = "Mask(HEX)：";
            // 
            // tbxSelect_point
            // 
            this.tbxSelect_point.Location = new System.Drawing.Point(361, 75);
            this.tbxSelect_point.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbxSelect_point.Name = "tbxSelect_point";
            this.tbxSelect_point.Size = new System.Drawing.Size(79, 25);
            this.tbxSelect_point.TabIndex = 88;
            // 
            // lblSelect_point
            // 
            this.lblSelect_point.AutoSize = true;
            this.lblSelect_point.Location = new System.Drawing.Point(275, 80);
            this.lblSelect_point.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelect_point.Name = "lblSelect_point";
            this.lblSelect_point.Size = new System.Drawing.Size(78, 15);
            this.lblSelect_point.TabIndex = 87;
            this.lblSelect_point.Text = "Pointer：";
            // 
            // cbxSelect_membank
            // 
            this.cbxSelect_membank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSelect_membank.FormattingEnabled = true;
            this.cbxSelect_membank.Items.AddRange(new object[] {
            "RFU",
            "EPC",
            "TID",
            "User"});
            this.cbxSelect_membank.Location = new System.Drawing.Point(113, 75);
            this.cbxSelect_membank.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxSelect_membank.Name = "cbxSelect_membank";
            this.cbxSelect_membank.Size = new System.Drawing.Size(103, 23);
            this.cbxSelect_membank.TabIndex = 86;
            // 
            // lblSelect_membank
            // 
            this.lblSelect_membank.AutoSize = true;
            this.lblSelect_membank.Location = new System.Drawing.Point(25, 80);
            this.lblSelect_membank.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelect_membank.Name = "lblSelect_membank";
            this.lblSelect_membank.Size = new System.Drawing.Size(78, 15);
            this.lblSelect_membank.TabIndex = 85;
            this.lblSelect_membank.Text = "Membank：";
            // 
            // cbxSelect_action
            // 
            this.cbxSelect_action.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSelect_action.FormattingEnabled = true;
            this.cbxSelect_action.Items.AddRange(new object[] {
            "match set SL or A, else ~SL or B",
            "match set SL or A",
            "not-match set ~SL or B",
            "match negate SL or (A->B, B->A)",
            "match set ~SL or B, else SL or A",
            "match set ~SL or B",
            "not-match set SL or A",
            "not-match negate SL or (A->B, B->A)"});
            this.cbxSelect_action.Location = new System.Drawing.Point(361, 34);
            this.cbxSelect_action.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxSelect_action.Name = "cbxSelect_action";
            this.cbxSelect_action.Size = new System.Drawing.Size(292, 23);
            this.cbxSelect_action.TabIndex = 84;
            // 
            // lblSelect_action
            // 
            this.lblSelect_action.AutoSize = true;
            this.lblSelect_action.Location = new System.Drawing.Point(283, 39);
            this.lblSelect_action.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelect_action.Name = "lblSelect_action";
            this.lblSelect_action.Size = new System.Drawing.Size(70, 15);
            this.lblSelect_action.TabIndex = 83;
            this.lblSelect_action.Text = "Action：";
            // 
            // cbxSelect_target
            // 
            this.cbxSelect_target.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSelect_target.FormattingEnabled = true;
            this.cbxSelect_target.Items.AddRange(new object[] {
            "S0",
            "S1",
            "S2",
            "S3",
            "SL",
            "101: RFU",
            "110: RFU",
            "111: RFU"});
            this.cbxSelect_target.Location = new System.Drawing.Point(113, 34);
            this.cbxSelect_target.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxSelect_target.Name = "cbxSelect_target";
            this.cbxSelect_target.Size = new System.Drawing.Size(103, 23);
            this.cbxSelect_target.TabIndex = 82;
            // 
            // lblSelect_Target
            // 
            this.lblSelect_Target.AutoSize = true;
            this.lblSelect_Target.Location = new System.Drawing.Point(33, 39);
            this.lblSelect_Target.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSelect_Target.Name = "lblSelect_Target";
            this.lblSelect_Target.Size = new System.Drawing.Size(70, 15);
            this.lblSelect_Target.TabIndex = 81;
            this.lblSelect_Target.Text = "Target：";
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(420, 308);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 29);
            this.btnCancel.TabIndex = 84;
            this.btnCancel.Text = "Chancel(&C)";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(168, 308);
            this.btnConfirm.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(100, 29);
            this.btnConfirm.TabIndex = 83;
            this.btnConfirm.Text = "Set(&S)";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // FrmIsoSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(691, 361);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gbxSelectCfg);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnConfirm);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmIsoSelect";
            this.Text = "FrmIsoSelect";
            this.Load += new System.EventHandler(this.FrmIsoSelect_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbxSelectCfg.ResumeLayout(false);
            this.gbxSelectCfg.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmbTarget;
        private System.Windows.Forms.Label lblTarget;
        private System.Windows.Forms.ComboBox cmbSession;
        private System.Windows.Forms.Label lblSession;
        private System.Windows.Forms.ComboBox cmbSel;
        private System.Windows.Forms.Label lblSel;
        private System.Windows.Forms.GroupBox gbxSelectCfg;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbxTruncate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbxSelect_mask;
        private System.Windows.Forms.Label lblSelect_mask;
        private System.Windows.Forms.TextBox tbxSelect_point;
        private System.Windows.Forms.Label lblSelect_point;
        private System.Windows.Forms.ComboBox cbxSelect_membank;
        private System.Windows.Forms.Label lblSelect_membank;
        private System.Windows.Forms.ComboBox cbxSelect_action;
        private System.Windows.Forms.Label lblSelect_action;
        private System.Windows.Forms.ComboBox cbxSelect_target;
        private System.Windows.Forms.Label lblSelect_Target;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirm;
    }
}