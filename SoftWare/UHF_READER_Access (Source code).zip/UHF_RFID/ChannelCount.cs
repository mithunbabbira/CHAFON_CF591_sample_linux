﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YYF100
{
    class ChannelCount
    {
        public static readonly ChannelCount[] EmptyArray = new ChannelCount[0];

        int m_iCount = 0;
        ChannelRegionItem m_region = null;

        public int Count
        {
            get { return m_iCount; }
        }

        public ChannelCount(int count, ChannelRegionItem region)
        {
            m_iCount = count;
            m_region = region;
        }

        public override string ToString()
        {
            if (m_region.Value == ChannelRegion.Custom)
                return m_iCount.ToString();
            return (m_region.StartFreq + (m_iCount - 1) * m_region.FreqStep / 1000f).ToString("F3");
        }
    }
}
