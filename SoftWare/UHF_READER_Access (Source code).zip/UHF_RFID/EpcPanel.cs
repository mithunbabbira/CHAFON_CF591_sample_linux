using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using UHF_RFID_Net;
using System.Threading;
using System.Collections.Specialized;
using System.IO;
using UHF_RFID.Properties;
using System.Collections;

namespace YYF100
{
    public partial class EpcPanel : UserControl
    {
        // 空密码，4字节全0数字
        private static readonly byte[] s_arrEmptyPwd = new byte[] { 0, 0, 0, 0 };
        // 十六进制编辑时，数据中间的间隔字符
        private static readonly char[] s_arrSplit = new char[] { ' ', '\t' };

        // BitVector32掩码，当前是否正在执行命令
        private static readonly int FLAG_IN_OPERATION = BitVector32.CreateMask();
        // BitVector32掩码，当前是否需要停止执行命令
        private static readonly int FLAG_STOP_OPERATION = BitVector32.CreateMask(FLAG_IN_OPERATION);

        // 停止盘点等待的时间
        private static readonly ushort s_usStopInventoryTimeout = 10000;

        // 标识集合
        BitVector32 m_flags = new BitVector32();

        // 当前选中的标签
        ShowTagItem m_tagItem = null;

        // 父窗口
        RFPanel m_owner = null;
        // 盘点数据版本，表示标签选择列表中，是第几次盘点上来的数据
        int m_iInventoryDataVersion = 0;

        // 标签响应数据
        Dictionary<RespKey, ShowTagResp> m_tags = new Dictionary<RespKey, ShowTagResp>(1024, new RespKeyCompare());

        // 命令参数：存储区
        UHF_RFID_Net.ISO.MemBank m_membank = UHF_RFID_Net.ISO.MemBank.UII;
        // 命令参数：起始地址
        ushort m_usWordPtr = 0;
        // 命令参数：读/写/擦除的字个数
        ushort m_usWordCount = 0;
        // 命令参数：写入数据
        byte[] m_arrWrittenData = Util.EmptyArray;
        // 命令参数：口令
        byte[] m_arrPwd = s_arrEmptyPwd;
        // 命令参数：锁定区域
        byte m_btLockArea = 0;
        // 命令参数：锁定类型
        byte m_btLockAction = 0;

        // 标签操作线程
        Thread m_thOperation = null;

        // 当前是否正在处理十斤进制格式化输入
        bool m_bChangeText = false;

        // 是否以温度格式显示数据
        bool m_bTempsen = false;

        public Reader Reader
        {
            get { return (m_owner == null ? null : m_owner.Reader); }
        }

        public Hashtable ht
        {
            get { return (m_owner == null ? null : m_owner.HT); }
        }

        protected bool InOperation
        {
            get { return m_flags[FLAG_IN_OPERATION]; }
            set { m_flags[FLAG_IN_OPERATION] = value; }
        }

        public bool StopOperation
        {
            get { return m_flags[FLAG_STOP_OPERATION]; }
            set { m_flags[FLAG_STOP_OPERATION] = value; }
        }

        public EpcPanel()
        {
            InitializeComponent();
        }

        private void EpcPanel_Load(object sender, EventArgs e)
        {
            try
            {
                m_bTempsen = string.Compare(Settings.Default.Tagtype, "Tempsen", StringComparison.OrdinalIgnoreCase) == 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }
        private void btnRead_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                if (InOperation)
                {
                    StopOperation = true;
                    CloseOperationThread();
                    reader.ISO.InventoryStop(s_usStopInventoryTimeout);
                    epcbtnRead.Text = (string)ht["Text57"];
                    EnabledButton(true);
                    return;
                }

                UHF_RFID_Net.ISO.MemBank mem;
                if (epcrdbRWTid.Checked)
                    mem = UHF_RFID_Net.ISO.MemBank.TID;
                else if (epcrdbRWUii.Checked)
                    mem = UHF_RFID_Net.ISO.MemBank.UII;
                else if (epcrdbRWRsv.Checked)
                    mem = UHF_RFID_Net.ISO.MemBank.FileType;
                else if (epcrdbRWUser.Checked)
                    mem = UHF_RFID_Net.ISO.MemBank.User;
                else
                    throw new Exception((string)ht["Text58"]);

                string ptr = txbRWWordPtr.Text.Trim();
                if (ptr.Length == 0)
                    throw new Exception((string)ht["Text59"]);
                int ptr2 = Util.NumberFromString(ptr);
                if (ptr2 < 0 || ptr2 > 65535)
                    throw new Exception((string)ht["Text60"]);

                string len = txbRWLen.Text.Trim();
                if (len.Length == 0)
                    throw new Exception((string)ht["Text61"]);
                int len2 = Util.NumberFromString(len);
                if (len2 < 0 || len2 > 65535)
                    throw new Exception((string)ht["Text62"]);

                byte[] pwd2;
                string pwd = txbRWPwd.Text.Trim();
                if (pwd.Length == 0)
                    pwd2 = s_arrEmptyPwd;
                else
                {
                    pwd2 = Util.HexArrayFromString(pwd);
                    if (pwd2.Length != 4)
                        throw new Exception((string)ht["Text63"]);
                }

                // 先清除数据
                lsvTags.Items.Clear();
                lock (m_tags) { m_tags.Clear(); }

                // 保存操作参数
                m_arrPwd = pwd2;
                m_membank = mem;
                m_usWordPtr = (ushort)ptr2;
                m_usWordCount = (ushort)len2;
                WriteLog(MessageType.Info, (string)ht["Text64"], null);

                m_thOperation = new Thread(ReadTagThread);
                EnabledButton(false);
                epcbtnRead.Enabled = true;
                epcbtnRead.Text = (string)ht["Text65"];
                InOperation = true;
                StopOperation = false;
                m_thOperation.Start();
            }
            catch (Exception ex)
            {
                epcbtnRead.Text = (string)ht["Text57"];
                EnabledButton(true);
                WriteLog(MessageType.Error, (string)ht["Text66"], ex);
                MessageBox.Show(this, (string)ht["Text66"] + ex.Message, (string)ht["Text9"]);
            }
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                if (InOperation)
                {
                    StopOperation = true;
                    CloseOperationThread();
                    reader.ISO.InventoryStop(s_usStopInventoryTimeout);
                    epcbtnWrite.Text = (string)ht["Text67"];
                    EnabledButton(true);
                    return;
                }

                UHF_RFID_Net.ISO.MemBank mem;
                if (epcrdbRWTid.Checked)
                    mem = UHF_RFID_Net.ISO.MemBank.TID;
                else if (epcrdbRWUii.Checked)
                    mem = UHF_RFID_Net.ISO.MemBank.UII;
                else if (epcrdbRWRsv.Checked)
                    mem = UHF_RFID_Net.ISO.MemBank.FileType;
                else if (epcrdbRWUser.Checked)
                    mem = UHF_RFID_Net.ISO.MemBank.User;
                else
                    throw new Exception((string)ht["Text58"]);

                string ptr = txbRWWordPtr.Text.Trim();
                if (ptr.Length == 0)
                    throw new Exception((string)ht["Text59"]);
                int ptr2 = Util.NumberFromString(ptr);
                if (ptr2 < 0 || ptr2 > 65535)
                    throw new Exception((string)ht["Text60"]);

                string pwd = txbRWPwd.Text.Trim();
                if (pwd.Length == 0)
                    throw new Exception((string)ht["Text68"]);
                byte[] pwd2 = Util.HexArrayFromString(pwd);
                if (pwd2.Length != 4)
                    throw new Exception((string)ht["Text63"]);

                string data = txbWData.Text.Trim();
                if (data.Length == 0)
                    throw new Exception((string)ht["Text69"]);
                byte[] data2 = Util.HexArrayFromString(data);
                if (data2.Length == 0)
                    throw new Exception((string)ht["Text69"]);

                // 先清除数据
                lsvTags.Items.Clear();
                lock (m_tags) { m_tags.Clear(); }

                // 保存操作参数
                m_arrPwd = pwd2;
                m_membank = mem;
                m_usWordPtr = (ushort)ptr2;
                m_arrWrittenData = data2;
                WriteLog(MessageType.Info, (string)ht["Text70"], null);

                m_thOperation = new Thread(WriteTagThread);
                EnabledButton(false);
                epcbtnWrite.Enabled = true;
                epcbtnWrite.Text = (string)ht["Text71"];
                InOperation = true;
                StopOperation = false;
                m_thOperation.Start();
            }
            catch (Exception ex)
            {
                epcbtnWrite.Text = (string)ht["Text67"];
                EnabledButton(true);
                WriteLog(MessageType.Error, (string)ht["Text72"], ex);
                MessageBox.Show(this, (string)ht["Text72"] + ex.Message, (string)ht["Text9"]);
            }
        }

        private void btnLock_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                if (InOperation)
                {
                    StopOperation = true;
                    CloseOperationThread();
                    reader.ISO.InventoryStop(s_usStopInventoryTimeout);
                    epcbtnLock.Text = (string)ht["Text73"];
                    EnabledButton(true);
                    return;
                }

                byte area;
                if (epcrdbLKillPwd.Checked)
                    area = 0;
                else if (epcrdbLAccPwd.Checked)
                    area = 1;
                else if (epcrdbLUii.Checked)
                    area = 2;
                else if (epcrdbLTid.Checked)
                    area = 3;
                else if (epcrdbLUser.Checked)
                    area = 4;
                else
                    throw new Exception((string)ht["Text58"]);

                byte action;
                if (epcrdbLOpen.Checked)
                    action = 0;
                else if (epcrdbLLock.Checked)
                    action = 2;
                else if (epcrdbLPOpen.Checked)
                    action = 1;
                else if (epcrdbLPLock.Checked)
                    action = 3;
                else
                    throw new Exception((string)ht["Text85"]);

                string pwd = txbLPwd.Text.Trim();
                if (pwd.Length == 0)
                    throw new Exception((string)ht["Text86"]);
                byte[] pwd2 = Util.HexArrayFromString(pwd);
                if (pwd2.Length != 4)
                    throw new Exception((string)ht["Text87"]);

                // 先清除数据
                lsvTags.Items.Clear();
                lock (m_tags) { m_tags.Clear(); }

                // 保存操作参数
                m_arrPwd = pwd2;
                m_btLockArea = area;
                m_btLockAction = action;
                WriteLog(MessageType.Info, (string)ht["Text88"], null);

                m_thOperation = new Thread(LockTagThread);
                EnabledButton(false);
                epcbtnLock.Enabled = true;
                epcbtnLock.Text = (string)ht["Text89"];
                InOperation = true;
                StopOperation = false;
                m_thOperation.Start();
            }
            catch (Exception ex)
            {
                epcbtnLock.Text = (string)ht["Text73"];
                EnabledButton(true);
                WriteLog(MessageType.Error, (string)ht["Text90"], ex);
                MessageBox.Show(this, (string)ht["Text90"] + ex.Message, (string)ht["Text9"]);
            }
        }

        private void btnKillTag_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                if (InOperation)
                {
                    StopOperation = true;
                    CloseOperationThread();
                    reader.ISO.InventoryStop(s_usStopInventoryTimeout);
                    epcbtnKillTag.Text = (string)ht["Text74"];
                    EnabledButton(true);
                    return;
                }

                string pwd = txbKillPwd.Text.Trim();
                if (pwd.Length == 0)
                    throw new Exception((string)ht["Text75"]);
                byte[] pwd2 = Util.HexArrayFromString(pwd);
                if (pwd2.Length != 4)
                    throw new Exception((string)ht["Text76"]);

                if (MessageBox.Show(this, (string)ht["Text77"],
                    (string)ht["Text74"], MessageBoxButtons.YesNo) != DialogResult.Yes)
                    return;

                // 先清除数据
                lsvTags.Items.Clear();
                lock (m_tags) { m_tags.Clear(); }

                // 保存操作参数
                m_arrPwd = pwd2;
                WriteLog(MessageType.Info, (string)ht["Text78"], null);

                m_thOperation = new Thread(KillTagThread);
                EnabledButton(false);
                epcbtnKillTag.Enabled = true;
                epcbtnKillTag.Text = (string)ht["Text79"];
                InOperation = true;
                StopOperation = false;
                m_thOperation.Start();
            }
            catch (Exception ex)
            {
                epcbtnKillTag.Text = (string)ht["Text74"];
                EnabledButton(true);
                WriteLog(MessageType.Error, (string)ht["Text80"], ex);
                MessageBox.Show(this, (string)ht["Text80"] + ex.Message, (string)ht["Text9"]);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                lsvTags.Items.Clear();
                lock (m_tags) { m_tags.Clear(); }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, (string)ht["Text9"]);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (sfd.ShowDialog(this) == DialogResult.OK)
                    SaveTags(sfd.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void textBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (m_bChangeText)
                    return;
                TextBox txb = sender as TextBox;
                if (txb == null)
                    return;
                m_bChangeText = true;

                FormatText(txb);

                m_bChangeText = false;
            }
            catch (Exception ex)
            {
                m_bChangeText = false;
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void textBox_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (m_bChangeText)
                    return;
                TextBox txb = sender as TextBox;
                if (txb == null || txb.SelectionLength > 0)
                    return;
                m_bChangeText = true;

                if (e.KeyCode == Keys.Delete)
                {
                    int pos = txb.SelectionStart;
                    if (pos + 1 < txb.TextLength && txb.Text[pos] == ' ')
                    {
                        e.Handled = true;
                        txb.Text = txb.Text.Remove(pos + 1, 1);
                        txb.SelectionStart = pos;
                        //FormatText(txb);
                    }
                }
                else if (e.KeyCode == Keys.Back)
                {
                    int pos = txb.SelectionStart;
                    if (pos > 1 && pos <= txb.TextLength && txb.Text[pos - 1] == ' ')
                    {
                        e.Handled = true;
                        txb.Text = txb.Text.Remove(pos - 2, 1);
                        txb.SelectionStart = pos - 1;
                        //FormatText(txb);
                    }
                }

                m_bChangeText = false;
            }
            catch (Exception ex)
            {
                m_bChangeText = false;
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void FormatText(TextBox txb)
        {
            string text = txb.Text;
            bool needFormat = false;
            for (int i = 0, l = 0; i < text.Length; i++)
            {
                int j = 0;
                for (; j < s_arrSplit.Length && s_arrSplit[j] != text[i]; j++) ;
                if (j >= s_arrSplit.Length)
                {
                    l++;
                    if (l > 2)
                    {
                        needFormat = true;
                        break;
                    }
                }
                else
                    l = 0;
            }
            if (needFormat)
            {
                if (txb.SelectionLength > 0)
                {
                    int pos = int.MaxValue;
                    text = Util.FormatHexString(text, ref pos);
                    txb.Text = text;
                    txb.SelectionStart = text.Length;
                    txb.SelectionLength = 0;
                }
                else
                {
                    int pos = txb.SelectionStart;
                    txb.Text = Util.FormatHexString(text, ref pos);
                    txb.SelectionStart = pos;
                    txb.SelectionLength = 0;
                }
            }
        }

        private void EnabledButton(bool enable)
        {
            try
            {
                epcbtnRead.Enabled = enable;
                epcbtnWrite.Enabled = enable;
                epcbtnLock.Enabled = enable;
                epcbtnKillTag.Enabled = enable;
            }
            catch { }
        }

        private void CloseOperationThread()
        {
            try
            {
                StopOperation = true;
                if (!m_thOperation.Join(4000))
                {
                    InOperation = false;
                    m_thOperation.Abort();
                }
            }
            catch { }
        }

        private void OnOperationEnd()
        {
            InOperation = false;
            StopOperation = true;
            EnabledButton(true);
            epcbtnRead.Text = (string)ht["Text57"];
            epcbtnWrite.Text = (string)ht["Text67"];
            epcbtnLock.Text = (string)ht["Text73"];
            epcbtnKillTag.Text = (string)ht["Text74"];

            WriteLog(MessageType.Info, (string)ht["Text81"], null);
        }

        /// <summary>
        /// 读标签线程主函数
        /// </summary>
        private void ReadTagThread()
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                {
                    DoStopOperation();
                    return;
                }
                ShowTagItem tag = m_tagItem;
                // 选择标签
                if (tag != null && tag.Code.Length < 32)
                    reader.ISO.SetSelectMask(0, (byte)(tag.Code.Length * 8), tag.Code);
                else
                    reader.ISO.SetSelectMask(0, (byte)0, Util.EmptyArray);
                // 执行读标签
                reader.ISO.ReadTag(m_arrPwd, m_membank, m_usWordPtr, m_usWordCount);

                byte btWordsCount;
                byte[] arrData = new byte[256];
                while (!StopOperation)
                {
                    TagRespItem item;
                    try
                    {
                        item = reader.ISO.GetReadResp(out btWordsCount, arrData, 1000);
                    }
                    catch (ReaderException ex)
                    {
                        if (ex.ErrorCode == ReaderException.ERROR_CMD_COMM_TIMEOUT ||
                            ex.ErrorCode == ReaderException.ERROR_CMD_RESP_FORMAT_ERROR)
                        {
                            if (this.m_owner != null && this.m_owner.IsClosed)
                            {
                                DoStopOperation();
                                return;
                            }
                            continue;
                        }
                        throw ex;
                    }
                    if (item == null)
                        break;
                    if (item.Antenna == 0 || item.Antenna > 4)
                        continue;

                    ShowTagResp sitem;
                    lock (m_tags)
                    {
                        RespKey key = new RespKey(1, item.Code);
                        if (m_tags.TryGetValue(key, out sitem))
                            sitem.IncCount(item, btWordsCount, arrData);
                        else
                        {
                            sitem = new ShowTagResp(1, item, btWordsCount, arrData);
                            m_tags.Add(key, sitem);
                        }
                    }
                    ShowTagResp1(sitem);
                }
                this.BeginInvoke(new ThreadStart(OnOperationEnd));
            }
            catch (Exception ex)
            {
                try
                {
                    WriteLog(MessageType.Error, (string)ht["Text82"], ex);
                }
                catch { }
                DoStopOperation();
            }
        }

        /// <summary>
        /// 写标签线程主函数
        /// </summary>
        private void WriteTagThread()
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                {
                    DoStopOperation();
                    return;
                }
                ShowTagItem tag = m_tagItem;
                // 选择标签
                if (tag != null && tag.Code.Length < 32)
                    reader.ISO.SetSelectMask(0, (byte)(tag.Code.Length * 8), tag.Code);
                else
                    reader.ISO.SetSelectMask(0, (byte)0, Util.EmptyArray);
                // 执行写标签
                reader.ISO.WriteTag(m_arrPwd, m_membank, m_usWordPtr, m_arrWrittenData);

                while (!StopOperation)
                {
                    TagRespItem item;
                    try
                    {
                        item = reader.ISO.GetWriteResp(1000);
                    }
                    catch (ReaderException ex)
                    {
                        if (ex.ErrorCode == ReaderException.ERROR_CMD_COMM_TIMEOUT ||
                            ex.ErrorCode == ReaderException.ERROR_CMD_RESP_FORMAT_ERROR)
                        {
                            if (this.m_owner != null && this.m_owner.IsClosed)
                            {
                                DoStopOperation();
                                return;
                            }
                            continue;
                        }
                        throw ex;
                    }
                    if (item == null)
                        break;
                    if (item.Antenna == 0 || item.Antenna > 4)
                        continue;

                    ShowTagResp sitem;
                    lock (m_tags)
                    {
                        RespKey key = new RespKey(2, item.Code);
                        if (m_tags.TryGetValue(key, out sitem))
                            sitem.IncCount(item);
                        else
                        {
                            sitem = new ShowTagResp(2, item);
                            m_tags.Add(key, sitem);
                        }
                    }
                    ShowTagResp2(sitem);
                }
                this.BeginInvoke(new ThreadStart(OnOperationEnd));
            }
            catch (Exception ex)
            {
                try
                {
                    WriteLog(MessageType.Error, (string)ht["Text82"], ex);
                }
                catch { }
                DoStopOperation();
            }
        }

        /// <summary>
        /// 锁定标签线程主函数
        /// </summary>
        private void LockTagThread()
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                {
                    DoStopOperation();
                    return;
                }
                ShowTagItem tag = m_tagItem;
                // 选择标签
                if (tag != null && tag.Code.Length < 32)
                    reader.ISO.SetSelectMask(0, (byte)(tag.Code.Length * 8), tag.Code);
                else
                    reader.ISO.SetSelectMask(0, (byte)0, Util.EmptyArray);
                // 执行锁定标签
                reader.ISO.LockTag(m_arrPwd, m_btLockArea, m_btLockAction);

                while (!StopOperation)
                {
                    TagRespItem item;
                    try
                    {
                        item = reader.ISO.GetLockResp(1000);
                    }
                    catch (ReaderException ex)
                    {
                        if (ex.ErrorCode == ReaderException.ERROR_CMD_COMM_TIMEOUT ||
                            ex.ErrorCode == ReaderException.ERROR_CMD_RESP_FORMAT_ERROR)
                        {
                            if (this.m_owner != null && this.m_owner.IsClosed)
                            {
                                DoStopOperation();
                                return;
                            }
                            continue;
                        }
                        throw ex;
                    }
                    if (item == null)
                        break;
                    if (item.Antenna == 0 || item.Antenna > 4)
                        continue;

                    ShowTagResp sitem;
                    lock (m_tags)
                    {
                        RespKey key = new RespKey(4, item.Code);
                        if (m_tags.TryGetValue(key, out sitem))
                            sitem.IncCount(item);
                        else
                        {
                            sitem = new ShowTagResp(4, item);
                            m_tags.Add(key, sitem);
                        }
                    }
                    ShowTagResp2(sitem);
                }
                this.BeginInvoke(new ThreadStart(OnOperationEnd));
            }
            catch (Exception ex)
            {
                try
                {
                    WriteLog(MessageType.Error, (string)ht["Text82"], ex);
                }
                catch { }
                DoStopOperation();
            }
        }

        /// <summary>
        /// 灭活标签线程主函数
        /// </summary>
        private void KillTagThread()
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                {
                    DoStopOperation();
                    return;
                }
                ShowTagItem tag = m_tagItem;
                // 选择标签
                if (tag != null && tag.Code.Length < 32)
                    reader.ISO.SetSelectMask(0, (byte)(tag.Code.Length * 8), tag.Code);
                else
                    reader.ISO.SetSelectMask(0, (byte)0, Util.EmptyArray);
                // 执行灭活标签
                reader.ISO.KillTag(m_arrPwd);

                while (!StopOperation)
                {
                    TagRespItem item;
                    try
                    {
                        item = reader.ISO.GetKillResp(1000);
                    }
                    catch (ReaderException ex)
                    {
                        if (ex.ErrorCode == ReaderException.ERROR_CMD_COMM_TIMEOUT ||
                            ex.ErrorCode == ReaderException.ERROR_CMD_RESP_FORMAT_ERROR)
                        {
                            if (this.m_owner != null && this.m_owner.IsClosed)
                            {
                                DoStopOperation();
                                return;
                            }
                            continue;
                        }
                        throw ex;
                    }
                    if (item == null)
                        break;
                    if (item.Antenna == 0 || item.Antenna > 4)
                        continue;

                    ShowTagResp sitem;
                    lock (m_tags)
                    {
                        RespKey key = new RespKey(5, item.Code);
                        if (m_tags.TryGetValue(key, out sitem))
                            sitem.IncCount(item);
                        else
                        {
                            sitem = new ShowTagResp(5, item);
                            m_tags.Add(key, sitem);
                        }
                    }
                    ShowTagResp2(sitem);
                }
                this.BeginInvoke(new ThreadStart(OnOperationEnd));
            }
            catch (Exception ex)
            {
                try
                {
                    WriteLog(MessageType.Error, (string)ht["Text82"], ex);
                }
                catch { }
                DoStopOperation();
            }
        }

        private void DoStopOperation()
        {
            try
            {
                InOperation = false;
                StopOperation = true;
                try
                {
                    Reader reader = this.Reader;
                    if (reader != null)
                        reader.ISO.InventoryStop(s_usStopInventoryTimeout);
                }
                catch (Exception) { };
            }
            catch { }
            try
            {
                this.BeginInvoke(new ThreadStart(OnOperationEnd));
            }
            catch { }
        }

        private delegate void ShowTagRespHandler(ShowTagResp item);

        private void ShowTagResp1(ShowTagResp item)
        {
            try
            {
                if (this.InvokeRequired)
                {
                    // 显示标签
                    this.BeginInvoke(new ShowTagRespHandler(ShowTagResp1), item);
                    return;
                }
                if (item.TagStatus != 0xFF)
                {
                    WriteLog(MessageType.Error, (string)ht["Text84"] + item.TagStatus.ToString("X2"), null);
                    return;
                }
                ListViewItem lvItem = item.ListViewItem;
                if (lvItem != null)
                {
                    lvItem.SubItems[1].Text = Util.HexArrayToString(item.PC);
                    lvItem.SubItems[2].Text = Util.HexArrayToString(item.CRC);
                    lvItem.SubItems[4].Text = (item.Data.Length >> 1).ToString();
                    if (m_bTempsen && item.Data.Length == 2)
                        lvItem.SubItems[5].Text = ((short)((item.Data[0] << 8) + item.Data[1]) / 10.0f).ToString("F1");
                    else
                        lvItem.SubItems[5].Text = Util.HexArrayToString(item.Data);
                    lvItem.SubItems[6].Text = item.Antenna.ToString();
                    lvItem.SubItems[7].Text = item.Count.ToString();
                }
                else
                {
                    lvItem = lsvTags.Items.Add((lsvTags.Items.Count + 1).ToString());
                    item.ListViewItem = lvItem;
                    lvItem.SubItems.Add(Util.HexArrayToString(item.PC));
                    lvItem.SubItems.Add(Util.HexArrayToString(item.CRC));
                    lvItem.SubItems.Add(Util.HexArrayToString(item.Code));
                    lvItem.SubItems.Add((item.Data.Length >> 1).ToString());
                    if (m_bTempsen && item.Data.Length == 2)
                        lvItem.SubItems.Add(((short)((item.Data[0] << 8) + item.Data[1]) / 10.0f).ToString("F1"));
                    else
                        lvItem.SubItems.Add(Util.HexArrayToString(item.Data));
                    lvItem.SubItems.Add(item.Antenna.ToString());
                    lvItem.SubItems.Add(item.Count.ToString());
                }
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text83"], ex);
            }
        }

        private void ShowTagResp2(ShowTagResp item)
        {
            try
            {
                if (this.InvokeRequired)
                {
                    // 显示标签
                    this.BeginInvoke(new ShowTagRespHandler(ShowTagResp2), item);
                    return;
                }
                if (item.TagStatus != 0xFF)
                {
                    WriteLog(MessageType.Error, (string)ht["Text84"] + item.TagStatus.ToString("X2"), null);
                    return;
                }
                ListViewItem lvItem = item.ListViewItem;
                if (lvItem != null)
                {
                    lvItem.SubItems[1].Text = Util.HexArrayToString(item.PC);
                    lvItem.SubItems[2].Text = Util.HexArrayToString(item.CRC);
                    lvItem.SubItems[6].Text = item.Antenna.ToString();
                    lvItem.SubItems[7].Text = item.Count.ToString();
                }
                else
                {
                    lvItem = lsvTags.Items.Add((lsvTags.Items.Count + 1).ToString());
                    item.ListViewItem = lvItem;
                    lvItem.SubItems.Add(Util.HexArrayToString(item.PC));
                    lvItem.SubItems.Add(Util.HexArrayToString(item.CRC));
                    lvItem.SubItems.Add(Util.HexArrayToString(item.Code));
                    lvItem.SubItems.Add(string.Empty);
                    lvItem.SubItems.Add(string.Empty);
                    lvItem.SubItems.Add(item.Antenna.ToString());
                    lvItem.SubItems.Add(item.Count.ToString());
                }
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text83"], ex);
            }
        }

        private void SaveTags(string fileName)
        {
            StringBuilder sb = new StringBuilder(128);
            foreach (ColumnHeader item in lsvTags.Columns)
            {
                sb.Append(item.Text);
                sb.Append(',');
            }
            if (sb.Length > 0)
                sb.Length -= 1;
            using (TextWriter tw = new StreamWriter(fileName, false, Encoding.Default))
            {
                tw.WriteLine(sb.ToString());

                for (int i = 0; i < lsvTags.Items.Count; i++)
                {
                    sb.Length = 0;
                    foreach (ListViewItem.ListViewSubItem item in lsvTags.Items[i].SubItems)
                    {
                        sb.Append(item.Text);
                        sb.Append(',');
                    }
                    if (sb.Length > 0)
                    {
                        sb.Length -= 1;
                        tw.WriteLine(sb.ToString());
                    }
                }
            }
        }

        internal void SetOwner(RFPanel owner)
        {
            m_owner = owner;
        }

        public void WriteLog(MessageType type, string msg, Exception ex)
        {
            if (m_owner != null)
                m_owner.WriteLog(type, msg, ex);
        }

        private void ckbSelTag_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (!epcckbSelTag.Checked)
                {
                    txbCode.Clear();
                    m_tagItem = null;
                }
                else
                {
                    m_tagItem = cmbTags.SelectedItem as ShowTagItem;
                    if (m_tagItem != null)
                        txbCode.Text = Util.HexArrayToString(m_tagItem.Code);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void cmbTags_DropDown(object sender, EventArgs e)
        {
            try
            {
                if (m_owner != null && m_owner.m_iInventoryDataVersion != m_iInventoryDataVersion)
                {
                    cmbTags.Items.Clear();
                    cmbTags.Items.AddRange(m_owner.TagItems);
                    m_iInventoryDataVersion = m_owner.m_iInventoryDataVersion;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnSelectTag_Click(object sender, EventArgs e)
        {
            try
            {
                ShowTagItem item = cmbTags.SelectedItem as ShowTagItem;
                if (item == null)
                    return;
                if (epcckbSelTag.Checked)
                    m_tagItem = item;
                txbCode.Text = Util.HexArrayToString(item.Code);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }
    }
}
