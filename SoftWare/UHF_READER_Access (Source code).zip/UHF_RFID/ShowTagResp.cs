﻿using System;
using System.Collections.Generic;
using System.Text;
using UHF_RFID_Net;
using System.Windows.Forms;

namespace YYF100
{
    /// <summary>
    /// 操作响应数据项
    /// </summary>
    public class ShowTagResp
    {
        private static readonly byte[] s_arrEmpty = new byte[0];

        /// <summary>
        /// 响应类型，
        /// 1：读标签响应；2：写标签响应；3：擦除标签响应；4：锁定标签响应：5：灭活标签响应
        /// </summary>
        private byte m_type;
        /// <summary>
        /// 被盘点到的次数
        /// </summary>
        private int m_count;

        /// <summary>
        /// 标签状态
        /// </summary>
        private byte m_tagStatus;
        /// <summary>
        /// 标签的PC或编码长度+编码头数据
        /// </summary>
        private byte[] m_pc;
        /// <summary>
        /// 标签的UII或编码数据
        /// </summary>
        private byte[] m_code;
        /// <summary>
        /// 盘点到该标签的天线，值范围：1~4
        /// </summary>
        private byte m_ant;
        /// <summary>
        /// CRC
        /// </summary>
        private byte[] m_crc;
        /// <summary>
        /// 读取到的数据长度
        /// </summary>
        private byte[] m_data;
        /// <summary>
        /// 该数据项显示的ListViewItem
        /// </summary>
        private ListViewItem m_lvItem = null;

        /// <summary>
        /// 响应类型，
        /// 1：读标签响应；2：写标签响应；3：擦除标签响应；4：锁定标签响应：5：灭活标签响应
        /// </summary>
        public byte RespType
        {
            get { return m_type; }
        }

        /// <summary>
        /// 标签状态
        /// </summary>
        public byte TagStatus
        {
            get { return m_tagStatus; }
        }

        /// <summary>
        /// 标签的PC或编码长度+编码头数据
        /// </summary>
        public byte[] PC
        {
            get { return m_pc; }
        }

        /// <summary>
        /// 标签的UII或编码数据
        /// </summary>
        public byte[] Code
        {
            get { return m_code; }
        }

        /// <summary>
        /// 盘点到该标签的天线，值范围：1~4
        /// </summary>
        public byte Antenna
        {
            get { return m_ant; }
        }

        /// <summary>
        /// CRC
        /// </summary>
        public byte[] CRC
        {
            get { return m_crc; }
        }

        /// <summary>
        /// 读取到的数据长度
        /// </summary>
        public byte[] Data
        {
            get { return m_data; }
        }

        /// <summary>
        /// 被盘点到的次数
        /// </summary>
        public int Count
        {
            get { return m_count; }
        }

        /// <summary>
        /// 该数据项显示的ListViewItem
        /// </summary>
        public ListViewItem ListViewItem
        {
            get { return m_lvItem; }
            set { m_lvItem = value; }
        }

        public ShowTagResp(byte type, TagRespItem item)
        {
            if (item.Code == null)
                throw new ArgumentNullException("item.Code");
            if (item.Antenna == 0 || item.Antenna > 4)
                throw new ArgumentOutOfRangeException("item.Antenna");

            m_type = type;
            m_count = 1;
            m_tagStatus = item.TagStatus;
            m_pc = item.PC;
            m_code = item.Code;
            m_ant = item.Antenna;
            m_crc = item.CRC;
        }

        public ShowTagResp(byte type, TagRespItem item, ushort wordsCount, byte[] data)
        {
            if (item.Code == null)
                throw new ArgumentNullException("item.Code");
            if (item.Antenna == 0 || item.Antenna > 4)
                throw new ArgumentOutOfRangeException("item.Antenna");

            m_type = type;
            m_count = 1;
            m_tagStatus = item.TagStatus;
            m_pc = item.PC;
            m_code = item.Code;
            m_ant = item.Antenna;
            m_crc = item.CRC;

            if (wordsCount > 0)
            {
                m_data = new byte[wordsCount << 1];
                Array.Copy(data, m_data, m_data.Length);
            }
            else
                m_data = s_arrEmpty;
        }

        public ShowTagResp(byte type, byte tagStatus, byte[] pc, byte[] code, byte ant, byte[] crc, byte[] data)
        {
            if (pc == null)
                throw new ArgumentNullException("pc");
            if (pc.Length != 2)
                throw new ArgumentException("pc长度必须是两字节");
            if (code == null)
                throw new ArgumentNullException("code");
            if (ant == 0 || ant > 4)
                throw new ArgumentOutOfRangeException("channel");

            m_type = type;
            m_count = 1;
            m_tagStatus = tagStatus;
            m_pc = pc;
            m_ant = ant;
            m_crc = crc;
            m_code = code;
            m_data = data;
        }

        public void IncCount(TagRespItem item, ushort wordsCount, byte[] data)
        {
            m_count++;
            m_tagStatus = item.TagStatus;
            m_pc = item.PC;
            m_ant = item.Antenna;
            m_crc = item.CRC;

            if (wordsCount > 0)
            {
                m_data = new byte[wordsCount << 1];
                Array.Copy(data, m_data, m_data.Length);
            }
            else
                m_data = s_arrEmpty;
        }

        public void IncCount(TagRespItem item)
        {
            m_count++;
            m_tagStatus = item.TagStatus;
            m_pc = item.PC;
            m_ant = item.Antenna;
            m_crc = item.CRC;
        }

        public bool CompareCode(byte[] code)
        {
            if (code == null)
                return false;
            if (m_code == code)
                return true;
            if (m_code.Length != code.Length)
                return false;
            for (int i = 0; i < code.Length; i++)
            {
                if (m_code[i] != code[i])
                    return false;
            }
            return true;
        }

        public override string ToString()
        {
            return Util.HexArrayToString(m_code);
        }
    }

    struct RespKey
    {
        private byte m_type;
        private byte[] m_code;

        public byte RespType
        {
            get { return m_type; }
        }

        public byte[] Code
        {
            get { return m_code; }
        }

        public RespKey(byte type, byte[] code)
        {
            m_type = type;
            m_code = code;
        }
    }

    class RespKeyCompare : IEqualityComparer<RespKey>
    {
        public bool Equals(RespKey x, RespKey y)
        {
            if (x.RespType != y.RespType)
                return false;
            if (x.Code == y.Code)
                return true;
            if (x.Code == null || y.Code == null)
                return false;

            if (x.Code.Length != y.Code.Length)
                return false;
            for (int i = 0; i < x.Code.Length; i++)
            {
                if (x.Code[i] != y.Code[i])
                    return false;
            }
            return true;
        }

        public int GetHashCode(RespKey obj)
        {
            if (obj.Code == null)
                return 0;
            if (obj.Code.Length == 0)
                return 0;
            int hash = obj.RespType;
            for (int i = 0; i < obj.Code.Length; i++)
            {
                hash = (hash << 1) + obj.Code[i];
            }
            return hash;
        }
    }
}
