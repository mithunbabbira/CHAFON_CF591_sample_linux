namespace YYF100
{
    partial class InventoryPanel
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.lblinvsum = new System.Windows.Forms.Label();
            this.lblInvCount = new System.Windows.Forms.Label();
            this.invlabel20 = new System.Windows.Forms.Label();
            this.invlabel25 = new System.Windows.Forms.Label();
            this.lblInvRate1 = new System.Windows.Forms.Label();
            this.lblInvTime1 = new System.Windows.Forms.Label();
            this.invlabel26 = new System.Windows.Forms.Label();
            this.invlabel27 = new System.Windows.Forms.Label();
            this.lblInvTotalCount1 = new System.Windows.Forms.Label();
            this.lblInvTotalTime1 = new System.Windows.Forms.Label();
            this.btnInventory = new System.Windows.Forms.Button();
            this.lsvTags = new System.Windows.Forms.ListView();
            this.colNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCodeLen = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colRssi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCw = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnFirstPage = new System.Windows.Forms.Button();
            this.btnPrevPage = new System.Windows.Forms.Button();
            this.btnNextPage = new System.Windows.Forms.Button();
            this.btnLastPage = new System.Windows.Forms.Button();
            this.rdbScene1 = new System.Windows.Forms.RadioButton();
            this.txbInvTime = new System.Windows.Forms.TextBox();
            this.txbPageLines = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.rdbScene0 = new System.Windows.Forms.RadioButton();
            this.lblUnit1 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.sfd = new System.Windows.Forms.SaveFileDialog();
            this.lblUnit2 = new System.Windows.Forms.Label();
            this.rdbScene2 = new System.Windows.Forms.RadioButton();
            this.txbInvCount = new System.Windows.Forms.TextBox();
            this.btnISOSelect = new System.Windows.Forms.Button();
            this.rdbScene4 = new System.Windows.Forms.RadioButton();
            this.lblUnit4 = new System.Windows.Forms.Label();
            this.txb_userTime = new System.Windows.Forms.TextBox();
            this.cmbSession = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.cmbQvalue = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.tbxAnswerTime = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lblInvTotalTime = new System.Windows.Forms.TextBox();
            this.lblInvTotalCount = new System.Windows.Forms.TextBox();
            this.lblInvTime = new System.Windows.Forms.TextBox();
            this.lblInvRate = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.invlabel138 = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.label32 = new System.Windows.Forms.Label();
            this.cmbInventoryArea = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.tbxInventoryStartAddr = new System.Windows.Forms.TextBox();
            this.tbxInventoryDataLen = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.invlabel8 = new System.Windows.Forms.Label();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblinvsum
            // 
            this.lblinvsum.AutoSize = true;
            this.lblinvsum.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblinvsum.ForeColor = System.Drawing.Color.DarkViolet;
            this.lblinvsum.Location = new System.Drawing.Point(22, 28);
            this.lblinvsum.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblinvsum.Name = "lblinvsum";
            this.lblinvsum.Size = new System.Drawing.Size(109, 20);
            this.lblinvsum.TabIndex = 0;
            this.lblinvsum.Text = "询查总数：";
            // 
            // lblInvCount
            // 
            this.lblInvCount.AutoSize = true;
            this.lblInvCount.Font = new System.Drawing.Font("微软雅黑", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblInvCount.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.lblInvCount.Location = new System.Drawing.Point(156, 8);
            this.lblInvCount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInvCount.Name = "lblInvCount";
            this.lblInvCount.Size = new System.Drawing.Size(160, 58);
            this.lblInvCount.TabIndex = 1;
            this.lblInvCount.Text = "00000";
            // 
            // invlabel20
            // 
            this.invlabel20.AutoSize = true;
            this.invlabel20.ForeColor = System.Drawing.Color.DarkMagenta;
            this.invlabel20.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.invlabel20.Location = new System.Drawing.Point(51, 22);
            this.invlabel20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.invlabel20.Name = "invlabel20";
            this.invlabel20.Size = new System.Drawing.Size(82, 15);
            this.invlabel20.TabIndex = 2;
            this.invlabel20.Text = "识别速度：";
            this.invlabel20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // invlabel25
            // 
            this.invlabel25.AutoSize = true;
            this.invlabel25.ForeColor = System.Drawing.Color.DarkMagenta;
            this.invlabel25.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.invlabel25.Location = new System.Drawing.Point(51, 55);
            this.invlabel25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.invlabel25.Name = "invlabel25";
            this.invlabel25.Size = new System.Drawing.Size(82, 15);
            this.invlabel25.TabIndex = 4;
            this.invlabel25.Text = "识别时间：";
            // 
            // lblInvRate1
            // 
            this.lblInvRate1.AutoSize = true;
            this.lblInvRate1.Location = new System.Drawing.Point(163, 35);
            this.lblInvRate1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInvRate1.Name = "lblInvRate1";
            this.lblInvRate1.Size = new System.Drawing.Size(31, 15);
            this.lblInvRate1.TabIndex = 3;
            this.lblInvRate1.Text = "000";
            this.lblInvRate1.Visible = false;
            // 
            // lblInvTime1
            // 
            this.lblInvTime1.AutoSize = true;
            this.lblInvTime1.Location = new System.Drawing.Point(163, 60);
            this.lblInvTime1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInvTime1.Name = "lblInvTime1";
            this.lblInvTime1.Size = new System.Drawing.Size(31, 15);
            this.lblInvTime1.TabIndex = 5;
            this.lblInvTime1.Text = "000";
            this.lblInvTime1.Visible = false;
            // 
            // invlabel26
            // 
            this.invlabel26.AutoSize = true;
            this.invlabel26.ForeColor = System.Drawing.Color.DarkMagenta;
            this.invlabel26.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.invlabel26.Location = new System.Drawing.Point(51, 88);
            this.invlabel26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.invlabel26.Name = "invlabel26";
            this.invlabel26.Size = new System.Drawing.Size(82, 15);
            this.invlabel26.TabIndex = 6;
            this.invlabel26.Text = "累计返回：";
            // 
            // invlabel27
            // 
            this.invlabel27.AutoSize = true;
            this.invlabel27.ForeColor = System.Drawing.Color.DarkMagenta;
            this.invlabel27.Location = new System.Drawing.Point(19, 119);
            this.invlabel27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.invlabel27.Name = "invlabel27";
            this.invlabel27.Size = new System.Drawing.Size(112, 15);
            this.invlabel27.TabIndex = 8;
            this.invlabel27.Text = "累计运行时间：";
            this.invlabel27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblInvTotalCount1
            // 
            this.lblInvTotalCount1.AutoSize = true;
            this.lblInvTotalCount1.Location = new System.Drawing.Point(163, 85);
            this.lblInvTotalCount1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInvTotalCount1.Name = "lblInvTotalCount1";
            this.lblInvTotalCount1.Size = new System.Drawing.Size(87, 15);
            this.lblInvTotalCount1.TabIndex = 7;
            this.lblInvTotalCount1.Text = "0000000000";
            this.lblInvTotalCount1.Visible = false;
            // 
            // lblInvTotalTime1
            // 
            this.lblInvTotalTime1.AutoSize = true;
            this.lblInvTotalTime1.Location = new System.Drawing.Point(163, 110);
            this.lblInvTotalTime1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInvTotalTime1.Name = "lblInvTotalTime1";
            this.lblInvTotalTime1.Size = new System.Drawing.Size(87, 15);
            this.lblInvTotalTime1.TabIndex = 9;
            this.lblInvTotalTime1.Text = "0000000000";
            this.lblInvTotalTime1.Visible = false;
            // 
            // btnInventory
            // 
            this.btnInventory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInventory.Font = new System.Drawing.Font("黑体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnInventory.Location = new System.Drawing.Point(962, 22);
            this.btnInventory.Margin = new System.Windows.Forms.Padding(4);
            this.btnInventory.Name = "btnInventory";
            this.btnInventory.Size = new System.Drawing.Size(120, 81);
            this.btnInventory.TabIndex = 28;
            this.btnInventory.Text = "开始";
            this.btnInventory.UseVisualStyleBackColor = true;
            this.btnInventory.Click += new System.EventHandler(this.btnInventory_Click);
            // 
            // lsvTags
            // 
            this.lsvTags.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lsvTags.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colNum,
            this.colCode,
            this.colCodeLen,
            this.colCount,
            this.colRssi,
            this.colCw});
            this.lsvTags.FullRowSelect = true;
            this.lsvTags.GridLines = true;
            this.lsvTags.HideSelection = false;
            this.lsvTags.Location = new System.Drawing.Point(4, 158);
            this.lsvTags.Margin = new System.Windows.Forms.Padding(4);
            this.lsvTags.Name = "lsvTags";
            this.lsvTags.Size = new System.Drawing.Size(1004, 240);
            this.lsvTags.TabIndex = 29;
            this.lsvTags.UseCompatibleStateImageBehavior = false;
            this.lsvTags.View = System.Windows.Forms.View.Details;
            // 
            // colNum
            // 
            this.colNum.Tag = "colNum";
            this.colNum.Text = "序号";
            this.colNum.Width = 64;
            // 
            // colCode
            // 
            this.colCode.Tag = "colCode";
            this.colCode.Text = "编码";
            this.colCode.Width = 250;
            // 
            // colCodeLen
            // 
            this.colCodeLen.Tag = "colCodeLen";
            this.colCodeLen.Text = "数据长度";
            // 
            // colCount
            // 
            this.colCount.Tag = "colCount";
            this.colCount.Text = "次数(天线1/2/3/4)";
            this.colCount.Width = 190;
            // 
            // colRssi
            // 
            this.colRssi.Tag = "colRssi";
            this.colRssi.Text = "RSSI(dBm)";
            this.colRssi.Width = 100;
            // 
            // colCw
            // 
            this.colCw.Tag = "colCw";
            this.colCw.Text = "信道";
            this.colCw.Width = 64;
            // 
            // btnFirstPage
            // 
            this.btnFirstPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnFirstPage.Location = new System.Drawing.Point(4, 422);
            this.btnFirstPage.Margin = new System.Windows.Forms.Padding(4);
            this.btnFirstPage.Name = "btnFirstPage";
            this.btnFirstPage.Size = new System.Drawing.Size(75, 29);
            this.btnFirstPage.TabIndex = 30;
            this.btnFirstPage.Text = "首页";
            this.btnFirstPage.UseVisualStyleBackColor = true;
            this.btnFirstPage.Click += new System.EventHandler(this.btnFirstPage_Click);
            // 
            // btnPrevPage
            // 
            this.btnPrevPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnPrevPage.Location = new System.Drawing.Point(87, 422);
            this.btnPrevPage.Margin = new System.Windows.Forms.Padding(4);
            this.btnPrevPage.Name = "btnPrevPage";
            this.btnPrevPage.Size = new System.Drawing.Size(81, 29);
            this.btnPrevPage.TabIndex = 31;
            this.btnPrevPage.Text = "上一页";
            this.btnPrevPage.UseVisualStyleBackColor = true;
            this.btnPrevPage.Click += new System.EventHandler(this.btnPrevPage_Click);
            // 
            // btnNextPage
            // 
            this.btnNextPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnNextPage.Location = new System.Drawing.Point(176, 422);
            this.btnNextPage.Margin = new System.Windows.Forms.Padding(4);
            this.btnNextPage.Name = "btnNextPage";
            this.btnNextPage.Size = new System.Drawing.Size(81, 29);
            this.btnNextPage.TabIndex = 32;
            this.btnNextPage.Text = "下一页";
            this.btnNextPage.UseVisualStyleBackColor = true;
            this.btnNextPage.Click += new System.EventHandler(this.btnNextPage_Click);
            // 
            // btnLastPage
            // 
            this.btnLastPage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnLastPage.Location = new System.Drawing.Point(265, 422);
            this.btnLastPage.Margin = new System.Windows.Forms.Padding(4);
            this.btnLastPage.Name = "btnLastPage";
            this.btnLastPage.Size = new System.Drawing.Size(75, 29);
            this.btnLastPage.TabIndex = 33;
            this.btnLastPage.Text = "尾页";
            this.btnLastPage.UseVisualStyleBackColor = true;
            this.btnLastPage.Click += new System.EventHandler(this.btnLastPage_Click);
            // 
            // rdbScene1
            // 
            this.rdbScene1.AutoSize = true;
            this.rdbScene1.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.rdbScene1.Checked = true;
            this.rdbScene1.Location = new System.Drawing.Point(70, 14);
            this.rdbScene1.Margin = new System.Windows.Forms.Padding(4);
            this.rdbScene1.Name = "rdbScene1";
            this.rdbScene1.Size = new System.Drawing.Size(73, 19);
            this.rdbScene1.TabIndex = 15;
            this.rdbScene1.TabStop = true;
            this.rdbScene1.Text = "按时间";
            this.rdbScene1.UseVisualStyleBackColor = true;
            // 
            // txbInvTime
            // 
            this.txbInvTime.Location = new System.Drawing.Point(163, 11);
            this.txbInvTime.Margin = new System.Windows.Forms.Padding(4);
            this.txbInvTime.Name = "txbInvTime";
            this.txbInvTime.Size = new System.Drawing.Size(81, 25);
            this.txbInvTime.TabIndex = 20;
            this.txbInvTime.Text = "0";
            // 
            // txbPageLines
            // 
            this.txbPageLines.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txbPageLines.Location = new System.Drawing.Point(455, 425);
            this.txbPageLines.Margin = new System.Windows.Forms.Padding(4);
            this.txbPageLines.Name = "txbPageLines";
            this.txbPageLines.Size = new System.Drawing.Size(60, 25);
            this.txbPageLines.TabIndex = 35;
            this.txbPageLines.Text = "30";
            this.txbPageLines.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txbPageLines_KeyDown);
            this.txbPageLines.Leave += new System.EventHandler(this.txbPageLines_Leave);
            // 
            // label37
            // 
            this.label37.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(524, 429);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(22, 15);
            this.label37.TabIndex = 36;
            this.label37.Text = "条";
            // 
            // label36
            // 
            this.label36.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(360, 429);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(82, 15);
            this.label36.TabIndex = 34;
            this.label36.Text = "每页显示：";
            // 
            // rdbScene0
            // 
            this.rdbScene0.AutoSize = true;
            this.rdbScene0.Enabled = false;
            this.rdbScene0.Location = new System.Drawing.Point(1009, 124);
            this.rdbScene0.Margin = new System.Windows.Forms.Padding(4);
            this.rdbScene0.Name = "rdbScene0";
            this.rdbScene0.Size = new System.Drawing.Size(88, 19);
            this.rdbScene0.TabIndex = 14;
            this.rdbScene0.Text = "循环盘点";
            this.rdbScene0.UseVisualStyleBackColor = true;
            this.rdbScene0.Visible = false;
            // 
            // lblUnit1
            // 
            this.lblUnit1.AutoSize = true;
            this.lblUnit1.Location = new System.Drawing.Point(248, 16);
            this.lblUnit1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUnit1.Name = "lblUnit1";
            this.lblUnit1.Size = new System.Drawing.Size(15, 15);
            this.lblUnit1.TabIndex = 37;
            this.lblUnit1.Text = "S";
            // 
            // btnClear
            // 
            this.btnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnClear.Location = new System.Drawing.Point(568, 422);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(117, 29);
            this.btnClear.TabIndex = 39;
            this.btnClear.Text = "清除数据";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.Location = new System.Drawing.Point(693, 422);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 29);
            this.btnSave.TabIndex = 40;
            this.btnSave.Text = "导出数据";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // sfd
            // 
            this.sfd.Filter = "*.txt|*.txt|*.*|*.*";
            // 
            // lblUnit2
            // 
            this.lblUnit2.AutoSize = true;
            this.lblUnit2.Location = new System.Drawing.Point(248, 53);
            this.lblUnit2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUnit2.Name = "lblUnit2";
            this.lblUnit2.Size = new System.Drawing.Size(39, 15);
            this.lblUnit2.TabIndex = 43;
            this.lblUnit2.Text = "Freq";
            // 
            // rdbScene2
            // 
            this.rdbScene2.AutoSize = true;
            this.rdbScene2.Location = new System.Drawing.Point(70, 51);
            this.rdbScene2.Margin = new System.Windows.Forms.Padding(4);
            this.rdbScene2.Name = "rdbScene2";
            this.rdbScene2.Size = new System.Drawing.Size(73, 19);
            this.rdbScene2.TabIndex = 41;
            this.rdbScene2.TabStop = true;
            this.rdbScene2.Text = "按次数";
            this.rdbScene2.UseVisualStyleBackColor = true;
            // 
            // txbInvCount
            // 
            this.txbInvCount.Location = new System.Drawing.Point(163, 48);
            this.txbInvCount.Margin = new System.Windows.Forms.Padding(4);
            this.txbInvCount.Name = "txbInvCount";
            this.txbInvCount.Size = new System.Drawing.Size(81, 25);
            this.txbInvCount.TabIndex = 42;
            this.txbInvCount.Text = "1";
            // 
            // btnISOSelect
            // 
            this.btnISOSelect.Location = new System.Drawing.Point(68, 113);
            this.btnISOSelect.Margin = new System.Windows.Forms.Padding(4);
            this.btnISOSelect.Name = "btnISOSelect";
            this.btnISOSelect.Size = new System.Drawing.Size(155, 29);
            this.btnISOSelect.TabIndex = 46;
            this.btnISOSelect.Text = "自定义参数设置";
            this.btnISOSelect.UseVisualStyleBackColor = true;
            this.btnISOSelect.Click += new System.EventHandler(this.btnISOSelect_Click);
            // 
            // rdbScene4
            // 
            this.rdbScene4.AutoSize = true;
            this.rdbScene4.Location = new System.Drawing.Point(69, 88);
            this.rdbScene4.Margin = new System.Windows.Forms.Padding(4);
            this.rdbScene4.Name = "rdbScene4";
            this.rdbScene4.Size = new System.Drawing.Size(73, 19);
            this.rdbScene4.TabIndex = 45;
            this.rdbScene4.TabStop = true;
            this.rdbScene4.Text = "自定义";
            this.rdbScene4.UseVisualStyleBackColor = true;
            // 
            // lblUnit4
            // 
            this.lblUnit4.AutoSize = true;
            this.lblUnit4.Location = new System.Drawing.Point(248, 90);
            this.lblUnit4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUnit4.Name = "lblUnit4";
            this.lblUnit4.Size = new System.Drawing.Size(15, 15);
            this.lblUnit4.TabIndex = 48;
            this.lblUnit4.Text = "S";
            this.lblUnit4.Click += new System.EventHandler(this.lblUnit4_Click);
            // 
            // txb_userTime
            // 
            this.txb_userTime.Location = new System.Drawing.Point(163, 85);
            this.txb_userTime.Margin = new System.Windows.Forms.Padding(4);
            this.txb_userTime.MaxLength = 3;
            this.txb_userTime.Name = "txb_userTime";
            this.txb_userTime.Size = new System.Drawing.Size(81, 25);
            this.txb_userTime.TabIndex = 47;
            this.txb_userTime.Text = "10";
            // 
            // cmbSession
            // 
            this.cmbSession.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSession.FormattingEnabled = true;
            this.cmbSession.Items.AddRange(new object[] {
            "S0",
            "S1",
            "S2",
            "S3"});
            this.cmbSession.Location = new System.Drawing.Point(222, 56);
            this.cmbSession.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSession.Name = "cmbSession";
            this.cmbSession.Size = new System.Drawing.Size(69, 23);
            this.cmbSession.TabIndex = 54;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(132, 60);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(78, 15);
            this.label34.TabIndex = 53;
            this.label34.Text = "Session：";
            // 
            // cmbQvalue
            // 
            this.cmbQvalue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQvalue.FormattingEnabled = true;
            this.cmbQvalue.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cmbQvalue.Location = new System.Drawing.Point(222, 21);
            this.cmbQvalue.Margin = new System.Windows.Forms.Padding(4);
            this.cmbQvalue.Name = "cmbQvalue";
            this.cmbQvalue.Size = new System.Drawing.Size(69, 23);
            this.cmbQvalue.TabIndex = 52;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(165, 25);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(45, 15);
            this.label33.TabIndex = 51;
            this.label33.Text = "Q值：";
            // 
            // tbxAnswerTime
            // 
            this.tbxAnswerTime.Location = new System.Drawing.Point(222, 92);
            this.tbxAnswerTime.MaxLength = 3;
            this.tbxAnswerTime.Name = "tbxAnswerTime";
            this.tbxAnswerTime.Size = new System.Drawing.Size(70, 25);
            this.tbxAnswerTime.TabIndex = 56;
            this.tbxAnswerTime.Text = "00";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(28, 97);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(182, 15);
            this.label35.TabIndex = 55;
            this.label35.Text = "询查间隔时间（&*10ms）：";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(6, 24);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lblinvsum);
            this.splitContainer1.Panel1.Controls.Add(this.lblInvCount);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.lblInvTotalTime);
            this.splitContainer1.Panel2.Controls.Add(this.invlabel26);
            this.splitContainer1.Panel2.Controls.Add(this.invlabel20);
            this.splitContainer1.Panel2.Controls.Add(this.lblInvTotalCount);
            this.splitContainer1.Panel2.Controls.Add(this.invlabel27);
            this.splitContainer1.Panel2.Controls.Add(this.invlabel25);
            this.splitContainer1.Panel2.Controls.Add(this.lblInvTime);
            this.splitContainer1.Panel2.Controls.Add(this.lblInvRate1);
            this.splitContainer1.Panel2.Controls.Add(this.lblInvRate);
            this.splitContainer1.Panel2.Controls.Add(this.lblInvTotalCount1);
            this.splitContainer1.Panel2.Controls.Add(this.lblInvTime1);
            this.splitContainer1.Panel2.Controls.Add(this.lblInvTotalTime1);
            this.splitContainer1.Size = new System.Drawing.Size(356, 256);
            this.splitContainer1.SplitterDistance = 74;
            this.splitContainer1.TabIndex = 62;
            // 
            // lblInvTotalTime
            // 
            this.lblInvTotalTime.Location = new System.Drawing.Point(166, 114);
            this.lblInvTotalTime.Margin = new System.Windows.Forms.Padding(4);
            this.lblInvTotalTime.Name = "lblInvTotalTime";
            this.lblInvTotalTime.Size = new System.Drawing.Size(113, 25);
            this.lblInvTotalTime.TabIndex = 24;
            this.lblInvTotalTime.Text = "000000";
            // 
            // lblInvTotalCount
            // 
            this.lblInvTotalCount.Location = new System.Drawing.Point(166, 83);
            this.lblInvTotalCount.Margin = new System.Windows.Forms.Padding(4);
            this.lblInvTotalCount.Name = "lblInvTotalCount";
            this.lblInvTotalCount.Size = new System.Drawing.Size(113, 25);
            this.lblInvTotalCount.TabIndex = 23;
            this.lblInvTotalCount.Text = "00000000";
            // 
            // lblInvTime
            // 
            this.lblInvTime.Location = new System.Drawing.Point(166, 50);
            this.lblInvTime.Margin = new System.Windows.Forms.Padding(4);
            this.lblInvTime.Name = "lblInvTime";
            this.lblInvTime.Size = new System.Drawing.Size(113, 25);
            this.lblInvTime.TabIndex = 22;
            this.lblInvTime.Text = "000";
            // 
            // lblInvRate
            // 
            this.lblInvRate.Location = new System.Drawing.Point(166, 17);
            this.lblInvRate.Margin = new System.Windows.Forms.Padding(4);
            this.lblInvRate.Name = "lblInvRate";
            this.lblInvRate.Size = new System.Drawing.Size(113, 25);
            this.lblInvRate.TabIndex = 21;
            this.lblInvRate.Text = "000";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.invlabel138);
            this.groupBox2.Controls.Add(this.txbInvTime);
            this.groupBox2.Controls.Add(this.rdbScene1);
            this.groupBox2.Controls.Add(this.lblUnit1);
            this.groupBox2.Controls.Add(this.lblUnit4);
            this.groupBox2.Controls.Add(this.txbInvCount);
            this.groupBox2.Controls.Add(this.txb_userTime);
            this.groupBox2.Controls.Add(this.rdbScene2);
            this.groupBox2.Controls.Add(this.btnISOSelect);
            this.groupBox2.Controls.Add(this.lblUnit2);
            this.groupBox2.Controls.Add(this.rdbScene4);
            this.groupBox2.Location = new System.Drawing.Point(4, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(398, 148);
            this.groupBox2.TabIndex = 63;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "询查方式";
            // 
            // invlabel138
            // 
            this.invlabel138.AutoSize = true;
            this.invlabel138.Location = new System.Drawing.Point(271, 16);
            this.invlabel138.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.invlabel138.Name = "invlabel138";
            this.invlabel138.Size = new System.Drawing.Size(120, 15);
            this.invlabel138.TabIndex = 61;
            this.invlabel138.Text = "（0：持续询查）";
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 455);
            this.splitter1.TabIndex = 65;
            this.splitter1.TabStop = false;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(35, 97);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(144, 15);
            this.label32.TabIndex = 59;
            this.label32.Text = "字节长度（Byte）：";
            // 
            // cmbInventoryArea
            // 
            this.cmbInventoryArea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbInventoryArea.FormattingEnabled = true;
            this.cmbInventoryArea.Items.AddRange(new object[] {
            "Reserve",
            "EPC",
            "TID",
            "User"});
            this.cmbInventoryArea.Location = new System.Drawing.Point(189, 21);
            this.cmbInventoryArea.Margin = new System.Windows.Forms.Padding(4);
            this.cmbInventoryArea.Name = "cmbInventoryArea";
            this.cmbInventoryArea.Size = new System.Drawing.Size(70, 23);
            this.cmbInventoryArea.TabIndex = 50;
            this.cmbInventoryArea.SelectedIndexChanged += new System.EventHandler(this.cmbInventoryArea_SelectedIndexChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(37, 25);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(142, 15);
            this.label30.TabIndex = 49;
            this.label30.Text = "询查区域（&号码）：";
            // 
            // tbxInventoryStartAddr
            // 
            this.tbxInventoryStartAddr.Location = new System.Drawing.Point(189, 55);
            this.tbxInventoryStartAddr.MaxLength = 3;
            this.tbxInventoryStartAddr.Name = "tbxInventoryStartAddr";
            this.tbxInventoryStartAddr.Size = new System.Drawing.Size(70, 25);
            this.tbxInventoryStartAddr.TabIndex = 58;
            this.tbxInventoryStartAddr.Text = "00";
            // 
            // tbxInventoryDataLen
            // 
            this.tbxInventoryDataLen.Location = new System.Drawing.Point(189, 92);
            this.tbxInventoryDataLen.MaxLength = 3;
            this.tbxInventoryDataLen.Name = "tbxInventoryDataLen";
            this.tbxInventoryDataLen.Size = new System.Drawing.Size(70, 25);
            this.tbxInventoryDataLen.TabIndex = 60;
            this.tbxInventoryDataLen.Text = "00";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(35, 59);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(144, 15);
            this.label31.TabIndex = 57;
            this.label31.Text = "起始地址（Byte）：";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.splitContainer2);
            this.groupBox3.Location = new System.Drawing.Point(408, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(600, 148);
            this.groupBox3.TabIndex = 64;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "询查参数";
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(3, 21);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.label31);
            this.splitContainer2.Panel1.Controls.Add(this.tbxInventoryDataLen);
            this.splitContainer2.Panel1.Controls.Add(this.label32);
            this.splitContainer2.Panel1.Controls.Add(this.cmbInventoryArea);
            this.splitContainer2.Panel1.Controls.Add(this.tbxInventoryStartAddr);
            this.splitContainer2.Panel1.Controls.Add(this.label30);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.cmbQvalue);
            this.splitContainer2.Panel2.Controls.Add(this.label33);
            this.splitContainer2.Panel2.Controls.Add(this.label35);
            this.splitContainer2.Panel2.Controls.Add(this.cmbSession);
            this.splitContainer2.Panel2.Controls.Add(this.tbxAnswerTime);
            this.splitContainer2.Panel2.Controls.Add(this.label34);
            this.splitContainer2.Size = new System.Drawing.Size(594, 124);
            this.splitContainer2.SplitterDistance = 276;
            this.splitContainer2.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.splitContainer1);
            this.groupBox1.Location = new System.Drawing.Point(826, 150);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(350, 290);
            this.groupBox1.TabIndex = 66;
            this.groupBox1.TabStop = false;
            // 
            // invlabel8
            // 
            this.invlabel8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.invlabel8.AutoSize = true;
            this.invlabel8.ForeColor = System.Drawing.Color.Red;
            this.invlabel8.Location = new System.Drawing.Point(10, 402);
            this.invlabel8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.invlabel8.Name = "invlabel8";
            this.invlabel8.Size = new System.Drawing.Size(457, 15);
            this.invlabel8.TabIndex = 62;
            this.invlabel8.Text = "注意：所有口令和数据都是十六进制格式，地址和长度是十进制格式";
            // 
            // InventoryPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.invlabel8);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.txbPageLines);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.rdbScene0);
            this.Controls.Add(this.btnInventory);
            this.Controls.Add(this.btnNextPage);
            this.Controls.Add(this.btnPrevPage);
            this.Controls.Add(this.btnLastPage);
            this.Controls.Add(this.btnFirstPage);
            this.Controls.Add(this.lsvTags);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "InventoryPanel";
            this.Size = new System.Drawing.Size(1179, 455);
            this.Load += new System.EventHandler(this.EpcPanel_Load);
            this.Leave += new System.EventHandler(this.InventoryPanel_Leave);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            this.splitContainer2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblinvsum;
        private System.Windows.Forms.Label lblInvCount;
        private System.Windows.Forms.Label invlabel20;
        private System.Windows.Forms.Label invlabel25;
        private System.Windows.Forms.Label lblInvRate1;
        private System.Windows.Forms.Label lblInvTime1;
        private System.Windows.Forms.Label invlabel26;
        private System.Windows.Forms.Label invlabel27;
        private System.Windows.Forms.Label lblInvTotalCount1;
        private System.Windows.Forms.Label lblInvTotalTime1;
        private System.Windows.Forms.Button btnInventory;
        private System.Windows.Forms.ListView lsvTags;
        private System.Windows.Forms.ColumnHeader colNum;
        private System.Windows.Forms.ColumnHeader colCode;
        private System.Windows.Forms.ColumnHeader colCount;
        private System.Windows.Forms.ColumnHeader colRssi;
        private System.Windows.Forms.ColumnHeader colCw;
        private System.Windows.Forms.Button btnFirstPage;
        private System.Windows.Forms.Button btnPrevPage;
        private System.Windows.Forms.Button btnNextPage;
        private System.Windows.Forms.Button btnLastPage;
        private System.Windows.Forms.RadioButton rdbScene1;
        private System.Windows.Forms.TextBox txbInvTime;
        private System.Windows.Forms.TextBox txbPageLines;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.RadioButton rdbScene0;
        private System.Windows.Forms.Label lblUnit1;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.SaveFileDialog sfd;
        private System.Windows.Forms.Label lblUnit2;
        private System.Windows.Forms.RadioButton rdbScene2;
        private System.Windows.Forms.TextBox txbInvCount;
        private System.Windows.Forms.Button btnISOSelect;
        private System.Windows.Forms.RadioButton rdbScene4;
        private System.Windows.Forms.Label lblUnit4;
        private System.Windows.Forms.TextBox txb_userTime;
        private System.Windows.Forms.ComboBox cmbSession;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox cmbQvalue;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox tbxAnswerTime;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox lblInvRate;
        private System.Windows.Forms.TextBox lblInvTime;
        private System.Windows.Forms.TextBox lblInvTotalCount;
        private System.Windows.Forms.TextBox lblInvTotalTime;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox cmbInventoryArea;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox tbxInventoryStartAddr;
        private System.Windows.Forms.TextBox tbxInventoryDataLen;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label invlabel138;
        private System.Windows.Forms.ColumnHeader colCodeLen;
        private System.Windows.Forms.Label invlabel8;
    }
}
