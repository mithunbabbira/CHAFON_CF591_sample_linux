using System;

namespace YYF100
{
    partial class RFPanel
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.ckbAnt1 = new System.Windows.Forms.CheckBox();
            this.ckbAnt2 = new System.Windows.Forms.CheckBox();
            this.btnCheckAnt = new System.Windows.Forms.Button();
            this.ckbAnt3 = new System.Windows.Forms.CheckBox();
            this.ckbAnt4 = new System.Windows.Forms.CheckBox();
            this.cmbTxPower = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.cmbFreqStart = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbnusb = new System.Windows.Forms.RadioButton();
            this.rbncom = new System.Windows.Forms.RadioButton();
            this.groupNet = new System.Windows.Forms.GroupBox();
            this.btnScannet = new System.Windows.Forms.Button();
            this.btnDisConnect = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.txbPort = new System.Windows.Forms.TextBox();
            this.rflabel32 = new System.Windows.Forms.Label();
            this.txbIPAddr = new System.Windows.Forms.TextBox();
            this.rflabel33 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdbMalaysia = new System.Windows.Forms.RadioButton();
            this.rdbEU = new System.Windows.Forms.RadioButton();
            this.rdbJapan = new System.Windows.Forms.RadioButton();
            this.rdbKorea = new System.Windows.Forms.RadioButton();
            this.cmbChannelCount = new System.Windows.Forms.ComboBox();
            this.lblChannelCount = new System.Windows.Forms.Label();
            this.lblChannelStepUnit = new System.Windows.Forms.Label();
            this.btnSetFreq = new System.Windows.Forms.Button();
            this.btnGetFreq = new System.Windows.Forms.Button();
            this.label28 = new System.Windows.Forms.Label();
            this.lblChannelStep = new System.Windows.Forms.Label();
            this.rdbFreqCustom = new System.Windows.Forms.RadioButton();
            this.rdbEts = new System.Windows.Forms.RadioButton();
            this.txbChannelStep = new System.Windows.Forms.TextBox();
            this.rdbChn2 = new System.Windows.Forms.RadioButton();
            this.rdbChn1 = new System.Windows.Forms.RadioButton();
            this.label30 = new System.Windows.Forms.Label();
            this.rdbFcc = new System.Windows.Forms.RadioButton();
            this.cmbChannelStart = new System.Windows.Forms.ComboBox();
            this.lblVersion = new System.Windows.Forms.Label();
            this.btnUpdateRfPara = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnOutputPara = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.cmbLanguage = new System.Windows.Forms.ComboBox();
            this.btnInputPara = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.tbxDeviceSN = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.tbxSoftversion = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tbxHardversion = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.gpbCom = new System.Windows.Forms.GroupBox();
            this.label32 = new System.Windows.Forms.Label();
            this.btnScanUsb = new System.Windows.Forms.Button();
            this.cbxusbpath = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbComBaud = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSportClose = new System.Windows.Forms.Button();
            this.btnSportOpen = new System.Windows.Forms.Button();
            this.cmbComPort = new System.Windows.Forms.ComboBox();
            this.btnDisableKC = new System.Windows.Forms.Button();
            this.cbxBuzzerEn = new System.Windows.Forms.CheckBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btnEnbableKC = new System.Windows.Forms.Button();
            this.cmbSession = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.cmbQvalue = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.tbxInventoryDataLen = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tbxInventoryStartAddr = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.cmbInventoryArea = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tbxAnswerTime = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cmbOutInterface = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbWorkmode = new System.Windows.Forms.ComboBox();
            this.cmbWiggendOutMode = new System.Windows.Forms.ComboBox();
            this.cmbWiegandMode = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbxTriggerTime = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.tbxFilterTime = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbxDeviceAddr = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbSerialbaud = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnGetAllPara = new System.Windows.Forms.Button();
            this.btnSetAllPara = new System.Windows.Forms.Button();
            this.btnSetDefaultPara = new System.Windows.Forms.Button();
            this.txbLog = new System.Windows.Forms.TextBox();
            this.tmiEpc = new System.Windows.Forms.ToolStripMenuItem();
            this.tmiGB = new System.Windows.Forms.ToolStripMenuItem();
            this.tmiGJB = new System.Windows.Forms.ToolStripMenuItem();
            this.tslProto = new System.Windows.Forms.ToolStripLabel();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.btnSetTxPower = new System.Windows.Forms.Button();
            this.rdbPointFreq = new System.Windows.Forms.CheckBox();
            this.cmbFreqEnd = new System.Windows.Forms.ComboBox();
            this.cmbRegion = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cmbGbModu = new System.Windows.Forms.ComboBox();
            this.cmbGbBlf = new System.Windows.Forms.ComboBox();
            this.btnGetLinkPrm = new System.Windows.Forms.Button();
            this.cmbGbTc = new System.Windows.Forms.ComboBox();
            this.btnSetLinkPrm = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbGbM = new System.Windows.Forms.ComboBox();
            this.cmbGbTrext = new System.Windows.Forms.ComboBox();
            this.RFlabel8 = new System.Windows.Forms.Label();
            this.panelEpc = new YYF100.EpcPanel();
            this.groupBox5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupNet.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.gpbCom.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.ckbAnt1);
            this.groupBox5.Controls.Add(this.ckbAnt2);
            this.groupBox5.Controls.Add(this.btnCheckAnt);
            this.groupBox5.Controls.Add(this.ckbAnt3);
            this.groupBox5.Controls.Add(this.ckbAnt4);
            this.groupBox5.Enabled = false;
            this.groupBox5.Location = new System.Drawing.Point(200, 286);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(818, 47);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "天线";
            this.groupBox5.Visible = false;
            // 
            // ckbAnt1
            // 
            this.ckbAnt1.AutoSize = true;
            this.ckbAnt1.Checked = true;
            this.ckbAnt1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbAnt1.Enabled = false;
            this.ckbAnt1.Location = new System.Drawing.Point(14, 20);
            this.ckbAnt1.Name = "ckbAnt1";
            this.ckbAnt1.Size = new System.Drawing.Size(54, 16);
            this.ckbAnt1.TabIndex = 0;
            this.ckbAnt1.Text = "天线1";
            this.ckbAnt1.UseVisualStyleBackColor = true;
            // 
            // ckbAnt2
            // 
            this.ckbAnt2.AutoSize = true;
            this.ckbAnt2.Location = new System.Drawing.Point(156, 20);
            this.ckbAnt2.Name = "ckbAnt2";
            this.ckbAnt2.Size = new System.Drawing.Size(54, 16);
            this.ckbAnt2.TabIndex = 1;
            this.ckbAnt2.Text = "天线2";
            this.ckbAnt2.UseVisualStyleBackColor = true;
            // 
            // btnCheckAnt
            // 
            this.btnCheckAnt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCheckAnt.Location = new System.Drawing.Point(630, 16);
            this.btnCheckAnt.Name = "btnCheckAnt";
            this.btnCheckAnt.Size = new System.Drawing.Size(75, 23);
            this.btnCheckAnt.TabIndex = 4;
            this.btnCheckAnt.Text = "搜索天线";
            this.btnCheckAnt.UseVisualStyleBackColor = true;
            this.btnCheckAnt.Visible = false;
            this.btnCheckAnt.Click += new System.EventHandler(this.btnGetAntenna_Click);
            // 
            // ckbAnt3
            // 
            this.ckbAnt3.AutoSize = true;
            this.ckbAnt3.Location = new System.Drawing.Point(298, 20);
            this.ckbAnt3.Name = "ckbAnt3";
            this.ckbAnt3.Size = new System.Drawing.Size(54, 16);
            this.ckbAnt3.TabIndex = 2;
            this.ckbAnt3.Text = "天线3";
            this.ckbAnt3.UseVisualStyleBackColor = true;
            this.ckbAnt3.Visible = false;
            // 
            // ckbAnt4
            // 
            this.ckbAnt4.AutoSize = true;
            this.ckbAnt4.Location = new System.Drawing.Point(440, 20);
            this.ckbAnt4.Name = "ckbAnt4";
            this.ckbAnt4.Size = new System.Drawing.Size(54, 16);
            this.ckbAnt4.TabIndex = 3;
            this.ckbAnt4.Text = "天线4";
            this.ckbAnt4.UseVisualStyleBackColor = true;
            this.ckbAnt4.Visible = false;
            // 
            // cmbTxPower
            // 
            this.cmbTxPower.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTxPower.FormattingEnabled = true;
            this.cmbTxPower.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33"});
            this.cmbTxPower.Location = new System.Drawing.Point(82, 27);
            this.cmbTxPower.Name = "cmbTxPower";
            this.cmbTxPower.Size = new System.Drawing.Size(82, 20);
            this.cmbTxPower.TabIndex = 1;
            this.cmbTxPower.SelectedIndexChanged += new System.EventHandler(this.cmbTxPower_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(171, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(23, 12);
            this.label16.TabIndex = 2;
            this.label16.Text = "dBm";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "输出功率：";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(495, 64);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(65, 12);
            this.label31.TabIndex = 11;
            this.label31.Text = "结束频率：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(371, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 12);
            this.label6.TabIndex = 7;
            this.label6.Text = "MHz";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(214, 64);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(65, 12);
            this.label35.TabIndex = 5;
            this.label35.Text = "起始频率：";
            // 
            // cmbFreqStart
            // 
            this.cmbFreqStart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFreqStart.FormattingEnabled = true;
            this.cmbFreqStart.Location = new System.Drawing.Point(284, 61);
            this.cmbFreqStart.Name = "cmbFreqStart";
            this.cmbFreqStart.Size = new System.Drawing.Size(82, 20);
            this.cmbFreqStart.TabIndex = 6;
            this.cmbFreqStart.SelectedValueChanged += new System.EventHandler(this.cmbFreqStart_SelectedValueChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbnusb);
            this.groupBox1.Controls.Add(this.rbncom);
            this.groupBox1.Controls.Add(this.groupNet);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.lblVersion);
            this.groupBox1.Controls.Add(this.btnUpdateRfPara);
            this.groupBox1.Controls.Add(this.lblStatus);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.gpbCom);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(194, 442);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "连接方式";
            // 
            // rbnusb
            // 
            this.rbnusb.AutoSize = true;
            this.rbnusb.Location = new System.Drawing.Point(147, 14);
            this.rbnusb.Name = "rbnusb";
            this.rbnusb.Size = new System.Drawing.Size(41, 16);
            this.rbnusb.TabIndex = 16;
            this.rbnusb.Text = "USB";
            this.rbnusb.UseVisualStyleBackColor = true;
            this.rbnusb.CheckedChanged += new System.EventHandler(this.rbnusb_CheckedChanged);
            // 
            // rbncom
            // 
            this.rbncom.AutoSize = true;
            this.rbncom.Checked = true;
            this.rbncom.Location = new System.Drawing.Point(100, 14);
            this.rbncom.Name = "rbncom";
            this.rbncom.Size = new System.Drawing.Size(41, 16);
            this.rbncom.TabIndex = 15;
            this.rbncom.TabStop = true;
            this.rbncom.Text = "Com";
            this.rbncom.UseVisualStyleBackColor = true;
            this.rbncom.Click += new System.EventHandler(this.rbncom_Click);
            // 
            // groupNet
            // 
            this.groupNet.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupNet.Controls.Add(this.btnScannet);
            this.groupNet.Controls.Add(this.btnDisConnect);
            this.groupNet.Controls.Add(this.btnConnect);
            this.groupNet.Controls.Add(this.txbPort);
            this.groupNet.Controls.Add(this.rflabel32);
            this.groupNet.Controls.Add(this.txbIPAddr);
            this.groupNet.Controls.Add(this.rflabel33);
            this.groupNet.Location = new System.Drawing.Point(6, 139);
            this.groupNet.Name = "groupNet";
            this.groupNet.Size = new System.Drawing.Size(182, 125);
            this.groupNet.TabIndex = 14;
            this.groupNet.TabStop = false;
            this.groupNet.Text = "网络连接";
            // 
            // btnScannet
            // 
            this.btnScannet.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnScannet.Location = new System.Drawing.Point(13, 97);
            this.btnScannet.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnScannet.Name = "btnScannet";
            this.btnScannet.Size = new System.Drawing.Size(156, 28);
            this.btnScannet.TabIndex = 6;
            this.btnScannet.Text = "扫描设备（&S）";
            this.btnScannet.UseVisualStyleBackColor = true;
            this.btnScannet.Click += new System.EventHandler(this.btnScannet_Click);
            // 
            // btnDisConnect
            // 
            this.btnDisConnect.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnDisConnect.Location = new System.Drawing.Point(95, 66);
            this.btnDisConnect.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDisConnect.Name = "btnDisConnect";
            this.btnDisConnect.Size = new System.Drawing.Size(74, 28);
            this.btnDisConnect.TabIndex = 5;
            this.btnDisConnect.Text = "断开(&D)";
            this.btnDisConnect.UseVisualStyleBackColor = true;
            this.btnDisConnect.Click += new System.EventHandler(this.btnDisConnect_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnConnect.Location = new System.Drawing.Point(13, 66);
            this.btnConnect.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(74, 28);
            this.btnConnect.TabIndex = 4;
            this.btnConnect.Text = "连接(&C)";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // txbPort
            // 
            this.txbPort.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbPort.Location = new System.Drawing.Point(66, 42);
            this.txbPort.Name = "txbPort";
            this.txbPort.Size = new System.Drawing.Size(110, 21);
            this.txbPort.TabIndex = 3;
            this.txbPort.Text = "2022";
            // 
            // rflabel32
            // 
            this.rflabel32.AutoSize = true;
            this.rflabel32.Location = new System.Drawing.Point(7, 45);
            this.rflabel32.Name = "rflabel32";
            this.rflabel32.Size = new System.Drawing.Size(53, 12);
            this.rflabel32.TabIndex = 2;
            this.rflabel32.Text = "端口号：";
            // 
            // txbIPAddr
            // 
            this.txbIPAddr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txbIPAddr.Location = new System.Drawing.Point(66, 14);
            this.txbIPAddr.Name = "txbIPAddr";
            this.txbIPAddr.Size = new System.Drawing.Size(110, 21);
            this.txbIPAddr.TabIndex = 1;
            this.txbIPAddr.Text = "192.168.1.120";
            // 
            // rflabel33
            // 
            this.rflabel33.AutoSize = true;
            this.rflabel33.Location = new System.Drawing.Point(7, 18);
            this.rflabel33.Name = "rflabel33";
            this.rflabel33.Size = new System.Drawing.Size(53, 12);
            this.rflabel33.TabIndex = 0;
            this.rflabel33.Text = "IP地址：";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.rdbMalaysia);
            this.groupBox2.Controls.Add(this.rdbEU);
            this.groupBox2.Controls.Add(this.rdbJapan);
            this.groupBox2.Controls.Add(this.rdbKorea);
            this.groupBox2.Controls.Add(this.cmbChannelCount);
            this.groupBox2.Controls.Add(this.lblChannelCount);
            this.groupBox2.Controls.Add(this.lblChannelStepUnit);
            this.groupBox2.Controls.Add(this.btnSetFreq);
            this.groupBox2.Controls.Add(this.btnGetFreq);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.lblChannelStep);
            this.groupBox2.Controls.Add(this.rdbFreqCustom);
            this.groupBox2.Controls.Add(this.rdbEts);
            this.groupBox2.Controls.Add(this.txbChannelStep);
            this.groupBox2.Controls.Add(this.rdbChn2);
            this.groupBox2.Controls.Add(this.rdbChn1);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.rdbFcc);
            this.groupBox2.Controls.Add(this.cmbChannelStart);
            this.groupBox2.Location = new System.Drawing.Point(195, 447);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(604, 76);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "工作频率";
            this.groupBox2.Visible = false;
            // 
            // rdbMalaysia
            // 
            this.rdbMalaysia.AutoSize = true;
            this.rdbMalaysia.Location = new System.Drawing.Point(413, 21);
            this.rdbMalaysia.Name = "rdbMalaysia";
            this.rdbMalaysia.Size = new System.Drawing.Size(71, 16);
            this.rdbMalaysia.TabIndex = 18;
            this.rdbMalaysia.TabStop = true;
            this.rdbMalaysia.Text = "MALAYSIA";
            this.rdbMalaysia.UseVisualStyleBackColor = true;
            // 
            // rdbEU
            // 
            this.rdbEU.AutoSize = true;
            this.rdbEU.Location = new System.Drawing.Point(368, 20);
            this.rdbEU.Name = "rdbEU";
            this.rdbEU.Size = new System.Drawing.Size(35, 16);
            this.rdbEU.TabIndex = 17;
            this.rdbEU.TabStop = true;
            this.rdbEU.Text = "EU";
            this.rdbEU.UseVisualStyleBackColor = true;
            // 
            // rdbJapan
            // 
            this.rdbJapan.AutoSize = true;
            this.rdbJapan.Location = new System.Drawing.Point(305, 21);
            this.rdbJapan.Name = "rdbJapan";
            this.rdbJapan.Size = new System.Drawing.Size(53, 16);
            this.rdbJapan.TabIndex = 16;
            this.rdbJapan.TabStop = true;
            this.rdbJapan.Text = "JAPAN";
            this.rdbJapan.UseVisualStyleBackColor = true;
            // 
            // rdbKorea
            // 
            this.rdbKorea.AutoSize = true;
            this.rdbKorea.Location = new System.Drawing.Point(242, 20);
            this.rdbKorea.Name = "rdbKorea";
            this.rdbKorea.Size = new System.Drawing.Size(53, 16);
            this.rdbKorea.TabIndex = 15;
            this.rdbKorea.TabStop = true;
            this.rdbKorea.Text = "KOREA";
            this.rdbKorea.UseVisualStyleBackColor = true;
            // 
            // cmbChannelCount
            // 
            this.cmbChannelCount.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChannelCount.FormattingEnabled = true;
            this.cmbChannelCount.Location = new System.Drawing.Point(445, 46);
            this.cmbChannelCount.Name = "cmbChannelCount";
            this.cmbChannelCount.Size = new System.Drawing.Size(74, 20);
            this.cmbChannelCount.TabIndex = 12;
            // 
            // lblChannelCount
            // 
            this.lblChannelCount.AutoSize = true;
            this.lblChannelCount.Location = new System.Drawing.Point(374, 49);
            this.lblChannelCount.Name = "lblChannelCount";
            this.lblChannelCount.Size = new System.Drawing.Size(65, 12);
            this.lblChannelCount.TabIndex = 11;
            this.lblChannelCount.Text = "信道个数：";
            // 
            // lblChannelStepUnit
            // 
            this.lblChannelStepUnit.AutoSize = true;
            this.lblChannelStepUnit.Location = new System.Drawing.Point(340, 49);
            this.lblChannelStepUnit.Name = "lblChannelStepUnit";
            this.lblChannelStepUnit.Size = new System.Drawing.Size(23, 12);
            this.lblChannelStepUnit.TabIndex = 10;
            this.lblChannelStepUnit.Text = "KHz";
            this.lblChannelStepUnit.Visible = false;
            // 
            // btnSetFreq
            // 
            this.btnSetFreq.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetFreq.Location = new System.Drawing.Point(520, 43);
            this.btnSetFreq.Name = "btnSetFreq";
            this.btnSetFreq.Size = new System.Drawing.Size(75, 23);
            this.btnSetFreq.TabIndex = 14;
            this.btnSetFreq.Text = "设置";
            this.btnSetFreq.UseVisualStyleBackColor = true;
            // 
            // btnGetFreq
            // 
            this.btnGetFreq.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetFreq.Location = new System.Drawing.Point(520, 16);
            this.btnGetFreq.Name = "btnGetFreq";
            this.btnGetFreq.Size = new System.Drawing.Size(75, 23);
            this.btnGetFreq.TabIndex = 13;
            this.btnGetFreq.Text = "获取";
            this.btnGetFreq.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(163, 49);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(23, 12);
            this.label28.TabIndex = 7;
            this.label28.Text = "MHz";
            // 
            // lblChannelStep
            // 
            this.lblChannelStep.AutoSize = true;
            this.lblChannelStep.Location = new System.Drawing.Point(195, 49);
            this.lblChannelStep.Name = "lblChannelStep";
            this.lblChannelStep.Size = new System.Drawing.Size(65, 12);
            this.lblChannelStep.TabIndex = 8;
            this.lblChannelStep.Text = "信道间隔：";
            this.lblChannelStep.Visible = false;
            // 
            // rdbFreqCustom
            // 
            this.rdbFreqCustom.AutoSize = true;
            this.rdbFreqCustom.Location = new System.Drawing.Point(494, 20);
            this.rdbFreqCustom.Name = "rdbFreqCustom";
            this.rdbFreqCustom.Size = new System.Drawing.Size(83, 16);
            this.rdbFreqCustom.TabIndex = 4;
            this.rdbFreqCustom.TabStop = true;
            this.rdbFreqCustom.Text = "自定义频点";
            this.rdbFreqCustom.UseVisualStyleBackColor = true;
            // 
            // rdbEts
            // 
            this.rdbEts.AutoSize = true;
            this.rdbEts.Location = new System.Drawing.Point(191, 20);
            this.rdbEts.Name = "rdbEts";
            this.rdbEts.Size = new System.Drawing.Size(41, 16);
            this.rdbEts.TabIndex = 3;
            this.rdbEts.TabStop = true;
            this.rdbEts.Text = "EU3";
            this.rdbEts.UseVisualStyleBackColor = true;
            // 
            // txbChannelStep
            // 
            this.txbChannelStep.BackColor = System.Drawing.SystemColors.Window;
            this.txbChannelStep.Location = new System.Drawing.Point(266, 46);
            this.txbChannelStep.Name = "txbChannelStep";
            this.txbChannelStep.Size = new System.Drawing.Size(70, 21);
            this.txbChannelStep.TabIndex = 9;
            this.txbChannelStep.Visible = false;
            // 
            // rdbChn2
            // 
            this.rdbChn2.AutoSize = true;
            this.rdbChn2.Location = new System.Drawing.Point(128, 21);
            this.rdbChn2.Name = "rdbChn2";
            this.rdbChn2.Size = new System.Drawing.Size(53, 16);
            this.rdbChn2.TabIndex = 2;
            this.rdbChn2.TabStop = true;
            this.rdbChn2.Text = "CHN-2";
            this.rdbChn2.UseVisualStyleBackColor = true;
            // 
            // rdbChn1
            // 
            this.rdbChn1.AutoSize = true;
            this.rdbChn1.Location = new System.Drawing.Point(65, 21);
            this.rdbChn1.Name = "rdbChn1";
            this.rdbChn1.Size = new System.Drawing.Size(53, 16);
            this.rdbChn1.TabIndex = 1;
            this.rdbChn1.TabStop = true;
            this.rdbChn1.Text = "CHN-1";
            this.rdbChn1.UseVisualStyleBackColor = true;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(14, 49);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 12);
            this.label30.TabIndex = 5;
            this.label30.Text = "起始频率：";
            // 
            // rdbFcc
            // 
            this.rdbFcc.AutoSize = true;
            this.rdbFcc.Location = new System.Drawing.Point(14, 20);
            this.rdbFcc.Name = "rdbFcc";
            this.rdbFcc.Size = new System.Drawing.Size(41, 16);
            this.rdbFcc.TabIndex = 0;
            this.rdbFcc.TabStop = true;
            this.rdbFcc.Text = "FCC";
            this.rdbFcc.UseVisualStyleBackColor = true;
            // 
            // cmbChannelStart
            // 
            this.cmbChannelStart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChannelStart.FormattingEnabled = true;
            this.cmbChannelStart.Location = new System.Drawing.Point(85, 46);
            this.cmbChannelStart.Name = "cmbChannelStart";
            this.cmbChannelStart.Size = new System.Drawing.Size(74, 20);
            this.cmbChannelStart.TabIndex = 6;
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Location = new System.Drawing.Point(22, 474);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(83, 36);
            this.lblVersion.TabIndex = 9;
            this.lblVersion.Text = "硬件版本：---\r\n软件版本：---\r\n  序列号：---";
            this.lblVersion.Visible = false;
            // 
            // btnUpdateRfPara
            // 
            this.btnUpdateRfPara.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdateRfPara.Location = new System.Drawing.Point(109, 486);
            this.btnUpdateRfPara.Name = "btnUpdateRfPara";
            this.btnUpdateRfPara.Size = new System.Drawing.Size(75, 23);
            this.btnUpdateRfPara.TabIndex = 8;
            this.btnUpdateRfPara.Text = "刷新界面";
            this.btnUpdateRfPara.UseVisualStyleBackColor = true;
            this.btnUpdateRfPara.Visible = false;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(11, 447);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(77, 12);
            this.lblStatus.TabIndex = 7;
            this.lblStatus.Text = "状态：未连接";
            this.lblStatus.Visible = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnOutputPara);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Controls.Add(this.cmbLanguage);
            this.groupBox6.Controls.Add(this.btnInputPara);
            this.groupBox6.Location = new System.Drawing.Point(7, 367);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox6.Size = new System.Drawing.Size(182, 73);
            this.groupBox6.TabIndex = 6;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "软件设置";
            // 
            // btnOutputPara
            // 
            this.btnOutputPara.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOutputPara.Enabled = false;
            this.btnOutputPara.Location = new System.Drawing.Point(8, 43);
            this.btnOutputPara.Name = "btnOutputPara";
            this.btnOutputPara.Size = new System.Drawing.Size(77, 22);
            this.btnOutputPara.TabIndex = 11;
            this.btnOutputPara.Text = "导出参数";
            this.btnOutputPara.UseVisualStyleBackColor = true;
            this.btnOutputPara.Click += new System.EventHandler(this.btnOutputPara_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(2, 18);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 12);
            this.label17.TabIndex = 2;
            this.label17.Text = "语言选择：";
            // 
            // cmbLanguage
            // 
            this.cmbLanguage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbLanguage.FormattingEnabled = true;
            this.cmbLanguage.Location = new System.Drawing.Point(74, 15);
            this.cmbLanguage.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbLanguage.Name = "cmbLanguage";
            this.cmbLanguage.Size = new System.Drawing.Size(104, 20);
            this.cmbLanguage.TabIndex = 3;
            this.cmbLanguage.Text = "Chinese";
            this.cmbLanguage.DropDown += new System.EventHandler(this.cmbLanguage_DropDown);
            this.cmbLanguage.SelectedValueChanged += new System.EventHandler(this.cmbLanguage_SelectedValueChanged);
            // 
            // btnInputPara
            // 
            this.btnInputPara.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInputPara.Enabled = false;
            this.btnInputPara.Location = new System.Drawing.Point(99, 43);
            this.btnInputPara.Name = "btnInputPara";
            this.btnInputPara.Size = new System.Drawing.Size(77, 22);
            this.btnInputPara.TabIndex = 12;
            this.btnInputPara.Text = "导入参数";
            this.btnInputPara.UseVisualStyleBackColor = true;
            this.btnInputPara.Click += new System.EventHandler(this.btnInputPara_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.Controls.Add(this.tbxDeviceSN);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.tbxSoftversion);
            this.groupBox7.Controls.Add(this.label26);
            this.groupBox7.Controls.Add(this.tbxHardversion);
            this.groupBox7.Controls.Add(this.label25);
            this.groupBox7.Location = new System.Drawing.Point(6, 266);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(182, 100);
            this.groupBox7.TabIndex = 3;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "读写器版本";
            // 
            // tbxDeviceSN
            // 
            this.tbxDeviceSN.Location = new System.Drawing.Point(73, 67);
            this.tbxDeviceSN.Margin = new System.Windows.Forms.Padding(2);
            this.tbxDeviceSN.Name = "tbxDeviceSN";
            this.tbxDeviceSN.Size = new System.Drawing.Size(99, 21);
            this.tbxDeviceSN.TabIndex = 40;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(5, 71);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(53, 12);
            this.label27.TabIndex = 39;
            this.label27.Text = "设备SN：";
            // 
            // tbxSoftversion
            // 
            this.tbxSoftversion.Location = new System.Drawing.Point(73, 41);
            this.tbxSoftversion.Margin = new System.Windows.Forms.Padding(2);
            this.tbxSoftversion.Name = "tbxSoftversion";
            this.tbxSoftversion.Size = new System.Drawing.Size(99, 21);
            this.tbxSoftversion.TabIndex = 38;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(5, 45);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(65, 12);
            this.label26.TabIndex = 37;
            this.label26.Text = "软件版本：";
            // 
            // tbxHardversion
            // 
            this.tbxHardversion.Location = new System.Drawing.Point(73, 14);
            this.tbxHardversion.Margin = new System.Windows.Forms.Padding(2);
            this.tbxHardversion.Name = "tbxHardversion";
            this.tbxHardversion.Size = new System.Drawing.Size(99, 21);
            this.tbxHardversion.TabIndex = 36;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 18);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 12);
            this.label25.TabIndex = 5;
            this.label25.Text = "硬件版本：";
            // 
            // gpbCom
            // 
            this.gpbCom.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gpbCom.Controls.Add(this.label32);
            this.gpbCom.Controls.Add(this.btnScanUsb);
            this.gpbCom.Controls.Add(this.cbxusbpath);
            this.gpbCom.Controls.Add(this.label2);
            this.gpbCom.Controls.Add(this.cmbComBaud);
            this.gpbCom.Controls.Add(this.label3);
            this.gpbCom.Controls.Add(this.btnSportClose);
            this.gpbCom.Controls.Add(this.btnSportOpen);
            this.gpbCom.Controls.Add(this.cmbComPort);
            this.gpbCom.Location = new System.Drawing.Point(6, 25);
            this.gpbCom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gpbCom.Name = "gpbCom";
            this.gpbCom.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gpbCom.Size = new System.Drawing.Size(182, 113);
            this.gpbCom.TabIndex = 0;
            this.gpbCom.TabStop = false;
            this.gpbCom.Text = "连接方式";
            // 
            // label32
            // 
            this.label32.Location = new System.Drawing.Point(6, 20);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(65, 12);
            this.label32.TabIndex = 11;
            this.label32.Text = "USB PATH：";
            this.label32.Visible = false;
            // 
            // btnScanUsb
            // 
            this.btnScanUsb.Location = new System.Drawing.Point(9, 44);
            this.btnScanUsb.Name = "btnScanUsb";
            this.btnScanUsb.Size = new System.Drawing.Size(74, 28);
            this.btnScanUsb.TabIndex = 10;
            this.btnScanUsb.Text = "ScanUSB";
            this.btnScanUsb.UseVisualStyleBackColor = true;
            this.btnScanUsb.Visible = false;
            this.btnScanUsb.Click += new System.EventHandler(this.btnScanUsb_Click);
            // 
            // cbxusbpath
            // 
            this.cbxusbpath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxusbpath.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxusbpath.FormattingEnabled = true;
            this.cbxusbpath.Location = new System.Drawing.Point(78, 17);
            this.cbxusbpath.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbxusbpath.Name = "cbxusbpath";
            this.cbxusbpath.Size = new System.Drawing.Size(98, 20);
            this.cbxusbpath.TabIndex = 1;
            this.cbxusbpath.Visible = false;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(6, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "串口号：";
            this.label2.MouseHover += new System.EventHandler(this.label2_MouseHover);
            // 
            // cmbComBaud
            // 
            this.cmbComBaud.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbComBaud.FormattingEnabled = true;
            this.cmbComBaud.Items.AddRange(new object[] {
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.cmbComBaud.Location = new System.Drawing.Point(77, 49);
            this.cmbComBaud.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbComBaud.Name = "cmbComBaud";
            this.cmbComBaud.Size = new System.Drawing.Size(99, 20);
            this.cmbComBaud.TabIndex = 5;
            this.cmbComBaud.Text = "115200";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 12);
            this.label3.TabIndex = 4;
            this.label3.Text = "波特率：";
            // 
            // btnSportClose
            // 
            this.btnSportClose.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSportClose.Location = new System.Drawing.Point(101, 77);
            this.btnSportClose.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSportClose.Name = "btnSportClose";
            this.btnSportClose.Size = new System.Drawing.Size(74, 28);
            this.btnSportClose.TabIndex = 3;
            this.btnSportClose.Text = "关闭(&C)";
            this.btnSportClose.UseVisualStyleBackColor = true;
            this.btnSportClose.Click += new System.EventHandler(this.btnSportClose_Click);
            // 
            // btnSportOpen
            // 
            this.btnSportOpen.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSportOpen.Location = new System.Drawing.Point(8, 77);
            this.btnSportOpen.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSportOpen.Name = "btnSportOpen";
            this.btnSportOpen.Size = new System.Drawing.Size(74, 28);
            this.btnSportOpen.TabIndex = 2;
            this.btnSportOpen.Text = "打开(&O)";
            this.btnSportOpen.UseVisualStyleBackColor = true;
            this.btnSportOpen.Click += new System.EventHandler(this.btnSportOpen_Click);
            this.btnSportOpen.MouseHover += new System.EventHandler(this.btnSportOpen_MouseHover);
            // 
            // cmbComPort
            // 
            this.cmbComPort.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbComPort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbComPort.FormattingEnabled = true;
            this.cmbComPort.Location = new System.Drawing.Point(77, 17);
            this.cmbComPort.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbComPort.Name = "cmbComPort";
            this.cmbComPort.Size = new System.Drawing.Size(99, 20);
            this.cmbComPort.TabIndex = 1;
            this.cmbComPort.DropDown += new System.EventHandler(this.cmbComPort_DropDown);
            // 
            // btnDisableKC
            // 
            this.btnDisableKC.Enabled = false;
            this.btnDisableKC.Location = new System.Drawing.Point(99, 150);
            this.btnDisableKC.Name = "btnDisableKC";
            this.btnDisableKC.Size = new System.Drawing.Size(77, 22);
            this.btnDisableKC.TabIndex = 14;
            this.btnDisableKC.Text = "释放继电器";
            this.btnDisableKC.UseVisualStyleBackColor = true;
            this.btnDisableKC.Click += new System.EventHandler(this.btnDisableKC_Click);
            // 
            // cbxBuzzerEn
            // 
            this.cbxBuzzerEn.AutoSize = true;
            this.cbxBuzzerEn.Checked = true;
            this.cbxBuzzerEn.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbxBuzzerEn.Location = new System.Drawing.Point(644, 122);
            this.cbxBuzzerEn.Name = "cbxBuzzerEn";
            this.cbxBuzzerEn.Size = new System.Drawing.Size(84, 16);
            this.cbxBuzzerEn.TabIndex = 12;
            this.cbxBuzzerEn.Text = "蜂鸣器使能";
            this.cbxBuzzerEn.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.btnDisableKC);
            this.groupBox8.Controls.Add(this.btnEnbableKC);
            this.groupBox8.Controls.Add(this.cmbSession);
            this.groupBox8.Controls.Add(this.label24);
            this.groupBox8.Controls.Add(this.cmbQvalue);
            this.groupBox8.Controls.Add(this.label23);
            this.groupBox8.Controls.Add(this.tbxInventoryDataLen);
            this.groupBox8.Controls.Add(this.label22);
            this.groupBox8.Controls.Add(this.tbxInventoryStartAddr);
            this.groupBox8.Controls.Add(this.label21);
            this.groupBox8.Controls.Add(this.cmbInventoryArea);
            this.groupBox8.Controls.Add(this.label19);
            this.groupBox8.Controls.Add(this.tbxAnswerTime);
            this.groupBox8.Controls.Add(this.label15);
            this.groupBox8.Controls.Add(this.cmbOutInterface);
            this.groupBox8.Controls.Add(this.label14);
            this.groupBox8.Controls.Add(this.label9);
            this.groupBox8.Controls.Add(this.cmbWorkmode);
            this.groupBox8.Controls.Add(this.cmbWiggendOutMode);
            this.groupBox8.Controls.Add(this.cmbWiegandMode);
            this.groupBox8.Controls.Add(this.label7);
            this.groupBox8.Controls.Add(this.tbxTriggerTime);
            this.groupBox8.Controls.Add(this.label10);
            this.groupBox8.Controls.Add(this.tbxFilterTime);
            this.groupBox8.Controls.Add(this.label8);
            this.groupBox8.Controls.Add(this.cbxBuzzerEn);
            this.groupBox8.Enabled = false;
            this.groupBox8.Location = new System.Drawing.Point(200, 101);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(818, 178);
            this.groupBox8.TabIndex = 7;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "读卡设置";
            // 
            // btnEnbableKC
            // 
            this.btnEnbableKC.Enabled = false;
            this.btnEnbableKC.Location = new System.Drawing.Point(11, 150);
            this.btnEnbableKC.Name = "btnEnbableKC";
            this.btnEnbableKC.Size = new System.Drawing.Size(77, 22);
            this.btnEnbableKC.TabIndex = 13;
            this.btnEnbableKC.Text = "闭合继电器";
            this.btnEnbableKC.UseVisualStyleBackColor = true;
            this.btnEnbableKC.Click += new System.EventHandler(this.btnEnbableKC_Click);
            // 
            // cmbSession
            // 
            this.cmbSession.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSession.FormattingEnabled = true;
            this.cmbSession.Items.AddRange(new object[] {
            "S0",
            "S1",
            "S2",
            "S3"});
            this.cmbSession.Location = new System.Drawing.Point(649, 86);
            this.cmbSession.Name = "cmbSession";
            this.cmbSession.Size = new System.Drawing.Size(36, 20);
            this.cmbSession.TabIndex = 39;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(578, 90);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(59, 12);
            this.label24.TabIndex = 38;
            this.label24.Text = "Session：";
            // 
            // cmbQvalue
            // 
            this.cmbQvalue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQvalue.FormattingEnabled = true;
            this.cmbQvalue.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.cmbQvalue.Location = new System.Drawing.Point(363, 86);
            this.cmbQvalue.Name = "cmbQvalue";
            this.cmbQvalue.Size = new System.Drawing.Size(36, 20);
            this.cmbQvalue.TabIndex = 37;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(321, 90);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(35, 12);
            this.label23.TabIndex = 36;
            this.label23.Text = "Q值：";
            // 
            // tbxInventoryDataLen
            // 
            this.tbxInventoryDataLen.Location = new System.Drawing.Point(363, 50);
            this.tbxInventoryDataLen.Margin = new System.Windows.Forms.Padding(2);
            this.tbxInventoryDataLen.MaxLength = 3;
            this.tbxInventoryDataLen.Name = "tbxInventoryDataLen";
            this.tbxInventoryDataLen.Size = new System.Drawing.Size(36, 21);
            this.tbxInventoryDataLen.TabIndex = 35;
            this.tbxInventoryDataLen.Text = "00";
            this.tbxInventoryDataLen.TextChanged += new System.EventHandler(this.tbxInventoryDataLen_TextChanged);
            this.tbxInventoryDataLen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxInventoryDataLen_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(253, 54);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(113, 12);
            this.label22.TabIndex = 34;
            this.label22.Text = "字节长度（Byte）：";
            // 
            // tbxInventoryStartAddr
            // 
            this.tbxInventoryStartAddr.Location = new System.Drawing.Point(110, 50);
            this.tbxInventoryStartAddr.Margin = new System.Windows.Forms.Padding(2);
            this.tbxInventoryStartAddr.MaxLength = 3;
            this.tbxInventoryStartAddr.Name = "tbxInventoryStartAddr";
            this.tbxInventoryStartAddr.Size = new System.Drawing.Size(54, 21);
            this.tbxInventoryStartAddr.TabIndex = 33;
            this.tbxInventoryStartAddr.Text = "00";
            this.tbxInventoryStartAddr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxInventoryStartAddr_KeyPress);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(12, 54);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(113, 12);
            this.label21.TabIndex = 32;
            this.label21.Text = "起始地址（Byte）：";
            // 
            // cmbInventoryArea
            // 
            this.cmbInventoryArea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbInventoryArea.FormattingEnabled = true;
            this.cmbInventoryArea.Items.AddRange(new object[] {
            "Reserve",
            "EPC",
            "TID",
            "User"});
            this.cmbInventoryArea.Location = new System.Drawing.Point(649, 16);
            this.cmbInventoryArea.Name = "cmbInventoryArea";
            this.cmbInventoryArea.Size = new System.Drawing.Size(82, 20);
            this.cmbInventoryArea.TabIndex = 31;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(530, 19);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(113, 12);
            this.label19.TabIndex = 30;
            this.label19.Text = "询查区域（&号码）：";
            // 
            // tbxAnswerTime
            // 
            this.tbxAnswerTime.Location = new System.Drawing.Point(518, 119);
            this.tbxAnswerTime.Margin = new System.Windows.Forms.Padding(2);
            this.tbxAnswerTime.MaxLength = 3;
            this.tbxAnswerTime.Name = "tbxAnswerTime";
            this.tbxAnswerTime.Size = new System.Drawing.Size(36, 21);
            this.tbxAnswerTime.TabIndex = 29;
            this.tbxAnswerTime.Text = "00";
            this.tbxAnswerTime.TextChanged += new System.EventHandler(this.tbxAnswerTime_TextChanged);
            this.tbxAnswerTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxAnswerTime_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(347, 123);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(143, 12);
            this.label15.TabIndex = 28;
            this.label15.Text = "询查间隔时间（&*10ms）：";
            // 
            // cmbOutInterface
            // 
            this.cmbOutInterface.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOutInterface.FormattingEnabled = true;
            this.cmbOutInterface.Items.AddRange(new object[] {
            "RS232",
            "RS485",
            "RJ45",
            "Wieggand",
            "WiFi",
            "USB",
            "KeyBoard",
            "CDC_COM"});
            this.cmbOutInterface.Location = new System.Drawing.Point(363, 16);
            this.cmbOutInterface.Name = "cmbOutInterface";
            this.cmbOutInterface.Size = new System.Drawing.Size(82, 20);
            this.cmbOutInterface.TabIndex = 27;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(293, 19);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 12);
            this.label14.TabIndex = 26;
            this.label14.Text = "通讯接口：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 90);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 12);
            this.label9.TabIndex = 22;
            this.label9.Text = "触发时间（&S）：";
            // 
            // cmbWorkmode
            // 
            this.cmbWorkmode.DisplayMember = "2";
            this.cmbWorkmode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWorkmode.FormattingEnabled = true;
            this.cmbWorkmode.Items.AddRange(new object[] {
            "应答模式",
            "主动模式",
            "触发模式"});
            this.cmbWorkmode.Location = new System.Drawing.Point(82, 16);
            this.cmbWorkmode.Name = "cmbWorkmode";
            this.cmbWorkmode.Size = new System.Drawing.Size(82, 20);
            this.cmbWorkmode.TabIndex = 25;
            this.cmbWorkmode.SelectedValueChanged += new System.EventHandler(this.cmbWorkmode_SelectedValueChanged);
            // 
            // cmbWiggendOutMode
            // 
            this.cmbWiggendOutMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWiggendOutMode.FormattingEnabled = true;
            this.cmbWiggendOutMode.Items.AddRange(new object[] {
            "高字节在前输出",
            "低字节在前输出"});
            this.cmbWiggendOutMode.Location = new System.Drawing.Point(186, 120);
            this.cmbWiggendOutMode.Name = "cmbWiggendOutMode";
            this.cmbWiggendOutMode.Size = new System.Drawing.Size(105, 20);
            this.cmbWiggendOutMode.TabIndex = 19;
            // 
            // cmbWiegandMode
            // 
            this.cmbWiegandMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWiegandMode.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cmbWiegandMode.FormattingEnabled = true;
            this.cmbWiegandMode.Items.AddRange(new object[] {
            "WG26",
            "WG34"});
            this.cmbWiegandMode.Location = new System.Drawing.Point(82, 120);
            this.cmbWiegandMode.Name = "cmbWiegandMode";
            this.cmbWiegandMode.Size = new System.Drawing.Size(82, 20);
            this.cmbWiegandMode.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 123);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 17;
            this.label7.Text = "韦根输出：";
            // 
            // tbxTriggerTime
            // 
            this.tbxTriggerTime.Location = new System.Drawing.Point(110, 86);
            this.tbxTriggerTime.Margin = new System.Windows.Forms.Padding(2);
            this.tbxTriggerTime.MaxLength = 3;
            this.tbxTriggerTime.Name = "tbxTriggerTime";
            this.tbxTriggerTime.Size = new System.Drawing.Size(54, 21);
            this.tbxTriggerTime.TabIndex = 23;
            this.tbxTriggerTime.Text = "3";
            this.tbxTriggerTime.TextChanged += new System.EventHandler(this.tbxTriggerTime_TextChanged);
            this.tbxTriggerTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxTriggerTime_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 19);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 12);
            this.label10.TabIndex = 24;
            this.label10.Text = "工作模式：";
            // 
            // tbxFilterTime
            // 
            this.tbxFilterTime.Location = new System.Drawing.Point(649, 50);
            this.tbxFilterTime.Margin = new System.Windows.Forms.Padding(2);
            this.tbxFilterTime.MaxLength = 3;
            this.tbxFilterTime.Name = "tbxFilterTime";
            this.tbxFilterTime.Size = new System.Drawing.Size(36, 21);
            this.tbxFilterTime.TabIndex = 21;
            this.tbxFilterTime.Text = "00";
            this.tbxFilterTime.TextChanged += new System.EventHandler(this.tbxFilterTime_TextChanged);
            this.tbxFilterTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxFilterTime_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(546, 54);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 12);
            this.label8.TabIndex = 20;
            this.label8.Text = "过滤时间（&S）：";
            // 
            // tbxDeviceAddr
            // 
            this.tbxDeviceAddr.BackColor = System.Drawing.SystemColors.Window;
            this.tbxDeviceAddr.Location = new System.Drawing.Point(694, 26);
            this.tbxDeviceAddr.Margin = new System.Windows.Forms.Padding(2);
            this.tbxDeviceAddr.MaxLength = 2;
            this.tbxDeviceAddr.Name = "tbxDeviceAddr";
            this.tbxDeviceAddr.Size = new System.Drawing.Size(36, 21);
            this.tbxDeviceAddr.TabIndex = 16;
            this.tbxDeviceAddr.Text = "00";
            this.tbxDeviceAddr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbxDeviceAddr_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(575, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 12);
            this.label5.TabIndex = 15;
            this.label5.Text = "设备地址（&HEX）：";
            // 
            // cmbSerialbaud
            // 
            this.cmbSerialbaud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSerialbaud.FormattingEnabled = true;
            this.cmbSerialbaud.Items.AddRange(new object[] {
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.cmbSerialbaud.Location = new System.Drawing.Point(363, 27);
            this.cmbSerialbaud.Name = "cmbSerialbaud";
            this.cmbSerialbaud.Size = new System.Drawing.Size(82, 20);
            this.cmbSerialbaud.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(293, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 13;
            this.label4.Text = "波特率：";
            // 
            // btnGetAllPara
            // 
            this.btnGetAllPara.Enabled = false;
            this.btnGetAllPara.Location = new System.Drawing.Point(200, 339);
            this.btnGetAllPara.Name = "btnGetAllPara";
            this.btnGetAllPara.Size = new System.Drawing.Size(92, 23);
            this.btnGetAllPara.TabIndex = 8;
            this.btnGetAllPara.Text = "获取所有参数";
            this.btnGetAllPara.UseVisualStyleBackColor = true;
            this.btnGetAllPara.Click += new System.EventHandler(this.btnGetAllPara_Click);
            // 
            // btnSetAllPara
            // 
            this.btnSetAllPara.Enabled = false;
            this.btnSetAllPara.Location = new System.Drawing.Point(459, 339);
            this.btnSetAllPara.Name = "btnSetAllPara";
            this.btnSetAllPara.Size = new System.Drawing.Size(92, 23);
            this.btnSetAllPara.TabIndex = 9;
            this.btnSetAllPara.Text = "设置所有参数";
            this.btnSetAllPara.UseVisualStyleBackColor = true;
            this.btnSetAllPara.Click += new System.EventHandler(this.btnSetAllPara_Click);
            // 
            // btnSetDefaultPara
            // 
            this.btnSetDefaultPara.Enabled = false;
            this.btnSetDefaultPara.Location = new System.Drawing.Point(718, 339);
            this.btnSetDefaultPara.Name = "btnSetDefaultPara";
            this.btnSetDefaultPara.Size = new System.Drawing.Size(75, 23);
            this.btnSetDefaultPara.TabIndex = 10;
            this.btnSetDefaultPara.Text = "默认参数";
            this.btnSetDefaultPara.UseVisualStyleBackColor = true;
            this.btnSetDefaultPara.Click += new System.EventHandler(this.btnSetDefaultPara_Click);
            // 
            // txbLog
            // 
            this.txbLog.Location = new System.Drawing.Point(0, 0);
            this.txbLog.Name = "txbLog";
            this.txbLog.Size = new System.Drawing.Size(100, 21);
            this.txbLog.TabIndex = 0;
            // 
            // tmiEpc
            // 
            this.tmiEpc.Name = "tmiEpc";
            this.tmiEpc.Size = new System.Drawing.Size(32, 19);
            // 
            // tmiGB
            // 
            this.tmiGB.Name = "tmiGB";
            this.tmiGB.Size = new System.Drawing.Size(32, 19);
            // 
            // tmiGJB
            // 
            this.tmiGJB.Name = "tmiGJB";
            this.tmiGJB.Size = new System.Drawing.Size(32, 19);
            // 
            // tslProto
            // 
            this.tslProto.Name = "tslProto";
            this.tslProto.Size = new System.Drawing.Size(23, 23);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.btnSetTxPower);
            this.groupBox9.Controls.Add(this.rdbPointFreq);
            this.groupBox9.Controls.Add(this.cmbFreqEnd);
            this.groupBox9.Controls.Add(this.cmbRegion);
            this.groupBox9.Controls.Add(this.label18);
            this.groupBox9.Controls.Add(this.label1);
            this.groupBox9.Controls.Add(this.cmbTxPower);
            this.groupBox9.Controls.Add(this.label16);
            this.groupBox9.Controls.Add(this.label4);
            this.groupBox9.Controls.Add(this.cmbSerialbaud);
            this.groupBox9.Controls.Add(this.label31);
            this.groupBox9.Controls.Add(this.label5);
            this.groupBox9.Controls.Add(this.tbxDeviceAddr);
            this.groupBox9.Controls.Add(this.label35);
            this.groupBox9.Controls.Add(this.cmbFreqStart);
            this.groupBox9.Controls.Add(this.label6);
            this.groupBox9.Enabled = false;
            this.groupBox9.Location = new System.Drawing.Point(200, 2);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox9.Size = new System.Drawing.Size(818, 93);
            this.groupBox9.TabIndex = 11;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "读写器参数";
            // 
            // btnSetTxPower
            // 
            this.btnSetTxPower.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetTxPower.Location = new System.Drawing.Point(200, 25);
            this.btnSetTxPower.Name = "btnSetTxPower";
            this.btnSetTxPower.Size = new System.Drawing.Size(75, 23);
            this.btnSetTxPower.TabIndex = 21;
            this.btnSetTxPower.Text = "设置功率";
            this.btnSetTxPower.UseVisualStyleBackColor = true;
            this.btnSetTxPower.Visible = false;
            this.btnSetTxPower.Click += new System.EventHandler(this.btnSetTxPower_Click);
            // 
            // rdbPointFreq
            // 
            this.rdbPointFreq.AutoSize = true;
            this.rdbPointFreq.Location = new System.Drawing.Point(680, 62);
            this.rdbPointFreq.Name = "rdbPointFreq";
            this.rdbPointFreq.Size = new System.Drawing.Size(60, 16);
            this.rdbPointFreq.TabIndex = 20;
            this.rdbPointFreq.Text = "单频点";
            this.rdbPointFreq.UseVisualStyleBackColor = true;
            this.rdbPointFreq.CheckedChanged += new System.EventHandler(this.rdbPointFreq_CheckedChanged);
            // 
            // cmbFreqEnd
            // 
            this.cmbFreqEnd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFreqEnd.FormattingEnabled = true;
            this.cmbFreqEnd.Location = new System.Drawing.Point(569, 61);
            this.cmbFreqEnd.Name = "cmbFreqEnd";
            this.cmbFreqEnd.Size = new System.Drawing.Size(82, 20);
            this.cmbFreqEnd.TabIndex = 14;
            this.cmbFreqEnd.SelectedValueChanged += new System.EventHandler(this.cmbFreqEnd_SelectedValueChanged);
            // 
            // cmbRegion
            // 
            this.cmbRegion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRegion.FormattingEnabled = true;
            this.cmbRegion.Items.AddRange(new object[] {
            "Custom",
            "USA",
            "Korea",
            "Europe",
            "Japan",
            "Malaysia",
            "Europe3",
            "China_1",
            "China_2"});
            this.cmbRegion.Location = new System.Drawing.Point(82, 61);
            this.cmbRegion.Name = "cmbRegion";
            this.cmbRegion.Size = new System.Drawing.Size(82, 20);
            this.cmbRegion.TabIndex = 18;
            this.cmbRegion.SelectedValueChanged += new System.EventHandler(this.cmbRegion_SelectedValueChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 64);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 12);
            this.label18.TabIndex = 17;
            this.label18.Text = "工作频段：";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.cmbGbModu);
            this.groupBox4.Controls.Add(this.cmbGbBlf);
            this.groupBox4.Controls.Add(this.btnGetLinkPrm);
            this.groupBox4.Controls.Add(this.cmbGbTc);
            this.groupBox4.Controls.Add(this.btnSetLinkPrm);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.cmbGbM);
            this.groupBox4.Controls.Add(this.cmbGbTrext);
            this.groupBox4.Location = new System.Drawing.Point(225, 463);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(854, 102);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "链路模式";
            this.groupBox4.Visible = false;
            // 
            // cmbGbModu
            // 
            this.cmbGbModu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGbModu.FormattingEnabled = true;
            this.cmbGbModu.Location = new System.Drawing.Point(141, 20);
            this.cmbGbModu.Name = "cmbGbModu";
            this.cmbGbModu.Size = new System.Drawing.Size(95, 20);
            this.cmbGbModu.TabIndex = 1;
            // 
            // cmbGbBlf
            // 
            this.cmbGbBlf.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGbBlf.FormattingEnabled = true;
            this.cmbGbBlf.Location = new System.Drawing.Point(141, 72);
            this.cmbGbBlf.Name = "cmbGbBlf";
            this.cmbGbBlf.Size = new System.Drawing.Size(95, 20);
            this.cmbGbBlf.TabIndex = 5;
            // 
            // btnGetLinkPrm
            // 
            this.btnGetLinkPrm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetLinkPrm.Location = new System.Drawing.Point(728, 18);
            this.btnGetLinkPrm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnGetLinkPrm.Name = "btnGetLinkPrm";
            this.btnGetLinkPrm.Size = new System.Drawing.Size(75, 23);
            this.btnGetLinkPrm.TabIndex = 10;
            this.btnGetLinkPrm.Text = "获取(&G)";
            this.btnGetLinkPrm.UseVisualStyleBackColor = true;
            // 
            // cmbGbTc
            // 
            this.cmbGbTc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGbTc.FormattingEnabled = true;
            this.cmbGbTc.Location = new System.Drawing.Point(457, 20);
            this.cmbGbTc.Name = "cmbGbTc";
            this.cmbGbTc.Size = new System.Drawing.Size(95, 20);
            this.cmbGbTc.TabIndex = 3;
            // 
            // btnSetLinkPrm
            // 
            this.btnSetLinkPrm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSetLinkPrm.Location = new System.Drawing.Point(728, 49);
            this.btnSetLinkPrm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSetLinkPrm.Name = "btnSetLinkPrm";
            this.btnSetLinkPrm.Size = new System.Drawing.Size(75, 23);
            this.btnSetLinkPrm.TabIndex = 11;
            this.btnSetLinkPrm.Text = "设置(&H)";
            this.btnSetLinkPrm.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(16, 75);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 12);
            this.label11.TabIndex = 4;
            this.label11.Text = "反向链路频率(BLF)：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(22, 23);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(113, 12);
            this.label20.TabIndex = 0;
            this.label20.Text = "前向链路调制方式：";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(314, 23);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(137, 12);
            this.label29.TabIndex = 2;
            this.label29.Text = "前向链路基准时间(Tc)：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(296, 49);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(155, 12);
            this.label12.TabIndex = 8;
            this.label12.Text = "反向链路前导信号(TRext)：";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(22, 49);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(113, 12);
            this.label13.TabIndex = 6;
            this.label13.Text = "反向链路编码方式：";
            // 
            // cmbGbM
            // 
            this.cmbGbM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGbM.FormattingEnabled = true;
            this.cmbGbM.Location = new System.Drawing.Point(141, 46);
            this.cmbGbM.Name = "cmbGbM";
            this.cmbGbM.Size = new System.Drawing.Size(95, 20);
            this.cmbGbM.TabIndex = 7;
            // 
            // cmbGbTrext
            // 
            this.cmbGbTrext.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGbTrext.FormattingEnabled = true;
            this.cmbGbTrext.Location = new System.Drawing.Point(457, 46);
            this.cmbGbTrext.Name = "cmbGbTrext";
            this.cmbGbTrext.Size = new System.Drawing.Size(95, 20);
            this.cmbGbTrext.TabIndex = 9;
            // 
            // RFlabel8
            // 
            this.RFlabel8.AutoSize = true;
            this.RFlabel8.ForeColor = System.Drawing.Color.Red;
            this.RFlabel8.Location = new System.Drawing.Point(206, 282);
            this.RFlabel8.Name = "RFlabel8";
            this.RFlabel8.Size = new System.Drawing.Size(365, 12);
            this.RFlabel8.TabIndex = 63;
            this.RFlabel8.Text = "注意：所有口令和数据都是十六进制格式，地址和长度是十进制格式";
            // 
            // panelEpc
            // 
            this.panelEpc.Location = new System.Drawing.Point(0, 0);
            this.panelEpc.Margin = new System.Windows.Forms.Padding(4);
            this.panelEpc.Name = "panelEpc";
            this.panelEpc.Size = new System.Drawing.Size(1065, 576);
            this.panelEpc.StopOperation = false;
            this.panelEpc.TabIndex = 0;
            // 
            // RFPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.RFlabel8);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.btnSetDefaultPara);
            this.Controls.Add(this.btnSetAllPara);
            this.Controls.Add(this.btnGetAllPara);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox5);
            this.Name = "RFPanel";
            this.Size = new System.Drawing.Size(1063, 442);
            this.Load += new System.EventHandler(this.RFPanel_Load);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupNet.ResumeLayout(false);
            this.groupNet.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.gpbCom.ResumeLayout(false);
            this.gpbCom.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.CheckBox ckbAnt1;
        private System.Windows.Forms.CheckBox ckbAnt2;
        private System.Windows.Forms.CheckBox ckbAnt3;
        private System.Windows.Forms.CheckBox ckbAnt4;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox cmbFreqStart;
        private System.Windows.Forms.ComboBox cmbTxPower;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox gpbCom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem tmiEpc;
        private System.Windows.Forms.ToolStripMenuItem tmiGB;
        private System.Windows.Forms.ToolStripMenuItem tmiGJB;
        private EpcPanel panelEpc;
        private System.Windows.Forms.ToolStripLabel tslProto;
        private System.Windows.Forms.TextBox txbLog;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbComBaud;
        private System.Windows.Forms.CheckBox cbxBuzzerEn;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox cmbSerialbaud;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbxDeviceAddr;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbWiegandMode;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbWiggendOutMode;
        private System.Windows.Forms.ComboBox cmbWorkmode;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbxTriggerTime;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tbxFilterTime;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.Button btnGetAllPara;
        private System.Windows.Forms.Button btnSetAllPara;
        private System.Windows.Forms.Button btnSetDefaultPara;
        private System.Windows.Forms.TextBox tbxAnswerTime;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmbOutInterface;
        private System.Windows.Forms.Label label14;
        public System.Windows.Forms.ComboBox cmbComPort;
        public System.Windows.Forms.Button btnSportClose;
        public System.Windows.Forms.Button btnSportOpen;
        public System.Windows.Forms.Button btnOutputPara;
        public System.Windows.Forms.Button btnInputPara;
        private System.Windows.Forms.GroupBox groupBox6;
        public System.Windows.Forms.ComboBox cmbLanguage;
        private System.Windows.Forms.Label label17;
        public System.Windows.Forms.Button btnDisableKC;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.ComboBox cmbRegion;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cmbInventoryArea;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox tbxInventoryDataLen;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox tbxInventoryStartAddr;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cmbSession;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cmbQvalue;
        private System.Windows.Forms.Label label23;
        public System.Windows.Forms.Button btnCheckAnt;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox tbxDeviceSN;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox tbxSoftversion;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox tbxHardversion;
        public System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Button btnUpdateRfPara;
        public System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox cmbGbModu;
        private System.Windows.Forms.ComboBox cmbGbBlf;
        private System.Windows.Forms.Button btnGetLinkPrm;
        private System.Windows.Forms.ComboBox cmbGbTc;
        private System.Windows.Forms.Button btnSetLinkPrm;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmbGbM;
        private System.Windows.Forms.ComboBox cmbGbTrext;
        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.RadioButton rdbMalaysia;
        public System.Windows.Forms.RadioButton rdbEU;
        public System.Windows.Forms.RadioButton rdbJapan;
        public System.Windows.Forms.RadioButton rdbKorea;
        private System.Windows.Forms.ComboBox cmbChannelCount;
        private System.Windows.Forms.Label lblChannelCount;
        private System.Windows.Forms.Label lblChannelStepUnit;
        private System.Windows.Forms.Button btnSetFreq;
        public System.Windows.Forms.Button btnGetFreq;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lblChannelStep;
        private System.Windows.Forms.RadioButton rdbFreqCustom;
        private System.Windows.Forms.RadioButton rdbEts;
        private System.Windows.Forms.TextBox txbChannelStep;
        private System.Windows.Forms.RadioButton rdbChn2;
        private System.Windows.Forms.RadioButton rdbChn1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.RadioButton rdbFcc;
        private System.Windows.Forms.ComboBox cmbChannelStart;
        private System.Windows.Forms.ComboBox cmbFreqEnd;
        private System.Windows.Forms.CheckBox rdbPointFreq;
        private System.Windows.Forms.Button btnSetTxPower;
        private System.Windows.Forms.GroupBox groupNet;
        private System.Windows.Forms.Button btnDisConnect;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox txbPort;
        private System.Windows.Forms.Label rflabel32;
        private System.Windows.Forms.TextBox txbIPAddr;
        private System.Windows.Forms.Label rflabel33;
        private System.Windows.Forms.Label RFlabel8;
        private System.Windows.Forms.Button btnScannet;
        public System.Windows.Forms.Button btnEnbableKC;
        public System.Windows.Forms.ComboBox cbxusbpath;
        private System.Windows.Forms.RadioButton rbnusb;
        private System.Windows.Forms.RadioButton rbncom;
        private System.Windows.Forms.Button btnScanUsb;
        private System.Windows.Forms.Label label32;
    }
}
