namespace YYF100
{
    partial class EpcPanel
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.epcgroupBox2 = new System.Windows.Forms.GroupBox();
            this.epcbtnRead = new System.Windows.Forms.Button();
            this.epcbtnWrite = new System.Windows.Forms.Button();
            this.txbRWPwd = new System.Windows.Forms.TextBox();
            this.txbWData = new System.Windows.Forms.TextBox();
            this.txbRWLen = new System.Windows.Forms.TextBox();
            this.txbRWWordPtr = new System.Windows.Forms.TextBox();
            this.epcrdbRWUser = new System.Windows.Forms.RadioButton();
            this.epcrdbRWTid = new System.Windows.Forms.RadioButton();
            this.epcrdbRWUii = new System.Windows.Forms.RadioButton();
            this.epcrdbRWRsv = new System.Windows.Forms.RadioButton();
            this.epclabel5 = new System.Windows.Forms.Label();
            this.epclabel2 = new System.Windows.Forms.Label();
            this.epclabel4 = new System.Windows.Forms.Label();
            this.epclabel3 = new System.Windows.Forms.Label();
            this.epcgroupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.epcrdbLOpen = new System.Windows.Forms.RadioButton();
            this.epcrdbLPLock = new System.Windows.Forms.RadioButton();
            this.epcrdbLLock = new System.Windows.Forms.RadioButton();
            this.epcrdbLPOpen = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.epcrdbLAccPwd = new System.Windows.Forms.RadioButton();
            this.epcrdbLTid = new System.Windows.Forms.RadioButton();
            this.epcrdbLKillPwd = new System.Windows.Forms.RadioButton();
            this.epcrdbLUser = new System.Windows.Forms.RadioButton();
            this.epcrdbLUii = new System.Windows.Forms.RadioButton();
            this.epcbtnLock = new System.Windows.Forms.Button();
            this.txbLPwd = new System.Windows.Forms.TextBox();
            this.epclabel6 = new System.Windows.Forms.Label();
            this.epcgroupBox4 = new System.Windows.Forms.GroupBox();
            this.txbKillPwd = new System.Windows.Forms.TextBox();
            this.epclabel7 = new System.Windows.Forms.Label();
            this.epcbtnKillTag = new System.Windows.Forms.Button();
            this.lsvTags = new System.Windows.Forms.ListView();
            this.colNum = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colPC = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCRC = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDataLen = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colAnt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colCount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.epclabel8 = new System.Windows.Forms.Label();
            this.epcbtnClear = new System.Windows.Forms.Button();
            this.epcbtnSave = new System.Windows.Forms.Button();
            this.sfd = new System.Windows.Forms.SaveFileDialog();
            this.EpcgroupBox1 = new System.Windows.Forms.GroupBox();
            this.epcckbSelTag = new System.Windows.Forms.CheckBox();
            this.epcbtnSelectTag = new System.Windows.Forms.Button();
            this.txbCode = new System.Windows.Forms.TextBox();
            this.cmbTags = new System.Windows.Forms.ComboBox();
            this.epclabel1 = new System.Windows.Forms.Label();
            this.epcgroupBox2.SuspendLayout();
            this.epcgroupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.epcgroupBox4.SuspendLayout();
            this.EpcgroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // epcgroupBox2
            // 
            this.epcgroupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.epcgroupBox2.Controls.Add(this.epcbtnRead);
            this.epcgroupBox2.Controls.Add(this.epcbtnWrite);
            this.epcgroupBox2.Controls.Add(this.txbRWPwd);
            this.epcgroupBox2.Controls.Add(this.txbWData);
            this.epcgroupBox2.Controls.Add(this.txbRWLen);
            this.epcgroupBox2.Controls.Add(this.txbRWWordPtr);
            this.epcgroupBox2.Controls.Add(this.epcrdbRWUser);
            this.epcgroupBox2.Controls.Add(this.epcrdbRWTid);
            this.epcgroupBox2.Controls.Add(this.epcrdbRWUii);
            this.epcgroupBox2.Controls.Add(this.epcrdbRWRsv);
            this.epcgroupBox2.Controls.Add(this.epclabel5);
            this.epcgroupBox2.Controls.Add(this.epclabel2);
            this.epcgroupBox2.Controls.Add(this.epclabel4);
            this.epcgroupBox2.Controls.Add(this.epclabel3);
            this.epcgroupBox2.Location = new System.Drawing.Point(3, 57);
            this.epcgroupBox2.Name = "epcgroupBox2";
            this.epcgroupBox2.Size = new System.Drawing.Size(792, 82);
            this.epcgroupBox2.TabIndex = 1;
            this.epcgroupBox2.TabStop = false;
            this.epcgroupBox2.Text = "读写数据";
            // 
            // epcbtnRead
            // 
            this.epcbtnRead.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.epcbtnRead.Location = new System.Drawing.Point(721, 14);
            this.epcbtnRead.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.epcbtnRead.Name = "epcbtnRead";
            this.epcbtnRead.Size = new System.Drawing.Size(63, 28);
            this.epcbtnRead.TabIndex = 12;
            this.epcbtnRead.Text = "读标签";
            this.epcbtnRead.UseVisualStyleBackColor = true;
            this.epcbtnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // epcbtnWrite
            // 
            this.epcbtnWrite.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.epcbtnWrite.Location = new System.Drawing.Point(721, 47);
            this.epcbtnWrite.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.epcbtnWrite.Name = "epcbtnWrite";
            this.epcbtnWrite.Size = new System.Drawing.Size(63, 28);
            this.epcbtnWrite.TabIndex = 13;
            this.epcbtnWrite.Text = "写标签";
            this.epcbtnWrite.UseVisualStyleBackColor = true;
            this.epcbtnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // txbRWPwd
            // 
            this.txbRWPwd.Location = new System.Drawing.Point(390, 19);
            this.txbRWPwd.MaxLength = 11;
            this.txbRWPwd.Name = "txbRWPwd";
            this.txbRWPwd.Size = new System.Drawing.Size(72, 21);
            this.txbRWPwd.TabIndex = 5;
            this.txbRWPwd.Text = "00 00 00 00";
            this.txbRWPwd.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            this.txbRWPwd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_KeyDown);
            // 
            // txbWData
            // 
            this.txbWData.Location = new System.Drawing.Point(85, 52);
            this.txbWData.Name = "txbWData";
            this.txbWData.Size = new System.Drawing.Size(672, 21);
            this.txbWData.TabIndex = 11;
            this.txbWData.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            this.txbWData.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_KeyDown);
            // 
            // txbRWLen
            // 
            this.txbRWLen.Location = new System.Drawing.Point(719, 19);
            this.txbRWLen.Name = "txbRWLen";
            this.txbRWLen.Size = new System.Drawing.Size(37, 21);
            this.txbRWLen.TabIndex = 9;
            this.txbRWLen.Text = "2";
            // 
            // txbRWWordPtr
            // 
            this.txbRWWordPtr.Location = new System.Drawing.Point(574, 19);
            this.txbRWWordPtr.MaxLength = 4;
            this.txbRWWordPtr.Name = "txbRWWordPtr";
            this.txbRWWordPtr.Size = new System.Drawing.Size(37, 21);
            this.txbRWWordPtr.TabIndex = 7;
            this.txbRWWordPtr.Text = "2";
            // 
            // epcrdbRWUser
            // 
            this.epcrdbRWUser.AutoSize = true;
            this.epcrdbRWUser.Location = new System.Drawing.Point(219, 20);
            this.epcrdbRWUser.Name = "epcrdbRWUser";
            this.epcrdbRWUser.Size = new System.Drawing.Size(59, 16);
            this.epcrdbRWUser.TabIndex = 3;
            this.epcrdbRWUser.Text = "User区";
            this.epcrdbRWUser.UseVisualStyleBackColor = true;
            // 
            // epcrdbRWTid
            // 
            this.epcrdbRWTid.AutoSize = true;
            this.epcrdbRWTid.Location = new System.Drawing.Point(152, 20);
            this.epcrdbRWTid.Name = "epcrdbRWTid";
            this.epcrdbRWTid.Size = new System.Drawing.Size(53, 16);
            this.epcrdbRWTid.TabIndex = 2;
            this.epcrdbRWTid.Text = "TID区";
            this.epcrdbRWTid.UseVisualStyleBackColor = true;
            // 
            // epcrdbRWUii
            // 
            this.epcrdbRWUii.AutoSize = true;
            this.epcrdbRWUii.Checked = true;
            this.epcrdbRWUii.Location = new System.Drawing.Point(86, 20);
            this.epcrdbRWUii.Name = "epcrdbRWUii";
            this.epcrdbRWUii.Size = new System.Drawing.Size(53, 16);
            this.epcrdbRWUii.TabIndex = 1;
            this.epcrdbRWUii.TabStop = true;
            this.epcrdbRWUii.Text = "UII区";
            this.epcrdbRWUii.UseVisualStyleBackColor = true;
            // 
            // epcrdbRWRsv
            // 
            this.epcrdbRWRsv.AutoSize = true;
            this.epcrdbRWRsv.Location = new System.Drawing.Point(14, 20);
            this.epcrdbRWRsv.Name = "epcrdbRWRsv";
            this.epcrdbRWRsv.Size = new System.Drawing.Size(59, 16);
            this.epcrdbRWRsv.TabIndex = 0;
            this.epcrdbRWRsv.Text = "密码区";
            this.epcrdbRWRsv.UseVisualStyleBackColor = true;
            // 
            // epclabel5
            // 
            this.epclabel5.AutoSize = true;
            this.epclabel5.Location = new System.Drawing.Point(14, 55);
            this.epclabel5.Name = "epclabel5";
            this.epclabel5.Size = new System.Drawing.Size(65, 12);
            this.epclabel5.TabIndex = 10;
            this.epclabel5.Text = "写入数据：";
            // 
            // epclabel2
            // 
            this.epclabel2.AutoSize = true;
            this.epclabel2.Location = new System.Drawing.Point(279, 22);
            this.epclabel2.Name = "epclabel2";
            this.epclabel2.Size = new System.Drawing.Size(95, 12);
            this.epclabel2.TabIndex = 4;
            this.epclabel2.Text = "访问密码(HEX)：";
            // 
            // epclabel4
            // 
            this.epclabel4.AutoSize = true;
            this.epclabel4.Location = new System.Drawing.Point(616, 22);
            this.epclabel4.Name = "epclabel4";
            this.epclabel4.Size = new System.Drawing.Size(101, 12);
            this.epclabel4.TabIndex = 8;
            this.epclabel4.Text = "数据长度(WORD)：";
            // 
            // epclabel3
            // 
            this.epclabel3.AutoSize = true;
            this.epclabel3.Location = new System.Drawing.Point(466, 22);
            this.epclabel3.Name = "epclabel3";
            this.epclabel3.Size = new System.Drawing.Size(101, 12);
            this.epclabel3.TabIndex = 6;
            this.epclabel3.Text = "起始地址(WORD)：";
            // 
            // epcgroupBox3
            // 
            this.epcgroupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.epcgroupBox3.Controls.Add(this.groupBox2);
            this.epcgroupBox3.Controls.Add(this.groupBox1);
            this.epcgroupBox3.Controls.Add(this.epcbtnLock);
            this.epcgroupBox3.Controls.Add(this.txbLPwd);
            this.epcgroupBox3.Controls.Add(this.epclabel6);
            this.epcgroupBox3.Location = new System.Drawing.Point(3, 145);
            this.epcgroupBox3.Name = "epcgroupBox3";
            this.epcgroupBox3.Size = new System.Drawing.Size(792, 89);
            this.epcgroupBox3.TabIndex = 2;
            this.epcgroupBox3.TabStop = false;
            this.epcgroupBox3.Text = "设置锁定状态";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.epcrdbLOpen);
            this.groupBox2.Controls.Add(this.epcrdbLPLock);
            this.groupBox2.Controls.Add(this.epcrdbLLock);
            this.groupBox2.Controls.Add(this.epcrdbLPOpen);
            this.groupBox2.Location = new System.Drawing.Point(14, 47);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(496, 36);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // epcrdbLOpen
            // 
            this.epcrdbLOpen.AutoSize = true;
            this.epcrdbLOpen.Checked = true;
            this.epcrdbLOpen.Location = new System.Drawing.Point(6, 13);
            this.epcrdbLOpen.Name = "epcrdbLOpen";
            this.epcrdbLOpen.Size = new System.Drawing.Size(47, 16);
            this.epcrdbLOpen.TabIndex = 0;
            this.epcrdbLOpen.TabStop = true;
            this.epcrdbLOpen.Text = "开放";
            this.epcrdbLOpen.UseVisualStyleBackColor = true;
            // 
            // epcrdbLPLock
            // 
            this.epcrdbLPLock.AutoSize = true;
            this.epcrdbLPLock.Location = new System.Drawing.Point(352, 13);
            this.epcrdbLPLock.Name = "epcrdbLPLock";
            this.epcrdbLPLock.Size = new System.Drawing.Size(71, 16);
            this.epcrdbLPLock.TabIndex = 3;
            this.epcrdbLPLock.Text = "永久锁定";
            this.epcrdbLPLock.UseVisualStyleBackColor = true;
            // 
            // epcrdbLLock
            // 
            this.epcrdbLLock.AutoSize = true;
            this.epcrdbLLock.Location = new System.Drawing.Point(114, 13);
            this.epcrdbLLock.Name = "epcrdbLLock";
            this.epcrdbLLock.Size = new System.Drawing.Size(47, 16);
            this.epcrdbLLock.TabIndex = 1;
            this.epcrdbLLock.Text = "锁定";
            this.epcrdbLLock.UseVisualStyleBackColor = true;
            // 
            // epcrdbLPOpen
            // 
            this.epcrdbLPOpen.AutoSize = true;
            this.epcrdbLPOpen.Location = new System.Drawing.Point(222, 13);
            this.epcrdbLPOpen.Name = "epcrdbLPOpen";
            this.epcrdbLPOpen.Size = new System.Drawing.Size(71, 16);
            this.epcrdbLPOpen.TabIndex = 2;
            this.epcrdbLPOpen.Text = "永久开放";
            this.epcrdbLPOpen.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.epcrdbLAccPwd);
            this.groupBox1.Controls.Add(this.epcrdbLTid);
            this.groupBox1.Controls.Add(this.epcrdbLKillPwd);
            this.groupBox1.Controls.Add(this.epcrdbLUser);
            this.groupBox1.Controls.Add(this.epcrdbLUii);
            this.groupBox1.Location = new System.Drawing.Point(14, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(496, 36);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // epcrdbLAccPwd
            // 
            this.epcrdbLAccPwd.AutoSize = true;
            this.epcrdbLAccPwd.Location = new System.Drawing.Point(6, 13);
            this.epcrdbLAccPwd.Name = "epcrdbLAccPwd";
            this.epcrdbLAccPwd.Size = new System.Drawing.Size(83, 16);
            this.epcrdbLAccPwd.TabIndex = 0;
            this.epcrdbLAccPwd.Text = "访问密码区";
            this.epcrdbLAccPwd.UseVisualStyleBackColor = true;
            // 
            // epcrdbLTid
            // 
            this.epcrdbLTid.AutoSize = true;
            this.epcrdbLTid.Location = new System.Drawing.Point(287, 13);
            this.epcrdbLTid.Name = "epcrdbLTid";
            this.epcrdbLTid.Size = new System.Drawing.Size(53, 16);
            this.epcrdbLTid.TabIndex = 3;
            this.epcrdbLTid.Text = "TID区";
            this.epcrdbLTid.UseVisualStyleBackColor = true;
            // 
            // epcrdbLKillPwd
            // 
            this.epcrdbLKillPwd.AutoSize = true;
            this.epcrdbLKillPwd.Location = new System.Drawing.Point(109, 13);
            this.epcrdbLKillPwd.Name = "epcrdbLKillPwd";
            this.epcrdbLKillPwd.Size = new System.Drawing.Size(83, 16);
            this.epcrdbLKillPwd.TabIndex = 1;
            this.epcrdbLKillPwd.Text = "灭活密码区";
            this.epcrdbLKillPwd.UseVisualStyleBackColor = true;
            // 
            // epcrdbLUser
            // 
            this.epcrdbLUser.AutoSize = true;
            this.epcrdbLUser.Location = new System.Drawing.Point(363, 13);
            this.epcrdbLUser.Name = "epcrdbLUser";
            this.epcrdbLUser.Size = new System.Drawing.Size(59, 16);
            this.epcrdbLUser.TabIndex = 4;
            this.epcrdbLUser.Text = "User区";
            this.epcrdbLUser.UseVisualStyleBackColor = true;
            // 
            // epcrdbLUii
            // 
            this.epcrdbLUii.AutoSize = true;
            this.epcrdbLUii.Checked = true;
            this.epcrdbLUii.Location = new System.Drawing.Point(212, 13);
            this.epcrdbLUii.Name = "epcrdbLUii";
            this.epcrdbLUii.Size = new System.Drawing.Size(53, 16);
            this.epcrdbLUii.TabIndex = 2;
            this.epcrdbLUii.TabStop = true;
            this.epcrdbLUii.Text = "UII区";
            this.epcrdbLUii.UseVisualStyleBackColor = true;
            // 
            // epcbtnLock
            // 
            this.epcbtnLock.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.epcbtnLock.Location = new System.Drawing.Point(721, 25);
            this.epcbtnLock.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.epcbtnLock.Name = "epcbtnLock";
            this.epcbtnLock.Size = new System.Drawing.Size(63, 28);
            this.epcbtnLock.TabIndex = 4;
            this.epcbtnLock.Text = "锁定标签";
            this.epcbtnLock.UseVisualStyleBackColor = true;
            this.epcbtnLock.Click += new System.EventHandler(this.btnLock_Click);
            // 
            // txbLPwd
            // 
            this.txbLPwd.Location = new System.Drawing.Point(678, 30);
            this.txbLPwd.MaxLength = 11;
            this.txbLPwd.Name = "txbLPwd";
            this.txbLPwd.Size = new System.Drawing.Size(78, 21);
            this.txbLPwd.TabIndex = 3;
            this.txbLPwd.Text = "00 00 00 00";
            this.txbLPwd.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            this.txbLPwd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_KeyDown);
            // 
            // epclabel6
            // 
            this.epclabel6.AutoSize = true;
            this.epclabel6.Location = new System.Drawing.Point(560, 33);
            this.epclabel6.Name = "epclabel6";
            this.epclabel6.Size = new System.Drawing.Size(95, 12);
            this.epclabel6.TabIndex = 2;
            this.epclabel6.Text = "访问口令(HEX)：";
            // 
            // epcgroupBox4
            // 
            this.epcgroupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.epcgroupBox4.Controls.Add(this.txbKillPwd);
            this.epcgroupBox4.Controls.Add(this.epclabel7);
            this.epcgroupBox4.Controls.Add(this.epcbtnKillTag);
            this.epcgroupBox4.Location = new System.Drawing.Point(3, 238);
            this.epcgroupBox4.Name = "epcgroupBox4";
            this.epcgroupBox4.Size = new System.Drawing.Size(792, 50);
            this.epcgroupBox4.TabIndex = 3;
            this.epcgroupBox4.TabStop = false;
            this.epcgroupBox4.Text = "灭活标签";
            // 
            // txbKillPwd
            // 
            this.txbKillPwd.Location = new System.Drawing.Point(680, 20);
            this.txbKillPwd.MaxLength = 11;
            this.txbKillPwd.Name = "txbKillPwd";
            this.txbKillPwd.Size = new System.Drawing.Size(77, 21);
            this.txbKillPwd.TabIndex = 1;
            this.txbKillPwd.Text = "00 00 00 00";
            this.txbKillPwd.TextChanged += new System.EventHandler(this.textBox_TextChanged);
            this.txbKillPwd.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_KeyDown);
            // 
            // epclabel7
            // 
            this.epclabel7.AutoSize = true;
            this.epclabel7.Location = new System.Drawing.Point(560, 23);
            this.epclabel7.Name = "epclabel7";
            this.epclabel7.Size = new System.Drawing.Size(95, 12);
            this.epclabel7.TabIndex = 0;
            this.epclabel7.Text = "灭活口令(HEX)：";
            // 
            // epcbtnKillTag
            // 
            this.epcbtnKillTag.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.epcbtnKillTag.Location = new System.Drawing.Point(721, 15);
            this.epcbtnKillTag.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.epcbtnKillTag.Name = "epcbtnKillTag";
            this.epcbtnKillTag.Size = new System.Drawing.Size(63, 28);
            this.epcbtnKillTag.TabIndex = 2;
            this.epcbtnKillTag.Text = "灭活标签";
            this.epcbtnKillTag.UseVisualStyleBackColor = true;
            this.epcbtnKillTag.Click += new System.EventHandler(this.btnKillTag_Click);
            // 
            // lsvTags
            // 
            this.lsvTags.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lsvTags.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colNum,
            this.colPC,
            this.colCRC,
            this.colCode,
            this.colDataLen,
            this.colData,
            this.colAnt,
            this.colCount});
            this.lsvTags.FullRowSelect = true;
            this.lsvTags.HideSelection = false;
            this.lsvTags.Location = new System.Drawing.Point(3, 331);
            this.lsvTags.Name = "lsvTags";
            this.lsvTags.Size = new System.Drawing.Size(793, 127);
            this.lsvTags.TabIndex = 6;
            this.lsvTags.UseCompatibleStateImageBehavior = false;
            this.lsvTags.View = System.Windows.Forms.View.Details;
            // 
            // colNum
            // 
            this.colNum.Tag = "epccolNum";
            this.colNum.Text = "序号";
            this.colNum.Width = 65;
            // 
            // colPC
            // 
            this.colPC.Tag = "colPCe";
            this.colPC.Text = "PC";
            this.colPC.Width = 49;
            // 
            // colCRC
            // 
            this.colCRC.Tag = "epccolCRC";
            this.colCRC.Text = "CRC";
            this.colCRC.Width = 42;
            // 
            // colCode
            // 
            this.colCode.Tag = "epccolCode";
            this.colCode.Text = "UII";
            this.colCode.Width = 116;
            // 
            // colDataLen
            // 
            this.colDataLen.Tag = "epccolDataLen";
            this.colDataLen.Text = "数据长度";
            this.colDataLen.Width = 101;
            // 
            // colData
            // 
            this.colData.Tag = "epccolData";
            this.colData.Text = "数据";
            this.colData.Width = 152;
            // 
            // colAnt
            // 
            this.colAnt.Tag = "epccolAnt";
            this.colAnt.Text = "天线";
            this.colAnt.Width = 97;
            // 
            // colCount
            // 
            this.colCount.Tag = "epccolCount";
            this.colCount.Text = "数目";
            this.colCount.Width = 173;
            // 
            // epclabel8
            // 
            this.epclabel8.AutoSize = true;
            this.epclabel8.ForeColor = System.Drawing.Color.Red;
            this.epclabel8.Location = new System.Drawing.Point(7, 299);
            this.epclabel8.Name = "epclabel8";
            this.epclabel8.Size = new System.Drawing.Size(365, 12);
            this.epclabel8.TabIndex = 4;
            this.epclabel8.Text = "注意：所有口令和数据都是十六进制格式，地址和长度是十进制格式";
            // 
            // epcbtnClear
            // 
            this.epcbtnClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.epcbtnClear.Location = new System.Drawing.Point(724, 297);
            this.epcbtnClear.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.epcbtnClear.Name = "epcbtnClear";
            this.epcbtnClear.Size = new System.Drawing.Size(63, 28);
            this.epcbtnClear.TabIndex = 5;
            this.epcbtnClear.Text = "清除数据";
            this.epcbtnClear.UseVisualStyleBackColor = true;
            this.epcbtnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // epcbtnSave
            // 
            this.epcbtnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.epcbtnSave.Location = new System.Drawing.Point(643, 300);
            this.epcbtnSave.Name = "epcbtnSave";
            this.epcbtnSave.Size = new System.Drawing.Size(75, 23);
            this.epcbtnSave.TabIndex = 42;
            this.epcbtnSave.Text = "导出数据";
            this.epcbtnSave.UseVisualStyleBackColor = true;
            this.epcbtnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // sfd
            // 
            this.sfd.Filter = "*.txt|*.txt|*.*|*.*";
            // 
            // EpcgroupBox1
            // 
            this.EpcgroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.EpcgroupBox1.Controls.Add(this.epcckbSelTag);
            this.EpcgroupBox1.Controls.Add(this.epcbtnSelectTag);
            this.EpcgroupBox1.Controls.Add(this.txbCode);
            this.EpcgroupBox1.Controls.Add(this.cmbTags);
            this.EpcgroupBox1.Controls.Add(this.epclabel1);
            this.EpcgroupBox1.Location = new System.Drawing.Point(3, 3);
            this.EpcgroupBox1.Name = "EpcgroupBox1";
            this.EpcgroupBox1.Size = new System.Drawing.Size(792, 49);
            this.EpcgroupBox1.TabIndex = 43;
            this.EpcgroupBox1.TabStop = false;
            this.EpcgroupBox1.Text = "选定标签操作";
            // 
            // epcckbSelTag
            // 
            this.epcckbSelTag.AutoSize = true;
            this.epcckbSelTag.Location = new System.Drawing.Point(14, 22);
            this.epcckbSelTag.Name = "epcckbSelTag";
            this.epcckbSelTag.Size = new System.Drawing.Size(96, 16);
            this.epcckbSelTag.TabIndex = 0;
            this.epcckbSelTag.Text = "已选定标签：";
            this.epcckbSelTag.UseVisualStyleBackColor = true;
            this.epcckbSelTag.CheckedChanged += new System.EventHandler(this.ckbSelTag_CheckedChanged);
            // 
            // epcbtnSelectTag
            // 
            this.epcbtnSelectTag.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.epcbtnSelectTag.Location = new System.Drawing.Point(721, 15);
            this.epcbtnSelectTag.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.epcbtnSelectTag.Name = "epcbtnSelectTag";
            this.epcbtnSelectTag.Size = new System.Drawing.Size(63, 28);
            this.epcbtnSelectTag.TabIndex = 4;
            this.epcbtnSelectTag.Text = "选定标签";
            this.epcbtnSelectTag.UseVisualStyleBackColor = true;
            this.epcbtnSelectTag.Click += new System.EventHandler(this.btnSelectTag_Click);
            // 
            // txbCode
            // 
            this.txbCode.Location = new System.Drawing.Point(116, 20);
            this.txbCode.Name = "txbCode";
            this.txbCode.ReadOnly = true;
            this.txbCode.Size = new System.Drawing.Size(250, 21);
            this.txbCode.TabIndex = 1;
            // 
            // cmbTags
            // 
            this.cmbTags.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTags.FormattingEnabled = true;
            this.cmbTags.Location = new System.Drawing.Point(484, 20);
            this.cmbTags.Name = "cmbTags";
            this.cmbTags.Size = new System.Drawing.Size(272, 20);
            this.cmbTags.TabIndex = 3;
            this.cmbTags.DropDown += new System.EventHandler(this.cmbTags_DropDown);
            // 
            // epclabel1
            // 
            this.epclabel1.AutoSize = true;
            this.epclabel1.Location = new System.Drawing.Point(400, 23);
            this.epclabel1.Name = "epclabel1";
            this.epclabel1.Size = new System.Drawing.Size(65, 12);
            this.epclabel1.TabIndex = 2;
            this.epclabel1.Text = "标签列表：";
            // 
            // EpcPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.EpcgroupBox1);
            this.Controls.Add(this.epcbtnSave);
            this.Controls.Add(this.epclabel8);
            this.Controls.Add(this.lsvTags);
            this.Controls.Add(this.epcbtnClear);
            this.Controls.Add(this.epcgroupBox4);
            this.Controls.Add(this.epcgroupBox3);
            this.Controls.Add(this.epcgroupBox2);
            this.Name = "EpcPanel";
            this.Size = new System.Drawing.Size(799, 461);
            this.Load += new System.EventHandler(this.EpcPanel_Load);
            this.epcgroupBox2.ResumeLayout(false);
            this.epcgroupBox2.PerformLayout();
            this.epcgroupBox3.ResumeLayout(false);
            this.epcgroupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.epcgroupBox4.ResumeLayout(false);
            this.epcgroupBox4.PerformLayout();
            this.EpcgroupBox1.ResumeLayout(false);
            this.EpcgroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox epcgroupBox2;
        private System.Windows.Forms.Button epcbtnRead;
        private System.Windows.Forms.Button epcbtnWrite;
        private System.Windows.Forms.TextBox txbRWPwd;
        private System.Windows.Forms.TextBox txbRWLen;
        private System.Windows.Forms.TextBox txbRWWordPtr;
        private System.Windows.Forms.RadioButton epcrdbRWUser;
        private System.Windows.Forms.RadioButton epcrdbRWTid;
        private System.Windows.Forms.RadioButton epcrdbRWUii;
        private System.Windows.Forms.RadioButton epcrdbRWRsv;
        private System.Windows.Forms.Label epclabel5;
        private System.Windows.Forms.Label epclabel2;
        private System.Windows.Forms.Label epclabel4;
        private System.Windows.Forms.Label epclabel3;
        private System.Windows.Forms.TextBox txbWData;
        private System.Windows.Forms.GroupBox epcgroupBox3;
        private System.Windows.Forms.Button epcbtnLock;
        private System.Windows.Forms.TextBox txbLPwd;
        private System.Windows.Forms.Label epclabel6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton epcrdbLOpen;
        private System.Windows.Forms.RadioButton epcrdbLPLock;
        private System.Windows.Forms.RadioButton epcrdbLLock;
        private System.Windows.Forms.RadioButton epcrdbLPOpen;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton epcrdbLAccPwd;
        private System.Windows.Forms.RadioButton epcrdbLTid;
        private System.Windows.Forms.RadioButton epcrdbLKillPwd;
        private System.Windows.Forms.RadioButton epcrdbLUser;
        private System.Windows.Forms.RadioButton epcrdbLUii;
        private System.Windows.Forms.GroupBox epcgroupBox4;
        private System.Windows.Forms.TextBox txbKillPwd;
        private System.Windows.Forms.Label epclabel7;
        private System.Windows.Forms.Button epcbtnKillTag;
        private System.Windows.Forms.ListView lsvTags;
        private System.Windows.Forms.ColumnHeader colNum;
        private System.Windows.Forms.ColumnHeader colCode;
        private System.Windows.Forms.ColumnHeader colPC;
        private System.Windows.Forms.ColumnHeader colCount;
        private System.Windows.Forms.ColumnHeader colDataLen;
        private System.Windows.Forms.ColumnHeader colData;
        private System.Windows.Forms.ColumnHeader colCRC;
        private System.Windows.Forms.Label epclabel8;
        private System.Windows.Forms.Button epcbtnClear;
        private System.Windows.Forms.ColumnHeader colAnt;
        private System.Windows.Forms.Button epcbtnSave;
        private System.Windows.Forms.SaveFileDialog sfd;
        private System.Windows.Forms.GroupBox EpcgroupBox1;
        private System.Windows.Forms.CheckBox epcckbSelTag;
        private System.Windows.Forms.Button epcbtnSelectTag;
        private System.Windows.Forms.TextBox txbCode;
        private System.Windows.Forms.ComboBox cmbTags;
        private System.Windows.Forms.Label epclabel1;
    }
}
