using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace YYF100
{
    public partial class FrmPrompt : Form
    {

        // 父窗口
        RFPanel m_owner = null;

        internal void SetOwner(RFPanel owner)
        {
            m_owner = owner;
        }

        public Hashtable ht
        {
            get { return (m_owner == null ? null : m_owner.HT); }
        }

        public string PromptText
        {
            get { return label1.Text; }
            set { label1.Text = value; }
        }

        public string FormText
        {
            get { return this.Text; }
            set { this.Text = value; }
        }



        public FrmPrompt()
        {
            InitializeComponent();
        }

        private void FrmPrompt_Load(object sender, EventArgs e)
        {
            try
            {
                CenterToParent();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }
    }
}
