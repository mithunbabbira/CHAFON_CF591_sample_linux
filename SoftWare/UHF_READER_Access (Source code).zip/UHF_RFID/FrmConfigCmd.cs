using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace YYF100
{
    public partial class FrmConfigCmd : Form
    {
        // 十六进制编辑时，数据中间的间隔字符
        private static readonly char[] s_arrSplit = new char[] { ' ', '\t' };

        // 测试命令项列表
        TestCmdItem[] m_testCmds;

        // 当前是否正在处理十斤进制格式化输入
        bool m_bChangeText = false;

        /// <summary>
        /// 测试命令项列表
        /// </summary>
        public TestCmdItem[] TestCmds
        {
            get { return m_testCmds; }
        }

        public FrmConfigCmd(TestCmdItem[] items)
        {
            m_testCmds = items;
            InitializeComponent();
            cmbPrmType.SelectedIndex = 0;
        }

        private void FrmConfigCmd_Load(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < m_testCmds.Length; i++)
                {
                    ListViewItem lvItem = lsvCmds.Items.Add(i.ToString());
                    TestCmdItem item = m_testCmds[i];
                    lvItem.Tag = item;
                    lvItem.SubItems.Add(item.Name);
                    lvItem.SubItems.Add("0x" + item.Cmd.ToString("X02"));
                    lvItem.SubItems.Add(item.IsAscii ? "ASCII码" : "十六进制");
                    lvItem.SubItems.Add(item.ParamStr);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void lsvCmds_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (lsvCmds.SelectedItems.Count == 0)
                    return;
                TestCmdItem item = lsvCmds.SelectedItems[0].Tag as TestCmdItem;
                if (item == null)
                    return;

                txbName.Text = item.Name;
                txbCmd.Text = "0x" + item.Cmd.ToString("X02");
                cmbPrmType.SelectedIndex = item.IsAscii ? 1 : 0;
                txbParam.Text = item.ParamStr;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void txbParam_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (m_bChangeText)
                    return;
                if (cmbPrmType.SelectedIndex == 0)
                {
                    TextBox txb = sender as TextBox;
                    if (txb == null)
                        return;
                    m_bChangeText = true;

                    FormatText(txb);
                }
                m_bChangeText = false;
            }
            catch (Exception ex)
            {
                m_bChangeText = false;
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void txbParam_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (m_bChangeText)
                    return;
                if (cmbPrmType.SelectedIndex == 0)
                {
                    TextBox txb = sender as TextBox;
                    if (txb == null || txb.SelectionLength > 0)
                        return;
                    m_bChangeText = true;

                    if (e.KeyCode == Keys.Delete)
                    {
                        int pos = txb.SelectionStart;
                        if (pos + 1 < txb.TextLength && txb.Text[pos] == ' ')
                        {
                            e.Handled = true;
                            txb.Text = txb.Text.Remove(pos + 1, 1);
                            txb.SelectionStart = pos;
                            //FormatText(txb);
                        }
                    }
                    else if (e.KeyCode == Keys.Back)
                    {
                        int pos = txb.SelectionStart;
                        if (pos > 1 && pos <= txb.TextLength && txb.Text[pos - 1] == ' ')
                        {
                            e.Handled = true;
                            txb.Text = txb.Text.Remove(pos - 2, 1);
                            txb.SelectionStart = pos - 1;
                            //FormatText(txb);
                        }
                    }
                }
                m_bChangeText = false;
            }
            catch (Exception ex)
            {
                m_bChangeText = false;
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void FormatText(TextBox txb)
        {
            string text = txb.Text;
            bool needFormat = false;
            for (int i = 0, l = 0; i < text.Length; i++)
            {
                int j = 0;
                for (; j < s_arrSplit.Length && s_arrSplit[j] != text[i]; j++) ;
                if (j >= s_arrSplit.Length)
                {
                    l++;
                    if (l > 2)
                    {
                        needFormat = true;
                        break;
                    }
                }
                else
                    l = 0;
            }
            if (needFormat)
            {
                if (txb.SelectionLength > 0)
                {
                    int pos = int.MaxValue;
                    text = Util.FormatHexString(text, ref pos);
                    txb.Text = text;
                    txb.SelectionStart = text.Length;
                    txb.SelectionLength = 0;
                }
                else
                {
                    int pos = txb.SelectionStart;
                    txb.Text = Util.FormatHexString(text, ref pos);
                    txb.SelectionStart = pos;
                    txb.SelectionLength = 0;
                }
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string name = txbName.Text.Trim();
                if (name.Length == 0)
                {
                    MessageBox.Show(this, "请输入命令名称", this.Text);
                    return;
                }
                if (name.IndexOf('-') >= 0)
                {
                    MessageBox.Show(this, "命令名称中不能包含字符 '-'，请用 '_' 或其他字符代替", this.Text);
                    return;
                }
                string cmd = txbCmd.Text.Trim();
                int cmd2 = Util.HexFromString(cmd);
                if (cmd2 > 0xFF)
                {
                    MessageBox.Show(this, "命令码超出范围：0x00 - 0xFF", this.Text);
                    return;
                }
                bool bIsAscii = cmbPrmType.SelectedIndex == 1;
                byte[] param = bIsAscii ? Encoding.Default.GetBytes(txbParam.Text.Trim()) : Util.HexArrayFromString(txbParam.Text.Trim());

                TestCmdItem item = new TestCmdItem(name, (byte)cmd2, bIsAscii, param);
                ListViewItem lvItem = lsvCmds.Items.Add(lsvCmds.Items.Count.ToString());
                lvItem.Tag = item;
                lvItem.SubItems.Add(item.Name);
                lvItem.SubItems.Add("0x" + item.Cmd.ToString("X02"));
                lvItem.SubItems.Add(item.IsAscii ? "ASCII码" : "十六进制");
                lvItem.SubItems.Add(item.ParamStr);
                lsvCmds.EnsureVisible(lsvCmds.Items.Count - 1);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            try
            {
                if (lsvCmds.SelectedItems.Count == 0)
                {
                    MessageBox.Show(this, "请先选择需要修改的项", this.Text);
                    return;
                }
                ListViewItem lvItem = lsvCmds.SelectedItems[0];
                TestCmdItem item = lvItem.Tag as TestCmdItem;
                if (item == null)
                    return;

                string name = txbName.Text.Trim();
                if (name.Length == 0)
                {
                    MessageBox.Show(this, "请输入命令名称", this.Text);
                    return;
                }
                if (name.IndexOf('-') >= 0)
                {
                    MessageBox.Show(this, "命令名称中不能包含字符 '-'，请用 '_' 或其他字符代替", this.Text);
                    return;
                }
                string cmd = txbCmd.Text.Trim();
                int cmd2 = Util.HexFromString(cmd);
                if (cmd2 > 0xFF)
                {
                    MessageBox.Show(this, "命令码超出范围：0x00 - 0xFF", this.Text);
                    return;
                }
                bool bIsAscii = cmbPrmType.SelectedIndex == 1;
                byte[] param = bIsAscii ? Encoding.Default.GetBytes(txbParam.Text.Trim()) : Util.HexArrayFromString(txbParam.Text.Trim());

                // 如果命令项已经添加至 '测试命令项列表' 中，则生成新的命令项，否则修改命令项数据
                // （该设计是为防止用户点击该窗口的取消按钮放弃保存数据时，防止原 '测试命令项列表' 数据被修改）
                if (item.IsAdded)
                {
                    item = new TestCmdItem(name, (byte)cmd2, bIsAscii, param);
                    lvItem.Tag = item;
                }
                else
                {
                    item.Name = name;
                    item.Cmd = (byte)cmd2;
                    item.IsAscii = bIsAscii;
                    item.SetParam(param);
                }

                lvItem.SubItems[1].Text = item.Name;
                lvItem.SubItems[2].Text = "0x" + item.Cmd.ToString("X02");
                lvItem.SubItems[3].Text = item.IsAscii ? "ASCII码" : "十六进制";
                lvItem.SubItems[4].Text = item.ParamStr;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (lsvCmds.SelectedItems.Count == 0)
                {
                    MessageBox.Show(this, "请先选择需要删除的项", this.Text);
                    return;
                }
                ListViewItem lvItem = lsvCmds.SelectedItems[0];
                int index = lvItem.Index;
                lsvCmds.Items.Remove(lvItem);
                for (int i = index; i < lsvCmds.Items.Count; i++)
                {
                    lsvCmds.Items[i].Text = i.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            try
            {
                lsvCmds.Items.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnMoveUp_Click(object sender, EventArgs e)
        {
            try
            {
                if (lsvCmds.SelectedItems.Count == 0)
                {
                    MessageBox.Show(this, "请先选择需要移动的项", this.Text);
                    return;
                }
                ListViewItem lvItem = lsvCmds.SelectedItems[0];
                int index = lvItem.Index;
                if (index == 0)
                    return;
                lsvCmds.Items.Remove(lvItem);
                lsvCmds.Items.Insert(index - 1, lvItem);
                lsvCmds.Items[index - 1].Text = (index - 1).ToString();
                lsvCmds.Items[index].Text = index.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnMoveDown_Click(object sender, EventArgs e)
        {
            try
            {
                if (lsvCmds.SelectedItems.Count == 0)
                {
                    MessageBox.Show(this, "请先选择需要移动的项", this.Text);
                    return;
                }
                ListViewItem lvItem = lsvCmds.SelectedItems[0];
                int index = lvItem.Index;
                if (index + 1 >= lsvCmds.Items.Count)
                    return;
                lsvCmds.Items.Remove(lvItem);
                lsvCmds.Items.Insert(index + 1, lvItem);
                lsvCmds.Items[index].Text = index.ToString();
                lsvCmds.Items[index + 1].Text = (index + 1).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                if (lsvCmds.Items.Count == 0)
                {
                    m_testCmds = TestCmdItem.EmptyArray;
                    this.DialogResult = DialogResult.OK;
                    return;
                }

                TestCmdItem[] items = new TestCmdItem[lsvCmds.Items.Count];
                for (int i = 0; i < items.Length; i++)
                {
                    items[i] = lsvCmds.Items[i].Tag as TestCmdItem;
                }
                m_testCmds = items;
                
                for (int i = 0; i < m_testCmds.Length; i++)
                {
                    m_testCmds[i].IsAdded = true;
                }
                this.DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }
    }
}
