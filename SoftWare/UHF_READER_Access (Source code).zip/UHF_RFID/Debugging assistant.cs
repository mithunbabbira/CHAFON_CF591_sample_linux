﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using UHF_RFID_Net;


namespace YYF100
{
    public partial class Debugging_assistant : UserControl
    {
        public Debugging_assistant()
        {
            InitializeComponent();
            TextBox.CheckForIllegalCrossThreadCalls = false;
        }
        RFPanel m_owner = null;

        public Reader Reader
        {
            get { return (m_owner == null ? null : m_owner.Reader); }
        }
        internal void SetOwner(RFPanel owner)
        {
            m_owner = owner;
        }

        private void WriteLog(MessageType type, string msg, Exception ex)
        {
            if (m_owner != null)
                m_owner.WriteLog(type, msg, ex);
        }

        // 当前是否正在处理十进制格式化输入
        bool m_bChangeText = false;
        private static readonly char[] s_arrSplit = new char[] { ' ', '\t' };

        Thread threadWatch = null; //负责监听客户端的线程
        Thread threadRcve = null; //负责监听客户端的线程
        Socket socketWatch = null; //负责监听客户端的套接字     

        Dictionary<string, Socket> dict = new Dictionary<string, Socket>(); //套接字集合
        Dictionary<string, Thread> dictThread = new Dictionary<string, Thread>();  //线程集合
        IPEndPoint Localippoint;

        /// <summary>
        /// 启动服务
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnServerConn_Click(object sender, EventArgs e)
        {
            try
            {

                if (socketWatch != null && Localippoint != null)
                {
                    if (string.Equals(Localippoint.Address.ToString(), this.txtIP.Text.Trim().ToString())  && string.Equals(Localippoint.Port.ToString(), this.txtPort.Text.Trim().ToString()))
                    {
                        //重复的本地ip和port，不再绑定socket
                    }
                    else
                    {
                        socConnection = null;
                        socketWatch.Close();
                        //定义一个套接字用于监听客户端发来的信息 包含3个参数(IP4寻址协议,流式连接,TCP协议)
                        socketWatch = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                        //服务端发送信息 需要1个IP地址和端口号              
                        IPAddress ipaddress = IPAddress.Parse(this.txtIP.Text.Trim());  //获取文本框输入的IP地址
                                                                                        //将IP地址和端口号绑定到网络节点endpoint上 
                        IPEndPoint endpoint = new IPEndPoint(ipaddress, int.Parse(this.txtPort.Text.Trim())); //获取文本框上输入的端口号
                                                                                                              //监听绑定的网络节点
                        socketWatch.Bind(endpoint);
                        //将套接字的监听队列长度限制为20
                        socketWatch.Listen(20);
                    }
                }
                else
                {
                    if(socketWatch!=null)
                    socketWatch.Close();
                    //定义一个套接字用于监听客户端发来的信息 包含3个参数(IP4寻址协议,流式连接,TCP协议)
                    socketWatch = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    //服务端发送信息 需要1个IP地址和端口号              
                    IPAddress ipaddress = IPAddress.Parse(this.txtIP.Text.Trim());  //获取文本框输入的IP地址
                                                                                    //将IP地址和端口号绑定到网络节点endpoint上 
                    IPEndPoint endpoint = new IPEndPoint(ipaddress, int.Parse(this.txtPort.Text.Trim())); //获取文本框上输入的端口号
                                                                                                          //监听绑定的网络节点
                    socketWatch.Bind(endpoint);
                    //将套接字的监听队列长度限制为20
                    socketWatch.Listen(20);
                }
                //创建一个监听委托
                ThreadStart ts = new ThreadStart(WatchConnecting);
                //创建一个监听线程 
                threadWatch = new Thread(ts);
                //将窗体线程设置为与后台同步
                threadWatch.IsBackground = true;
                //启动线程
                threadWatch.Start();
                //启动线程后 txtMsg文本框显示相应提示
                txtMsg.AppendText("Starts to listen for information from the client!" + "\r\n");

                this.btnServerConn.Enabled = false;
                this.btnServerDisConn.Enabled = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error：" + ex.ToString());
                txtMsg.AppendText("The server fails to start the service Procedure!" + "\r\n");
                this.btnServerConn.Enabled = true;
            }
        }

        private void btnServerDisConn_Click(object sender, EventArgs e)
        {
            //有问题
            try
            {

                if (!threadWatch.Join(500))
                    threadWatch.Abort();
                if (threadRcve != null)
                {
                    if (!threadRcve.Join(500))
                        threadRcve.Abort();
                }
                //socketWatch.Close();
                txtMsg.AppendText("End Listening for information from the client!" + "\r\n");
                this.btnServerConn.Enabled = true;
                this.btnServerDisConn.Enabled = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error：" + ex.ToString());
                txtMsg.AppendText("The server fails to shut down the service Procedure!" + "\r\n");
                this.btnServerConn.Enabled = true;
            }

        }


        //创建一个负责和客户端通信的套接字 
        Socket socConnection = null;

        /// <summary>
        /// 监听客户端发来的请求
        /// </summary>
        private void WatchConnecting()
        {
            while (true)  //持续不断监听客户端发来的请求
            {
                try
                {
                    if (socConnection != null)
                    {
                        txtMsg.AppendText(socConnection.RemoteEndPoint.ToString() + "The client is successfully connected Procedure! " + "\r\n"); //客户端IP
                        Localippoint = (IPEndPoint)socConnection.LocalEndPoint;
                        lb_ipOnline.Items.Add(socConnection.RemoteEndPoint.ToString());
                        //创建一个通信线程 
                        ParameterizedThreadStart pts = new ParameterizedThreadStart(ServerRecMsg);
                        threadRcve = new Thread(pts);
                        threadRcve.IsBackground = true;
                        //启动线程
                        threadRcve.Start(socConnection);
                    }
                    else
                    {
                        Localippoint = null;
                        socConnection = socketWatch.Accept();  //等待客户端的连接 并且创建一个负责通信的Socket    
                        dictThread.Add(socConnection.RemoteEndPoint.ToString(), threadRcve);   // 将新建的线程 添加 到线程的集合中去。
                                                                                               // 向列表控件中添加客户端的IP信息；
                        lb_ipOnline.Items.Add(socConnection.RemoteEndPoint.ToString());
                        // 将与客户端连接的 套接字 对象添加到集合中；
                        dict.Add(socConnection.RemoteEndPoint.ToString(), socConnection);
                        //txtMsg.AppendText("客户端连接成功! " + "\r\n");
                        txtMsg.AppendText(socConnection.RemoteEndPoint.ToString() + "The client is successfully connected Procedure! " + "\r\n"); //客户端IP
                        Localippoint = (IPEndPoint)socConnection.LocalEndPoint;
                        //创建一个通信线程 
                        ParameterizedThreadStart pts = new ParameterizedThreadStart(ServerRecMsg);
                        threadRcve = new Thread(pts);
                        threadRcve.IsBackground = true;
                        //启动线程
                        threadRcve.Start(socConnection);
                    }
                }
                catch (Exception ex)
                {
                    socConnection = null;
                    Console.WriteLine("Error：" + ex.ToString());
                    txtMsg.AppendText("Failed to connect to the client Procedure!" + "\r\n");
                }
                break;
            }
        }

        /// <summary>
        /// 发送信息到客户端的方法
        /// </summary>
        /// <param name="sendMsg">发送的字符串信息</param>
        private void ServerSendMsg(string sendMsg)
        {
            string strKey = "";
            try
            {
                //将输入的字符串转换成 机器可以识别的字节数组
                byte[] arrSendMsg = Encoding.UTF8.GetBytes(sendMsg);
                //向客户端发送字节数组信息
                //socConnection.Send(arrSendMsg);


                strKey = lb_ipOnline.Text.Trim();
                if (string.IsNullOrEmpty(strKey))   // 判断是不是选择了发送的对象；
                {
                    MessageBox.Show("请选择你要发送的好友！！！");
                }
                else
                {
                    dict[strKey].Send(arrSendMsg);// 解决了 sokConnection是局部变量，不能再本函数中引用的问题；

                    //将发送的字符串信息附加到文本框txtMsg上
                    txtMsg.AppendText(socConnection.LocalEndPoint.ToString() + "服务器 " + GetCurrentTime() + "\r\n" + sendMsg + "\r\n");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("错误：" + ex.ToString());
                txtMsg.AppendText(dict[strKey].RemoteEndPoint.ToString() + "客户端已断开连接,无法发送信息！" + "\r\n");
            }
        }

        /// <summary>
        /// 发送信息到客户端的方法
        /// </summary>
        /// <param name="sendMsg">发送的字符串信息</param>
        private void ServerSendMsgAll(string sendMsg)
        {

            try
            {
                //将输入的字符串转换成 机器可以识别的字节数组
                byte[] arrSendMsg = Encoding.UTF8.GetBytes(sendMsg);
                //向客户端发送字节数组信息
                //socConnection.Send(arrSendMsg);

                foreach (Socket s in dict.Values)
                {
                    //s.Send(arrMsg);
                    s.Send(arrSendMsg);
                }
                txtMsg.AppendText(socConnection.LocalEndPoint.ToString() + "服务器群发 " + GetCurrentTime() + "\r\n" + sendMsg + "\r\n");

            }
            catch (Exception ex)
            {
                Console.WriteLine("错误：" + ex.ToString());
                txtMsg.AppendText("客户端已断开连接,无法发送信息！" + "\r\n");
            }
        }


        /// <summary>
        /// 接收客户端发来的信息 
        /// </summary>
        /// <param name="socketClientPara">客户端套接字对象</param>
        private void ServerRecMsg(object socketClientPara)
        {
            Socket socketServer = socketClientPara as Socket; //类型转换 objec->Socket
            while (true)
            {
                //创建一个内存缓冲区 其大小为1024*1024字节  即1M
                byte[] arrServerRecMsg = new byte[1024 * 1024];
                try
                {
                    //将接收到的信息存入到内存缓冲区,并返回其字节数组的长度
                    int length = socketServer.Receive(arrServerRecMsg);
                    //将机器接受到的字节数组转换为人可以读懂的字符串
                    string strSRecMsg = Util.HexArrayToString(arrServerRecMsg, 0, length);
                    
                    Console.WriteLine(length);
                    if (strSRecMsg.Length != 0)
                    {
                        //将发送的字符串信息附加到文本框txtMsg上   客户端IP 时间  消息

                        txtMsg.AppendText(socketServer.RemoteEndPoint.ToString() + "Client " + GetCurrentTime() + "\r\n" + strSRecMsg + "\r\n");
                        System.Console.WriteLine(strSRecMsg);
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error：" + ex.ToString());
                    txtMsg.AppendText(socketServer.RemoteEndPoint.ToString() + "The client has been disconnected！" + "\r\n");

                    // 从 通信套接字 集合中删除被中断连接的通信套接字；
                    dict.Remove(socketServer.RemoteEndPoint.ToString());
                    // 从通信线程集合中删除被中断连接的通信线程对象；
                    dictThread.Remove(socketServer.RemoteEndPoint.ToString());
                    // 从列表中移除被中断的连接IP
                    lb_ipOnline.Items.Remove(socketServer.RemoteEndPoint.ToString());

                    break;
                }
            }
        }

        /// <summary>
        /// 发送消息到客户端
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSendMsg_Click(object sender, EventArgs e)
        {
            if (this.txtSendMsg.Text.Trim() != "")
            {
                //调用 ServerSendMsg方法  发送信息到客户端
                ServerSendMsg(this.txtSendMsg.Text.Trim()); //.Trim()是删除字符串头部及尾部出现的空格
                this.txtSendMsg.Clear();
            }
        }

        private void btnSendMsgAll_Click(object sender, EventArgs e)
        {
            if (this.txtSendMsg.Text.Trim() != "")
            {
                //调用 ServerSendMsgAll方法  群发信息到客户端
                ServerSendMsgAll(this.txtSendMsg.Text.Trim()); //.Trim()是删除字符串头部及尾部出现的空格
                this.txtSendMsg.Clear();
            }
        }


        /// <summary>
        /// 快捷键 Enter 发送信息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtSendMsg_KeyDown(object sender, KeyEventArgs e)
        {
            //如果用户按下了Enter键
            if (e.KeyCode == Keys.Enter)
            {
                //则调用 服务器向客户端发送信息的方法
                ServerSendMsg(this.txtSendMsg.Text.Trim());//.Trim()是删除字符串头部及尾部出现的空格
                this.txtSendMsg.Clear();
            }
        }



        /// <summary>
        /// 获取当前系统时间的方法
        /// </summary>
        /// <returns>当前时间</returns>
        private DateTime GetCurrentTime()
        {
            DateTime currentTime = new DateTime();
            currentTime = DateTime.Now;
            return currentTime;
        }

        /// <summary>
        /// 获取本地IPv4地址
        /// </summary>
        /// <returns></returns>
        public IPAddress GetLocalIPv4Address()
        {
            IPAddress localIpv4 = null;
            //获取本机所有的IP地址列表
            IPAddress[] IpList = Dns.GetHostAddresses(Dns.GetHostName());
            //循环遍历所有IP地址
            foreach (IPAddress IP in IpList)
            {
                //判断是否是IPv4地址
                if (IP.AddressFamily == AddressFamily.InterNetwork)
                {
                    localIpv4 = IP;
                }
                else
                {
                    continue;
                }
            }
            return localIpv4;
        }

        /// <summary>
        /// 获取本地IP事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnGetLocalIP_Click(object sender, EventArgs e)
        {
            //接收IPv4的地址
            IPAddress localIP = GetLocalIPv4Address();
            //赋值给文本框
            this.txtIP.Text = localIP.ToString();

        }

        private void Send_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                bool CmdStatus ;
                byte btStatus = 0;
                string res = "success";
                byte[] cmdarray = Util.HexArrayFromString(textBox2.Text);
                Array.Reverse(cmdarray);
                ushort cmd = BitConverter.ToUInt16(cmdarray, 0);

                byte[] payload = Util.HexArrayFromString(textBox3.Text.Trim('\0'));
                int payloadlen = payload.Length;
                if (payloadlen == 0)
                {
                    payload = Util.EmptyArray;
                }
                CmdStatus = reader.SendSingeFrame(cmd, payloadlen, payload, 5000, true);
                if (CmdStatus == true)
                {
                    int len;
                    byte[] data = new byte[1024];
                    reader.RecvSingeFrame(cmd, out btStatus, 5000,out len ,data);
                    if (btStatus == 0)
                    {
                        string strSRecMsg = Util.HexArrayToString(data, 0, len);
                        textBox4.AppendText(strSRecMsg + "\r\n");
                        WriteLog(MessageType.Info, "receive success", null);
                        res = "Send and Receive Succeed。";
                    }
                    else
                    {
                        res = "Receive fail";
                    }
                }
                MessageBox.Show(this, res, this.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Error：" + ex.Message, this.Text);
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (m_bChangeText)
                    return;
                TextBox txb = sender as TextBox;
                if (txb == null || txb.SelectionLength > 0)
                    return;
                m_bChangeText = true;

                if (e.KeyCode == Keys.Delete)
                {
                    int pos = txb.SelectionStart;
                    if (pos + 1 < txb.TextLength && txb.Text[pos] == ' ')
                    {
                        e.Handled = true;
                        txb.Text = txb.Text.Remove(pos + 1, 1);
                        txb.SelectionStart = pos;
                        //FormatText(txb);
                    }
                }
                else if (e.KeyCode == Keys.Back)
                {
                    int pos = txb.SelectionStart;
                    if (pos > 1 && pos <= txb.TextLength && txb.Text[pos - 1] == ' ')
                    {
                        e.Handled = true;
                        txb.Text = txb.Text.Remove(pos - 2, 1);
                        txb.SelectionStart = pos - 1;
                        //FormatText(txb);
                    }
                }

                m_bChangeText = false;
            }
            catch (Exception ex)
            {
                m_bChangeText = false;
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (m_bChangeText)
                    return;
                TextBox txb = sender as TextBox;
                if (txb == null)
                    return;
                m_bChangeText = true;

                FormatText(txb);

                m_bChangeText = false;
            }
            catch (Exception ex)
            {
                m_bChangeText = false;
                MessageBox.Show(this, ex.Message, this.Text);
            }
        }

        private void FormatText(TextBox txb)
        {
            string text = txb.Text;
            bool needFormat = false;
            for (int i = 0, l = 0; i < text.Length; i++)
            {
                int j = 0;
                for (; j < s_arrSplit.Length && s_arrSplit[j] != text[i]; j++) ;
                if (j >= s_arrSplit.Length)
                {
                    l++;
                    if (l > 2)
                    {
                        needFormat = true;
                        break;
                    }
                }
                else
                    l = 0;
            }
            if (needFormat)
            {
                if (txb.SelectionLength > 0)
                {
                    int pos = int.MaxValue;
                    text = Util.FormatHexString(text, ref pos);
                    txb.Text = text;
                    txb.SelectionStart = text.Length;
                    txb.SelectionLength = 0;
                }
                else
                {
                    int pos = txb.SelectionStart;
                    txb.Text = Util.FormatHexString(text, ref pos);
                    txb.SelectionStart = pos;
                    txb.SelectionLength = 0;
                }
            }
        }
    }
}
