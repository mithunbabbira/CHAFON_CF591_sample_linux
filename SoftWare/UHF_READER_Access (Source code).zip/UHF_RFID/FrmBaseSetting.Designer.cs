namespace YYF100
{
    partial class FrmBaseSetting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.lblVersion = new System.Windows.Forms.Label();
            this.btnSaveParam = new System.Windows.Forms.Button();
            this.btnResetToFactory = new System.Windows.Forms.Button();
            this.btnRestart = new System.Windows.Forms.Button();
            this.btnGetVersion = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.ofd = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(136, 236);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(108, 35);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "关闭";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Location = new System.Drawing.Point(41, 61);
            this.lblVersion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(83, 45);
            this.lblVersion.TabIndex = 0;
            this.lblVersion.Text = "硬件版本：\r\n软件版本：\r\n  序列号：";
            // 
            // btnSaveParam
            // 
            this.btnSaveParam.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSaveParam.Location = new System.Drawing.Point(193, 176);
            this.btnSaveParam.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSaveParam.Name = "btnSaveParam";
            this.btnSaveParam.Size = new System.Drawing.Size(160, 35);
            this.btnSaveParam.TabIndex = 5;
            this.btnSaveParam.Text = "保存配置(&S)";
            this.btnSaveParam.UseVisualStyleBackColor = true;
            this.btnSaveParam.Click += new System.EventHandler(this.btnSaveParam_Click);
            // 
            // btnResetToFactory
            // 
            this.btnResetToFactory.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnResetToFactory.Location = new System.Drawing.Point(193, 131);
            this.btnResetToFactory.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnResetToFactory.Name = "btnResetToFactory";
            this.btnResetToFactory.Size = new System.Drawing.Size(160, 35);
            this.btnResetToFactory.TabIndex = 3;
            this.btnResetToFactory.Text = "恢复出厂(&E)";
            this.btnResetToFactory.UseVisualStyleBackColor = true;
            this.btnResetToFactory.Click += new System.EventHandler(this.btnResetToFactory_Click);
            // 
            // btnRestart
            // 
            this.btnRestart.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnRestart.Location = new System.Drawing.Point(25, 131);
            this.btnRestart.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRestart.Name = "btnRestart";
            this.btnRestart.Size = new System.Drawing.Size(160, 35);
            this.btnRestart.TabIndex = 2;
            this.btnRestart.Text = "重启系统(&R)";
            this.btnRestart.UseVisualStyleBackColor = true;
            this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
            // 
            // btnGetVersion
            // 
            this.btnGetVersion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetVersion.Location = new System.Drawing.Point(227, 16);
            this.btnGetVersion.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnGetVersion.Name = "btnGetVersion";
            this.btnGetVersion.Size = new System.Drawing.Size(127, 35);
            this.btnGetVersion.TabIndex = 1;
            this.btnGetVersion.Text = "获取版本(&V)";
            this.btnGetVersion.UseVisualStyleBackColor = true;
            this.btnGetVersion.Click += new System.EventHandler(this.btnGetVersion_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(8, 225);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 1);
            this.label1.TabIndex = 6;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnUpdate.Location = new System.Drawing.Point(25, 176);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(160, 35);
            this.btnUpdate.TabIndex = 4;
            this.btnUpdate.Text = "固件升级(&U)";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // ofd
            // 
            this.ofd.Filter = "*.bin|*.bin|*.*|*.*";
            // 
            // FrmBaseSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(379, 282);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.btnSaveParam);
            this.Controls.Add(this.btnResetToFactory);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnRestart);
            this.Controls.Add(this.btnGetVersion);
            this.Controls.Add(this.btnClose);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmBaseSetting";
            this.Text = "基本设置";
            this.Load += new System.EventHandler(this.FrmBaseSetting_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Button btnSaveParam;
        private System.Windows.Forms.Button btnResetToFactory;
        private System.Windows.Forms.Button btnRestart;
        private System.Windows.Forms.Button btnGetVersion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.OpenFileDialog ofd;


    }
}