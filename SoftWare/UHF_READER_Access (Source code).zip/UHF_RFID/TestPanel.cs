using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using UHF_RFID_Net;
using UHF_RFID.Properties;
using System.IO;
using System.Threading;
using System.Collections;

namespace YYF100
{
    public partial class TestPanel : UserControl
    {
        // 父窗口
        RFPanel m_owner = null;
        // 载波是否已经打开
        bool m_bCwOn = false;

        // 测试命令项列表
        TestCmdItem[] m_testCmds = TestCmdItem.EmptyArray;

        // 接收灵敏度测试结果
        Exception m_excTestSensi = null;
        // 接收灵敏度测试线程
        Thread m_thTestSensi = null;
        bool m_bError = false;

        public Protocol Protocol
        {
            get { return (m_owner == null ? Protocol.ISO_18000_63 : m_owner.Protocol); }
        }

        public Reader Reader
        {
            get { return (m_owner == null ? null : m_owner.Reader); }
        }
        public TestPanel()
        {
            InitializeComponent();
        }

        internal void SetOwner(RFPanel owner)
        {
            m_owner = owner;
        }

        public Hashtable ht
        {
            get { return (m_owner == null ? null : m_owner.HT); }
        }
        internal bool GetSettings()
        {
            Reader reader = this.Reader;
            if (reader == null || !reader.IsOpened)
                return false;
            m_bError = false;
            btnGetTemp_Click(this, EventArgs.Empty);
            if (m_bError)
                return false;
            return !m_bError;
        }


        private void WriteLog(MessageType type, string msg, Exception ex)
        {
            if (m_owner != null)
                m_owner.WriteLog(type, msg, ex);
        }

        private void btnFreqCfg_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                {
                    MessageBox.Show(this, (string)ht["Text2"], (string)ht["Text9"]);
                    return;
                }

                string freq = txbFreq.Text.Trim();
                if (freq.Length == 0)
                    throw new Exception("请输入'频率'");
                uint freq2;
                if (!uint.TryParse(freq, out freq2) || freq2 == 0)
                    throw new Exception("输入的'频率'值必须是大于0的整数");

                reader.Test.TestFreqCfg(freq2, 5000);
                WriteLog(MessageType.Info, "配置频率成功", null);
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, "配置频率失败，错误：", ex);
            }
        }

        private void btnBackWave_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                {
                    MessageBox.Show(this, (string)ht["Text2"], (string)ht["Text9"]);
                    return;
                }

                string count = txtTestCount.Text.Trim();
                if (count.Length == 0)
                    throw new Exception("请输入'测试次数'");
                uint count2;
                if (!uint.TryParse(count, out count2) || count2 == 0 || count2 > 49)
                    throw new Exception("输入的'测试次数'值必须是1~49（包括1和49）之间的整数");

                Int16 value = 0;
                value = reader.Test.TestBlPower((byte)count2, 5000);
                float waveLoss = ((float)value) / 10.0f;
                txbBackWaveLoss.Text = waveLoss.ToString();
                WriteLog(MessageType.Info, "测试回波损耗成功", null);
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, "测试回波损耗失败，错误：", ex);
            }
        }

        private void btnCw_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                {
                    MessageBox.Show(this, (string)ht["Text2"], (string)ht["Text9"]);
                    return;
                }

                reader.Test.SwitchRfPower(!m_bCwOn);
                m_bCwOn = !m_bCwOn;
                if (m_bCwOn)
                {
                    testbtnCw.Text = "关闭";
                    WriteLog(MessageType.Info, "打开载波成功", null);
                }
                else
                {
                    testbtnCw.Text = "开启";
                    WriteLog(MessageType.Info, "关闭载波成功", null);
                }

            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, "打开载波失败，错误：", ex);
            }
        }

        private void btnGetTemp_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                WriteLog(MessageType.Info, "开始获取阅读器温度信息", null);
                byte tempLimit;
                byte temp = reader.GetTemperature(out tempLimit);
                WriteLog(MessageType.Info, "阅读器温度信息获取成功", null);
                txbCurTemp.Text = ((sbyte)temp).ToString();
                txbTempLimit.Text = tempLimit.ToString();
            }
            catch (Exception ex)
            {
                m_bError = true;
                WriteLog(MessageType.Error, "温度信息获取失败：", ex);
                MessageBox.Show(this, "温度信息获取失败：" + ex.Message, this.Text);
            }
        }

        private void btnSetTemp_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                string temp = txbTempLimit.Text.Trim();
                if (temp.Length == 0)
                    throw new Exception("请输入'温度阈值'");
                int temp2 = Util.NumberFromString(temp);
                if (temp2 < 50 || temp2 > 90)
                    throw new Exception("输入的'温度阈值'值必须是50~90（包括50和90）之间的整数");

                Settings.Default.TempLimit = (byte)temp2;
                Settings.Default.Save();

                WriteLog(MessageType.Info, "开始设置阅读器温度信息", null);
                reader.SetTemperature((byte)temp2, 0);
                WriteLog(MessageType.Info, "阅读器温度信息设置成功", null);
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, "温度信息设置失败：", ex);
                MessageBox.Show(this, "温度信息设置失败：" + ex.Message, this.Text);
            }
        }

        private void TestPanel_Load(object sender, EventArgs e)
        {
            //try
            //{
            //    MultiLanguage.SetLanguage(this);
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(this, ex.Message, this.Text);
            //}
        }

        private void testbtnSetPowerdelta_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                WriteLog(MessageType.Info, "开始设置功率补偿", null);
                DeltaPara PowerDelta = new DeltaPara();
                PowerDelta.DELTAPOWER = (byte)Util.DecFromString(testtxbDeltapower.Text);
                PowerDelta.DELTA1 = (byte)Util.DecFromString(testtxbDelta1.Text);
                PowerDelta.DELTA2 = (byte)Util.DecFromString(testtxbDelta2.Text);

                reader.SetPowerDelta(PowerDelta);
                WriteLog(MessageType.Info, "设置天线功率成功", null);
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, "温度信息设置失败：", ex);
                MessageBox.Show(this, "温度信息设置失败：" + ex.Message, this.Text);
            }
        }


        private void testbtngetPowerdelta_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                WriteLog(MessageType.Info, "开始获取天线功率", null);
                DeltaPara PowerDelta = new DeltaPara();
                PowerDelta = reader.GetPowerDelta();

                testtxbDeltapower.Text = PowerDelta.DELTAPOWER.ToString("D");
                testtxbDelta1.Text = PowerDelta.DELTA1.ToString("D");
                testtxbDelta2.Text = PowerDelta.DELTA2.ToString("D");

                WriteLog(MessageType.Info, "天线功率成功", null);
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, "温度信息设置失败：", ex);
                MessageBox.Show(this, "温度信息设置失败：" + ex.Message, this.Text);
            }
        }
    }
}
