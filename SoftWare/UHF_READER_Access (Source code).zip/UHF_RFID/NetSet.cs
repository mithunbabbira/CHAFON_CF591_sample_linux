using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using UHF_RFID_Net;
using System.Net;
using System.Text.RegularExpressions;

namespace YYF100
{
    public partial class NetSet : UserControl
    {

        RFPanel m_owner = null;


        internal void SetOwner(RFPanel owner)
        {
            m_owner = owner;
        }

        public Hashtable ht
        {
            get { return (m_owner == null ? null : m_owner.HT); }
        }

        public Reader Reader
        {
            get { return (m_owner == null ? null : m_owner.Reader); }
        }

        public NetSet()
        {
            InitializeComponent();
        }


        private void WriteLog(MessageType type, string msg, Exception ex)
        {
            if (m_owner != null)
                m_owner.WriteLog(type, msg, ex);
        }


        private void btnGetNetInfo_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                NetInfo Info = reader.GetNetInfo();

                WriteLog(MessageType.Info, (string)ht["Text105"], null);
                txbNetIPAddr.Text = (new System.Net.IPAddress(Info.device_ip)).ToString();
                txbGateway.Text = (new System.Net.IPAddress(Info.device_GateWay)).ToString();
                txbNetmask.Text = (new System.Net.IPAddress(Info.device_netmask)).ToString();
                txbNetMACAddr.Text = Util.HexArrayToString(Info.device_mac).Trim().Replace(" ", "");
                txbNETPort.Text =Info.device_port.ToString("D");
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text106"], ex);
                MessageBox.Show(this, (string)ht["Text106"] + ex.Message, this.Text);
            }
        }

        private void btnSetNetInfo_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                NetInfo info;

                string ip = txbNetIPAddr.Text.Trim();
                if (ip.Length == 0)
                {
                    MessageBox.Show(this, (string)ht["Text107"], this.Text);
                    return;
                }
                System.Net.IPAddress ip2;
                if (!System.Net.IPAddress.TryParse(ip, out ip2))
                {
                    MessageBox.Show(this, (string)ht["Text108"], this.Text);
                    return;
                }

                string gateway = txbGateway.Text.Trim();
                if (gateway.Length == 0)
                {
                    MessageBox.Show(this, (string)ht["Text107"], this.Text);
                    return;
                }
                System.Net.IPAddress gateway2;
                if (!System.Net.IPAddress.TryParse(gateway, out gateway2))
                {
                    MessageBox.Show(this, (string)ht["Text108"], this.Text);
                    return;
                }

                string Netmask = txbNetmask.Text.Trim();
                if (gateway.Length == 0)
                {
                    MessageBox.Show(this, (string)ht["Text107"], this.Text);
                    return;
                }
                System.Net.IPAddress Netmask2;
                if (!System.Net.IPAddress.TryParse(Netmask, out Netmask2))
                {
                    MessageBox.Show(this, (string)ht["Text108"], this.Text);
                    return;
                }

                string mac = txbNetMACAddr.Text;
                if (mac.Length == 0)
                {
                    MessageBox.Show(this, (string)ht["Text109"], this.Text);
                    return;
                }
                string port = txbNETPort.Text;
                if (port.Length == 0)
                {
                    MessageBox.Show(this, (string)ht["Text110"], this.Text);
                    return;
                }
                info.device_ip = ip2.Address;
                info.device_mac = Util.HexArrayFromString(txbNetMACAddr.Text.Replace("-",""));
                info.device_port = (ushort)Util.NumberFromString(txbNETPort.Text);

                info.device_netmask = Netmask2.Address;
                info.device_GateWay = gateway2.Address;

                reader.SetNetInfo(info);
                WriteLog(MessageType.Info, (string)ht["Text111"], null);
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text112"], ex);
                MessageBox.Show(this, (string)ht["Text112"] + ex.Message, this.Text);
            }
        }

        private void txbNetMACAddr_TextChanged(object sender, EventArgs e)
        {

            TextBox t = (TextBox)sender;//定义t为文本框本身
            StringBuilder sb = new StringBuilder();//sb为可变字符串
            int Selection = t.SelectionStart;//整型，选定的文本起始点
            char s = '-';//需要加入的字符

            string str = t.Text.Replace(s.ToString(), "");//用空格替换掉"-"
            for (int i = 1; i <= str.Length; i++)
            {
                sb.Append(str[i - 1]);//末尾加入前一个字符
                if ((i != 0 && i % 2 == 0))//i不为零且为偶数时
                {
                    if (i == str.Length) continue;//i为结尾时退出循环，到比较条件
                    sb.Append(s);//添加"-"
                    Selection++;//选定的文本起始点加1
                }
            }
            Selection = Selection - t.Text.Split(s).Length + 1;//选定的文本起如点，光标移到最后
            t.Text = sb.ToString();//文本框的字符串改为sb
            t.SelectionStart = Selection < 0 ? 0 : Selection;//如果选定的文本起始点小于0,则为0，否则的话为选定的文本起始点
        }

        private void btnGetRemoteNetInfo_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                RemoteNetInfo Info = reader.GetRemoteNetInfo();

                WriteLog(MessageType.Info, (string)ht["Text105"], null);
                txbRemoteNetIPAddr.Text = (new System.Net.IPAddress(Info.Remote_ip)).ToString();
                txbRemoteNETPort.Text = Info.remote_port.ToString("D");
                txbHearttime.Text = Info.HEARTTIME.ToString("D");

                if (Info.ENABLE == 1)
                {
                    cbxRemoteNetEn.Checked = true;
                }
                else
                {
                    cbxRemoteNetEn.Checked = false;
                }
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text106"], ex);
                MessageBox.Show(this, (string)ht["Text106"] + ex.Message, this.Text);
            }
        }

        private void btnSetRemoteNetInfo_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);


                string ip = txbRemoteNetIPAddr.Text.Trim();
                if (ip.Length == 0)
                {
                    MessageBox.Show(this, (string)ht["Text107"], this.Text);
                    return;
                }
                System.Net.IPAddress ip2;
                if (!System.Net.IPAddress.TryParse(ip, out ip2))
                {
                    MessageBox.Show(this, (string)ht["Text108"], this.Text);
                    return;
                }
                string port = txbRemoteNETPort.Text;
                if (port.Length == 0)
                {
                    MessageBox.Show(this, (string)ht["Text110"], this.Text);
                    return;
                }

                RemoteNetInfo info = new RemoteNetInfo();
                info.Remote_ip = ip2.Address;
                info.remote_port = (ushort)Util.NumberFromString(txbRemoteNETPort.Text);
                info.HEARTTIME = (byte)Util.NumberFromString(txbHearttime.Text);
                if (cbxRemoteNetEn.Checked)
                {
                    info.ENABLE = 1;
                }
                else
                {
                    info.ENABLE = 0;
                }


                reader.SetRemoteNetInfo(info);
                WriteLog(MessageType.Info, (string)ht["Text111"], null);
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text112"], ex);
                MessageBox.Show(this, (string)ht["Text112"] + ex.Message, this.Text);
            }
        }

        private void NetSet_Load(object sender, EventArgs e)
        {
            cbxWIFIMode.SelectedIndex = 1;   //默认模式选择串口
            if (Reader.Devicetpye == 4)
            {
                netgroupBox3.Visible = true; //显示wifi
            }
        }
        private bool isIP(String IpStr)
        {
            bool IsIpResult = false;
            try
            {
                IPAddress ipAd = IPAddress.Parse(IpStr);
                IsIpResult = true;
            }
            catch
            {
                IsIpResult = false;
            }
            return IsIpResult;
        }

        //private void txt(void)
        //{
        //    bool blnTest = false;
        //        bool _Result = true;

        //        Regex regex = new Regex("^[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}$");
        //        blnTest = regex.IsMatch(txtbox_ServerIP.Text);
        //    if (blnTest == true)
        //    {
        //        string[] strTemp = this.txtbox_ServerIP.Text.Split(new char[] { ‘.’ }); // textBox1.Text.Split(new char[] { ‘.’ });
        //        for (int i = 0; i<strTemp.Length; i++)
        //        {
        //            if (Convert.ToInt32(strTemp[i]) > 255)
        //            { //大于255则提示，不符合IP格式
        //                MessageBox.Show("不符合IP格式");
        //                _Result = false;
        //                txtbox_ServerIP.Text = "";
        //            }
        //}
        //    }
        //    else
        //    {
        //    //输入非数字则提示，不符合IP格式
        //    MessageBox.Show("不符合IP格式");
        //    _Result = false;
        //    txtbox_ServerIP.Text = "";
        //    }
            


        private void txbNetIPAddr_TextChanged(object sender, EventArgs e)
        {

            //if (isIP(txbNetIPAddr.Text))
            //{

            //}
            //else
            //{
            //    txbNetIPAddr.Clear();
            //}

            //bool blnTest = false;
            //bool _Result = true;

            //Regex regex = new Regex("^[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}$");
            //blnTest = regex.IsMatch(txbNetIPAddr.Text);
            //if (blnTest == true)
            //{
            //    string[] strTemp = this.txbNetIPAddr.Text.Split(new char[] { '.' }); // textBox1.Text.Split(new char[] { ‘.’ });
            //    for (int i = 0; i < strTemp.Length; i++)
            //    {
            //        if (Convert.ToInt32(strTemp[i]) > 255)
            //        { //大于255则提示，不符合IP格式
            //            MessageBox.Show("不符合IP格式");
            //            _Result = false;
            //            txbNetIPAddr.Text = "";
            //        }
            //    }
            //}
        }

        private void btnSetWIFIInfo_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);


                string ip = txbWIFIIPAddr.Text.Trim();
                if (ip.Length == 0)
                {
                    MessageBox.Show(this, (string)ht["Text107"], this.Text);
                    return;
                }
                System.Net.IPAddress ip2;
                if (!System.Net.IPAddress.TryParse(ip, out ip2))
                {
                    MessageBox.Show(this, (string)ht["Text108"], this.Text);
                    return;
                }
                string port = txbWIFIPORT.Text;
                if (port.Length == 0)
                {
                    MessageBox.Show(this, (string)ht["Text110"], this.Text);
                    return;
                }

                wifiPara info = new wifiPara();
                info.wifi_ip = ip2.Address;
                info.wifi_port = (ushort)Util.NumberFromString(txbWIFIPORT.Text);
                if (cbxWIFItEn.Checked)
                {
                    info.WiFiEn |= 0x01;
                }
                else
                {
                    info.WiFiEn &= 0xFE;
                }

                if (cbxWIFIMode.SelectedIndex == 0)    // smartconfig,
                {
                    info.WiFiEn |= 0x02;
                    //info.WiFiEn &= 0xFD;              // 写死成串口输出
                }
                else
                {
                    info.WiFiEn |= 0x02;
                }

                info.Ssid = Encoding.ASCII.GetBytes(txbWIFISSID.Text.PadRight(32,'\0'));
                info.Password = Encoding.ASCII.GetBytes(txbWIFIPASSWORD.Text.PadRight(64,'\0'));

                reader.SetwifiPara(info);
                WriteLog(MessageType.Info, (string)ht["Text111"], null);
            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text112"], ex);
                MessageBox.Show(this, (string)ht["Text112"] + ex.Message, this.Text);
            }
        }

        private void btnGetWIFIInfo_Click(object sender, EventArgs e)
        {
            try
            {
                Reader reader = this.Reader;
                if (reader == null)
                    throw new Exception((string)ht["Text2"]);

                wifiPara Info = reader.GetwifiPara();

                WriteLog(MessageType.Info, (string)ht["Text105"], null);
                txbWIFISSID.Text = Encoding.ASCII.GetString(Info.Ssid).Trim('\0');
                txbWIFIPASSWORD.Text = Encoding.ASCII.GetString(Info.Password).Trim('\0');
                txbWIFIIPAddr.Text = (new System.Net.IPAddress(Info.wifi_ip)).ToString();
                txbWIFIPORT.Text = Info.wifi_port.ToString("D");
                if ((Info.WiFiEn & 0x01) == 1)         // 使能
                {
                    cbxWIFItEn.Checked = true;
                }
                else
                {
                    cbxWIFItEn.Checked = false;
                }

                if ((Info.WiFiEn & 0x02) == 2)          //模式选择
                {
                    cbxWIFIMode.SelectedIndex = 1;
                }
                else
                {
                    //cbxWIFIMode.SelectedIndex = 0;
                    cbxWIFIMode.SelectedIndex = 1;    //写死成串口控制
                }

            }
            catch (Exception ex)
            {
                WriteLog(MessageType.Error, (string)ht["Text106"], ex);
                MessageBox.Show(this, (string)ht["Text106"] + ex.Message, this.Text);
            }
        }

        private void cbxWIFIMode_SelectedValueChanged(object sender, EventArgs e)
        {
            if (cbxWIFIMode.SelectedIndex == 0)  //smartconfig
            {
                txbWIFISSID.Enabled = false;
                txbWIFIPASSWORD.Enabled = false;
            }
            else
            {
                txbWIFISSID.Enabled = true;
                txbWIFIPASSWORD.Enabled = true;
            }
        }
    }
}
