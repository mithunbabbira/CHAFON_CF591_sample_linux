﻿using System;
using System.Collections.Generic;
using System.Text;

namespace YYF100
{
    public class TestCmdItem
    {
        public static readonly TestCmdItem[] EmptyArray = new TestCmdItem[0];

        // 命令名称
        private string m_strName = string.Empty;
        // 参数是否是ASCII码类型
        private bool m_bIsAscii = false;
        // 命令码
        private byte m_btCmd = 0;
        // 命令参数
        private byte[] m_arrParam = Util.EmptyArray;
        // 当前命令项是否已添加至 '测试命令项列表' 中
        private bool m_bAdded = false;

        /// <summary>
        /// 命令名称
        /// </summary>
        public string Name
        {
            get { return m_strName; }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");
                string value2 = value.Trim();
                if (value2.Length == 0)
                    throw new ArgumentException("命令名称不能为空", "value");
                m_strName = value2;
            }
        }

        /// <summary>
        /// 命令码
        /// </summary>
        public byte Cmd
        {
            get { return m_btCmd; }
            set { m_btCmd = value; }
        }

        /// <summary>
        /// 参数是否是ASCII码类型
        /// </summary>
        public bool IsAscii
        {
            get { return m_bIsAscii; }
            set { m_bIsAscii = value; }
        }

        /// <summary>
        /// 命令参数
        /// </summary>
        /*public byte[] Param
        {
            get { return m_arrParam; }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");
                m_arrParam = value;
            }
        }*/

        public string ParamStr
        {
            get { return m_bIsAscii ? Encoding.Default.GetString(m_arrParam) : Util.HexArrayToString(m_arrParam); }
        }

        /// <summary>
        /// 当前命令项是否已添加至 '测试命令项列表' 中
        /// </summary>
        public bool IsAdded
        {
            get { return m_bAdded; }
            set { m_bAdded = value; }
        }

        public TestCmdItem()
        {
        }

        public TestCmdItem(string strName, byte btCmd, bool bIsAscii, byte[] param)
        {
            if (strName == null)
                throw new ArgumentNullException("strName");
            if (param == null)
                throw new ArgumentNullException("param");
            string strName2 = strName.Trim();
            if (strName2.Length == 0)
                throw new ArgumentException("命令名称不能为空", "strName");
            m_bIsAscii = bIsAscii;
            m_strName = strName2;
            m_btCmd = btCmd;
            m_arrParam = param;
        }

        public TestCmdItem(string strName, byte btCmd, byte[] param)
        {
            if (strName == null)
                throw new ArgumentNullException("strName");
            if (param == null)
                throw new ArgumentNullException("param");
            string strName2 = strName.Trim();
            if (strName2.Length == 0)
                throw new ArgumentException("命令名称不能为空", "strName");
            m_bIsAscii = strName2.EndsWith("(A)");
            m_strName = m_bIsAscii || strName2.EndsWith("(H)") ? strName2.Substring(0, strName2.Length - 3) : strName2;
            m_btCmd = btCmd;
            m_arrParam = param;
        }

        public void SetParam(byte[] param)
        {
            if (param == null)
                throw new ArgumentNullException("param");
            m_arrParam = param;
        }

        public override string ToString()
        {
            if (m_bIsAscii)
                return m_strName + "(A) - 0x" + m_btCmd.ToString("X02") + " - " + Encoding.Default.GetString(m_arrParam);
            return m_strName + "(H) - 0x" + m_btCmd.ToString("X02") + " - " + Util.HexArrayToString(m_arrParam);
        }
    }
}
