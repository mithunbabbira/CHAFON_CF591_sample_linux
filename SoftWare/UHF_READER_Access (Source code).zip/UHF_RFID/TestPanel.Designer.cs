namespace YYF100
{
    partial class TestPanel
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.testgroupBox1 = new System.Windows.Forms.GroupBox();
            this.testlabel2 = new System.Windows.Forms.Label();
            this.testbtnFreqCfg = new System.Windows.Forms.Button();
            this.testlabel1 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txbFreq = new System.Windows.Forms.TextBox();
            this.testgroupBox3 = new System.Windows.Forms.GroupBox();
            this.testlabel5 = new System.Windows.Forms.Label();
            this.testbtnCw = new System.Windows.Forms.Button();
            this.testgroupBox4 = new System.Windows.Forms.GroupBox();
            this.testlabel6 = new System.Windows.Forms.Label();
            this.testbtnSetTemp = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txbTempLimit = new System.Windows.Forms.TextBox();
            this.testlabel8 = new System.Windows.Forms.Label();
            this.testlabel7 = new System.Windows.Forms.Label();
            this.testbtnGetTemp = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txbCurTemp = new System.Windows.Forms.TextBox();
            this.testgroupBox2 = new System.Windows.Forms.GroupBox();
            this.testlabel3 = new System.Windows.Forms.Label();
            this.txtTestCount = new System.Windows.Forms.TextBox();
            this.testbtnBackWave = new System.Windows.Forms.Button();
            this.testlabel4 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txbBackWaveLoss = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.testtxbDeltapower = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.testtxbDelta2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.testbtnSetPowerdelta = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.testbtngetPowerdelta = new System.Windows.Forms.Button();
            this.testtxbDelta1 = new System.Windows.Forms.TextBox();
            this.testgroupBox1.SuspendLayout();
            this.testgroupBox3.SuspendLayout();
            this.testgroupBox4.SuspendLayout();
            this.testgroupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // testgroupBox1
            // 
            this.testgroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.testgroupBox1.Controls.Add(this.testlabel2);
            this.testgroupBox1.Controls.Add(this.testbtnFreqCfg);
            this.testgroupBox1.Controls.Add(this.testlabel1);
            this.testgroupBox1.Controls.Add(this.label20);
            this.testgroupBox1.Controls.Add(this.txbFreq);
            this.testgroupBox1.Location = new System.Drawing.Point(3, 3);
            this.testgroupBox1.Name = "testgroupBox1";
            this.testgroupBox1.Size = new System.Drawing.Size(766, 54);
            this.testgroupBox1.TabIndex = 1;
            this.testgroupBox1.TabStop = false;
            this.testgroupBox1.Text = "频率测试";
            // 
            // testlabel2
            // 
            this.testlabel2.AutoSize = true;
            this.testlabel2.Location = new System.Drawing.Point(251, 27);
            this.testlabel2.Name = "testlabel2";
            this.testlabel2.Size = new System.Drawing.Size(173, 12);
            this.testlabel2.TabIndex = 4;
            this.testlabel2.Text = "在以下测试中测试频率为可选项";
            // 
            // testbtnFreqCfg
            // 
            this.testbtnFreqCfg.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.testbtnFreqCfg.Location = new System.Drawing.Point(682, 20);
            this.testbtnFreqCfg.Name = "testbtnFreqCfg";
            this.testbtnFreqCfg.Size = new System.Drawing.Size(75, 23);
            this.testbtnFreqCfg.TabIndex = 3;
            this.testbtnFreqCfg.Text = "设置";
            this.testbtnFreqCfg.UseVisualStyleBackColor = true;
            this.testbtnFreqCfg.Click += new System.EventHandler(this.btnFreqCfg_Click);
            // 
            // testlabel1
            // 
            this.testlabel1.AutoSize = true;
            this.testlabel1.Location = new System.Drawing.Point(17, 27);
            this.testlabel1.Name = "testlabel1";
            this.testlabel1.Size = new System.Drawing.Size(65, 12);
            this.testlabel1.TabIndex = 0;
            this.testlabel1.Text = "测试频率：";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(196, 27);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(23, 12);
            this.label20.TabIndex = 2;
            this.label20.Text = "kHz";
            // 
            // txbFreq
            // 
            this.txbFreq.Location = new System.Drawing.Point(115, 24);
            this.txbFreq.Name = "txbFreq";
            this.txbFreq.Size = new System.Drawing.Size(75, 21);
            this.txbFreq.TabIndex = 1;
            this.txbFreq.Text = "920125";
            // 
            // testgroupBox3
            // 
            this.testgroupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.testgroupBox3.Controls.Add(this.testlabel5);
            this.testgroupBox3.Controls.Add(this.testbtnCw);
            this.testgroupBox3.Location = new System.Drawing.Point(3, 134);
            this.testgroupBox3.Name = "testgroupBox3";
            this.testgroupBox3.Size = new System.Drawing.Size(766, 61);
            this.testgroupBox3.TabIndex = 6;
            this.testgroupBox3.TabStop = false;
            this.testgroupBox3.Text = "开启载波";
            // 
            // testlabel5
            // 
            this.testlabel5.AutoSize = true;
            this.testlabel5.Location = new System.Drawing.Point(17, 27);
            this.testlabel5.Name = "testlabel5";
            this.testlabel5.Size = new System.Drawing.Size(77, 12);
            this.testlabel5.TabIndex = 0;
            this.testlabel5.Text = "说明：开启CW";
            // 
            // testbtnCw
            // 
            this.testbtnCw.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.testbtnCw.Location = new System.Drawing.Point(682, 20);
            this.testbtnCw.Name = "testbtnCw";
            this.testbtnCw.Size = new System.Drawing.Size(75, 23);
            this.testbtnCw.TabIndex = 1;
            this.testbtnCw.Text = "开启";
            this.testbtnCw.UseVisualStyleBackColor = true;
            this.testbtnCw.Click += new System.EventHandler(this.btnCw_Click);
            // 
            // testgroupBox4
            // 
            this.testgroupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.testgroupBox4.Controls.Add(this.testlabel6);
            this.testgroupBox4.Controls.Add(this.testbtnSetTemp);
            this.testgroupBox4.Controls.Add(this.label4);
            this.testgroupBox4.Controls.Add(this.txbTempLimit);
            this.testgroupBox4.Controls.Add(this.testlabel8);
            this.testgroupBox4.Controls.Add(this.testlabel7);
            this.testgroupBox4.Controls.Add(this.testbtnGetTemp);
            this.testgroupBox4.Controls.Add(this.label5);
            this.testgroupBox4.Controls.Add(this.txbCurTemp);
            this.testgroupBox4.Location = new System.Drawing.Point(3, 201);
            this.testgroupBox4.Name = "testgroupBox4";
            this.testgroupBox4.Size = new System.Drawing.Size(766, 97);
            this.testgroupBox4.TabIndex = 7;
            this.testgroupBox4.TabStop = false;
            this.testgroupBox4.Text = "工作温度监控";
            // 
            // testlabel6
            // 
            this.testlabel6.AutoSize = true;
            this.testlabel6.Location = new System.Drawing.Point(14, 27);
            this.testlabel6.Name = "testlabel6";
            this.testlabel6.Size = new System.Drawing.Size(65, 12);
            this.testlabel6.TabIndex = 9;
            this.testlabel6.Text = "温度阈值：";
            // 
            // testbtnSetTemp
            // 
            this.testbtnSetTemp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.testbtnSetTemp.Location = new System.Drawing.Point(682, 22);
            this.testbtnSetTemp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.testbtnSetTemp.Name = "testbtnSetTemp";
            this.testbtnSetTemp.Size = new System.Drawing.Size(75, 23);
            this.testbtnSetTemp.TabIndex = 13;
            this.testbtnSetTemp.Text = "设置(&H)";
            this.testbtnSetTemp.UseVisualStyleBackColor = true;
            this.testbtnSetTemp.Click += new System.EventHandler(this.btnSetTemp_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(161, 27);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(17, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "℃";
            // 
            // txbTempLimit
            // 
            this.txbTempLimit.Location = new System.Drawing.Point(85, 24);
            this.txbTempLimit.Name = "txbTempLimit";
            this.txbTempLimit.Size = new System.Drawing.Size(70, 21);
            this.txbTempLimit.TabIndex = 10;
            // 
            // testlabel8
            // 
            this.testlabel8.AutoSize = true;
            this.testlabel8.Location = new System.Drawing.Point(195, 27);
            this.testlabel8.Name = "testlabel8";
            this.testlabel8.Size = new System.Drawing.Size(281, 12);
            this.testlabel8.TabIndex = 12;
            this.testlabel8.Text = "工作温度到达设定值后，自动休眠冷却后继续工作。";
            // 
            // testlabel7
            // 
            this.testlabel7.AutoSize = true;
            this.testlabel7.Location = new System.Drawing.Point(14, 66);
            this.testlabel7.Name = "testlabel7";
            this.testlabel7.Size = new System.Drawing.Size(65, 12);
            this.testlabel7.TabIndex = 4;
            this.testlabel7.Text = "当前温度：";
            // 
            // testbtnGetTemp
            // 
            this.testbtnGetTemp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.testbtnGetTemp.Location = new System.Drawing.Point(682, 61);
            this.testbtnGetTemp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.testbtnGetTemp.Name = "testbtnGetTemp";
            this.testbtnGetTemp.Size = new System.Drawing.Size(75, 23);
            this.testbtnGetTemp.TabIndex = 8;
            this.testbtnGetTemp.Text = "获取(&G)";
            this.testbtnGetTemp.UseVisualStyleBackColor = true;
            this.testbtnGetTemp.Click += new System.EventHandler(this.btnGetTemp_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(161, 66);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 12);
            this.label5.TabIndex = 6;
            this.label5.Text = "℃";
            // 
            // txbCurTemp
            // 
            this.txbCurTemp.BackColor = System.Drawing.SystemColors.Window;
            this.txbCurTemp.Location = new System.Drawing.Point(85, 62);
            this.txbCurTemp.Name = "txbCurTemp";
            this.txbCurTemp.ReadOnly = true;
            this.txbCurTemp.Size = new System.Drawing.Size(70, 21);
            this.txbCurTemp.TabIndex = 5;
            // 
            // testgroupBox2
            // 
            this.testgroupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.testgroupBox2.Controls.Add(this.testlabel3);
            this.testgroupBox2.Controls.Add(this.txtTestCount);
            this.testgroupBox2.Controls.Add(this.testbtnBackWave);
            this.testgroupBox2.Controls.Add(this.testlabel4);
            this.testgroupBox2.Controls.Add(this.label12);
            this.testgroupBox2.Controls.Add(this.txbBackWaveLoss);
            this.testgroupBox2.Location = new System.Drawing.Point(3, 69);
            this.testgroupBox2.Name = "testgroupBox2";
            this.testgroupBox2.Size = new System.Drawing.Size(766, 56);
            this.testgroupBox2.TabIndex = 8;
            this.testgroupBox2.TabStop = false;
            this.testgroupBox2.Text = "回波测试";
            // 
            // testlabel3
            // 
            this.testlabel3.AutoSize = true;
            this.testlabel3.Location = new System.Drawing.Point(17, 27);
            this.testlabel3.Name = "testlabel3";
            this.testlabel3.Size = new System.Drawing.Size(65, 12);
            this.testlabel3.TabIndex = 12;
            this.testlabel3.Text = "测试次数：";
            // 
            // txtTestCount
            // 
            this.txtTestCount.Location = new System.Drawing.Point(115, 23);
            this.txtTestCount.Name = "txtTestCount";
            this.txtTestCount.Size = new System.Drawing.Size(48, 21);
            this.txtTestCount.TabIndex = 13;
            this.txtTestCount.Text = "10";
            // 
            // testbtnBackWave
            // 
            this.testbtnBackWave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.testbtnBackWave.Location = new System.Drawing.Point(679, 20);
            this.testbtnBackWave.Name = "testbtnBackWave";
            this.testbtnBackWave.Size = new System.Drawing.Size(75, 23);
            this.testbtnBackWave.TabIndex = 0;
            this.testbtnBackWave.Text = "回波测试";
            this.testbtnBackWave.UseVisualStyleBackColor = true;
            this.testbtnBackWave.Click += new System.EventHandler(this.btnBackWave_Click);
            // 
            // testlabel4
            // 
            this.testlabel4.AutoSize = true;
            this.testlabel4.Location = new System.Drawing.Point(224, 27);
            this.testlabel4.Name = "testlabel4";
            this.testlabel4.Size = new System.Drawing.Size(65, 12);
            this.testlabel4.TabIndex = 9;
            this.testlabel4.Text = "回波损耗：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(394, 27);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 12);
            this.label12.TabIndex = 11;
            this.label12.Text = "dB";
            // 
            // txbBackWaveLoss
            // 
            this.txbBackWaveLoss.Location = new System.Drawing.Point(327, 23);
            this.txbBackWaveLoss.Name = "txbBackWaveLoss";
            this.txbBackWaveLoss.ReadOnly = true;
            this.txbBackWaveLoss.Size = new System.Drawing.Size(61, 21);
            this.txbBackWaveLoss.TabIndex = 10;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.testtxbDeltapower);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.testtxbDelta2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.testbtnSetPowerdelta);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.testbtngetPowerdelta);
            this.groupBox1.Controls.Add(this.testtxbDelta1);
            this.groupBox1.Location = new System.Drawing.Point(3, 314);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(766, 81);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "功率补偿";
            // 
            // testtxbDeltapower
            // 
            this.testtxbDeltapower.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.testtxbDeltapower.FormattingEnabled = true;
            this.testtxbDeltapower.Items.AddRange(new object[] {
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33"});
            this.testtxbDeltapower.Location = new System.Drawing.Point(97, 33);
            this.testtxbDeltapower.Name = "testtxbDeltapower";
            this.testtxbDeltapower.Size = new System.Drawing.Size(81, 20);
            this.testtxbDeltapower.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(284, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 14;
            this.label3.Text = "DeltaPara2：";
            // 
            // testtxbDelta2
            // 
            this.testtxbDelta2.BackColor = System.Drawing.SystemColors.Window;
            this.testtxbDelta2.Location = new System.Drawing.Point(367, 47);
            this.testtxbDelta2.Name = "testtxbDelta2";
            this.testtxbDelta2.Size = new System.Drawing.Size(70, 21);
            this.testtxbDelta2.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 9;
            this.label1.Text = "分段功率值：";
            // 
            // testbtnSetPowerdelta
            // 
            this.testbtnSetPowerdelta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.testbtnSetPowerdelta.Location = new System.Drawing.Point(682, 16);
            this.testbtnSetPowerdelta.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.testbtnSetPowerdelta.Name = "testbtnSetPowerdelta";
            this.testbtnSetPowerdelta.Size = new System.Drawing.Size(75, 23);
            this.testbtnSetPowerdelta.TabIndex = 13;
            this.testbtnSetPowerdelta.Text = "设置(&H)";
            this.testbtnSetPowerdelta.UseVisualStyleBackColor = true;
            this.testbtnSetPowerdelta.Click += new System.EventHandler(this.testbtnSetPowerdelta_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(184, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 12);
            this.label2.TabIndex = 11;
            this.label2.Text = "dBm";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(284, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 12);
            this.label6.TabIndex = 4;
            this.label6.Text = "DeltaPara1：";
            // 
            // testbtngetPowerdelta
            // 
            this.testbtngetPowerdelta.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.testbtngetPowerdelta.Location = new System.Drawing.Point(682, 44);
            this.testbtngetPowerdelta.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.testbtngetPowerdelta.Name = "testbtngetPowerdelta";
            this.testbtngetPowerdelta.Size = new System.Drawing.Size(75, 23);
            this.testbtngetPowerdelta.TabIndex = 8;
            this.testbtngetPowerdelta.Text = "获取(&G)";
            this.testbtngetPowerdelta.UseVisualStyleBackColor = true;
            this.testbtngetPowerdelta.Click += new System.EventHandler(this.testbtngetPowerdelta_Click);
            // 
            // testtxbDelta1
            // 
            this.testtxbDelta1.BackColor = System.Drawing.SystemColors.Window;
            this.testtxbDelta1.Location = new System.Drawing.Point(367, 19);
            this.testtxbDelta1.Name = "testtxbDelta1";
            this.testtxbDelta1.Size = new System.Drawing.Size(70, 21);
            this.testtxbDelta1.TabIndex = 5;
            // 
            // TestPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.testgroupBox2);
            this.Controls.Add(this.testgroupBox4);
            this.Controls.Add(this.testgroupBox3);
            this.Controls.Add(this.testgroupBox1);
            this.Name = "TestPanel";
            this.Size = new System.Drawing.Size(772, 442);
            this.Load += new System.EventHandler(this.TestPanel_Load);
            this.testgroupBox1.ResumeLayout(false);
            this.testgroupBox1.PerformLayout();
            this.testgroupBox3.ResumeLayout(false);
            this.testgroupBox3.PerformLayout();
            this.testgroupBox4.ResumeLayout(false);
            this.testgroupBox4.PerformLayout();
            this.testgroupBox2.ResumeLayout(false);
            this.testgroupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox testgroupBox1;
        private System.Windows.Forms.Label testlabel2;
        private System.Windows.Forms.Button testbtnFreqCfg;
        private System.Windows.Forms.Label testlabel1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txbFreq;
        private System.Windows.Forms.GroupBox testgroupBox3;
        private System.Windows.Forms.Label testlabel5;
        private System.Windows.Forms.Button testbtnCw;
        private System.Windows.Forms.GroupBox testgroupBox4;
        private System.Windows.Forms.Label testlabel7;
        private System.Windows.Forms.Button testbtnGetTemp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txbCurTemp;
        private System.Windows.Forms.GroupBox testgroupBox2;
        private System.Windows.Forms.Label testlabel3;
        private System.Windows.Forms.TextBox txtTestCount;
        private System.Windows.Forms.Button testbtnBackWave;
        private System.Windows.Forms.Label testlabel4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txbBackWaveLoss;
        private System.Windows.Forms.Label testlabel6;
        private System.Windows.Forms.Button testbtnSetTemp;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txbTempLimit;
        private System.Windows.Forms.Label testlabel8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox testtxbDeltapower;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox testtxbDelta2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button testbtnSetPowerdelta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button testbtngetPowerdelta;
        private System.Windows.Forms.TextBox testtxbDelta1;
    }
}
