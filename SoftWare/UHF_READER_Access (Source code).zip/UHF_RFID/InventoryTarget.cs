using System;
using System.Collections.Generic;
using System.Text;
using UHF_RFID_Net;

namespace YYF100
{
    public enum InventoryTarget
    {
        A,
        B
    }

    public class InventoryTargetItem
    {
        public static readonly InventoryTargetItem[] Options = new InventoryTargetItem[] {
            new InventoryTargetItem(InventoryTarget.A),
            new InventoryTargetItem(InventoryTarget.B) };

        private static Protocol m_proto = Protocol.ISO_18000_63;

        public static Protocol Protocol
        {
            get { return m_proto; }
            set { m_proto = value; }
        }

        InventoryTarget m_value;

        public InventoryTarget Value
        {
            get { return m_value; }
        }

        public InventoryTargetItem(InventoryTarget value)
        {
            m_value = value;
        }

        public override string ToString()
        {
            return InventoryTargetToString(m_value);
        }

        public static string InventoryTargetToString(InventoryTarget value)
        {
            if (m_proto == Protocol.ISO_18000_63)
            {
                switch (value)
                {
                    case InventoryTarget.A:
                        return "A";
                    case InventoryTarget.B:
                        return "B";
                }
            }
            else
            {
                switch (value)
                {
                    case InventoryTarget.A:
                        return "0";
                    case InventoryTarget.B:
                        return "1";
                }
            }
            return "未定义值：0x" + ((int)value).ToString("X2");
        }
    }
}
